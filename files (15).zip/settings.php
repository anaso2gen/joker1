<?php
/**
 * ملف إعدادات النظام العامة
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

// إعدادات قاعدة البيانات (تم تعريفها مسبقاً في config.php)

// إعدادات VdoCipher الإضافية
define('VDOCIPHER_WEBHOOK_SECRET', 'your_webhook_secret_here');
define('VDOCIPHER_PLAYER_THEME', '9ae8bbe8dd964ddc9bdb932cca1cb59a');

// إعدادات الأمان
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 دقيقة
define('PASSWORD_MIN_LENGTH', 8);
define('REQUIRE_EMAIL_VERIFICATION', false);

// إعدادات الجلسات
define('SESSION_TIMEOUT', 7200); // ساعتان
define('REMEMBER_ME_DURATION', 2592000); // 30 يوم
define('MAX_CONCURRENT_SESSIONS', 2);

// إعدادات الملفات
define('MAX_UPLOAD_SIZE', 10485760); // 10 MB
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'webp']);
define('ALLOWED_VIDEO_TYPES', ['mp4', 'webm', 'ogg']);

// إعدادات الإشعارات
define('ENABLE_EMAIL_NOTIFICATIONS', true);
define('ENABLE_SMS_NOTIFICATIONS', false);
define('NOTIFICATION_EMAIL', 'notifications@example.com');

// إعدادات التشفير الإضافية
define('ENCRYPTION_METHOD', 'AES-256-CBC');
define('HASH_ALGORITHM', 'sha256');

// إعدادات API
define('API_RATE_LIMIT', 100); // طلب في الدقيقة
define('API_KEY_LENGTH', 32);
define('ENABLE_API_DOCUMENTATION', true);

// إعدادات التخزين المؤقت
define('ENABLE_CACHE', true);
define('CACHE_DURATION', 3600); // ساعة واحدة
define('CACHE_PREFIX', 'lp_');

// إعدادات الموقع
$siteSettings = [
    'site_name' => SITE_NAME,
    'site_description' => 'منصة تعليمية متقدمة لتطوير المهارات',
    'site_keywords' => 'تعليم، دورات، مهارات، تطوير، تدريب',
    'contact_email' => 'info@example.com',
    'support_email' => 'support@example.com',
    'phone' => '+966123456789',
    'address' => 'المملكة العربية السعودية',
    'social_media' => [
        'facebook' => 'https://facebook.com/yourpage',
        'twitter' => 'https://twitter.com/yourhandle',
        'instagram' => 'https://instagram.com/yourhandle',
        'youtube' => 'https://youtube.com/yourchannel',
        'linkedin' => 'https://linkedin.com/company/yourcompany'
    ]
];

// إعدادات المظهر
$themeSettings = [
    'default_theme' => 'light',
    'enable_dark_mode' => true,
    'primary_color' => '#007bff',
    'secondary_color' => '#6c757d',
    'success_color' => '#28a745',
    'warning_color' => '#ffc107',
    'danger_color' => '#dc3545',
    'info_color' => '#17a2b8',
    'font_family' => 'Tajawal',
    'enable_animations' => true,
    'enable_sound_effects' => false
];

// إعدادات التعليم
$educationSettings = [
    'course_completion_threshold' => 80, // النسبة المئوية للإكمال
    'allow_course_preview' => true,
    'preview_lessons_count' => 2,
    'enable_certificates' => true,
    'certificate_template' => 'default',
    'enable_quizzes' => true,
    'quiz_pass_score' => 70,
    'enable_progress_tracking' => true,
    'enable_course_ratings' => true,
    'enable_course_reviews' => true
];

// إعدادات الدفع (للمستقبل)
$paymentSettings = [
    'enable_payments' => false,
    'currency' => 'SAR',
    'payment_methods' => ['credit_card', 'bank_transfer'],
    'tax_rate' => 15, // ضريبة القيمة المضافة
    'enable_coupons' => true,
    'enable_refunds' => true,
    'refund_period' => 7 // أيام
];

// إعدادات البحث
$searchSettings = [
    'enable_search' => true,
    'search_min_characters' => 3,
    'search_max_results' => 50,
    'enable_autocomplete' => true,
    'search_categories' => ['courses', 'lessons', 'users'],
    'enable_search_analytics' => true
];

// إعدادات الصيانة
$maintenanceSettings = [
    'maintenance_mode' => false,
    'maintenance_message' => 'الموقع تحت الصيانة. سنعود قريباً!',
    'maintenance_allowed_ips' => ['127.0.0.1'],
    'backup_frequency' => 'daily',
    'cleanup_frequency' => 'weekly',
    'log_retention_days' => 30
];

// دالة للحصول على إعداد معين
function getSetting($category, $key = null, $default = null) {
    global $siteSettings, $themeSettings, $educationSettings, 
           $paymentSettings, $searchSettings, $maintenanceSettings;
    
    $settings = [
        'site' => $siteSettings,
        'theme' => $themeSettings,
        'education' => $educationSettings,
        'payment' => $paymentSettings,
        'search' => $searchSettings,
        'maintenance' => $maintenanceSettings
    ];
    
    if (!isset($settings[$category])) {
        return $default;
    }
    
    if ($key === null) {
        return $settings[$category];
    }
    
    return $settings[$category][$key] ?? $default;
}

// دالة لحفظ الإعدادات (في قاعدة البيانات)
function saveSetting($category, $key, $value) {
    try {
        $db = Database::getInstance()->getConnection();
        
        $stmt = $db->prepare("
            INSERT INTO settings (category, setting_key, setting_value, updated_at) 
            VALUES (?, ?, ?, NOW())
            ON DUPLICATE KEY UPDATE 
            setting_value = VALUES(setting_value), 
            updated_at = NOW()
        ");
        
        return $stmt->execute([$category, $key, json_encode($value)]);
    } catch (Exception $e) {
        error_log("Error saving setting: " . $e->getMessage());
        return false;
    }
}

// دالة لتحميل الإعدادات من قاعدة البيانات
function loadSettings() {
    try {
        $db = Database::getInstance()->getConnection();
        
        $stmt = $db->prepare("SELECT category, setting_key, setting_value FROM settings");
        $stmt->execute();
        
        $settings = [];
        while ($row = $stmt->fetch()) {
            $settings[$row['category']][$row['setting_key']] = json_decode($row['setting_value'], true);
        }
        
        return $settings;
    } catch (Exception $e) {
        error_log("Error loading settings: " . $e->getMessage());
        return [];
    }
}

// SQL لإنشاء جدول الإعدادات
/*
CREATE TABLE IF NOT EXISTS settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category VARCHAR(50) NOT NULL,
    setting_key VARCHAR(100) NOT NULL,
    setting_value TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_setting (category, setting_key),
    INDEX idx_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
*/

// إعدادات تطوير إضافية
if (ENVIRONMENT === 'development') {
    // تفعيل عرض الأخطاء
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    
    // إعدادات debugging
    define('DEBUG_MODE', true);
    define('LOG_QUERIES', true);
    define('SHOW_DEBUG_INFO', true);
} else {
    // إعدادات الإنتاج
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(E_ERROR | E_WARNING | E_PARSE);
    
    define('DEBUG_MODE', false);
    define('LOG_QUERIES', false);
    define('SHOW_DEBUG_INFO', false);
}

// دالة للتحقق من حالة الصيانة
function isMaintenanceMode() {
    if (!getSetting('maintenance', 'maintenance_mode', false)) {
        return false;
    }
    
    // السماح لعناوين IP المحددة
    $allowedIPs = getSetting('maintenance', 'maintenance_allowed_ips', []);
    $currentIP = getRealIpAddress();
    
    return !in_array($currentIP, $allowedIPs);
}

// دالة لعرض صفحة الصيانة
function showMaintenancePage() {
    $message = getSetting('maintenance', 'maintenance_message', 'الموقع تحت الصيانة');
    
    http_response_code(503);
    header('Retry-After: 3600'); // إعادة المحاولة بعد ساعة
    
    echo "<!DOCTYPE html>
    <html lang='ar' dir='rtl'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>صيانة - " . SITE_NAME . "</title>
        <style>
            body { font-family: 'Tajawal', sans-serif; text-align: center; padding: 50px; background: #f8f9fa; }
            .container { max-width: 600px; margin: 0 auto; background: white; padding: 40px; border-radius: 10px; box-shadow: 0 0 20px rgba(0,0,0,0.1); }
            h1 { color: #333; margin-bottom: 20px; }
            p { color: #666; font-size: 18px; line-height: 1.6; }
            .icon { font-size: 64px; color: #ffc107; margin-bottom: 20px; }
        </style>
        <link href='https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap' rel='stylesheet'>
        <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css' rel='stylesheet'>
    </head>
    <body>
        <div class='container'>
            <div class='icon'><i class='fas fa-tools'></i></div>
            <h1>صيانة مؤقتة</h1>
            <p>{$message}</p>
            <p><small>نعتذر عن الإزعاج ونتطلع لخدمتكم قريباً</small></p>
        </div>
    </body>
    </html>";
    exit;
}

// التحقق من حالة الصيانة
if (isMaintenanceMode() && !defined('SKIP_MAINTENANCE_CHECK')) {
    showMaintenancePage();
}
?>