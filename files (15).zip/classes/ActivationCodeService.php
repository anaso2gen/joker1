<?php
/**
 * خدمة أكواد التفعيل
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 11:07:54
 */

class ActivationCodeService
{
    private $db;
    
    public function __construct()
    {
        $this->db = Database::getInstance();
    }
    
    /**
     * إنشاء كود تفعيل جديد
     */
    public function generateCode($courseId, $expiryDays = 365, $maxUses = 1, $type = 'course')
    {
        try {
            // إنشاء كود فريد
            $code = $this->generateUniqueCode();
            
            // تحديد تاريخ الانتهاء
            $expiryDate = date('Y-m-d H:i:s', strtotime("+{$expiryDays} days"));
            
            $stmt = $this->db->prepare("
                INSERT INTO activation_codes (
                    code, course_id, type, max_uses, uses_count, 
                    expires_at, status, created_by, created_at
                ) VALUES (?, ?, ?, ?, 0, ?, 'active', ?, NOW())
            ");
            
            $stmt->execute([
                $code,
                $courseId,
                $type,
                $maxUses,
                $expiryDate,
                $_SESSION['user_id'] ?? null
            ]);
            
            return [
                'success' => true,
                'code' => $code,
                'expires_at' => $expiryDate,
                'message' => 'تم إنشاء كود التفعيل بنجاح'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'خطأ في إنشاء كود التفعيل: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * إنشاء عدة أكواد تفعيل
     */
    public function generateBulkCodes($courseId, $quantity, $expiryDays = 365, $maxUses = 1)
    {
        try {
            $codes = [];
            $expiryDate = date('Y-m-d H:i:s', strtotime("+{$expiryDays} days"));
            
            $this->db->beginTransaction();
            
            $stmt = $this->db->prepare("
                INSERT INTO activation_codes (
                    code, course_id, type, max_uses, uses_count, 
                    expires_at, status, created_by, created_at
                ) VALUES (?, ?, 'course', ?, 0, ?, 'active', ?, NOW())
            ");
            
            for ($i = 0; $i < $quantity; $i++) {
                $code = $this->generateUniqueCode();
                
                $stmt->execute([
                    $code,
                    $courseId,
                    $maxUses,
                    $expiryDate,
                    $_SESSION['user_id'] ?? null
                ]);
                
                $codes[] = $code;
            }
            
            $this->db->commit();
            
            return [
                'success' => true,
                'codes' => $codes,
                'quantity' => $quantity,
                'expires_at' => $expiryDate,
                'message' => "تم إنشاء {$quantity} كود تفعيل بنجاح"
            ];
            
        } catch (Exception $e) {
            $this->db->rollBack();
            return [
                'success' => false,
                'message' => 'خطأ في إنشاء الأكواد: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * تفعيل كود
     */
    public function activateCode($code, $userId)
    {
        try {
            // البحث عن الكود
            $stmt = $this->db->prepare("
                SELECT ac.*, c.title as course_title, c.price
                FROM activation_codes ac
                LEFT JOIN courses c ON ac.course_id = c.id
                WHERE ac.code = ? AND ac.status = 'active'
            ");
            $stmt->execute([$code]);
            $codeData = $stmt->fetch();
            
            if (!$codeData) {
                return [
                    'success' => false,
                    'message' => 'كود التفعيل غير صحيح أو منتهي الصلاحية'
                ];
            }
            
            // فحص تاريخ الانتهاء
            if (strtotime($codeData['expires_at']) < time()) {
                return [
                    'success' => false,
                    'message' => 'كود التفعيل منتهي الصلاحية'
                ];
            }
            
            // فحص عدد الاستخدامات
            if ($codeData['uses_count'] >= $codeData['max_uses']) {
                return [
                    'success' => false,
                    'message' => 'تم استنفاد جميع استخدامات هذا الكود'
                ];
            }
            
            // فحص إذا كان المستخدم مسجل في الدورة مسبقاً
            if ($codeData['type'] === 'course') {
                $stmt = $this->db->prepare("
                    SELECT id FROM enrollments 
                    WHERE user_id = ? AND course_id = ?
                ");
                $stmt->execute([$userId, $codeData['course_id']]);
                
                if ($stmt->fetch()) {
                    return [
                        'success' => false,
                        'message' => 'أنت مسجل في هذه الدورة مسبقاً'
                    ];
                }
            }
            
            $this->db->beginTransaction();
            
            // تسجيل الاستخدام
            $stmt = $this->db->prepare("
                INSERT INTO code_usage_log (
                    code_id, user_id, used_at, ip_address, user_agent
                ) VALUES (?, ?, NOW(), ?, ?)
            ");
            $stmt->execute([
                $codeData['id'],
                $userId,
                $_SERVER['REMOTE_ADDR'] ?? '',
                $_SERVER['HTTP_USER_AGENT'] ?? ''
            ]);
            
            // تحديث عداد الاستخدامات
            $stmt = $this->db->prepare("
                UPDATE activation_codes 
                SET uses_count = uses_count + 1,
                    last_used_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$codeData['id']]);
            
            // تنفيذ العملية حسب نوع الكود
            $result = $this->executeCodeAction($codeData, $userId);
            
            if ($result['success']) {
                $this->db->commit();
                
                return [
                    'success' => true,
                    'message' => $result['message'],
                    'course_id' => $codeData['course_id'],
                    'course_title' => $codeData['course_title']
                ];
            } else {
                $this->db->rollBack();
                return $result;
            }
            
        } catch (Exception $e) {
            $this->db->rollBack();
            return [
                'success' => false,
                'message' => 'خطأ في تفعيل الكود: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * تنفيذ عملية الكود
     */
    private function executeCodeAction($codeData, $userId)
    {
        switch ($codeData['type']) {
            case 'course':
                return $this->enrollUserInCourse($codeData['course_id'], $userId);
                
            case 'discount':
                return $this->applyDiscount($codeData, $userId);
                
            case 'premium':
                return $this->upgradeToPremium($userId, $codeData);
                
            default:
                return [
                    'success' => false,
                    'message' => 'نوع الكود غير مدعوم'
                ];
        }
    }
    
    /**
     * تسجيل المستخدم في الدورة
     */
    private function enrollUserInCourse($courseId, $userId)
    {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO enrollments (
                    user_id, course_id, enrolled_at, payment_status, 
                    payment_method, status
                ) VALUES (?, ?, NOW(), 'completed', 'activation_code', 'active')
            ");
            $stmt->execute([$userId, $courseId]);
            
            // تحديث إحصائيات الدورة
            $stmt = $this->db->prepare("
                UPDATE courses 
                SET enrolled_count = enrolled_count + 1 
                WHERE id = ?
            ");
            $stmt->execute([$courseId]);
            
            return [
                'success' => true,
                'message' => 'تم تسجيلك في الدورة بنجاح!'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'فشل في التسجيل في الدورة: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * تطبيق خصم
     */
    private function applyDiscount($codeData, $userId)
    {
        try {
            // حفظ الخصم في الجلسة للاستخدام عند الدفع
            $_SESSION['discount_code'] = $codeData['code'];
            $_SESSION['discount_amount'] = $codeData['discount_amount'];
            $_SESSION['discount_type'] = $codeData['discount_type'];
            
            return [
                'success' => true,
                'message' => 'تم تطبيق كود الخصم بنجاح'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'فشل في تطبيق الخصم: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * ترقية لعضوية مميزة
     */
    private function upgradeToPremium($userId, $codeData)
    {
        try {
            $duration = $codeData['premium_duration'] ?? 30; // افتراضي 30 يوم
            $expiryDate = date('Y-m-d H:i:s', strtotime("+{$duration} days"));
            
            $stmt = $this->db->prepare("
                UPDATE users 
                SET subscription_type = 'premium',
                    subscription_expires_at = ?,
                    updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$expiryDate, $userId]);
            
            return [
                'success' => true,
                'message' => "تم ترقية حسابك لعضوية مميزة لمدة {$duration} يوم"
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'فشل في ترقية الحساب: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * إنشاء كود فريد
     */
    private function generateUniqueCode($length = 12)
    {
        $attempts = 0;
        $maxAttempts = 10;
        
        do {
            $code = $this->generateRandomCode($length);
            $stmt = $this->db->prepare("SELECT id FROM activation_codes WHERE code = ?");
            $stmt->execute([$code]);
            $exists = $stmt->fetch();
            $attempts++;
        } while ($exists && $attempts < $maxAttempts);
        
        if ($exists) {
            throw new Exception('فشل في إنشاء كود فريد');
        }
        
        return $code;
    }
    
    /**
     * إنشاء كود عشوائي
     */
    private function generateRandomCode($length = 12)
    {
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $code = '';
        
        for ($i = 0; $i < $length; $i++) {
            $code .= $chars[random_int(0, strlen($chars) - 1)];
        }
        
        // إضافة فواصل للقراءة
        return chunk_split($code, 4, '-');
        return rtrim($code, '-');
    }
    
    /**
     * الحصول على قائمة الأكواد
     */
    public function getCodes($filters = [], $page = 1, $limit = 20)
    {
        try {
            $offset = ($page - 1) * $limit;
            
            $whereClause = "WHERE 1=1";
            $params = [];
            
            if (!empty($filters['course_id'])) {
                $whereClause .= " AND ac.course_id = ?";
                $params[] = $filters['course_id'];
            }
            
            if (!empty($filters['status'])) {
                $whereClause .= " AND ac.status = ?";
                $params[] = $filters['status'];
            }
            
            if (!empty($filters['type'])) {
                $whereClause .= " AND ac.type = ?";
                $params[] = $filters['type'];
            }
            
            $stmt = $this->db->prepare("
                SELECT ac.*, c.title as course_title,
                       u.name as created_by_name
                FROM activation_codes ac
                LEFT JOIN courses c ON ac.course_id = c.id
                LEFT JOIN users u ON ac.created_by = u.id
                {$whereClause}
                ORDER BY ac.created_at DESC
                LIMIT ? OFFSET ?
            ");
            
            $params[] = $limit;
            $params[] = $offset;
            $stmt->execute($params);
            $codes = $stmt->fetchAll();
            
            // عدد الأكواد الإجمالي
            $countStmt = $this->db->prepare("
                SELECT COUNT(*) FROM activation_codes ac {$whereClause}
            ");
            $countStmt->execute(array_slice($params, 0, -2));
            $total = $countStmt->fetchColumn();
            
            return [
                'success' => true,
                'codes' => $codes,
                'total' => $total,
                'current_page' => $page,
                'per_page' => $limit,
                'total_pages' => ceil($total / $limit)
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'خطأ في جلب الأكواد: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * تعطيل كود
     */
    public function deactivateCode($codeId)
    {
        try {
            $stmt = $this->db->prepare("
                UPDATE activation_codes 
                SET status = 'disabled', updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$codeId]);
            
            return [
                'success' => true,
                'message' => 'تم تعطيل الكود بنجاح'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'خطأ في تعطيل الكود: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * حذف كود
     */
    public function deleteCode($codeId)
    {
        try {
            $this->db->beginTransaction();
            
            // حذف سجلات الاستخدام
            $stmt = $this->db->prepare("DELETE FROM code_usage_log WHERE code_id = ?");
            $stmt->execute([$codeId]);
            
            // حذف الكود
            $stmt = $this->db->prepare("DELETE FROM activation_codes WHERE id = ?");
            $stmt->execute([$codeId]);
            
            $this->db->commit();
            
            return [
                'success' => true,
                'message' => 'تم حذف الكود بنجاح'
            ];
            
        } catch (Exception $e) {
            $this->db->rollBack();
            return [
                'success' => false,
                'message' => 'خطأ في حذف الكود: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * تصدير الأكواد
     */
    public function exportCodes($courseId, $format = 'csv')
    {
        try {
            $stmt = $this->db->prepare("
                SELECT ac.code, c.title as course_title, ac.max_uses, 
                       ac.uses_count, ac.expires_at, ac.status
                FROM activation_codes ac
                LEFT JOIN courses c ON ac.course_id = c.id
                WHERE ac.course_id = ?
                ORDER BY ac.created_at DESC
            ");
            $stmt->execute([$courseId]);
            $codes = $stmt->fetchAll();
            
            if ($format === 'csv') {
                return $this->exportToCSV($codes);
            } elseif ($format === 'txt') {
                return $this->exportToTXT($codes);
            }
            
            return [
                'success' => false,
                'message' => 'تنسيق التصدير غير مدعوم'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'خطأ في تصدير الأكواد: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * تصدير لـ CSV
     */
    private function exportToCSV($codes)
    {
        $filename = 'activation_codes_' . date('Y-m-d_H-i-s') . '.csv';
        $filepath = sys_get_temp_dir() . '/' . $filename;
        
        $file = fopen($filepath, 'w');
        
        // كتابة العناوين
        fputcsv($file, ['الكود', 'الدورة', 'الحد الأقصى', 'المستخدم', 'تاريخ الانتهاء', 'الحالة']);
        
        // كتابة البيانات
        foreach ($codes as $code) {
            fputcsv($file, [
                $code['code'],
                $code['course_title'],
                $code['max_uses'],
                $code['uses_count'],
                $code['expires_at'],
                $code['status']
            ]);
        }
        
        fclose($file);
        
        return [
            'success' => true,
            'file' => $filepath,
            'filename' => $filename
        ];
    }
    
    /**
     * تصدير لـ TXT
     */
    private function exportToTXT($codes)
    {
        $filename = 'activation_codes_' . date('Y-m-d_H-i-s') . '.txt';
        $filepath = sys_get_temp_dir() . '/' . $filename;
        
        $content = "أكواد التفعيل - " . date('Y-m-d H:i:s') . "\n";
        $content .= str_repeat('=', 50) . "\n\n";
        
        foreach ($codes as $code) {
            $content .= $code['code'] . "\n";
        }
        
        file_put_contents($filepath, $content);
        
        return [
            'success' => true,
            'file' => $filepath,
            'filename' => $filename
        ];
    }
    
    /**
     * إحصائيات الأكواد
     */
    public function getCodeStats($courseId = null)
    {
        try {
            $whereClause = $courseId ? "WHERE course_id = ?" : "";
            $params = $courseId ? [$courseId] : [];
            
            $stmt = $this->db->prepare("
                SELECT 
                    COUNT(*) as total_codes,
                    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_codes,
                    SUM(uses_count) as total_uses,
                    SUM(CASE WHEN expires_at < NOW() THEN 1 ELSE 0 END) as expired_codes
                FROM activation_codes
                {$whereClause}
            ");
            $stmt->execute($params);
            $stats = $stmt->fetch();
            
            return [
                'success' => true,
                'stats' => $stats
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'خطأ في جلب الإحصائيات: ' . $e->getMessage()
            ];
        }
    }
}