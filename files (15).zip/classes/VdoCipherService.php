<?php
/**
 * خدمة VdoCipher لحماية الفيديو
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 11:07:54
 */

class VdoCipherService
{
    private $apiKey;
    private $secretKey;
    private $baseUrl = 'https://dev.vdocipher.com/api';
    
    public function __construct()
    {
        $this->apiKey = $_ENV['VDOCIPHER_API_KEY'] ?? '';
        $this->secretKey = $_ENV['VDOCIPHER_SECRET_KEY'] ?? '';
        
        if (empty($this->apiKey) || empty($this->secretKey)) {
            throw new Exception('VdoCipher API credentials not configured');
        }
    }
    
    /**
     * رفع فيديو جديد
     */
    public function uploadVideo($title, $description = '', $tags = [])
    {
        try {
            $url = $this->baseUrl . '/videos';
            
            $data = [
                'title' => $title,
                'description' => $description,
                'tags' => implode(',', $tags)
            ];
            
            $response = $this->makeRequest('PUT', $url, $data);
            
            if ($response['success']) {
                return [
                    'success' => true,
                    'video_id' => $response['data']['videoId'],
                    'upload_link' => $response['data']['uploadLink'],
                    'message' => 'تم إنشاء رابط الرفع بنجاح'
                ];
            }
            
            return [
                'success' => false,
                'message' => $response['message'] ?? 'فشل في إنشاء رابط الرفع'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'خطأ في الاتصال مع VdoCipher: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * الحصول على معلومات الفيديو
     */
    public function getVideoInfo($videoId)
    {
        try {
            $url = $this->baseUrl . '/videos/' . $videoId;
            $response = $this->makeRequest('GET', $url);
            
            if ($response['success']) {
                return [
                    'success' => true,
                    'data' => [
                        'video_id' => $response['data']['id'],
                        'title' => $response['data']['title'],
                        'description' => $response['data']['description'],
                        'duration' => $response['data']['length'],
                        'status' => $response['data']['status'],
                        'poster' => $response['data']['poster'],
                        'created_at' => $response['data']['createdAt']
                    ]
                ];
            }
            
            return [
                'success' => false,
                'message' => 'فشل في الحصول على معلومات الفيديو'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'خطأ في الاتصال: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * إنشاء OTP للمشاهدة الآمنة
     */
    public function generateOTP($videoId, $userId = null, $duration = 3600)
    {
        try {
            $url = $this->baseUrl . '/videos/' . $videoId . '/otp';
            
            $data = [
                'ttl' => $duration,
                'annotate' => json_encode([
                    'user_id' => $userId,
                    'video_id' => $videoId,
                    'timestamp' => time()
                ])
            ];
            
            $response = $this->makeRequest('POST', $url, $data);
            
            if ($response['success']) {
                return [
                    'success' => true,
                    'otp' => $response['data']['otp'],
                    'playback_info' => $response['data']['playbackInfo'],
                    'expires_at' => time() + $duration
                ];
            }
            
            return [
                'success' => false,
                'message' => 'فشل في إنشاء OTP'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'خطأ في إنشاء OTP: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * حذف فيديو
     */
    public function deleteVideo($videoId)
    {
        try {
            $url = $this->baseUrl . '/videos/' . $videoId;
            $response = $this->makeRequest('DELETE', $url);
            
            return [
                'success' => $response['success'],
                'message' => $response['success'] ? 'تم حذف الفيديو بنجاح' : 'فشل في حذف الفيديو'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'خطأ في حذف الفيديو: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * الحصول على قائمة الفيديوهات
     */
    public function getVideosList($page = 1, $limit = 50)
    {
        try {
            $url = $this->baseUrl . '/videos?page=' . $page . '&limit=' . $limit;
            $response = $this->makeRequest('GET', $url);
            
            if ($response['success']) {
                return [
                    'success' => true,
                    'videos' => $response['data']['rows'],
                    'total' => $response['data']['count'],
                    'current_page' => $page,
                    'per_page' => $limit
                ];
            }
            
            return [
                'success' => false,
                'message' => 'فشل في الحصول على قائمة الفيديوهات'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'خطأ في الحصول على القائمة: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * تحديث معلومات الفيديو
     */
    public function updateVideo($videoId, $title = null, $description = null, $tags = null)
    {
        try {
            $url = $this->baseUrl . '/videos/' . $videoId;
            
            $data = [];
            if ($title) $data['title'] = $title;
            if ($description) $data['description'] = $description;
            if ($tags) $data['tags'] = implode(',', $tags);
            
            if (empty($data)) {
                return [
                    'success' => false,
                    'message' => 'لا توجد بيانات للتحديث'
                ];
            }
            
            $response = $this->makeRequest('POST', $url, $data);
            
            return [
                'success' => $response['success'],
                'message' => $response['success'] ? 'تم تحديث الفيديو بنجاح' : 'فشل في تحديث الفيديو'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'خطأ في تحديث الفيديو: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * إنشاء صورة مصغرة مخصصة
     */
    public function generateThumbnail($videoId, $timeStamp = 10)
    {
        try {
            $url = $this->baseUrl . '/videos/' . $videoId . '/thumbnail';
            
            $data = [
                'timestamp' => $timeStamp
            ];
            
            $response = $this->makeRequest('POST', $url, $data);
            
            if ($response['success']) {
                return [
                    'success' => true,
                    'thumbnail_url' => $response['data']['poster']
                ];
            }
            
            return [
                'success' => false,
                'message' => 'فشل في إنشاء الصورة المصغرة'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'خطأ في إنشاء الصورة المصغرة: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * إنشاء webhook للأحداث
     */
    public function createWebhook($url, $events = ['upload.complete', 'encode.complete'])
    {
        try {
            $webhookUrl = $this->baseUrl . '/webhooks';
            
            $data = [
                'url' => $url,
                'events' => $events
            ];
            
            $response = $this->makeRequest('POST', $webhookUrl, $data);
            
            if ($response['success']) {
                return [
                    'success' => true,
                    'webhook_id' => $response['data']['id'],
                    'webhook_url' => $response['data']['url']
                ];
            }
            
            return [
                'success' => false,
                'message' => 'فشل في إنشاء webhook'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'خطأ في إنشاء webhook: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * معالجة webhook events
     */
    public function handleWebhook($payload, $signature)
    {
        try {
            // التحقق من التوقيع
            $expectedSignature = hash_hmac('sha256', $payload, $this->secretKey);
            
            if (!hash_equals($expectedSignature, $signature)) {
                return [
                    'success' => false,
                    'message' => 'Invalid webhook signature'
                ];
            }
            
            $data = json_decode($payload, true);
            
            if (!$data) {
                return [
                    'success' => false,
                    'message' => 'Invalid JSON payload'
                ];
            }
            
            // معالجة الأحداث المختلفة
            switch ($data['event']) {
                case 'upload.complete':
                    return $this->handleUploadComplete($data);
                    
                case 'encode.complete':
                    return $this->handleEncodeComplete($data);
                    
                case 'video.ready':
                    return $this->handleVideoReady($data);
                    
                default:
                    return [
                        'success' => true,
                        'message' => 'Event received but not handled: ' . $data['event']
                    ];
            }
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Webhook processing error: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * معالجة اكتمال الرفع
     */
    private function handleUploadComplete($data)
    {
        try {
            $videoId = $data['id'];
            
            // تحديث حالة الفيديو في قاعدة البيانات
            $db = Database::getInstance();
            $stmt = $db->prepare("
                UPDATE lesson_videos 
                SET status = 'processing', vdo_video_id = ?
                WHERE temp_video_id = ?
            ");
            $stmt->execute([$videoId, $data['tempId'] ?? '']);
            
            return [
                'success' => true,
                'message' => 'Upload completed for video: ' . $videoId
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error handling upload complete: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * معالجة اكتمال التشفير
     */
    private function handleEncodeComplete($data)
    {
        try {
            $videoId = $data['id'];
            
            // تحديث حالة الفيديو
            $db = Database::getInstance();
            $stmt = $db->prepare("
                UPDATE lesson_videos 
                SET status = 'ready', duration = ?, poster = ?
                WHERE vdo_video_id = ?
            ");
            $stmt->execute([
                $data['length'] ?? 0,
                $data['poster'] ?? '',
                $videoId
            ]);
            
            return [
                'success' => true,
                'message' => 'Encoding completed for video: ' . $videoId
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error handling encode complete: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * معالجة جهازية الفيديو
     */
    private function handleVideoReady($data)
    {
        try {
            $videoId = $data['id'];
            
            // تحديث حالة الفيديو إلى جاهز
            $db = Database::getInstance();
            $stmt = $db->prepare("
                UPDATE lesson_videos 
                SET status = 'published', ready_at = NOW()
                WHERE vdo_video_id = ?
            ");
            $stmt->execute([$videoId]);
            
            // إرسال إشعار للمدرب
            $this->notifyInstructorVideoReady($videoId);
            
            return [
                'success' => true,
                'message' => 'Video ready: ' . $videoId
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error handling video ready: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * إشعار المدرب بجهازية الفيديو
     */
    private function notifyInstructorVideoReady($videoId)
    {
        try {
            $db = Database::getInstance();
            $stmt = $db->prepare("
                SELECT l.title, c.title as course_title, u.email, u.name
                FROM lesson_videos lv
                JOIN lessons l ON lv.lesson_id = l.id
                JOIN courses c ON l.course_id = c.id
                JOIN users u ON c.instructor_id = u.id
                WHERE lv.vdo_video_id = ?
            ");
            $stmt->execute([$videoId]);
            $info = $stmt->fetch();
            
            if ($info) {
                // إرسال إيميل
                $emailService = new EmailService();
                $emailService->sendVideoReadyNotification($info);
            }
            
        } catch (Exception $e) {
            error_log('Failed to notify instructor: ' . $e->getMessage());
        }
    }
    
    /**
     * طلب HTTP إلى VdoCipher API
     */
    private function makeRequest($method, $url, $data = null)
    {
        $ch = curl_init();
        
        $headers = [
            'Authorization: Apisecret ' . $this->apiKey,
            'Content-Type: application/json',
            'Accept: application/json'
        ];
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT => 'TrendAcademy/1.0'
        ]);
        
        if ($data && in_array($method, ['POST', 'PUT', 'PATCH'])) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        
        curl_close($ch);
        
        if ($error) {
            throw new Exception('cURL Error: ' . $error);
        }
        
        $decodedResponse = json_decode($response, true);
        
        if ($httpCode >= 200 && $httpCode < 300) {
            return [
                'success' => true,
                'data' => $decodedResponse
            ];
        } else {
            return [
                'success' => false,
                'message' => $decodedResponse['message'] ?? 'HTTP Error: ' . $httpCode,
                'code' => $httpCode
            ];
        }
    }
}