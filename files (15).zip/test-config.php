<?php
// ملف اختبار سريع - احذفه بعد التشخيص
if (file_exists('config.php')) {
    echo "✅ ملف config.php موجود<br>";
    
    try {
        define('LEARNING_PLATFORM', true);
        require_once 'config.php';
        echo "✅ تم تحميل config.php بنجاح<br>";
        
        // اختبار الاتصال بقاعدة البيانات
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET, 
                       DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        echo "✅ الاتصال بقاعدة البيانات ناجح<br>";
        
        // فحص الجداول
        $stmt = $pdo->query("SHOW TABLES");
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
        echo "✅ عدد الجداول الموجودة: " . count($tables) . "<br>";
        
        if (in_array('users', $tables)) {
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
            $userCount = $stmt->fetch()['count'];
            echo "✅ عدد المستخدمين: $userCount<br>";
        }
        
        echo "<br><strong>✅ كل شيء يبدو طبيعياً!</strong>";
        
    } catch (Exception $e) {
        echo "❌ خطأ: " . $e->getMessage();
    }
} else {
    echo "❌ ملف config.php غير موجود!";
}
?>