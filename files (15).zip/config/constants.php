<?php
/**
 * ثوابت النظام
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:56:22
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

// معلومات الموقع
define('SITE_NAME', 'ترند التعليمية');
define('SITE_DESCRIPTION', 'منصة تعليمية متقدمة لتعلم التكنولوجيا والبرمجة');
define('SITE_URL', 'https://trendacademy.com');
define('SITE_EMAIL', 'info@trendacademy.com');
define('SUPPORT_EMAIL', 'support@trendacademy.com');

// إعدادات التطبيق
define('APP_ENV', 'production'); // development, staging, production
define('APP_DEBUG', false);
define('APP_TIMEZONE', 'Asia/Riyadh');

// إعدادات قاعدة البيانات
define('DB_HOST', 'localhost');
define('DB_NAME', 'trend_academy');
define('DB_USER', 'trend_user');
define('DB_PASS', 'SecureP@ssw0rd123!');
define('DB_CHARSET', 'utf8mb4');

// إعدادات الأمان
define('ENCRYPTION_KEY', 'your-32-character-secret-key-here');
define('JWT_SECRET', 'your-jwt-secret-key-here');
define('SESSION_LIFETIME', 86400); // 24 hours
define('REMEMBER_ME_LIFETIME', 2592000); // 30 days

// إعدادات رفع الملفات
define('UPLOAD_MAX_SIZE', 10485760); // 10MB
define('AVATAR_MAX_SIZE', 2097152); // 2MB
define('VIDEO_MAX_SIZE', 104857600); // 100MB
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'webp']);
define('ALLOWED_VIDEO_TYPES', ['mp4', 'webm', 'mov', 'avi']);
define('ALLOWED_DOCUMENT_TYPES', ['pdf', 'doc', 'docx', 'txt']);

// مجلدات التخزين
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('AVATAR_PATH', UPLOAD_PATH . 'avatars/');
define('COURSE_PATH', UPLOAD_PATH . 'courses/');
define('VIDEO_PATH', UPLOAD_PATH . 'videos/');
define('DOCUMENT_PATH', UPLOAD_PATH . 'documents/');
define('BACKUP_PATH', __DIR__ . '/../backups/');

// إعدادات البريد الإلكتروني
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', 'your-email@gmail.com');
define('MAIL_PASSWORD', 'your-app-password');
define('MAIL_ENCRYPTION', 'tls');
define('MAIL_FROM_ADDRESS', 'noreply@trendacademy.com');
define('MAIL_FROM_NAME', 'ترند التعليمية');

// إعدادات وسائل التواصل الاجتماعي
define('FACEBOOK_URL', 'https://facebook.com/trendacademy');
define('TWITTER_URL', 'https://twitter.com/trendacademy');
define('INSTAGRAM_URL', 'https://instagram.com/trendacademy');
define('LINKEDIN_URL', 'https://linkedin.com/company/trendacademy');
define('YOUTUBE_URL', 'https://youtube.com/c/trendacademy');
define('TELEGRAM_URL', 'https://t.me/trendacademy');

// إعدادات الدفع
define('PAYPAL_CLIENT_ID', 'your-paypal-client-id');
define('PAYPAL_CLIENT_SECRET', 'your-paypal-client-secret');
define('STRIPE_PUBLIC_KEY', 'your-stripe-public-key');
define('STRIPE_SECRET_KEY', 'your-stripe-secret-key');
define('TABBY_PUBLIC_KEY', 'your-tabby-public-key');
define('TABBY_SECRET_KEY', 'your-tabby-secret-key');

// إعدادات التخزين السحابي
define('AWS_ACCESS_KEY_ID', 'your-aws-access-key');
define('AWS_SECRET_ACCESS_KEY', 'your-aws-secret-key');
define('AWS_DEFAULT_REGION', 'us-east-1');
define('AWS_BUCKET', 'trendacademy-storage');
define('CDN_URL', 'https://cdn.trendacademy.com');

// إعدادات التحليلات
define('GOOGLE_ANALYTICS_ID', 'G-XXXXXXXXXX');
define('FACEBOOK_PIXEL_ID', '1234567890');

// رسائل النظام
define('SUCCESS_MESSAGES', [
    'login' => 'تم تسجيل الدخول بنجاح',
    'register' => 'تم إنشاء الحساب بنجاح',
    'profile_updated' => 'تم تحديث الملف الشخصي بنجاح',
    'password_changed' => 'تم تغيير كلمة المرور بنجاح',
    'course_enrolled' => 'تم التسجيل في الدورة بنجاح',
    'lesson_completed' => 'تم إكمال الدرس بنجاح',
    'review_added' => 'تم إضافة التقييم بنجاح',
    'note_saved' => 'تم حفظ الملاحظة بنجاح'
]);

define('ERROR_MESSAGES', [
    'invalid_login' => 'بيانات تسجيل الدخول غير صحيحة',
    'account_inactive' => 'حسابك غير نشط، يرجى التواصل مع الإدارة',
    'email_not_verified' => 'يرجى تفعيل بريدك الإلكتروني أولاً',
    'access_denied' => 'ليس لديك صلاحية للوصول لهذه الصفحة',
    'invalid_token' => 'رمز التفعيل غير صحيح أو منتهي الصلاحية',
    'file_too_large' => 'حجم الملف كبير جداً',
    'invalid_file_type' => 'نوع الملف غير مدعوم',
    'upload_failed' => 'فشل في رفع الملف',
    'database_error' => 'حدث خطأ في قاعدة البيانات',
    'general_error' => 'حدث خطأ غير متوقع، يرجى المحاولة لاحقاً'
]);

// مستويات الدورات
define('COURSE_LEVELS', [
    'beginner' => 'مبتدئ',
    'intermediate' => 'متوسط', 
    'advanced' => 'متقدم',
    'expert' => 'خبير'
]);

// فئات الدورات
define('COURSE_CATEGORIES', [
    'programming' => 'البرمجة',
    'web-development' => 'تطوير الويب',
    'mobile-development' => 'تطوير التطبيقات',
    'data-science' => 'علم البيانات',
    'artificial-intelligence' => 'الذكاء الاصطناعي',
    'cybersecurity' => 'الأمن السيبراني',
    'digital-marketing' => 'التسويق الرقمي',
    'graphic-design' => 'التصميم الجرافيكي',
    'photography' => 'التصوير الفوتوغرافي',
    'business' => 'إدارة الأعمال',
    'languages' => 'اللغات',
    'personal-development' => 'التطوير الشخصي'
]);

// أنواع التنبيهات
define('ALERT_TYPES', [
    'success' => 'success',
    'error' => 'danger',
    'warning' => 'warning',
    'info' => 'info'
]);

// أنواع الإشعارات
define('NOTIFICATION_TYPES', [
    'course_enrolled' => 'تم التسجيل في دورة جديدة',
    'lesson_completed' => 'تم إكمال درس',
    'course_completed' => 'تم إكمال دورة',
    'certificate_earned' => 'تم الحصول على شهادة',
    'new_course_available' => 'دورة جديدة متاحة',
    'course_updated' => 'تم تحديث دورة',
    'review_approved' => 'تم قبول تقييمك',
    'system_maintenance' => 'صيانة النظام',
    'security_alert' => 'تنبيه أمني'
]);

// أنواع السجلات
define('ACTIVITY_TYPES', [
    'login' => 'تسجيل دخول',
    'logout' => 'تسجيل خروج',
    'register' => 'تسجيل حساب جديد',
    'profile_update' => 'تحديث الملف الشخصي',
    'password_change' => 'تغيير كلمة المرور',
    'course_view' => 'مشاهدة دورة',
    'course_enroll' => 'التسجيل في دورة',
    'lesson_access' => 'الوصول لدرس',
    'lesson_complete' => 'إكمال درس',
    'course_complete' => 'إكمال دورة',
    'review_add' => 'إضافة تقييم',
    'note_add' => 'إضافة ملاحظة',
    'file_upload' => 'رفع ملف'
]);

// معدلات الحد الأقصى للطلبات
define('RATE_LIMITS', [
    'login_attempts' => 5, // كل 15 دقيقة
    'registration_attempts' => 3, // كل ساعة
    'password_reset_attempts' => 3, // كل ساعة
    'api_requests' => 1000, // كل ساعة
    'file_uploads' => 10 // كل ساعة
]);

// إعدادات التخزين المؤقت
define('CACHE_SETTINGS', [
    'enabled' => true,
    'default_ttl' => 3600, // ساعة واحدة
    'course_list_ttl' => 1800, // 30 دقيقة
    'user_data_ttl' => 900, // 15 دقيقة
    'stats_ttl' => 300 // 5 دقائق
]);

// إعدادات النسخ الاحتياطي
define('BACKUP_SETTINGS', [
    'auto_backup' => true,
    'backup_frequency' => 'daily', // daily, weekly, monthly
    'keep_backups' => 30, // عدد النسخ المحتفظ بها
    'compress_backups' => true
]);

// معلومات الاتصال
define('CONTACT_INFO', [
    'address' => 'الرياض، المملكة العربية السعودية',
    'phone' => '+966 11 123 4567',
    'whatsapp' => '+966 50 123 4567',
    'working_hours' => 'السبت - الخميس: 9:00 ص - 6:00 م'
]);

// إعدادات SEO
define('SEO_SETTINGS', [
    'keywords' => 'تعليم, دورات, برمجة, تطوير, ذكاء اصطناعي, تصميم',
    'author' => 'ترند التعليمية',
    'robots' => 'index, follow',
    'og_type' => 'website',
    'twitter_card' => 'summary_large_image'
]);

// أرقام الإصدار
define('APP_VERSION', '1.0.0');
define('DB_VERSION', '1.0.0');
define('API_VERSION', 'v1');

// إعدادات المطورين
define('DEVELOPER_INFO', [
    'name' => 'anaso2gen',
    'email' => 'anaso2gen@developer.com',
    'github' => 'https://github.com/anaso2gen',
    'website' => 'https://anaso2gen.dev'
]);
?>