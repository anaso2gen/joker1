-- تكملة جدول سجلات الأمان
CREATE TABLE `security_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(100) NOT NULL,
  `severity` enum('low','medium','high','critical') DEFAULT 'medium',
  `description` text NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `additional_data` json DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_event_type` (`event_type`),
  KEY `idx_severity` (`severity`),
  KEY `idx_user` (`user_id`),
  KEY `idx_ip_address` (`ip_address`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_security_logs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول سجلات API
CREATE TABLE `api_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(100) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `request_data` json DEFAULT NULL,
  `response_status` int(11) DEFAULT NULL,
  `execution_time` decimal(8,3) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_action` (`action`),
  KEY `idx_user` (`user_id`),
  KEY `idx_ip_address` (`ip_address`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_api_logs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول إعدادات النظام
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL UNIQUE,
  `setting_value` text DEFAULT NULL,
  `setting_type` enum('string','number','boolean','json') DEFAULT 'string',
  `description` text DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول الصفحات الثابتة
CREATE TABLE `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL UNIQUE,
  `content` longtext NOT NULL,
  `meta_description` varchar(500) DEFAULT NULL,
  `meta_keywords` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_slug` (`slug`),
  KEY `idx_active_pages` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول الأسئلة الشائعة
CREATE TABLE `faqs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(500) NOT NULL,
  `answer` text NOT NULL,
  `category` varchar(100) DEFAULT 'general',
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category`),
  KEY `idx_sort_order` (`sort_order`),
  KEY `idx_active_faqs` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول رسائل التواصل
CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `replied_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_email` (`email`),
  KEY `idx_is_read` (`is_read`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج البيانات الأساسية

-- إدراج المستخدم الإداري الافتراضي
INSERT INTO `users` (`first_name`, `last_name`, `email`, `password_hash`, `is_admin`, `is_active`, `email_verified`, `email_verified_at`) VALUES
('أنس', 'المطور', 'admin@trendacademy.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1, 1, 1, NOW()),
('ترند', 'الأكاديمية', 'info@trendacademy.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1, 1, 1, NOW());

-- إدراج إعدادات النظام الافتراضية
INSERT INTO `system_settings` (`setting_key`, `setting_value`, `setting_type`, `description`, `is_public`) VALUES
('site_name', 'ترند التعليمية', 'string', 'اسم الموقع', 1),
('site_description', 'منصة تعليمية متقدمة لتعلم التكنولوجيا والبرمجة', 'string', 'وصف الموقع', 1),
('site_logo', '/assets/images/logo.png', 'string', 'شعار الموقع', 1),
('maintenance_mode', '0', 'boolean', 'وضع الصيانة', 0),
('registration_enabled', '1', 'boolean', 'تفعيل التسجيل', 0),
('email_verification_required', '1', 'boolean', 'تفعيل البريد الإلكتروني مطلوب', 0),
('max_file_size', '10485760', 'number', 'الحد الأقصى لحجم الملف بالبايت', 0),
('supported_languages', '["ar", "en"]', 'json', 'اللغات المدعومة', 1),
('default_language', 'ar', 'string', 'اللغة الافتراضية', 1),
('currency', 'SAR', 'string', 'العملة الافتراضية', 1),
('timezone', 'Asia/Riyadh', 'string', 'المنطقة الزمنية', 0);

-- إدراج الصفحات الثابتة الافتراضية
INSERT INTO `pages` (`title`, `slug`, `content`, `meta_description`, `is_active`) VALUES
('من نحن', 'about', '<h1>من نحن</h1><p>ترند التعليمية هي منصة تعليمية رائدة تهدف إلى تقديم أفضل المحتوى التعليمي في مجال التكنولوجيا والبرمجة.</p>', 'تعرف على منصة ترند التعليمية ورؤيتنا في التعليم الرقمي', 1),
('شروط الاستخدام', 'terms', '<h1>شروط الاستخدام</h1><p>مرحباً بكم في منصة ترند التعليمية. باستخدامكم لهذه المنصة، فإنكم توافقون على الشروط والأحكام التالية...</p>', 'شروط وأحكام استخدام منصة ترند التعليمية', 1),
('سياسة الخصوصية', 'privacy', '<h1>سياسة الخصوصية</h1><p>نحن في ترند التعليمية نحترم خصوصيتكم ونلتزم بحماية معلوماتكم الشخصية...</p>', 'سياسة الخصوصية وحماية البيانات في منصة ترند التعليمية', 1),
('اتصل بنا', 'contact', '<h1>اتصل بنا</h1><p>نحن هنا لمساعدتكم! لا تترددوا في التواصل معنا عبر الوسائل التالية...</p>', 'تواصل مع فريق ترند التعليمية', 1);

-- إدراج الأسئلة الشائعة الافتراضية
INSERT INTO `faqs` (`question`, `answer`, `category`, `sort_order`, `is_active`) VALUES
('كيف يمكنني التسجيل في المنصة؟', 'يمكنك التسجيل عبر النقر على زر "تسجيل جديد" في أعلى الصفحة وملء النموذج المطلوب.', 'registration', 1, 1),
('هل التسجيل مجاني؟', 'نعم، التسجيل في المنصة مجاني تماماً. تحتاج فقط لبريد إلكتروني صحيح.', 'registration', 2, 1),
('كيف يمكنني الاشتراك في دورة؟', 'بعد تسجيل الدخول، انتقل إلى صفحة الدورة واضغط على زر "اشترك الآن".', 'courses', 1, 1),
('هل يمكنني الوصول للدورات مدى الحياة؟', 'نعم، بمجرد اشتراكك في دورة، ستتمكن من الوصول إليها مدى الحياة.', 'courses', 2, 1),
('كيف أحصل على شهادة إتمام؟', 'بعد إكمال جميع دروس الدورة بنجاح، ستحصل تلقائياً على شهادة إتمام.', 'certificates', 1, 1),
('هل الشهادات معتمدة؟', 'شهادات ترند التعليمية معترف بها في الصناعة ويمكن إضافتها لملفك المهني.', 'certificates', 2, 1);

-- إنشاء فهارس إضافية لتحسين الأداء
CREATE INDEX idx_courses_stats ON courses(is_active, created_at);
CREATE INDEX idx_lessons_course_section ON lessons(section_id, sort_order, is_active);
CREATE INDEX idx_subscriptions_active_user ON subscriptions(user_id, is_active, created_at);
CREATE INDEX idx_lesson_progress_user_completed ON lesson_progress(user_id, completed, last_accessed);
CREATE INDEX idx_course_reviews_course_approved ON course_reviews(course_id, is_approved, rating);
CREATE INDEX idx_notifications_user_unread ON notifications(user_id, is_read, created_at);

-- إنشاء مشاهدات (Views) مفيدة
CREATE VIEW course_stats AS
SELECT 
    c.id,
    c.name,
    c.category,
    c.level,
    c.price,
    COUNT(DISTINCT s.id) as students_count,
    COUNT(DISTINCT sec.id) as sections_count,
    COUNT(DISTINCT l.id) as lessons_count,
    SUM(l.duration) as total_duration,
    AVG(cr.rating) as avg_rating,
    COUNT(DISTINCT cr.id) as reviews_count,
    SUM(s.price_paid) as total_revenue
FROM courses c
LEFT JOIN subscriptions s ON c.id = s.course_id AND s.is_active = 1
LEFT JOIN sections sec ON c.id = sec.course_id
LEFT JOIN lessons l ON sec.id = l.section_id AND l.is_active = 1
LEFT JOIN course_reviews cr ON c.id = cr.course_id AND cr.is_approved = 1
WHERE c.is_active = 1
GROUP BY c.id;

CREATE VIEW user_progress_overview AS
SELECT 
    u.id as user_id,
    u.first_name,
    u.last_name,
    u.email,
    COUNT(DISTINCT s.course_id) as enrolled_courses,
    COUNT(DISTINCT CASE WHEN lp.completed = 1 THEN lp.lesson_id END) as completed_lessons,
    COUNT(DISTINCT cc.course_id) as completed_courses,
    SUM(s.price_paid) as total_spent,
    MAX(lp.last_accessed) as last_activity
FROM users u
LEFT JOIN subscriptions s ON u.id = s.user_id AND s.is_active = 1
LEFT JOIN lesson_progress lp ON u.id = lp.user_id
LEFT JOIN course_completions cc ON u.id = cc.user_id
WHERE u.is_active = 1
GROUP BY u.id;

-- إنشاء stored procedures مفيدة
DELIMITER //

CREATE PROCEDURE GetCourseProgress(IN user_id INT, IN course_id INT)
BEGIN
    SELECT 
        COUNT(DISTINCT l.id) as total_lessons,
        COUNT(DISTINCT CASE WHEN lp.completed = 1 THEN lp.lesson_id END) as completed_lessons,
        ROUND((COUNT(DISTINCT CASE WHEN lp.completed = 1 THEN lp.lesson_id END) / COUNT(DISTINCT l.id)) * 100, 2) as progress_percentage
    FROM lessons l
    JOIN sections s ON l.section_id = s.id
    LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = user_id
    WHERE s.course_id = course_id AND l.is_active = 1;
END //

CREATE PROCEDURE GetDashboardStats()
BEGIN
    SELECT 
        (SELECT COUNT(*) FROM users WHERE is_active = 1) as total_users,
        (SELECT COUNT(*) FROM courses WHERE is_active = 1) as total_courses,
        (SELECT COUNT(*) FROM subscriptions WHERE is_active = 1) as total_subscriptions,
        (SELECT SUM(price_paid) FROM subscriptions) as total_revenue,
        (SELECT COUNT(*) FROM course_completions) as total_certificates,
        (SELECT COUNT(*) FROM lesson_progress WHERE completed = 1) as total_completed_lessons;
END //

CREATE PROCEDURE CleanupOldData()
BEGIN
    -- حذف محاولات تسجيل الدخول القديمة (أكثر من 30 يوم)
    DELETE FROM login_attempts WHERE attempted_at < DATE_SUB(NOW(), INTERVAL 30 DAY);
    
    -- حذف الجلسات المنتهية
    DELETE FROM user_sessions WHERE expires_at < NOW();
    
    -- حذف طلبات إعادة تعيين كلمة المرور المنتهية
    DELETE FROM password_resets WHERE expires_at < NOW();
    
    -- حذف سجلات API القديمة (أكثر من 90 يوم)
    DELETE FROM api_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY);
    
    -- حذف سجلات النشاط القديمة (أكثر من 180 يوم)
    DELETE FROM activity_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 180 DAY);
END //

DELIMITER ;

-- إنشاء triggers مفيدة
DELIMITER //

-- Trigger لتحديث عدد استخدامات كود الاشتراك
CREATE TRIGGER update_subscription_code_usage
    AFTER INSERT ON subscriptions
    FOR EACH ROW
BEGIN
    IF NEW.subscription_code IS NOT NULL THEN
        UPDATE subscription_codes 
        SET current_uses = current_uses + 1,
            used_by = NEW.user_id,
            used_at = NOW()
        WHERE code = NEW.subscription_code;
    END IF;
END //

-- Trigger لإنشاء إشعار عند التسجيل في دورة
CREATE TRIGGER notify_course_enrollment
    AFTER INSERT ON subscriptions
    FOR EACH ROW
BEGIN
    INSERT INTO notifications (user_id, title, message, type, data)
    VALUES (
        NEW.user_id,
        'تم التسجيل في دورة جديدة',
        CONCAT('تم تسجيلك بنجاح في الدورة. يمكنك الآن البدء في التعلم!'),
        'course_enrolled',
        JSON_OBJECT('course_id', NEW.course_id, 'subscription_id', NEW.id)
    );
END //

-- Trigger لإنشاء إشعار عند إكمال دورة
CREATE TRIGGER notify_course_completion
    AFTER INSERT ON course_completions
    FOR EACH ROW
BEGIN
    INSERT INTO notifications (user_id, title, message, type, data)
    VALUES (
        NEW.user_id,
        'تهانينا! تم إكمال الدورة',
        CONCAT('أحسنت! لقد أكملت الدورة بنجاح وحصلت على شهادة إتمام.'),
        'course_completed',
        JSON_OBJECT('course_id', NEW.course_id, 'certificate_code', NEW.certificate_code)
    );
END //

DELIMITER ;

-- تفعيل event scheduler لتشغيل المهام المجدولة
SET GLOBAL event_scheduler = ON;

-- إنشاء events مجدولة
DELIMITER //

-- تنظيف البيانات القديمة يومياً في الساعة 2:00 صباحاً
CREATE EVENT cleanup_old_data
ON SCHEDULE EVERY 1 DAY
STARTS TIMESTAMP(CURRENT_DATE + INTERVAL 1 DAY, '02:00:00')
DO
BEGIN
    CALL CleanupOldData();
END //

-- إنشاء نسخة احتياطية أسبوعية
CREATE EVENT weekly_backup_reminder
ON SCHEDULE EVERY 1 WEEK
STARTS TIMESTAMP(CURRENT_DATE + INTERVAL (7 - WEEKDAY(CURRENT_DATE)) DAY, '01:00:00')
DO
BEGIN
    INSERT INTO system_notifications (type, message, created_at)
    VALUES ('backup_reminder', 'حان وقت إنشاء نسخة احتياطية من قاعدة البيانات', NOW());
END //

DELIMITER ;

SET FOREIGN_KEY_CHECKS = 1;

-- إنشاء مستخدم قاعدة البيانات
-- CREATE USER 'trend_user'@'localhost' IDENTIFIED BY 'SecureP@ssw0rd123!';
-- GRANT ALL PRIVILEGES ON trend_academy.* TO 'trend_user'@'localhost';
-- FLUSH PRIVILEGES;