<?php
/**
 * مشغل الفيديو المحمي مع VdoCipher
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 08:36:29
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/session.php';

// طلب تسجيل الدخول
$sessionManager->requireLogin();

$user = $sessionManager->getCurrentUser();
$lessonId = intval($_GET['lesson_id'] ?? 0);

if (!$lessonId) {
    header('Location: courses.php');
    exit;
}

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    
    // جلب تفاصيل الدرس والدورة
    $stmt = $pdo->prepare("
        SELECT l.*, s.name as section_name, s.course_id, c.name as course_name, c.category
        FROM lessons l
        JOIN sections s ON l.section_id = s.id
        JOIN courses c ON s.course_id = c.id
        WHERE l.id = ? AND l.is_active = 1 AND c.is_active = 1
    ");
    $stmt->execute([$lessonId]);
    $lesson = $stmt->fetch();
    
    if (!$lesson) {
        header('Location: courses.php');
        exit;
    }
    
    // التحقق من صحة الوصول للدرس
    $hasAccess = false;
    
    // فحص الدروس المجانية
    if ($lesson['is_preview']) {
        $hasAccess = true;
    } else {
        // فحص الاشتراك
        $stmt = $pdo->prepare("
            SELECT * FROM subscriptions 
            WHERE user_id = ? AND course_id = ? AND is_active = 1
        ");
        $stmt->execute([$user['id'], $lesson['course_id']]);
        
        if ($stmt->fetch()) {
            $hasAccess = true;
        }
    }
    
    // فحص الصلاحيات الإدارية
    if ($user['is_admin']) {
        $hasAccess = true;
    }
    
    if (!$hasAccess) {
        logSecurityEvent('Unauthorized lesson access attempt', 'high', [
            'user_id' => $user['id'],
            'lesson_id' => $lessonId,
            'course_id' => $lesson['course_id']
        ]);
        
        header('Location: course.php?id=' . $lesson['course_id']);
        exit;
    }
    
    // جلب جميع دروس الدورة للتنقل
    $stmt = $pdo->prepare("
        SELECT l.id, l.name, l.duration, l.is_preview, s.name as section_name,
               s.id as section_id, s.sort_order as section_order,
               l.sort_order as lesson_order,
               lp.completed, lp.last_position
        FROM lessons l
        JOIN sections s ON l.section_id = s.id
        LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = ?
        WHERE s.course_id = ? AND l.is_active = 1
        ORDER BY s.sort_order, l.sort_order
    ");
    $stmt->execute([$user['id'], $lesson['course_id']]);
    $allLessons = $stmt->fetchAll();
    
    // تنظيم الدروس حسب الأقسام
    $courseSections = [];
    foreach ($allLessons as $lessonItem) {
        $sectionId = $lessonItem['section_id'];
        if (!isset($courseSections[$sectionId])) {
            $courseSections[$sectionId] = [
                'name' => $lessonItem['section_name'],
                'lessons' => []
            ];
        }
        $courseSections[$sectionId]['lessons'][] = $lessonItem;
    }
    
    // العثور على الدرس التالي والسابق
    $currentIndex = -1;
    $flatLessons = [];
    foreach ($allLessons as $index => $lessonItem) {
        $flatLessons[] = $lessonItem;
        if ($lessonItem['id'] == $lessonId) {
            $currentIndex = $index;
        }
    }
    
    $prevLesson = $currentIndex > 0 ? $flatLessons[$currentIndex - 1] : null;
    $nextLesson = $currentIndex < count($flatLessons) - 1 ? $flatLessons[$currentIndex + 1] : null;
    
    // جلب/إنشاء سجل التقدم
    $stmt = $pdo->prepare("
        SELECT * FROM lesson_progress 
        WHERE user_id = ? AND lesson_id = ?
    ");
    $stmt->execute([$user['id'], $lessonId]);
    $progress = $stmt->fetch();
    
    if (!$progress) {
        // إنشاء سجل تقدم جديد
        $stmt = $pdo->prepare("
            INSERT INTO lesson_progress (user_id, lesson_id, started_at, ip_address)
            VALUES (?, ?, NOW(), ?)
        ");
        $stmt->execute([$user['id'], $lessonId, getRealIpAddress()]);
        
        $progress = [
            'user_id' => $user['id'],
            'lesson_id' => $lessonId,
            'last_position' => 0,
            'completed' => 0
        ];
    }
    
    // جلب ملاحظات المستخدم للدرس
    $stmt = $pdo->prepare("
        SELECT * FROM lesson_notes 
        WHERE user_id = ? AND lesson_id = ? 
        ORDER BY created_at DESC
    ");
    $stmt->execute([$user['id'], $lessonId]);
    $userNotes = $stmt->fetchAll();
    
} catch (PDOException $e) {
    logSecurityEvent('Failed to load lesson player', 'medium', ['error' => $e->getMessage()]);
    header('Location: courses.php');
    exit;
}

// تضمين ملف العرض
require_once __DIR__ . '/frontend/views/pages/player.php';
?>