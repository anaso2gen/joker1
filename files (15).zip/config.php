<?php
/**
 * ملف الإعدادات الرئيسي للمنصة التعليمية
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 08:30:09
 */

// منع الوصول المباشر
if (!defined('LEARNING_PLATFORM')) {
    define('LEARNING_PLATFORM', true);
}

// ==============================================
// إعدادات قاعدة البيانات
// ==============================================
define('DB_HOST', 'localhost');
define('DB_NAME', 'learning_platform');
define('DB_USER', 'root');  // غير هذا حسب إعدادات الخادم
define('DB_PASS', '');      // غير هذا حسب إعدادات الخادم
define('DB_CHARSET', 'utf8mb4');

// ==============================================
// إعدادات الموقع العامة
// ==============================================
define('SITE_NAME', 'منصة ترند التعليمية');
define('SITE_URL', 'http://localhost/learning-platform'); // غير هذا حسب رابط موقعك
define('ADMIN_EMAIL', 'admin@trendeducation.com');

// ==============================================
// إعدادات الأمان
// ==============================================
define('SECURITY_KEY', 'your-unique-security-key-here-64-characters-long-random-string');
define('ENCRYPTION_SALT', 'your-encryption-salt-here-32-chars');

// ==============================================
// إعدادات VdoCipher
// ==============================================
define('VDOCIPHER_API_SECRET', 'your_vdocipher_api_secret_here');
define('VDOCIPHER_API_URL', 'https://dev.vdocipher.com/api');

// ==============================================
// إعدادات الجلسة والأمان
// ==============================================
define('SESSION_TIMEOUT', 7200);        // 2 ساعة
define('MAX_LOGIN_ATTEMPTS', 5);        // محاولات تسجيل دخول
define('LOGIN_LOCKOUT_TIME', 900);      // 15 دقيقة

// ==============================================
// إعدادات البيئة
// ==============================================
define('ENVIRONMENT', 'development'); // أو 'production'
define('DEBUG_MODE', true);           // false في الإنتاج

// ==============================================
// إعدادات الملفات والرفع
// ==============================================
define('MAX_FILE_SIZE', 50 * 1024 * 1024); // 50 ميجابايت
define('UPLOAD_PATH', __DIR__ . '/uploads/');

// ==============================================
// إعدادات التوقيت
// ==============================================
date_default_timezone_set('Asia/Riyadh');

// ==============================================
// إعدادات عرض الأخطاء (للتطوير فقط)
// ==============================================
if (ENVIRONMENT === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('log_errors', 1);
    ini_set('error_log', __DIR__ . '/logs/php_errors.log');
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// ==============================================
// بدء الجلسة إذا لم تكن مبدوءة
// ==============================================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>