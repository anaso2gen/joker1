/**
 * سكريپت لوحة التحكم المكتمل
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 10:32:41
 */

'use strict';

const DashboardManager = {
    // إعدادات لوحة التحكم
    config: {
        refreshInterval: 30000, // 30 ثانية
        chartAnimationDuration: 1000,
        notificationAutoHide: 5000,
        maxNotifications: 10,
        autoSaveInterval: 60000, // دقيقة واحدة
        sidebarStateKey: 'dashboard_sidebar_state'
    },
    
    // حالة لوحة التحكم
    state: {
        isInitialized: false,
        sidebarCollapsed: false,
        activeModule: null,
        dashboardData: {},
        refreshTimer: null,
        charts: {},
        notifications: [],
        isDarkMode: false
    },
    
    // تهيئة لوحة التحكم
    init() {
        if (this.state.isInitialized) return;
        
        try {
            this.initializeSidebar();
            this.initializeCharts();
            this.initializeDataTables();
            this.initializeModals();
            this.initializeNotifications();
            this.initializeBulkActions();
            this.initializeSearch();
            this.initializeFilters();
            this.initializeAutoRefresh();
            this.initializeKeyboardShortcuts();
            this.loadDashboardData();
            
            this.state.isInitialized = true;
            console.log('Dashboard Manager initialized successfully');
        } catch (error) {
            console.error('Dashboard initialization failed:', error);
        }
    },
    
    // تهيئة الشريط الجانبي
    initializeSidebar() {
        const sidebar = document.querySelector('.dashboard-sidebar');
        const toggleBtn = document.querySelector('.sidebar-toggle');
        const overlay = document.querySelector('.sidebar-overlay');
        
        if (!sidebar || !toggleBtn) return;
        
        // استرجاع حالة الشريط الجانبي
        const savedState = localStorage.getItem(this.config.sidebarStateKey);
        if (savedState === 'collapsed') {
            this.collapseSidebar();
        }
        
        // تبديل الشريط الجانبي
        toggleBtn.addEventListener('click', () => {
            this.toggleSidebar();
        });
        
        // إغلاق بالنقر على الخلفية (موبايل)
        if (overlay) {
            overlay.addEventListener('click', () => {
                this.closeSidebar();
            });
        }
        
        // تهيئة القوائم المنسدلة
        this.initializeSidebarDropdowns();
        
        // تهيئة البحث في الشريط الجانبي
        this.initializeSidebarSearch();
    },
    
    // تهيئة القوائم المنسدلة في الشريط الجانبي
    initializeSidebarDropdowns() {
        const dropdownToggles = document.querySelectorAll('.nav-dropdown-toggle');
        
        dropdownToggles.forEach(toggle => {
            toggle.addEventListener('click', (e) => {
                e.preventDefault();
                const dropdown = toggle.nextElementSibling;
                const isOpen = dropdown.classList.contains('show');
                
                // إغلاق جميع القوائم المنسدلة الأخرى
                document.querySelectorAll('.nav-dropdown.show').forEach(dd => {
                    if (dd !== dropdown) {
                        dd.classList.remove('show');
                        dd.previousElementSibling.classList.remove('active');
                    }
                });
                
                // تبديل القائمة الحالية
                dropdown.classList.toggle('show', !isOpen);
                toggle.classList.toggle('active', !isOpen);
            });
        });
    },
    
    // تهيئة البحث في الشريط الجانبي
    initializeSidebarSearch() {
        const searchInput = document.querySelector('.sidebar-search input');
        if (!searchInput) return;
        
        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase();
            this.filterSidebarItems(query);
        });
    },
    
    // فلترة عناصر الشريط الجانبي
    filterSidebarItems(query) {
        const navItems = document.querySelectorAll('.nav-item');
        
        navItems.forEach(item => {
            const link = item.querySelector('.nav-link');
            const text = link.textContent.toLowerCase();
            const shouldShow = text.includes(query);
            
            item.style.display = shouldShow ? 'block' : 'none';
        });
    },
    
    // تبديل الشريط الجانبي
    toggleSidebar() {
        if (this.state.sidebarCollapsed) {
            this.expandSidebar();
        } else {
            this.collapseSidebar();
        }
    },
    
    // طي الشريط الجانبي
    collapseSidebar() {
        const sidebar = document.querySelector('.dashboard-sidebar');
        const mainContent = document.querySelector('.dashboard-main');
        
        sidebar.classList.add('collapsed');
        document.body.classList.add('sidebar-collapsed');
        
        this.state.sidebarCollapsed = true;
        localStorage.setItem(this.config.sidebarStateKey, 'collapsed');
        
        // إخفاء النصوص والقوائم المنسدلة
        document.querySelectorAll('.nav-dropdown.show').forEach(dropdown => {
            dropdown.classList.remove('show');
        });
    },
    
    // توسيع الشريط الجانبي
    expandSidebar() {
        const sidebar = document.querySelector('.dashboard-sidebar');
        
        sidebar.classList.remove('collapsed');
        document.body.classList.remove('sidebar-collapsed');
        
        this.state.sidebarCollapsed = false;
        localStorage.setItem(this.config.sidebarStateKey, 'expanded');
    },
    
    // إغلاق الشريط الجانبي (موبايل)
    closeSidebar() {
        const sidebar = document.querySelector('.dashboard-sidebar');
        const overlay = document.querySelector('.sidebar-overlay');
        
        sidebar.classList.remove('open');
        if (overlay) overlay.classList.remove('show');
    },
    
    // تهيئة الرسوم البيانية
    initializeCharts() {
        this.initializeStatsCards();
        this.initializeRevenueChart();
        this.initializeUsersChart();
        this.initializeCoursesChart();
        this.initializeActivityChart();
    },
    
    // تهيئة بطاقات الإحصائيات
    initializeStatsCards() {
        const statCards = document.querySelectorAll('.stat-card');
        
        statCards.forEach((card, index) => {
            // تأثير الظهور التدريجي
            setTimeout(() => {
                card.classList.add('animate-in');
            }, index * 100);
            
            // تأثير العد التصاعدي
            const valueElement = card.querySelector('.stat-value');
            if (valueElement) {
                this.animateCounter(valueElement);
            }
        });
    },
    
    // تحريك العداد
    animateCounter(element) {
        const target = parseInt(element.textContent.replace(/[^\d]/g, ''));
        const duration = 2000;
        const steps = 60;
        const stepValue = target / steps;
        const stepDuration = duration / steps;
        
        let current = 0;
        const timer = setInterval(() => {
            current += stepValue;
            
            if (current >= target) {
                current = target;
                clearInterval(timer);
            }
            
            element.textContent = Math.floor(current).toLocaleString('ar-SA');
        }, stepDuration);
    },
    
    // تهيئة مخطط الإيرادات
    initializeRevenueChart() {
        const canvas = document.getElementById('revenueChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        this.state.charts.revenue = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو'],
                datasets: [{
                    label: 'الإيرادات',
                    data: [12000, 19000, 15000, 25000, 22000, 30000],
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                        labels: {
                            usePointStyle: true,
                            font: {
                                family: 'Cairo'
                            }
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleFont: {
                            family: 'Cairo'
                        },
                        bodyFont: {
                            family: 'Cairo'
                        },
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': ' + 
                                       context.parsed.y.toLocaleString('ar-SA') + ' ريال';
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            font: {
                                family: 'Cairo'
                            }
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        },
                        ticks: {
                            font: {
                                family: 'Cairo'
                            },
                            callback: function(value) {
                                return value.toLocaleString('ar-SA') + ' ريال';
                            }
                        }
                    }
                },
                animation: {
                    duration: this.config.chartAnimationDuration,
                    easing: 'easeInOutQuart'
                }
            }
        });
    },
    
    // تهيئة مخطط المستخدمين
    initializeUsersChart() {
        const canvas = document.getElementById('usersChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        this.state.charts.users = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['مستخدمين نشطين', 'مستخدمين جدد', 'مستخدمين غير نشطين'],
                datasets: [{
                    data: [65, 25, 10],
                    backgroundColor: [
                        '#48bb78',
                        '#667eea',
                        '#ed8936'
                    ],
                    borderWidth: 0,
                    cutout: '70%'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            padding: 20,
                            font: {
                                family: 'Cairo'
                            }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((context.parsed * 100) / total).toFixed(1);
                                return context.label + ': ' + percentage + '%';
                            }
                        }
                    }
                },
                animation: {
                    animateRotate: true,
                    duration: this.config.chartAnimationDuration
                }
            }
        });
    },
    
    // تهيئة مخطط الدورات
    initializeCoursesChart() {
        const canvas = document.getElementById('coursesChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        this.state.charts.courses = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['البرمجة', 'التسويق', 'التصميم', 'الأعمال', 'اللغات'],
                datasets: [{
                    label: 'عدد الدورات',
                    data: [45, 32, 28, 35, 20],
                    backgroundColor: [
                        '#667eea',
                        '#764ba2',
                        '#f093fb',
                        '#48bb78',
                        '#ed8936'
                    ],
                    borderRadius: 8,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            font: {
                                family: 'Cairo'
                            }
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        },
                        ticks: {
                            font: {
                                family: 'Cairo'
                            }
                        }
                    }
                },
                animation: {
                    delay: (context) => context.dataIndex * 100,
                    duration: this.config.chartAnimationDuration
                }
            }
        });
    },
    
    // تهيئة مخطط النشاط
    initializeActivityChart() {
        const canvas = document.getElementById('activityChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        this.state.charts.activity = new Chart(ctx, {
            type: 'line',
            data: {
                labels: Array.from({length: 24}, (_, i) => i + ':00'),
                datasets: [{
                    label: 'نشاط المستخدمين',
                    data: [20, 15, 10, 8, 12, 25, 45, 80, 120, 150, 180, 200, 190, 170, 160, 140, 130, 110, 90, 70, 50, 40, 30, 25],
                    borderColor: '#48bb78',
                    backgroundColor: 'rgba(72, 187, 120, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 0,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            maxTicksLimit: 6,
                            font: {
                                family: 'Cairo'
                            }
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        },
                        ticks: {
                            font: {
                                family: 'Cairo'
                            }
                        }
                    }
                },
                animation: {
                    duration: this.config.chartAnimationDuration,
                    easing: 'easeInOutQuart'
                }
            }
        });
    },
    
    // تهيئة الجداول
    initializeDataTables() {
        const tables = document.querySelectorAll('.data-table');
        
        tables.forEach(table => {
            this.enhanceTable(table);
        });
        
        // تهيئة البحث في الجداول
        this.initializeTableSearch();
        
        // تهيئة الترتيب
        this.initializeTableSorting();
        
        // تهيئة التصفية
        this.initializeTableFiltering();
        
        // تهيئة التصفح
        this.initializeTablePagination();
    },
    
    // تحسين الجدول
    enhanceTable(table) {
        // إضافة فئات CSS
        table.classList.add('enhanced-table');
        
        // تمييز الصفوف عند التمرير
        const rows = table.querySelectorAll('tbody tr');
        rows.forEach(row => {
            row.addEventListener('mouseenter', () => {
                row.classList.add('highlighted');
            });
            
            row.addEventListener('mouseleave', () => {
                row.classList.remove('highlighted');
            });
        });
        
        // إضافة أزرار الإجراءات
        this.addActionButtons(table);
    },
    
    // إضافة أزرار الإجراءات
    addActionButtons(table) {
        const actionCells = table.querySelectorAll('td[data-actions]');
        
        actionCells.forEach(cell => {
            const actions = cell.dataset.actions.split(',');
            const buttonsHtml = actions.map(action => {
                const actionConfig = this.getActionConfig(action.trim());
                return `
                    <button class="action-btn ${action.trim()}" 
                            data-action="${action.trim()}" 
                            title="${actionConfig.title}">
                        <i class="${actionConfig.icon}"></i>
                    </button>
                `;
            }).join('');
            
            cell.innerHTML = buttonsHtml;
            
            // إضافة مستمعي الأحداث
            cell.querySelectorAll('.action-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    this.handleTableAction(e.target.closest('button'), table);
                });
            });
        });
    },
    
    // الحصول على إعدادات الإجراء
    getActionConfig(action) {
        const configs = {
            'view': { icon: 'fas fa-eye', title: 'عرض' },
            'edit': { icon: 'fas fa-edit', title: 'تعديل' },
            'delete': { icon: 'fas fa-trash', title: 'حذف' },
            'download': { icon: 'fas fa-download', title: 'تحميل' },
            'approve': { icon: 'fas fa-check', title: 'موافقة' },
            'reject': { icon: 'fas fa-times', title: 'رفض' }
        };
        
        return configs[action] || { icon: 'fas fa-cog', title: action };
    },
    
    // معالجة إجراءات الجدول
    handleTableAction(button, table) {
        const action = button.dataset.action;
        const row = button.closest('tr');
        const id = row.dataset.id;
        
        switch (action) {
            case 'view':
                this.viewRecord(id, table);
                break;
            case 'edit':
                this.editRecord(id, table);
                break;
            case 'delete':
                this.deleteRecord(id, table);
                break;
            case 'download':
                this.downloadRecord(id, table);
                break;
            case 'approve':
                this.approveRecord(id, table);
                break;
            case 'reject':
                this.rejectRecord(id, table);
                break;
            default:
                console.log('Unknown action:', action);
        }
    },
    
    // تهيئة البحث في الجداول
    initializeTableSearch() {
        const searchInputs = document.querySelectorAll('.table-search input');
        
        searchInputs.forEach(input => {
            let searchTimeout;
            
            input.addEventListener('input', (e) => {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    this.searchTable(e.target);
                }, 300);
            });
        });
    },
    
    // البحث في الجدول
    searchTable(input) {
        const table = input.closest('.dashboard-table').querySelector('table');
        const query = input.value.toLowerCase();
        const rows = table.querySelectorAll('tbody tr');
        
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            const shouldShow = text.includes(query);
            row.style.display = shouldShow ? '' : 'none';
        });
        
        this.updateTableStats(table);
    },
    
    // تهيئة ترتيب الجداول
    initializeTableSorting() {
        const sortableHeaders = document.querySelectorAll('th[data-sort]');
        
        sortableHeaders.forEach(header => {
            header.style.cursor = 'pointer';
            header.innerHTML += ' <i class="fas fa-sort sort-icon"></i>';
            
            header.addEventListener('click', () => {
                this.sortTable(header);
            });
        });
    },
    
    // ترتيب الجدول
    sortTable(header) {
        const table = header.closest('table');
        const tbody = table.querySelector('tbody');
        const rows = Array.from(tbody.querySelectorAll('tr'));
        const columnIndex = Array.from(header.parentNode.children).indexOf(header);
        const sortType = header.dataset.sort;
        const isAscending = !header.classList.contains('asc');
        
        // إزالة فئات الترتيب من جميع الرؤوس
        table.querySelectorAll('th').forEach(th => {
            th.classList.remove('asc', 'desc');
            const icon = th.querySelector('.sort-icon');
            if (icon) icon.className = 'fas fa-sort sort-icon';
        });
        
        // إضافة فئة الترتيب للرأس الحالي
        header.classList.add(isAscending ? 'asc' : 'desc');
        const icon = header.querySelector('.sort-icon');
        if (icon) {
            icon.className = `fas fa-sort-${isAscending ? 'up' : 'down'} sort-icon`;
        }
        
        // ترتيب الصفوف
        rows.sort((a, b) => {
            const aValue = a.children[columnIndex].textContent.trim();
            const bValue = b.children[columnIndex].textContent.trim();
            
            let comparison = 0;
            
            if (sortType === 'number') {
                comparison = parseFloat(aValue) - parseFloat(bValue);
            } else if (sortType === 'date') {
                comparison = new Date(aValue) - new Date(bValue);
            } else {
                comparison = aValue.localeCompare(bValue, 'ar');
            }
            
            return isAscending ? comparison : -comparison;
        });
        
        // إعادة ترتيب DOM
        rows.forEach(row => tbody.appendChild(row));
    },
    
    // تهيئة التصفية
    initializeTableFiltering() {
        const filterSelects = document.querySelectorAll('.table-filter select');
        
        filterSelects.forEach(select => {
            select.addEventListener('change', (e) => {
                this.filterTable(e.target);
            });
        });
    },
    
    // تصفية الجدول
    filterTable(select) {
        const table = select.closest('.dashboard-table').querySelector('table');
        const column = select.dataset.column;
        const value = select.value;
        const rows = table.querySelectorAll('tbody tr');
        
        rows.forEach(row => {
            const cellValue = row.cells[column].textContent.trim();
            const shouldShow = !value || cellValue === value;
            row.style.display = shouldShow ? '' : 'none';
        });
        
        this.updateTableStats(table);
    },
    
    // تهيئة تصفح الجداول
    initializeTablePagination() {
        const paginationContainers = document.querySelectorAll('.table-pagination');
        
        paginationContainers.forEach(container => {
            this.setupPagination(container);
        });
    },
    
    // إعداد التصفح
    setupPagination(container) {
        const table = container.closest('.dashboard-table').querySelector('table');
        const rows = Array.from(table.querySelectorAll('tbody tr'));
        const rowsPerPage = parseInt(container.dataset.perPage) || 10;
        const totalPages = Math.ceil(rows.length / rowsPerPage);
        
        let currentPage = 1;
        
        const showPage = (page) => {
            const start = (page - 1) * rowsPerPage;
            const end = start + rowsPerPage;
            
            rows.forEach((row, index) => {
                row.style.display = (index >= start && index < end) ? '' : 'none';
            });
            
            this.updatePaginationButtons(container, page, totalPages);
        };
        
        // إنشاء أزرار التصفح
        this.createPaginationButtons(container, totalPages, showPage);
        
        // عرض الصفحة الأولى
        showPage(1);
    },
    
    // إنشاء أزرار التصفح
    createPaginationButtons(container, totalPages, showPage) {
        container.innerHTML = `
            <button class="btn btn-sm btn-outline-primary" data-page="prev" disabled>
                <i class="fas fa-chevron-right"></i>
            </button>
            <span class="pagination-info">
                صفحة <span class="current-page">1</span> من <span class="total-pages">${totalPages}</span>
            </span>
            <button class="btn btn-sm btn-outline-primary" data-page="next" ${totalPages <= 1 ? 'disabled' : ''}>
                <i class="fas fa-chevron-left"></i>
            </button>
        `;
        
        let currentPage = 1;
        
        container.addEventListener('click', (e) => {
            const button = e.target.closest('button');
            if (!button) return;
            
            const action = button.dataset.page;
            
            if (action === 'prev' && currentPage > 1) {
                currentPage--;
                showPage(currentPage);
            } else if (action === 'next' && currentPage < totalPages) {
                currentPage++;
                showPage(currentPage);
            }
        });
    },
    
    // تحديث أزرار التصفح
    updatePaginationButtons(container, currentPage, totalPages) {
        const prevBtn = container.querySelector('[data-page="prev"]');
        const nextBtn = container.querySelector('[data-page="next"]');
        const currentPageSpan = container.querySelector('.current-page');
        
        prevBtn.disabled = currentPage <= 1;
        nextBtn.disabled = currentPage >= totalPages;
        currentPageSpan.textContent = currentPage;
    },
    
    // تحديث إحصائيات الجدول
    updateTableStats(table) {
        const totalRows = table.querySelectorAll('tbody tr').length;
        const visibleRows = table.querySelectorAll('tbody tr:not([style*="display: none"])').length;
        
        const statsContainer = table.closest('.dashboard-table').querySelector('.table-stats');
        if (statsContainer) {
            statsContainer.textContent = `عرض ${visibleRows} من ${totalRows} سجل`;
        }
    },
    
    // تهيئة النماذج المنبثقة
    initializeModals() {
        // تهيئة نموذج إضافة/تعديل المستخدم
        this.initializeUserModal();
        
        // تهيئة نموذج إضافة/تعديل الدورة
        this.initializeCourseModal();
        
        // تهيئة نموذج تأكيد الحذف
        this.initializeDeleteModal();
        
        // تهيئة نموذج الإعدادات
        this.initializeSettingsModal();
    },
    
    // تهيئة نموذج المستخدم
    initializeUserModal() {
        const modal = document.getElementById('userModal');
        if (!modal) return;
        
        const form = modal.querySelector('form');
        const submitBtn = modal.querySelector('.btn-primary');
        
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            try {
                this.showLoading(submitBtn);
                
                const formData = new FormData(form);
                const isEdit = formData.get('user_id');
                const action = isEdit ? 'update_user' : 'create_user';
                
                const response = await APIManager.post(action, Object.fromEntries(formData));
                
                if (response.success) {
                    this.hideModal('userModal');
                    this.showSuccess(isEdit ? 'تم تحديث المستخدم بنجاح' : 'تم إضافة المستخدم بنجاح');
                    this.refreshTable('usersTable');
                } else {
                    throw new Error(response.message);
                }
            } catch (error) {
                this.showError(error.message);
            } finally {
                this.hideLoading(submitBtn);
            }
        });
    },
    
    // تهيئة نموذج الدورة
    initializeCourseModal() {
        const modal = document.getElementById('courseModal');
        if (!modal) return;
        
        const form = modal.querySelector('form');
        const imageInput = modal.querySelector('input[type="file"]');
        const imagePreview = modal.querySelector('.image-preview');
        
        // معاينة الصورة
        if (imageInput && imagePreview) {
            imageInput.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        imagePreview.src = e.target.result;
                        imagePreview.style.display = 'block';
                    };
                    reader.readAsDataURL(file);
                }
            });
        }
        
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            try {
                const formData = new FormData(form);
                const isEdit = formData.get('course_id');
                const action = isEdit ? 'update_course' : 'create_course';
                
                const response = await APIManager.post(action, formData);
                
                if (response.success) {
                    this.hideModal('courseModal');
                    this.showSuccess(isEdit ? 'تم تحديث الدورة بنجاح' : 'تم إضافة الدورة بنجاح');
                    this.refreshTable('coursesTable');
                } else {
                    throw new Error(response.message);
                }
            } catch (error) {
                this.showError(error.message);
            }
        });
    },
    
    // تهيئة نموذج الحذف
    initializeDeleteModal() {
        const modal = document.getElementById('deleteModal');
        if (!modal) return;
        
        const confirmBtn = modal.querySelector('.btn-danger');
        
        confirmBtn.addEventListener('click', async () => {
            try {
                this.showLoading(confirmBtn);
                
                const entityType = modal.dataset.entityType;
                const entityId = modal.dataset.entityId;
                
                const response = await APIManager.delete(`delete_${entityType}`, { id: entityId });
                
                if (response.success) {
                    this.hideModal('deleteModal');
                    this.showSuccess('تم الحذف بنجاح');
                    this.refreshTable(`${entityType}sTable`);
                } else {
                    throw new Error(response.message);
                }
            } catch (error) {
                this.showError(error.message);
            } finally {
                this.hideLoading(confirmBtn);
            }
        });
    },
    
    // تهيئة الإشعارات
    initializeNotifications() {
        this.loadNotifications();
        this.setupNotificationPolling();
    },
    
    // تحميل الإشعارات
    async loadNotifications() {
        try {
            const response = await NotificationAPI.getNotifications();
            
            if (response.success) {
                this.displayNotifications(response.data);
                this.updateNotificationBadge(response.data);
            }
        } catch (error) {
            console.error('Failed to load notifications:', error);
        }
    },
    
    // عرض الإشعارات
    displayNotifications(notifications) {
        const container = document.querySelector('.notifications-list');
        if (!container) return;
        
        if (notifications.length === 0) {
            container.innerHTML = '<div class="no-notifications">لا توجد إشعارات جديدة</div>';
            return;
        }
        
        container.innerHTML = notifications.map(notification => `
            <div class="notification-item ${notification.is_read ? 'read' : 'unread'}" 
                 data-id="${notification.id}">
                <div class="notification-icon ${notification.type}">
                    <i class="${this.getNotificationIcon(notification.type)}"></i>
                </div>
                <div class="notification-content">
                    <h6>${notification.title}</h6>
                    <p>${notification.message}</p>
                    <span class="notification-time">${this.formatTime(notification.created_at)}</span>
                </div>
                ${!notification.is_read ? '<div class="notification-dot"></div>' : ''}
            </div>
        `).join('');
        
        // إضافة مستمعي الأحداث
        container.querySelectorAll('.notification-item').forEach(item => {
            item.addEventListener('click', () => {
                this.markNotificationAsRead(item.dataset.id);
            });
        });
    },
    
    // تحديث شارة الإشعارات
    updateNotificationBadge(notifications) {
        const badge = document.querySelector('.notifications-badge');
        if (!badge) return;
        
        const unreadCount = notifications.filter(n => !n.is_read).length;
        
        if (unreadCount > 0) {
            badge.textContent = unreadCount > 99 ? '99+' : unreadCount;
            badge.style.display = 'block';
        } else {
            badge.style.display = 'none';
        }
    },
    
    // إعداد استطلاع الإشعارات
    setupNotificationPolling() {
        setInterval(() => {
            this.loadNotifications();
        }, 30000); // كل 30 ثانية
    },
    
    // تهيئة الإجراءات المجمعة
    initializeBulkActions() {
        const selectAllCheckbox = document.querySelector('.select-all');
        const bulkActionSelect = document.querySelector('.bulk-actions select');
        const applyBulkBtn = document.querySelector('.apply-bulk-action');
        
        if (selectAllCheckbox) {
            selectAllCheckbox.addEventListener('change', (e) => {
                this.toggleAllRows(e.target.checked);
            });
        }
        
        if (applyBulkBtn) {
            applyBulkBtn.addEventListener('click', () => {
                this.applyBulkAction();
            });
        }
        
        // مراقبة تغيير تحديد الصفوف
        document.addEventListener('change', (e) => {
            if (e.target.classList.contains('row-checkbox')) {
                this.updateBulkActionUI();
            }
        });
    },
    
    // تبديل تحديد جميع الصفوف
    toggleAllRows(checked) {
        const checkboxes = document.querySelectorAll('.row-checkbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = checked;
        });
        
        this.updateBulkActionUI();
    },
    
    // تحديث واجهة الإجراءات المجمعة
    updateBulkActionUI() {
        const selectedCount = document.querySelectorAll('.row-checkbox:checked').length;
        const bulkActionContainer = document.querySelector('.bulk-actions');
        
        if (bulkActionContainer) {
            bulkActionContainer.style.display = selectedCount > 0 ? 'block' : 'none';
            
            const countSpan = bulkActionContainer.querySelector('.selected-count');
            if (countSpan) {
                countSpan.textContent = selectedCount;
            }
        }
    },
    
    // تطبيق الإجراء المجمع
    async applyBulkAction() {
        const action = document.querySelector('.bulk-actions select').value;
        const selectedIds = Array.from(document.querySelectorAll('.row-checkbox:checked'))
                                .map(cb => cb.value);
        
        if (!action || selectedIds.length === 0) {
            this.showWarning('يرجى اختيار إجراء وتحديد عناصر');
            return;
        }
        
        try {
            const response = await APIManager.post('bulk_action', {
                action: action,
                ids: selectedIds
            });
            
            if (response.success) {
                this.showSuccess(`تم تطبيق الإجراء على ${selectedIds.length} عنصر`);
                this.refreshCurrentTable();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.showError(error.message);
        }
    },
    
    // تهيئة البحث العام
    initializeSearch() {
        const searchInput = document.querySelector('.header-search input');
        if (!searchInput) return;
        
        let searchTimeout;
        
        searchInput.addEventListener('input', (e) => {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                this.performGlobalSearch(e.target.value);
            }, 300);
        });
    },
    
    // البحث العام
    async performGlobalSearch(query) {
        if (query.length < 2) return;
        
        try {
            const response = await APIManager.get('global_search', { query });
            
            if (response.success) {
                this.displaySearchResults(response.data);
            }
        } catch (error) {
            console.error('Search failed:', error);
        }
    },
    
    // عرض نتائج البحث
    displaySearchResults(results) {
        const dropdown = document.querySelector('.search-dropdown');
        if (!dropdown) return;
        
        if (results.length === 0) {
            dropdown.innerHTML = '<div class="search-empty">لا توجد نتائج</div>';
        } else {
            dropdown.innerHTML = results.map(result => `
                <a href="${result.url}" class="search-result">
                    <i class="${result.icon}"></i>
                    <div>
                        <strong>${result.title}</strong>
                        <small>${result.type}</small>
                    </div>
                </a>
            `).join('');
        }
        
        dropdown.classList.add('show');
    },
    
    // تهيئة الفلاتر
    initializeFilters() {
        const filterForm = document.querySelector('.filters-form');
        if (!filterForm) return;
        
        filterForm.addEventListener('change', () => {
            this.applyFilters();
        });
        
        // زر إعادة تعيين الفلاتر
        const resetBtn = document.querySelector('.reset-filters');
        if (resetBtn) {
            resetBtn.addEventListener('click', () => {
                this.resetFilters();
            });
        }
    },
    
    // تطبيق الفلاتر
    async applyFilters() {
        const filterForm = document.querySelector('.filters-form');
        const formData = new FormData(filterForm);
        const filters = Object.fromEntries(formData);
        
        try {
            const response = await APIManager.get('get_filtered_data', filters);
            
            if (response.success) {
                this.updateTableData(response.data);
            }
        } catch (error) {
            this.showError('فشل في تطبيق الفلاتر');
        }
    },
    
    // تهيئة التحديث التلقائي
    initializeAutoRefresh() {
        this.state.refreshTimer = setInterval(() => {
            this.refreshDashboardData();
        }, this.config.refreshInterval);
        
        // إيقاف التحديث عند عدم النشاط
        let inactivityTimer;
        const resetInactivityTimer = () => {
            clearTimeout(inactivityTimer);
            inactivityTimer = setTimeout(() => {
                clearInterval(this.state.refreshTimer);
            }, 5 * 60 * 1000); // 5 دقائق
        };
        
        ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'].forEach(event => {
            document.addEventListener(event, resetInactivityTimer, true);
        });
    },
    
    // تحديث بيانات لوحة التحكم
    async refreshDashboardData() {
        try {
            const response = await AdminAPI.getDashboardStats();
            
            if (response.success) {
                this.updateDashboardStats(response.data);
            }
        } catch (error) {
            console.error('Failed to refresh dashboard data:', error);
        }
    },
    
    // تحديث إحصائيات لوحة التحكم
    updateDashboardStats(data) {
        // تحديث بطاقات الإحصائيات
        Object.keys(data.stats).forEach(key => {
            const card = document.querySelector(`[data-stat="${key}"]`);
            if (card) {
                const valueElement = card.querySelector('.stat-value');
                if (valueElement) {
                    valueElement.textContent = data.stats[key].toLocaleString('ar-SA');
                }
            }
        });
        
        // تحديث الرسوم البيانية
        this.updateCharts(data.charts);
    },
    
    // تحديث الرسوم البيانية
    updateCharts(chartsData) {
        Object.keys(chartsData).forEach(chartName => {
            const chart = this.state.charts[chartName];
            if (chart) {
                chart.data = chartsData[chartName];
                chart.update('none'); // تحديث بدون أنيميشن
            }
        });
    },
    
    // تهيئة اختصارات لوحة المفاتيح
    initializeKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Ctrl + / للبحث
            if (e.ctrlKey && e.key === '/') {
                e.preventDefault();
                const searchInput = document.querySelector('.header-search input');
                if (searchInput) searchInput.focus();
            }
            
            // Ctrl + N لإضافة جديد
            if (e.ctrlKey && e.key === 'n') {
                e.preventDefault();
                const addBtn = document.querySelector('.btn-add-new');
                if (addBtn) addBtn.click();
            }
            
            // ESC لإغلاق النماذج
            if (e.key === 'Escape') {
                const openModal = document.querySelector('.modal.show');
                if (openModal) {
                    this.hideModal(openModal.id);
                }
            }
        });
    },
    
    // تحميل بيانات لوحة التحكم
    async loadDashboardData() {
        try {
            const response = await AdminAPI.getDashboardStats();
            
            if (response.success) {
                this.state.dashboardData = response.data;
                this.updateDashboardStats(response.data);
            }
        } catch (error) {
            console.error('Failed to load dashboard data:', error);
            this.showError('فشل في تحميل بيانات لوحة التحكم');
        }
    },
    
    // دوال مساعدة
    showModal(modalId, data = {}) {
        const modal = document.getElementById(modalId);
        if (modal) {
            // تعبئة البيانات إذا كانت متوفرة
            if (Object.keys(data).length > 0) {
                this.populateModalData(modal, data);
            }
            
            modal.classList.add('show');
            modal.style.display = 'block';
            document.body.classList.add('modal-open');
        }
    },
    
    hideModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('show');
            setTimeout(() => {
                modal.style.display = 'none';
                document.body.classList.remove('modal-open');
                this.clearModalData(modal);
            }, 300);
        }
    },
    
    populateModalData(modal, data) {
        Object.keys(data).forEach(key => {
            const field = modal.querySelector(`[name="${key}"]`);
            if (field) {
                field.value = data[key];
            }
        });
    },
    
    clearModalData(modal) {
        const form = modal.querySelector('form');
        if (form) {
            form.reset();
        }
    },
    
    showLoading(button) {
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري المعالجة...';
    },
    
    hideLoading(button, originalText) {
        button.disabled = false;
        button.innerHTML = originalText || 'حفظ';
    },
    
    showSuccess(message) {
        this.showNotification(message, 'success');
    },
    
    showError(message) {
        this.showNotification(message, 'error');
    },
    
    showWarning(message) {
        this.showNotification(message, 'warning');
    },
    
    showNotification(message, type) {
        if (window.showNotification) {
            window.showNotification(message, type);
        } else {
            alert(message);
        }
    },
    
    refreshTable(tableId) {
        const table = document.getElementById(tableId);
        if (table) {
            // إعادة تحميل بيانات الجدول
            this.loadTableData(table);
        }
    },
    
    refreshCurrentTable() {
        const activeTable = document.querySelector('.data-table:not([style*="display: none"])');
        if (activeTable) {
            this.refreshTable(activeTable.id);
        }
    },
    
    formatTime(timestamp) {
        const date = new Date(timestamp);
        const now = new Date();
        const diff = now - date;
        
        const minutes = Math.floor(diff / 60000);
        const hours = Math.floor(diff / 3600000);
        const days = Math.floor(diff / 86400000);
        
        if (minutes < 1) return 'الآن';
        if (minutes < 60) return `منذ ${minutes} دقيقة`;
        if (hours < 24) return `منذ ${hours} ساعة`;
        if (days < 7) return `منذ ${days} يوم`;
        
        return date.toLocaleDateString('ar-SA');
    },
    
    getNotificationIcon(type) {
        const icons = {
            'info': 'fas fa-info-circle',
            'success': 'fas fa-check-circle',
            'warning': 'fas fa-exclamation-triangle',
            'error': 'fas fa-exclamation-circle',
            'user': 'fas fa-user',
            'course': 'fas fa-graduation-cap',
            'payment': 'fas fa-credit-card'
        };
        
        return icons[type] || icons.info;
    },
    
    // إجراءات الجدول
    viewRecord(id, table) {
        console.log('View record:', id);
        // تنفيذ عرض السجل
    },
    
    editRecord(id, table) {
        console.log('Edit record:', id);
        // تنفيذ تعديل السجل
    },
    
    async deleteRecord(id, table) {
        // تأكيد الحذف
        const confirmDelete = await this.confirmAction('هل أنت متأكد من حذف هذا السجل؟');
        if (confirmDelete) {
            // تنفيذ الحذف
            console.log('Delete record:', id);
        }
    },
    
    downloadRecord(id, table) {
        console.log('Download record:', id);
        // تنفيذ التحميل
    },
    
    approveRecord(id, table) {
        console.log('Approve record:', id);
        // تنفيذ الموافقة
    },
    
    rejectRecord(id, table) {
        console.log('Reject record:', id);
        // تنفيذ الرفض
    },
    
    async confirmAction(message) {
        return new Promise((resolve) => {
            const modal = document.createElement('div');
            modal.className = 'modal show';
            modal.innerHTML = `
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5>تأكيد الإجراء</h5>
                        </div>
                        <div class="modal-body">
                            <p>${message}</p>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-secondary" data-action="cancel">إلغاء</button>
                            <button class="btn btn-danger" data-action="confirm">تأكيد</button>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
            
            modal.addEventListener('click', (e) => {
                const action = e.target.dataset.action;
                if (action) {
                    document.body.removeChild(modal);
                    resolve(action === 'confirm');
                }
            });
        });
    }
};

// تهيئة لوحة التحكم عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    if (document.body.dataset.page === 'dashboard') {
        DashboardManager.init();
    }
});

// تصدير للاستخدام العام
window.DashboardManager = DashboardManager;