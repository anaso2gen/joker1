/**
 * سكريپت الأمان
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 10:30:08
 */

'use strict';

const SecurityManager = {
    // إعدادات الأمان
    config: {
        sessionTimeout: 30 * 60 * 1000, // 30 دقيقة
        inactivityTimeout: 15 * 60 * 1000, // 15 دقيقة
        maxLoginAttempts: 5,
        passwordMinLength: 8,
        enableCSRFProtection: true,
        enableXSSProtection: true,
        enableClickjacking: true,
        enableContentTypeSniffing: false,
        logSecurityEvents: true
    },
    
    // حالة الأمان
    state: {
        isInitialized: false,
        lastActivity: Date.now(),
        sessionStartTime: Date.now(),
        securityLevel: 'normal', // low, normal, high
        threatDetected: false,
        blockedRequests: 0,
        warnings: []
    },
    
    // قوائم الحماية
    blockedPatterns: [
        // XSS patterns
        /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
        /javascript:/gi,
        /vbscript:/gi,
        /onload\s*=/gi,
        /onerror\s*=/gi,
        /onclick\s*=/gi,
        
        // SQL injection patterns
        /(\%27)|(\')|(\-\-)|(\%23)|(#)/gi,
        /((\%3D)|(=))[^\n]*((\%27)|(\')|(\-\-)|(\%3B)|(;))/gi,
        /\w*((\%27)|(\'))((\%6F)|o|(\%4F))((\%72)|r|(\%52))/gi,
        
        // Command injection patterns
        /(\||&|;|\$|\`)/gi,
        /(\.\.\/|\.\.\\)/gi
    ],
    
    // نطاقات موثوقة
    trustedDomains: [
        window.location.hostname,
        'fonts.googleapis.com',
        'fonts.gstatic.com',
        'cdnjs.cloudflare.com'
    ],
    
    // تهيئة مدير الأمان
    init() {
        if (this.state.isInitialized) return;
        
        try {
            this.setupCSRFProtection();
            this.setupXSSProtection();
            this.setupClickjackingProtection();
            this.setupContentTypeProtection();
            this.setupSessionSecurity();
            this.setupActivityMonitoring();
            this.setupFormValidation();
            this.setupRequestInterception();
            this.setupDOMProtection();
            this.startSecurityMonitoring();
            
            this.state.isInitialized = true;
            this.logSecurityEvent('security_manager_initialized', 'info');
            
        } catch (error) {
            console.error('Security Manager initialization failed:', error);
            this.logSecurityEvent('security_init_failed', 'error', { error: error.message });
        }
    },
    
    // إعداد حماية CSRF
    setupCSRFProtection() {
        if (!this.config.enableCSRFProtection) return;
        
        // إضافة CSRF token لجميع النماذج
        const forms = document.querySelectorAll('form');
        forms.forEach(form => {
            if (!form.querySelector('input[name="csrf_token"]')) {
                const csrfToken = this.getCSRFToken();
                if (csrfToken) {
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'csrf_token';
                    input.value = csrfToken;
                    form.appendChild(input);
                }
            }
        });
        
        // مراقبة النماذج الجديدة
        this.observeNewForms();
        
        // تحديث CSRF token دورياً
        this.setupCSRFRefresh();
    },
    
    // مراقبة النماذج الجديدة
    observeNewForms() {
        const observer = new MutationObserver(mutations => {
            mutations.forEach(mutation => {
                mutation.addedNodes.forEach(node => {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        const forms = node.querySelectorAll ? node.querySelectorAll('form') : [];
                        forms.forEach(form => {
                            this.addCSRFTokenToForm(form);
                        });
                        
                        if (node.tagName === 'FORM') {
                            this.addCSRFTokenToForm(node);
                        }
                    }
                });
            });
        });
        
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    },
    
    // إضافة CSRF token للنموذج
    addCSRFTokenToForm(form) {
        if (!form.querySelector('input[name="csrf_token"]')) {
            const csrfToken = this.getCSRFToken();
            if (csrfToken) {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'csrf_token';
                input.value = csrfToken;
                form.appendChild(input);
            }
        }
    },
    
    // تحديث CSRF token
    setupCSRFRefresh() {
        setInterval(async () => {
            try {
                const newToken = await this.refreshCSRFToken();
                this.updateCSRFTokens(newToken);
            } catch (error) {
                this.logSecurityEvent('csrf_refresh_failed', 'warning', { error: error.message });
            }
        }, 10 * 60 * 1000); // كل 10 دقائق
    },
    
    // تحديث جميع CSRF tokens
    updateCSRFTokens(newToken) {
        // تحديث meta tag
        const metaTag = document.querySelector('meta[name="csrf-token"]');
        if (metaTag) {
            metaTag.setAttribute('content', newToken);
        }
        
        // تحديث hidden inputs
        const inputs = document.querySelectorAll('input[name="csrf_token"]');
        inputs.forEach(input => {
            input.value = newToken;
        });
    },
    
    // الحصول على CSRF token
    getCSRFToken() {
        return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') ||
               document.querySelector('input[name="csrf_token"]')?.value;
    },
    
    // تحديث CSRF token
    async refreshCSRFToken() {
        const response = await fetch('/api.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: 'action=refresh_csrf_token',
            credentials: 'same-origin'
        });
        
        const result = await response.json();
        if (result.success) {
            return result.data.token;
        }
        
        throw new Error(result.message || 'Failed to refresh CSRF token');
    },
    
    // إعداد حماية XSS
    setupXSSProtection() {
        if (!this.config.enableXSSProtection) return;
        
        // مراقبة المدخلات
        this.monitorInputs();
        
        // تطهير المحتوى الديناميكي
        this.sanitizeDynamicContent();
        
        // حماية innerHTML
        this.protectInnerHTML();
    },
    
    // مراقبة المدخلات
    monitorInputs() {
        document.addEventListener('input', (e) => {
            const value = e.target.value;
            if (this.containsMaliciousContent(value)) {
                this.handleMaliciousInput(e.target, value);
            }
        });
        
        document.addEventListener('paste', (e) => {
            const clipboardData = e.clipboardData.getData('text');
            if (this.containsMaliciousContent(clipboardData)) {
                e.preventDefault();
                this.showSecurityWarning('تم منع لصق محتوى مشبوه');
            }
        });
    },
    
    // فحص المحتوى المشبوه
    containsMaliciousContent(content) {
        return this.blockedPatterns.some(pattern => pattern.test(content));
    },
    
    // معالجة المدخلات المشبوهة
    handleMaliciousInput(element, value) {
        // إزالة المحتوى المشبوه
        const cleanValue = this.sanitizeInput(value);
        element.value = cleanValue;
        
        // تسجيل الحدث الأمني
        this.logSecurityEvent('malicious_input_detected', 'warning', {
            element: element.name || element.id || 'unknown',
            originalValue: value.substring(0, 100), // أول 100 حرف فقط
            cleanValue: cleanValue.substring(0, 100)
        });
        
        // إشعار المستخدم
        this.showSecurityWarning('تم إزالة محتوى مشبوه من المدخل');
        
        // زيادة مستوى التهديد
        this.increaseThreatLevel();
    },
    
    // تطهير المدخل
    sanitizeInput(input) {
        let sanitized = input;
        
        // إزالة الأنماط المشبوهة
        this.blockedPatterns.forEach(pattern => {
            sanitized = sanitized.replace(pattern, '');
        });
        
        // تشفير الأحرف الخاصة
        sanitized = sanitized
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#x27;')
            .replace(/\//g, '&#x2F;');
        
        return sanitized;
    },
    
    // تطهير المحتوى الديناميكي
    sanitizeDynamicContent() {
        // مراقبة تغييرات DOM
        const observer = new MutationObserver(mutations => {
            mutations.forEach(mutation => {
                mutation.addedNodes.forEach(node => {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        this.scanElementForThreats(node);
                    }
                });
            });
        });
        
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    },
    
    // فحص العنصر للتهديدات
    scanElementForThreats(element) {
        // فحص النصوص
        const textContent = element.textContent || '';
        if (this.containsMaliciousContent(textContent)) {
            element.textContent = this.sanitizeInput(textContent);
            this.logSecurityEvent('malicious_content_sanitized', 'warning');
        }
        
        // فحص الخصائص
        ['href', 'src', 'action', 'onclick', 'onload'].forEach(attr => {
            const value = element.getAttribute(attr);
            if (value && this.containsMaliciousContent(value)) {
                element.removeAttribute(attr);
                this.logSecurityEvent('malicious_attribute_removed', 'warning', { 
                    attribute: attr, 
                    value: value.substring(0, 50) 
                });
            }
        });
    },
    
    // حماية innerHTML
    protectInnerHTML() {
        const originalInnerHTML = Object.getOwnPropertyDescriptor(Element.prototype, 'innerHTML');
        
        Object.defineProperty(Element.prototype, 'innerHTML', {
            set: function(value) {
                const sanitizedValue = SecurityManager.sanitizeHTML(value);
                originalInnerHTML.set.call(this, sanitizedValue);
            },
            get: originalInnerHTML.get
        });
    },
    
    // تطهير HTML
    sanitizeHTML(html) {
        const div = document.createElement('div');
        div.textContent = html;
        return div.innerHTML;
    },
    
    // إعداد حماية Clickjacking
    setupClickjackingProtection() {
        if (!this.config.enableClickjacking) return;
        
        // فحص إذا كانت الصفحة في iframe
        if (window !== window.top) {
            // التحقق من النطاق المسموح
            try {
                const parentOrigin = document.referrer;
                if (!this.isAllowedOrigin(parentOrigin)) {
                    this.logSecurityEvent('clickjacking_attempt', 'high', { 
                        referrer: parentOrigin 
                    });
                    
                    // إعادة توجيه للصفحة الرئيسية
                    window.top.location = window.location;
                }
            } catch (error) {
                // خطأ في الوصول للنافذة الأب - احتمال clickjacking
                this.logSecurityEvent('potential_clickjacking', 'high');
                document.body.style.display = 'none';
                alert('تم اكتشاف محاولة أمنية مشبوهة');
            }
        }
    },
    
    // فحص النطاق المسموح
    isAllowedOrigin(origin) {
        if (!origin) return false;
        
        try {
            const url = new URL(origin);
            return this.trustedDomains.includes(url.hostname);
        } catch (error) {
            return false;
        }
    },
    
    // إعداد حماية نوع المحتوى
    setupContentTypeProtection() {
        if (!this.config.enableContentTypeSniffing) return;
        
        // مراقبة تحميل الملفات
        document.addEventListener('change', (e) => {
            if (e.target.type === 'file') {
                this.validateFileUpload(e.target);
            }
        });
    },
    
    // التحقق من رفع الملفات
    validateFileUpload(input) {
        const files = Array.from(input.files);
        
        files.forEach(file => {
            // فحص نوع الملف
            if (!this.isAllowedFileType(file)) {
                input.value = '';
                this.showSecurityWarning('نوع الملف غير مسموح');
                this.logSecurityEvent('invalid_file_type', 'warning', {
                    filename: file.name,
                    type: file.type,
                    size: file.size
                });
                return;
            }
            
            // فحص حجم الملف
            if (!this.isAllowedFileSize(file)) {
                input.value = '';
                this.showSecurityWarning('حجم الملف كبير جداً');
                this.logSecurityEvent('file_size_exceeded', 'warning', {
                    filename: file.name,
                    size: file.size
                });
                return;
            }
            
            // فحص اسم الملف
            if (this.containsMaliciousContent(file.name)) {
                input.value = '';
                this.showSecurityWarning('اسم الملف يحتوي على محتوى مشبوه');
                this.logSecurityEvent('malicious_filename', 'warning', {
                    filename: file.name
                });
                return;
            }
        });
    },
    
    // فحص نوع الملف المسموح
    isAllowedFileType(file) {
        const allowedTypes = [
            'image/jpeg', 'image/png', 'image/gif', 'image/webp',
            'application/pdf', 'text/plain',
            'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'video/mp4', 'video/webm'
        ];
        
        return allowedTypes.includes(file.type);
    },
    
    // فحص حجم الملف المسموح
    isAllowedFileSize(file) {
        const maxSize = 50 * 1024 * 1024; // 50MB
        return file.size <= maxSize;
    },
    
    // إعداد أمان الجلسة
    setupSessionSecurity() {
        // مراقبة انتهاء صلاحية الجلسة
        this.startSessionMonitoring();
        
        // حماية من Session Fixation
        this.protectSessionFixation();
        
        // مراقبة تغيير المستخدم
        this.monitorUserChange();
    },
    
    // بدء مراقبة الجلسة
    startSessionMonitoring() {
        setInterval(() => {
            this.checkSessionValidity();
        }, 60000); // كل دقيقة
    },
    
    // فحص صحة الجلسة
    async checkSessionValidity() {
        try {
            const response = await fetch('/api.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: 'action=check_session',
                credentials: 'same-origin'
            });
            
            const result = await response.json();
            
            if (!result.success) {
                this.handleSessionExpired();
            }
        } catch (error) {
            this.logSecurityEvent('session_check_failed', 'warning', { 
                error: error.message 
            });
        }
    },
    
    // معالجة انتهاء الجلسة
    handleSessionExpired() {
        this.logSecurityEvent('session_expired', 'info');
        
        // إشعار المستخدم
        const sessionExpiredModal = this.createSessionExpiredModal();
        document.body.appendChild(sessionExpiredModal);
        sessionExpiredModal.style.display = 'block';
    },
    
    // إنشاء نموذج انتهاء الجلسة
    createSessionExpiredModal() {
        const modal = document.createElement('div');
        modal.className = 'security-modal session-expired-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>انتهت صلاحية الجلسة</h3>
                </div>
                <div class="modal-body">
                    <p>انتهت صلاحية جلستك لأسباب أمنية. يرجى تسجيل الدخول مرة أخرى.</p>
                </div>
                <div class="modal-footer">
                    <button onclick="window.location.href='/login.php'" class="btn btn-primary">
                        تسجيل الدخول
                    </button>
                </div>
            </div>
        `;
        
        return modal;
    },
    
    // حماية من Session Fixation
    protectSessionFixation() {
        // تجديد معرف الجلسة عند تسجيل الدخول
        document.addEventListener('login-success', () => {
            this.regenerateSession();
        });
    },
    
    // تجديد الجلسة
    async regenerateSession() {
        try {
            await fetch('/api.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: 'action=regenerate_session',
                credentials: 'same-origin'
            });
        } catch (error) {
            this.logSecurityEvent('session_regeneration_failed', 'warning', { 
                error: error.message 
            });
        }
    },
    
    // مراقبة تغيير المستخدم
    monitorUserChange() {
        let currentUser = null;
        
        setInterval(async () => {
            try {
                const response = await fetch('/api.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: 'action=get_current_user',
                    credentials: 'same-origin'
                });
                
                const result = await response.json();
                
                if (result.success) {
                    if (currentUser && currentUser.id !== result.data.id) {
                        this.logSecurityEvent('user_changed', 'high', {
                            oldUser: currentUser.id,
                            newUser: result.data.id
                        });
                        
                        // إعادة تحميل الصفحة
                        window.location.reload();
                    }
                    
                    currentUser = result.data;
                }
            } catch (error) {
                // تجاهل الأخطاء
            }
        }, 5 * 60 * 1000); // كل 5 دقائق
    },
    
    // إعداد مراقبة النشاط
    setupActivityMonitoring() {
        // مراقبة النشاط
        ['click', 'keypress', 'mousemove', 'scroll'].forEach(event => {
            document.addEventListener(event, () => {
                this.updateLastActivity();
            });
        });
        
        // فحص عدم النشاط
        setInterval(() => {
            this.checkInactivity();
        }, 60000); // كل دقيقة
    },
    
    // تحديث آخر نشاط
    updateLastActivity() {
        this.state.lastActivity = Date.now();
    },
    
    // فحص عدم النشاط
    checkInactivity() {
        const inactiveTime = Date.now() - this.state.lastActivity;
        
        if (inactiveTime > this.config.inactivityTimeout) {
            this.handleInactivity();
        } else if (inactiveTime > this.config.inactivityTimeout - 2 * 60 * 1000) {
            // تحذير قبل دقيقتين
            this.showInactivityWarning();
        }
    },
    
    // معالجة عدم النشاط
    handleInactivity() {
        this.logSecurityEvent('inactivity_timeout', 'info');
        
        // تسجيل خروج تلقائي
        this.autoLogout();
    },
    
    // تسجيل خروج تلقائي
    async autoLogout() {
        try {
            await fetch('/api.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: 'action=logout&reason=inactivity',
                credentials: 'same-origin'
            });
            
            // إعادة توجيه لصفحة تسجيل الدخول
            window.location.href = '/login.php?message=auto_logout';
        } catch (error) {
            this.logSecurityEvent('auto_logout_failed', 'error', { 
                error: error.message 
            });
        }
    },
    
    // عرض تحذير عدم النشاط
    showInactivityWarning() {
        if (document.querySelector('.inactivity-warning')) return;
        
        const warning = document.createElement('div');
        warning.className = 'security-warning inactivity-warning';
        warning.innerHTML = `
            <div class="warning-content">
                <i class="fas fa-clock"></i>
                <span>ستتم إعادة تسجيل دخولك تلقائياً خلال دقيقتين بسبب عدم النشاط</span>
                <button onclick="this.parentNode.parentNode.remove()">×</button>
            </div>
        `;
        
        document.body.appendChild(warning);
        
        // إزالة التحذير بعد 10 ثوانٍ
        setTimeout(() => {
            if (warning.parentNode) {
                warning.parentNode.removeChild(warning);
            }
        }, 10000);
    },
    
    // إعداد التحقق من النماذج
    setupFormValidation() {
        document.addEventListener('submit', (e) => {
            if (!this.validateFormSecurity(e.target)) {
                e.preventDefault();
                this.showSecurityWarning('النموذج لا يحتوي على الحماية المطلوبة');
            }
        });
    },
    
    // التحقق من أمان النموذج
    validateFormSecurity(form) {
        // التحقق من وجود CSRF token
        if (this.config.enableCSRFProtection) {
            const csrfToken = form.querySelector('input[name="csrf_token"]');
            if (!csrfToken || !csrfToken.value) {
                this.logSecurityEvent('form_missing_csrf', 'warning', {
                    formId: form.id || 'unknown'
                });
                return false;
            }
        }
        
        // التحقق من البيانات المدخلة
        const inputs = form.querySelectorAll('input, textarea');
        for (let input of inputs) {
            if (this.containsMaliciousContent(input.value)) {
                this.logSecurityEvent('form_malicious_input', 'warning', {
                    formId: form.id || 'unknown',
                    inputName: input.name || 'unknown'
                });
                return false;
            }
        }
        
        return true;
    },
    
    // إعداد اعتراض الطلبات
    setupRequestInterception() {
        // اعتراض fetch requests
        const originalFetch = window.fetch;
        window.fetch = async (...args) => {
            const [url, options] = args;
            
            // التحقق من الأمان
            if (!this.isSecureRequest(url, options)) {
                this.logSecurityEvent('insecure_request_blocked', 'warning', { url });
                throw new Error('Insecure request blocked');
            }
            
            return originalFetch.apply(window, args);
        };
        
        // اعتراض XMLHttpRequest
        const originalXHROpen = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function(method, url, ...args) {
            if (!SecurityManager.isSecureRequest(url, { method })) {
                SecurityManager.logSecurityEvent('insecure_xhr_blocked', 'warning', { url });
                throw new Error('Insecure XHR request blocked');
            }
            
            return originalXHROpen.apply(this, [method, url, ...args]);
        };
    },
    
    // فحص أمان الطلب
    isSecureRequest(url, options = {}) {
        try {
            const requestUrl = new URL(url, window.location.origin);
            
            // التحقق من البروتوكول
            if (requestUrl.protocol !== 'https:' && requestUrl.protocol !== 'http:') {
                return false;
            }
            
            // التحقق من النطاق
            if (!this.trustedDomains.includes(requestUrl.hostname) && 
                requestUrl.hostname !== window.location.hostname) {
                return false;
            }
            
            // التحقق من المحتوى المشبوه في URL
            if (this.containsMaliciousContent(url)) {
                return false;
            }
            
            return true;
        } catch (error) {
            return false;
        }
    },
    
    // إعداد حماية DOM
    setupDOMProtection() {
        // حماية من DOM manipulation
        this.protectCriticalElements();
        
        // مراقبة التغييرات المشبوهة
        this.monitorDOMChanges();
    },
    
    // حماية العناصر الحرجة
    protectCriticalElements() {
        const criticalSelectors = [
            'script[src]',
            'link[rel="stylesheet"]',
            'meta[name="csrf-token"]',
            'form[method="post"]'
        ];
        
        criticalSelectors.forEach(selector => {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                this.protectElement(element);
            });
        });
    },
    
    // حماية عنصر واحد
    protectElement(element) {
        // منع التعديل المباشر
        Object.defineProperty(element, 'innerHTML', {
            set: function() {
                SecurityManager.logSecurityEvent('protected_element_modification', 'high', {
                    element: this.tagName,
                    id: this.id || 'unknown'
                });
                throw new Error('Protected element modification blocked');
            },
            get: function() {
                return this.innerHTML;
            }
        });
    },
    
    // مراقبة تغييرات DOM
    monitorDOMChanges() {
        const observer = new MutationObserver(mutations => {
            mutations.forEach(mutation => {
                if (mutation.type === 'childList') {
                    mutation.addedNodes.forEach(node => {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            this.analyzeNewElement(node);
                        }
                    });
                }
            });
        });
        
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    },
    
    // تحليل العنصر الجديد
    analyzeNewElement(element) {
        // فحص العناصر المشبوهة
        if (element.tagName === 'SCRIPT' && !element.src) {
            this.logSecurityEvent('inline_script_detected', 'high');
            element.remove();
            return;
        }
        
        // فحص الروابط الخارجية
        if (element.tagName === 'A' && element.href) {
            try {
                const url = new URL(element.href);
                if (!this.trustedDomains.includes(url.hostname)) {
                    element.setAttribute('rel', 'noopener noreferrer');
                    element.setAttribute('target', '_blank');
                }
            } catch (error) {
                // URL غير صالح
                element.removeAttribute('href');
            }
        }
    },
    
    // بدء مراقبة الأمان
    startSecurityMonitoring() {
        // مراقبة دورية
        setInterval(() => {
            this.performSecurityCheck();
        }, 5 * 60 * 1000); // كل 5 دقائق
        
        // مراقبة الأحداث المشبوهة
        this.monitorSuspiciousActivity();
    },
    
    // فحص أمني دوري
    performSecurityCheck() {
        // فحص التهديدات
        this.detectThreats();
        
        // فحص الأداء
        this.checkPerformance();
        
        // تنظيف المؤقت
        this.cleanup();
    },
    
    // اكتشاف التهديدات
    detectThreats() {
        // فحص Console
        if (this.isConsoleOpen()) {
            this.logSecurityEvent('console_open_detected', 'medium');
            this.showDeveloperWarning();
        }
        
        // فحص الإضافات المشبوهة
        if (this.detectSuspiciousExtensions()) {
            this.logSecurityEvent('suspicious_extension_detected', 'high');
        }
        
        // فحص تغيير User Agent
        if (this.detectUserAgentChange()) {
            this.logSecurityEvent('user_agent_changed', 'medium');
        }
    },
    
    // فحص فتح Console
    isConsoleOpen() {
        const threshold = 160;
        return window.outerHeight - window.innerHeight > threshold ||
               window.outerWidth - window.innerWidth > threshold;
    },
    
    // عرض تحذير للمطورين
    showDeveloperWarning() {
        console.warn('%cتحذير أمني!', 'color: red; font-size: 30px; font-weight: bold;');
        console.warn('%cإذا لم تكن مطوراً، فقد تكون ضحية لهجوم أمني. أغلق هذه النافذة فوراً!', 'color: red; font-size: 16px;');
    },
    
    // فحص الإضافات المشبوهة
    detectSuspiciousExtensions() {
        // فحص تعديلات DOM غير طبيعية
        const suspiciousElements = document.querySelectorAll('[data-extension], [class*="extension"]');
        return suspiciousElements.length > 0;
    },
    
    // فحص تغيير User Agent
    detectUserAgentChange() {
        const currentUA = navigator.userAgent;
        const storedUA = sessionStorage.getItem('original_ua');
        
        if (!storedUA) {
            sessionStorage.setItem('original_ua', currentUA);
            return false;
        }
        
        return currentUA !== storedUA;
    },
    
    // فحص الأداء
    checkPerformance() {
        const memoryInfo = performance.memory;
        
        if (memoryInfo) {
            const memoryUsage = memoryInfo.usedJSHeapSize / memoryInfo.totalJSHeapSize;
            
            if (memoryUsage > 0.9) {
                this.logSecurityEvent('high_memory_usage', 'warning', {
                    usage: (memoryUsage * 100).toFixed(2) + '%'
                });
            }
        }
    },
    
    // تنظيف المؤقت
    cleanup() {
        // تنظيف cache منتهية الصلاحية
        const now = Date.now();
        const expiredKeys = [];
        
        for (let [key, value] of this.cache?.entries() || []) {
            if (value.timestamp && now - value.timestamp > 30 * 60 * 1000) {
                expiredKeys.push(key);
            }
        }
        
        expiredKeys.forEach(key => this.cache?.delete(key));
        
        // تنظيف التحذيرات القديمة
        this.state.warnings = this.state.warnings.filter(warning => 
            now - warning.timestamp < 60 * 60 * 1000
        );
    },
    
    // مراقبة النشاط المشبوه
    monitorSuspiciousActivity() {
        // مراقبة محاولات التلاعب
        document.addEventListener('contextmenu', (e) => {
            if (this.state.securityLevel === 'high') {
                e.preventDefault();
                this.showSecurityWarning('تم تعطيل القائمة السياقية لأسباب أمنية');
            }
        });
        
        // مراقبة اختصارات لوحة المفاتيح المشبوهة
        document.addEventListener('keydown', (e) => {
            if (this.isSuspiciousKeyCombo(e)) {
                this.logSecurityEvent('suspicious_key_combo', 'medium', {
                    key: e.key,
                    ctrlKey: e.ctrlKey,
                    altKey: e.altKey,
                    shiftKey: e.shiftKey
                });
            }
        });
    },
    
    // فحص تركيبات المفاتيح المشبوهة
    isSuspiciousKeyCombo(e) {
        // F12, Ctrl+Shift+I, Ctrl+U, etc.
        const suspiciousCombos = [
            { key: 'F12' },
            { key: 'I', ctrlKey: true, shiftKey: true },
            { key: 'U', ctrlKey: true },
            { key: 'S', ctrlKey: true } // حفظ الصفحة
        ];
        
        return suspiciousCombos.some(combo => 
            e.key === combo.key &&
            e.ctrlKey === !!combo.ctrlKey &&
            e.shiftKey === !!combo.shiftKey &&
            e.altKey === !!combo.altKey
        );
    },
    
    // زيادة مستوى التهديد
    increaseThreatLevel() {
        this.state.blockedRequests++;
        
        if (this.state.blockedRequests >= 5) {
            this.state.securityLevel = 'high';
            this.logSecurityEvent('threat_level_increased', 'high', {
                blockedRequests: this.state.blockedRequests
            });
        } else if (this.state.blockedRequests >= 2) {
            this.state.securityLevel = 'medium';
        }
    },
    
    // عرض تحذير أمني
    showSecurityWarning(message) {
        // إزالة التحذيرات السابقة
        const existingWarnings = document.querySelectorAll('.security-warning');
        existingWarnings.forEach(warning => warning.remove());
        
        // إنشاء تحذير جديد
        const warning = document.createElement('div');
        warning.className = 'security-warning';
        warning.innerHTML = `
            <div class="warning-content">
                <i class="fas fa-shield-alt"></i>
                <span>${message}</span>
                <button onclick="this.parentNode.parentNode.remove()">×</button>
            </div>
        `;
        
        document.body.appendChild(warning);
        
        // إزالة التحذير تلقائياً
        setTimeout(() => {
            if (warning.parentNode) {
                warning.parentNode.removeChild(warning);
            }
        }, 5000);
        
        // حفظ التحذير في السجل
        this.state.warnings.push({
            message,
            timestamp: Date.now()
        });
    },
    
    // تسجيل حدث أمني
    logSecurityEvent(eventType, severity, details = {}) {
        if (!this.config.logSecurityEvents) return;
        
        const event = {
            type: eventType,
            severity: severity,
            timestamp: new Date().toISOString(),
            url: window.location.href,
            userAgent: navigator.userAgent,
            details: details
        };
        
        // طباعة في Console للتطوير
        if (severity === 'high' || severity === 'error') {
            console.error('Security Event:', event);
        } else if (severity === 'warning' || severity === 'medium') {
            console.warn('Security Event:', event);
        } else {
            console.info('Security Event:', event);
        }
        
        // إرسال للخادم
        this.sendSecurityEventToServer(event);
    },
    
    // إرسال الحدث الأمني للخادم
    async sendSecurityEventToServer(event) {
        try {
            await fetch('/api.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: new URLSearchParams({
                    action: 'log_security_event',
                    event: JSON.stringify(event),
                    csrf_token: this.getCSRFToken() || ''
                }),
                credentials: 'same-origin'
            });
        } catch (error) {
            // فشل في إرسال السجل - لا نفعل شيئاً
        }
    },
    
    // الحصول على تقرير الأمان
    getSecurityReport() {
        return {
            isInitialized: this.state.isInitialized,
            securityLevel: this.state.securityLevel,
            threatDetected: this.state.threatDetected,
            blockedRequests: this.state.blockedRequests,
            warnings: this.state.warnings.length,
            sessionAge: Date.now() - this.state.sessionStartTime,
            lastActivity: Date.now() - this.state.lastActivity
        };
    }
};

// تهيئة مدير الأمان عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    SecurityManager.init();
});

// تصدير للاستخدام العام
window.SecurityManager = SecurityManager;