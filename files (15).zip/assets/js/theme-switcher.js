/**
 * مبدل الثيم - التبديل بين الوضع الفاتح والمظلم
 */

class ThemeSwitcher {
    constructor() {
        this.currentTheme = this.getStoredTheme() || this.getPreferredTheme();
        this.themeToggle = null;
        this.init();
    }
    
    init() {
        this.setTheme(this.currentTheme);
        this.createToggleButton();
        this.bindEvents();
        this.updateToggleIcon();
    }
    
    /**
     * إنشاء زر التبديل
     */
    createToggleButton() {
        // البحث عن زر موجود أو إنشاء جديد
        this.themeToggle = document.getElementById('theme-toggle');
        
        if (!this.themeToggle) {
            this.themeToggle = document.createElement('button');
            this.themeToggle.id = 'theme-toggle';
            this.themeToggle.className = 'btn btn-link theme-toggle-btn';
            this.themeToggle.setAttribute('data-bs-toggle', 'tooltip');
            this.themeToggle.setAttribute('data-bs-placement', 'bottom');
            this.themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
            
            // إضافة الزر إلى شريط التنقل
            const navbar = document.querySelector('.navbar-nav');
            if (navbar) {
                const li = document.createElement('li');
                li.className = 'nav-item';
                li.appendChild(this.themeToggle);
                navbar.appendChild(li);
            }
        }
    }
    
    /**
     * ربط الأحداث
     */
    bindEvents() {
        if (this.themeToggle) {
            this.themeToggle.addEventListener('click', () => {
                this.toggleTheme();
            });
        }
        
        // الاستماع لتغييرات تفضيلات النظام
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
            if (this.getStoredTheme() !== 'light' && this.getStoredTheme() !== 'dark') {
                this.setTheme(e.matches ? 'dark' : 'light');
            }
        });
    }
    
    /**
     * الحصول على الثيم المفضل من النظام
     */
    getPreferredTheme() {
        return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    
    /**
     * الحصول على الثيم المحفوظ
     */
    getStoredTheme() {
        return localStorage.getItem('theme');
    }
    
    /**
     * حفظ الثيم
     */
    setStoredTheme(theme) {
        localStorage.setItem('theme', theme);
    }
    
    /**
     * تطبيق الثيم
     */
    setTheme(theme) {
        if (theme === 'auto') {
            document.documentElement.setAttribute('data-bs-theme', this.getPreferredTheme());
        } else {
            document.documentElement.setAttribute('data-bs-theme', theme);
        }
        
        // تحديث CSS
        this.updateThemeCSS(theme);
        this.currentTheme = theme;
        this.updateToggleIcon();
        
        // إرسال حدث مخصص
        const event = new CustomEvent('themeChanged', { detail: { theme } });
        document.dispatchEvent(event);
    }
    
    /**
     * تحديث ملف CSS حسب الثيم
     */
    updateThemeCSS(theme) {
        // إزالة ملفات الثيم السابقة
        const existingThemeLinks = document.querySelectorAll('link[data-theme]');
        existingThemeLinks.forEach(link => link.remove());
        
        // إضافة ملف الثيم الجديد
        const themeFile = theme === 'dark' ? 'theme-dark.css' : 'theme-light.css';
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = `/themes/${themeFile}`;
        link.setAttribute('data-theme', theme);
        document.head.appendChild(link);
        
        // تحديث كلاس body
        document.body.className = document.body.className.replace(/theme-\w+/g, '');
        document.body.classList.add(`theme-${theme}`);
    }
    
    /**
     * تبديل الثيم
     */
    toggleTheme() {
        const newTheme = this.currentTheme === 'dark' ? 'light' : 'dark';
        this.setStoredTheme(newTheme);
        this.setTheme(newTheme);
        
        // تأثير بصري للتبديل
        this.animateToggle();
        
        // إشعار المستخدم
        const message = newTheme === 'dark' ? 'تم التبديل للوضع المظلم' : 'تم التبديل للوضع الفاتح';
        this.showThemeNotification(message);
    }
    
    /**
     * تحديث أيقونة زر التبديل
     */
    updateToggleIcon() {
        if (!this.themeToggle) return;
        
        const icon = this.themeToggle.querySelector('i');
        const currentActiveTheme = document.documentElement.getAttribute('data-bs-theme');
        
        if (currentActiveTheme === 'dark') {
            icon.className = 'fas fa-moon';
            this.themeToggle.setAttribute('title', 'التبديل للوضع الفاتح');
        } else {
            icon.className = 'fas fa-sun';
            this.themeToggle.setAttribute('title', 'التبديل للوضع المظلم');
        }
        
        // تحديث tooltip إذا كان موجوداً
        const tooltip = bootstrap.Tooltip.getInstance(this.themeToggle);
        if (tooltip) {
            tooltip.dispose();
            new bootstrap.Tooltip(this.themeToggle);
        }
    }
    
    /**
     * تأثير الحركة عند التبديل
     */
    animateToggle() {
        if (!this.themeToggle) return;
        
        // تدوير الأيقونة
        const icon = this.themeToggle.querySelector('i');
        icon.style.transform = 'rotate(360deg)';
        icon.style.transition = 'transform 0.5s ease';
        
        setTimeout(() => {
            icon.style.transform = '';
            icon.style.transition = '';
        }, 500);
        
        // تأثير الانتقال للصفحة
        document.body.style.transition = 'background-color 0.3s ease, color 0.3s ease';
        setTimeout(() => {
            document.body.style.transition = '';
        }, 300);
    }
    
    /**
     * إشعار تغيير الثيم
     */
    showThemeNotification(message) {
        // إنشاء إشعار مؤقت
        const notification = document.createElement('div');
        notification.className = 'theme-notification';
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--bs-primary);
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            z-index: 9999;
            font-size: 0.9rem;
            transform: translateX(100%);
            transition: transform 0.3s ease;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        `;
        
        document.body.appendChild(notification);
        
        // إظهار الإشعار
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // إخفاء الإشعار
        setTimeout(() => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 2000);
    }
    
    /**
     * الحصول على الثيم الحالي
     */
    getCurrentTheme() {
        return this.currentTheme;
    }
    
    /**
     * تطبيق ثيم محدد
     */
    applyTheme(theme) {
        if (['light', 'dark', 'auto'].includes(theme)) {
            this.setStoredTheme(theme);
            this.setTheme(theme);
        }
    }
}

// تهيئة مبدل الثيم عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    window.themeSwitcher = new ThemeSwitcher();
});

// CSS للتحسينات البصرية
const themeStyles = `
<style>
.theme-toggle-btn {
    color: var(--bs-nav-link-color);
    border: none;
    background: transparent;
    font-size: 1.2rem;
    padding: 0.5rem;
    border-radius: 50%;
    transition: all 0.3s ease;
    position: relative;
}

.theme-toggle-btn:hover {
    background: rgba(var(--bs-primary-rgb), 0.1);
    color: var(--bs-primary);
    transform: scale(1.1);
}

.theme-toggle-btn:focus {
    box-shadow: 0 0 0 0.2rem rgba(var(--bs-primary-rgb), 0.25);
}

.theme-toggle-btn i {
    transition: all 0.3s ease;
}

.theme-dark {
    --bs-body-bg: #1a1a1a;
    --bs-body-color: #ffffff;
    --bs-border-color: #404040;
    --bs-nav-link-color: #ffffff;
    --bs-navbar-brand-color: #ffffff;
}

.theme-light {
    --bs-body-bg: #ffffff;
    --bs-body-color: #212529;
    --bs-border-color: #dee2e6;
    --bs-nav-link-color: #212529;
    --bs-navbar-brand-color: #212529;
}

/* تحسينات الانتقال السلس */
*, *::before, *::after {
    transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out;
}

/* تحسينات خاصة للثيم المظلم */
.theme-dark .card {
    background-color: #2d2d2d;
    border-color: #404040;
}

.theme-dark .form-control {
    background-color: #2d2d2d;
    border-color: #404040;
    color: #ffffff;
}

.theme-dark .form-control:focus {
    background-color: #2d2d2d;
    border-color: var(--bs-primary);
    color: #ffffff;
}

.theme-dark .btn-secondary {
    background-color: #404040;
    border-color: #404040;
    color: #ffffff;
}

.theme-dark .btn-secondary:hover {
    background-color: #555555;
    border-color: #555555;
}

.theme-dark .dropdown-menu {
    background-color: #2d2d2d;
    border-color: #404040;
}

.theme-dark .dropdown-item {
    color: #ffffff;
}

.theme-dark .dropdown-item:hover {
    background-color: #404040;
    color: #ffffff;
}

.theme-dark .modal-content {
    background-color: #2d2d2d;
    border-color: #404040;
}

.theme-dark .modal-header {
    border-bottom-color: #404040;
}

.theme-dark .modal-footer {
    border-top-color: #404040;
}

.theme-dark .table {
    color: #ffffff;
}

.theme-dark .table th,
.theme-dark .table td {
    border-color: #404040;
}

.theme-dark .table-striped tbody tr:nth-of-type(odd) {
    background-color: rgba(255, 255, 255, 0.05);
}

/* تحسينات للمكونات المخصصة */
.theme-dark .stats-card {
    background-color: #2d2d2d;
    border-color: #404040;
}

.theme-dark .management-card {
    background-color: #2d2d2d;
    border-color: #404040;
}

.theme-dark .list-item {
    border-color: #404040;
}

.theme-dark .list-item:hover {
    background-color: #404040;
}

/* تحسينات للنصوص */
.theme-dark .text-muted {
    color: #b3b3b3 !important;
}

.theme-dark .text-secondary {
    color: #b3b3b3 !important;
}

/* تحسينات لشريط التمرير */
.theme-dark ::-webkit-scrollbar {
    width: 8px;
}

.theme-dark ::-webkit-scrollbar-track {
    background: #1a1a1a;
}

.theme-dark ::-webkit-scrollbar-thumb {
    background: #404040;
    border-radius: 4px;
}

.theme-dark ::-webkit-scrollbar-thumb:hover {
    background: #555555;
}

/* تحسينات الطباعة */
@media print {
    .theme-toggle-btn {
        display: none !important;
    }
}
</style>
`;

// إضافة الأنماط إلى الصفحة
document.head.insertAdjacentHTML('beforeend', themeStyles);