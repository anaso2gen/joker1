/**
 * سكريپت المصادقة
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 10:26:36
 */

'use strict';

const AuthManager = {
    // إعدادات المصادقة
    config: {
        passwordMinLength: 8,
        passwordMaxAttempts: 5,
        lockoutDuration: 15 * 60 * 1000, // 15 دقيقة
        otpLength: 6,
        otpTimeout: 5 * 60 * 1000, // 5 دقائق
        rememberMeDuration: 30 // 30 يوم
    },
    
    // حالة المصادقة
    state: {
        loginAttempts: 0,
        isLocked: false,
        lockoutEndTime: null,
        currentStep: 'login', // login, otp, password_reset
        otpTimer: null,
        formData: {}
    },
    
    // تهيئة مدير المصادقة
    init() {
        this.initializeEventListeners();
        this.checkLockoutStatus();
        this.initializePasswordStrength();
        this.initializeOTPInputs();
        this.initializeSocialAuth();
        this.restoreFormData();
    },
    
    // تهيئة مستمعي الأحداث
    initializeEventListeners() {
        // نماذج تسجيل الدخول
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }
        
        // نماذج التسجيل
        const registerForm = document.getElementById('registerForm');
        if (registerForm) {
            registerForm.addEventListener('submit', (e) => this.handleRegister(e));
        }
        
        // نماذج إعادة تعيين كلمة المرور
        const forgotPasswordForm = document.getElementById('forgotPasswordForm');
        if (forgotPasswordForm) {
            forgotPasswordForm.addEventListener('submit', (e) => this.handleForgotPassword(e));
        }
        
        // نماذج تأكيد كلمة المرور الجديدة
        const resetPasswordForm = document.getElementById('resetPasswordForm');
        if (resetPasswordForm) {
            resetPasswordForm.addEventListener('submit', (e) => this.handleResetPassword(e));
        }
        
        // نماذج OTP
        const otpForm = document.getElementById('otpForm');
        if (otpForm) {
            otpForm.addEventListener('submit', (e) => this.handleOTPVerification(e));
        }
        
        // أزرار إعادة الإرسال
        const resendBtns = document.querySelectorAll('.resend-otp');
        resendBtns.forEach(btn => {
            btn.addEventListener('click', (e) => this.handleResendOTP(e));
        });
        
        // أزرار إظهار/إخفاء كلمة المرور
        const passwordToggles = document.querySelectorAll('.password-toggle');
        passwordToggles.forEach(toggle => {
            toggle.addEventListener('click', (e) => this.togglePasswordVisibility(e));
        });
        
        // خانات التذكر
        const rememberCheckbox = document.getElementById('rememberMe');
        if (rememberCheckbox) {
            rememberCheckbox.addEventListener('change', (e) => this.handleRememberMe(e));
        }
    },
    
    // معالجة تسجيل الدخول
    async handleLogin(e) {
        e.preventDefault();
        
        if (this.state.isLocked) {
            this.showError('تم قفل الحساب مؤقتاً. حاول مرة أخرى لاحقاً.');
            return;
        }
        
        const form = e.target;
        const formData = new FormData(form);
        const data = Object.fromEntries(formData);
        
        // تخزين بيانات النموذج
        this.state.formData = data;
        
        try {
            this.showLoading(form);
            
            const response = await this.apiCall('login', data);
            
            if (response.success) {
                // نجح تسجيل الدخول
                this.state.loginAttempts = 0;
                this.clearFormData();
                
                if (response.data.requires_otp) {
                    // يتطلب تأكيد OTP
                    this.showOTPStep(response.data);
                } else {
                    // تسجيل دخول مكتمل
                    this.handleLoginSuccess(response.data);
                }
            } else {
                throw new Error(response.message || 'فشل تسجيل الدخول');
            }
        } catch (error) {
            this.handleLoginError(error);
        } finally {
            this.hideLoading(form);
        }
    },
    
    // معالجة التسجيل
    async handleRegister(e) {
        e.preventDefault();
        
        const form = e.target;
        const formData = new FormData(form);
        const data = Object.fromEntries(formData);
        
        // التحقق من تطابق كلمات المرور
        if (data.password !== data.password_confirm) {
            this.showError('كلمات المرور غير متطابقة');
            return;
        }
        
        // التحقق من قوة كلمة المرور
        const passwordStrength = this.calculatePasswordStrength(data.password);
        if (passwordStrength.score < 3) {
            this.showError('كلمة المرور ضعيفة جداً. يرجى استخدام كلمة مرور أقوى.');
            return;
        }
        
        try {
            this.showLoading(form);
            
            const response = await this.apiCall('register', data);
            
            if (response.success) {
                this.showSuccess('تم إنشاء الحساب بنجاح! تحقق من بريدك الإلكتروني للتفعيل.');
                
                // انتقال إلى صفحة التأكيد
                setTimeout(() => {
                    window.location.href = '/login.php?message=registration_success';
                }, 2000);
            } else {
                throw new Error(response.message || 'فشل إنشاء الحساب');
            }
        } catch (error) {
            this.showError(error.message);
        } finally {
            this.hideLoading(form);
        }
    },
    
    // معالجة نسيان كلمة المرور
    async handleForgotPassword(e) {
        e.preventDefault();
        
        const form = e.target;
        const formData = new FormData(form);
        const data = Object.fromEntries(formData);
        
        try {
            this.showLoading(form);
            
            const response = await this.apiCall('forgot_password', data);
            
            if (response.success) {
                this.showSuccess('تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني.');
                form.reset();
            } else {
                throw new Error(response.message || 'فشل إرسال رابط إعادة التعيين');
            }
        } catch (error) {
            this.showError(error.message);
        } finally {
            this.hideLoading(form);
        }
    },
    
    // معالجة إعادة تعيين كلمة المرور
    async handleResetPassword(e) {
        e.preventDefault();
        
        const form = e.target;
        const formData = new FormData(form);
        const data = Object.fromEntries(formData);
        
        // التحقق من تطابق كلمات المرور
        if (data.password !== data.password_confirm) {
            this.showError('كلمات المرور غير متطابقة');
            return;
        }
        
        // التحقق من قوة كلمة المرور
        const passwordStrength = this.calculatePasswordStrength(data.password);
        if (passwordStrength.score < 3) {
            this.showError('كلمة المرور ضعيفة جداً. يرجى استخدام كلمة مرور أقوى.');
            return;
        }
        
        try {
            this.showLoading(form);
            
            const response = await this.apiCall('reset_password', data);
            
            if (response.success) {
                this.showSuccess('تم تغيير كلمة المرور بنجاح!');
                
                setTimeout(() => {
                    window.location.href = '/login.php?message=password_reset_success';
                }, 2000);
            } else {
                throw new Error(response.message || 'فشل تغيير كلمة المرور');
            }
        } catch (error) {
            this.showError(error.message);
        } finally {
            this.hideLoading(form);
        }
    },
    
    // معالجة تأكيد OTP
    async handleOTPVerification(e) {
        e.preventDefault();
        
        const form = e.target;
        const otpInputs = form.querySelectorAll('.otp-input');
        const otp = Array.from(otpInputs).map(input => input.value).join('');
        
        if (otp.length !== this.config.otpLength) {
            this.showError('يرجى إدخال رمز التأكيد كاملاً');
            return;
        }
        
        try {
            this.showLoading(form);
            
            const data = {
                otp: otp,
                ...this.state.formData
            };
            
            const response = await this.apiCall('verify_otp', data);
            
            if (response.success) {
                this.handleLoginSuccess(response.data);
            } else {
                throw new Error(response.message || 'رمز التأكيد غير صحيح');
            }
        } catch (error) {
            this.showError(error.message);
            this.clearOTPInputs();
        } finally {
            this.hideLoading(form);
        }
    },
    
    // معالجة إعادة إرسال OTP
    async handleResendOTP(e) {
        e.preventDefault();
        
        const btn = e.target.closest('.resend-otp');
        
        try {
            btn.disabled = true;
            btn.textContent = 'جاري الإرسال...';
            
            const response = await this.apiCall('resend_otp', this.state.formData);
            
            if (response.success) {
                this.showSuccess('تم إعادة إرسال رمز التأكيد');
                this.startOTPTimer();
            } else {
                throw new Error(response.message || 'فشل إعادة الإرسال');
            }
        } catch (error) {
            this.showError(error.message);
        } finally {
            setTimeout(() => {
                btn.disabled = false;
                btn.textContent = 'إعادة الإرسال';
            }, 30000); // 30 ثانية قبل السماح بإعادة الإرسال
        }
    },
    
    // معالجة نجاح تسجيل الدخول
    handleLoginSuccess(data) {
        this.showSuccess('تم تسجيل الدخول بنجاح!');
        
        // تخزين بيانات المستخدم إذا لزم الأمر
        if (data.user) {
            localStorage.setItem('user_data', JSON.stringify(data.user));
        }
        
        // إعادة التوجيه
        const redirectUrl = new URLSearchParams(window.location.search).get('redirect') || 
                           data.redirect_url || 
                           '/dashboard.php';
        
        setTimeout(() => {
            window.location.href = redirectUrl;
        }, 1500);
    },
    
    // معالجة خطأ تسجيل الدخول
    handleLoginError(error) {
        this.state.loginAttempts++;
        
        if (this.state.loginAttempts >= this.config.passwordMaxAttempts) {
            this.lockAccount();
            this.showError('تم تجاوز الحد الأقصى للمحاولات. تم قفل الحساب مؤقتاً.');
        } else {
            const remainingAttempts = this.config.passwordMaxAttempts - this.state.loginAttempts;
            this.showError(`${error.message}. المحاولات المتبقية: ${remainingAttempts}`);
        }
    },
    
    // قفل الحساب
    lockAccount() {
        this.state.isLocked = true;
        this.state.lockoutEndTime = Date.now() + this.config.lockoutDuration;
        
        localStorage.setItem('auth_lockout', JSON.stringify({
            endTime: this.state.lockoutEndTime,
            attempts: this.state.loginAttempts
        }));
        
        this.startLockoutTimer();
    },
    
    // بدء مؤقت القفل
    startLockoutTimer() {
        const timer = setInterval(() => {
            const remainingTime = this.state.lockoutEndTime - Date.now();
            
            if (remainingTime <= 0) {
                this.unlockAccount();
                clearInterval(timer);
            } else {
                this.updateLockoutDisplay(remainingTime);
            }
        }, 1000);
    },
    
    // إلغاء قفل الحساب
    unlockAccount() {
        this.state.isLocked = false;
        this.state.lockoutEndTime = null;
        this.state.loginAttempts = 0;
        
        localStorage.removeItem('auth_lockout');
        this.hideLockoutDisplay();
    },
    
    // تحديث عرض القفل
    updateLockoutDisplay(remainingTime) {
        const minutes = Math.floor(remainingTime / 60000);
        const seconds = Math.floor((remainingTime % 60000) / 1000);
        
        const display = document.querySelector('.lockout-timer');
        if (display) {
            display.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        }
    },
    
    // إخفاء عرض القفل
    hideLockoutDisplay() {
        const display = document.querySelector('.lockout-message');
        if (display) {
            display.style.display = 'none';
        }
    },
    
    // فحص حالة القفل
    checkLockoutStatus() {
        const lockoutData = localStorage.getItem('auth_lockout');
        
        if (lockoutData) {
            const data = JSON.parse(lockoutData);
            
            if (Date.now() < data.endTime) {
                this.state.isLocked = true;
                this.state.lockoutEndTime = data.endTime;
                this.state.loginAttempts = data.attempts;
                this.startLockoutTimer();
            } else {
                this.unlockAccount();
            }
        }
    },
    
    // تهيئة مؤشر قوة كلمة المرور
    initializePasswordStrength() {
        const passwordInputs = document.querySelectorAll('input[type="password"][data-strength="true"]');
        
        passwordInputs.forEach(input => {
            input.addEventListener('input', (e) => {
                const strength = this.calculatePasswordStrength(e.target.value);
                this.updatePasswordStrengthDisplay(input, strength);
            });
        });
    },
    
    // حساب قوة كلمة المرور
    calculatePasswordStrength(password) {
        let score = 0;
        const checks = {
            length: password.length >= this.config.passwordMinLength,
            lowercase: /[a-z]/.test(password),
            uppercase: /[A-Z]/.test(password),
            numbers: /\d/.test(password),
            symbols: /[^A-Za-z0-9]/.test(password),
            noCommonPatterns: !this.isCommonPattern(password)
        };
        
        score = Object.values(checks).filter(Boolean).length;
        
        const levels = {
            0: 'very-weak',
            1: 'weak', 
            2: 'weak',
            3: 'fair',
            4: 'good',
            5: 'strong',
            6: 'very-strong'
        };
        
        return {
            score: score,
            level: levels[score] || 'weak',
            checks: checks
        };
    },
    
    // فحص الأنماط الشائعة
    isCommonPattern(password) {
        const commonPatterns = [
            /^123456/,
            /^password/i,
            /^qwerty/i,
            /^admin/i,
            /^welcome/i,
            /^12345678/,
            /^abc123/i
        ];
        
        return commonPatterns.some(pattern => pattern.test(password));
    },
    
    // تحديث عرض قوة كلمة المرور
    updatePasswordStrengthDisplay(input, strength) {
        const container = input.parentNode.querySelector('.password-strength');
        if (!container) return;
        
        const meter = container.querySelector('.strength-meter');
        const text = container.querySelector('.strength-text');
        const requirements = container.querySelector('.strength-requirements');
        
        if (meter) {
            meter.className = `strength-meter ${strength.level}`;
            meter.style.width = `${(strength.score / 6) * 100}%`;
        }
        
        if (text) {
            const messages = {
                'very-weak': 'ضعيفة جداً',
                'weak': 'ضعيفة',
                'fair': 'متوسطة',
                'good': 'جيدة', 
                'strong': 'قوية',
                'very-strong': 'قوية جداً'
            };
            
            text.textContent = messages[strength.level];
            text.className = `strength-text ${strength.level}`;
        }
        
        if (requirements) {
            this.updatePasswordRequirements(requirements, strength.checks);
        }
        
        container.style.display = input.value ? 'block' : 'none';
    },
    
    // تحديث متطلبات كلمة المرور
    updatePasswordRequirements(container, checks) {
        const requirements = [
            { key: 'length', text: '8 أحرف على الأقل' },
            { key: 'lowercase', text: 'حرف صغير' },
            { key: 'uppercase', text: 'حرف كبير' },
            { key: 'numbers', text: 'رقم' },
            { key: 'symbols', text: 'رمز خاص' },
            { key: 'noCommonPatterns', text: 'ليس نمط شائع' }
        ];
        
        container.innerHTML = requirements.map(req => `
            <div class="requirement ${checks[req.key] ? 'met' : 'unmet'}">
                <i class="fas ${checks[req.key] ? 'fa-check' : 'fa-times'}"></i>
                ${req.text}
            </div>
        `).join('');
    },
    
    // تهيئة مدخلات OTP
    initializeOTPInputs() {
        const otpInputs = document.querySelectorAll('.otp-input');
        
        otpInputs.forEach((input, index) => {
            input.addEventListener('input', (e) => {
                const value = e.target.value;
                
                // السماح بالأرقام فقط
                if (!/^\d*$/.test(value)) {
                    e.target.value = value.replace(/\D/g, '');
                    return;
                }
                
                // الانتقال للمدخل التالي
                if (value.length === 1 && index < otpInputs.length - 1) {
                    otpInputs[index + 1].focus();
                }
                
                // تحديث مظهر المدخل
                e.target.classList.toggle('filled', value.length === 1);
            });
            
            input.addEventListener('keydown', (e) => {
                // Backspace للمدخل السابق
                if (e.key === 'Backspace' && !e.target.value && index > 0) {
                    otpInputs[index - 1].focus();
                }
                
                // Arrow keys للتنقل
                if (e.key === 'ArrowRight' && index < otpInputs.length - 1) {
                    otpInputs[index + 1].focus();
                }
                if (e.key === 'ArrowLeft' && index > 0) {
                    otpInputs[index - 1].focus();
                }
            });
            
            input.addEventListener('paste', (e) => {
                e.preventDefault();
                const paste = e.clipboardData.getData('text');
                const digits = paste.replace(/\D/g, '').slice(0, this.config.otpLength);
                
                digits.split('').forEach((digit, i) => {
                    if (otpInputs[index + i]) {
                        otpInputs[index + i].value = digit;
                        otpInputs[index + i].classList.add('filled');
                    }
                });
                
                // التركيز على المدخل التالي المناسب
                const nextIndex = Math.min(index + digits.length, otpInputs.length - 1);
                otpInputs[nextIndex].focus();
            });
        });
    },
    
    // مسح مدخلات OTP
    clearOTPInputs() {
        const otpInputs = document.querySelectorAll('.otp-input');
        otpInputs.forEach(input => {
            input.value = '';
            input.classList.remove('filled');
        });
        
        if (otpInputs.length > 0) {
            otpInputs[0].focus();
        }
    },
    
    // بدء مؤقت OTP
    startOTPTimer() {
        const timerDisplay = document.querySelector('.otp-timer');
        if (!timerDisplay) return;
        
        let timeLeft = this.config.otpTimeout / 1000; // بالثواني
        
        this.state.otpTimer = setInterval(() => {
            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;
            
            timerDisplay.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
            
            if (timeLeft <= 0) {
                clearInterval(this.state.otpTimer);
                this.handleOTPTimeout();
            }
            
            timeLeft--;
        }, 1000);
    },
    
    // معالجة انتهاء مهلة OTP
    handleOTPTimeout() {
        this.showError('انتهت صلاحية رمز التأكيد. يرجى طلب رمز جديد.');
        this.clearOTPInputs();
        
        const resendBtn = document.querySelector('.resend-otp');
        if (resendBtn) {
            resendBtn.disabled = false;
        }
    },
    
    // عرض خطوة OTP
    showOTPStep(data) {
        this.state.currentStep = 'otp';
        
        const loginStep = document.querySelector('.login-step');
        const otpStep = document.querySelector('.otp-step');
        
        if (loginStep && otpStep) {
            loginStep.style.display = 'none';
            otpStep.style.display = 'block';
            
            // تحديث معلومات OTP
            const phoneDisplay = otpStep.querySelector('.phone-display');
            if (phoneDisplay && data.masked_phone) {
                phoneDisplay.textContent = data.masked_phone;
            }
            
            this.startOTPTimer();
            
            // التركيز على أول مدخل OTP
            const firstOtpInput = otpStep.querySelector('.otp-input');
            if (firstOtpInput) {
                firstOtpInput.focus();
            }
        }
    },
    
    // تبديل رؤية كلمة المرور
    togglePasswordVisibility(e) {
        const toggle = e.target.closest('.password-toggle');
        const input = toggle.parentNode.querySelector('input');
        const icon = toggle.querySelector('i');
        
        if (input.type === 'password') {
            input.type = 'text';
            icon.className = 'fas fa-eye-slash';
            toggle.setAttribute('aria-label', 'إخفاء كلمة المرور');
        } else {
            input.type = 'password';
            icon.className = 'fas fa-eye';
            toggle.setAttribute('aria-label', 'إظهار كلمة المرور');
        }
    },
    
    // معالجة تذكرني
    handleRememberMe(e) {
        const isChecked = e.target.checked;
        
        if (isChecked) {
            this.showInfo(`سيتم تذكر تسجيل دخولك لمدة ${this.config.rememberMeDuration} يوم`);
        }
    },
    
    // تهيئة تسجيل الدخول الاجتماعي
    initializeSocialAuth() {
        const socialBtns = document.querySelectorAll('.social-auth-btn');
        
        socialBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const provider = btn.dataset.provider;
                this.handleSocialAuth(provider);
            });
        });
    },
    
    // معالجة تسجيل الدخول الاجتماعي
    handleSocialAuth(provider) {
        const popup = window.open(
            `/auth/social/${provider}`,
            'social-auth',
            'width=500,height=600,scrollbars=yes,resizable=yes'
        );
        
        // مراقبة النافذة المنبثقة
        const checkClosed = setInterval(() => {
            if (popup.closed) {
                clearInterval(checkClosed);
                this.checkSocialAuthResult();
            }
        }, 1000);
    },
    
    // فحص نتيجة تسجيل الدخول الاجتماعي
    async checkSocialAuthResult() {
        try {
            const response = await this.apiCall('check_social_auth');
            
            if (response.success) {
                this.handleLoginSuccess(response.data);
            }
        } catch (error) {
            // تجاهل الخطأ إذا لم يكن هناك نتيجة
        }
    },
    
    // حفظ بيانات النموذج
    saveFormData() {
        const forms = document.querySelectorAll('.auth-form[data-save="true"]');
        
        forms.forEach(form => {
            const formData = new FormData(form);
            const data = {};
            
            for (let [key, value] of formData.entries()) {
                if (!key.includes('password') && !key.includes('token')) {
                    data[key] = value;
                }
            }
            
            localStorage.setItem(`auth_form_${form.id}`, JSON.stringify(data));
        });
    },
    
    // استرجاع بيانات النموذج
    restoreFormData() {
        const forms = document.querySelectorAll('.auth-form[data-save="true"]');
        
        forms.forEach(form => {
            const savedData = localStorage.getItem(`auth_form_${form.id}`);
            
            if (savedData) {
                try {
                    const data = JSON.parse(savedData);
                    
                    Object.keys(data).forEach(key => {
                        const field = form.querySelector(`[name="${key}"]`);
                        if (field && field.type !== 'password') {
                            field.value = data[key];
                        }
                    });
                } catch (error) {
                    console.error('Failed to restore form data:', error);
                }
            }
        });
    },
    
    // مسح بيانات النموذج المحفوظة
    clearFormData() {
        const forms = document.querySelectorAll('.auth-form[data-save="true"]');
        
        forms.forEach(form => {
            localStorage.removeItem(`auth_form_${form.id}`);
        });
    },
    
    // استدعاء API
    async apiCall(action, data = {}) {
        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');
        
        const formData = new FormData();
        formData.append('action', action);
        
        if (csrfToken) {
            formData.append('csrf_token', csrfToken);
        }
        
        Object.keys(data).forEach(key => {
            formData.append(key, data[key]);
        });
        
        const response = await fetch('/api.php', {
            method: 'POST',
            body: formData,
            credentials: 'same-origin'
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        return await response.json();
    },
    
    // عرض التحميل
    showLoading(form) {
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.classList.add('loading');
            
            const spinner = submitBtn.querySelector('.spinner');
            if (spinner) {
                spinner.style.display = 'block';
            }
        }
    },
    
    // إخفاء التحميل
    hideLoading(form) {
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.classList.remove('loading');
            
            const spinner = submitBtn.querySelector('.spinner');
            if (spinner) {
                spinner.style.display = 'none';
            }
        }
    },
    
    // عرض رسالة خطأ
    showError(message) {
        this.showAlert(message, 'error');
    },
    
    // عرض رسالة نجاح
    showSuccess(message) {
        this.showAlert(message, 'success');
    },
    
    // عرض رسالة معلومات
    showInfo(message) {
        this.showAlert(message, 'info');
    },
    
    // عرض تنبيه
    showAlert(message, type) {
        // إزالة التنبيهات السابقة
        const existingAlerts = document.querySelectorAll('.auth-alert');
        existingAlerts.forEach(alert => alert.remove());
        
        // إنشاء تنبيه جديد
        const alert = document.createElement('div');
        alert.className = `auth-alert alert-${type}`;
        alert.innerHTML = `
            <i class="fas ${this.getAlertIcon(type)}"></i>
            <span>${message}</span>
            <button class="alert-close">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        // إضافة التنبيه لأول نموذج موجود
        const authContainer = document.querySelector('.auth-card, .auth-container, .container');
        if (authContainer) {
            authContainer.insertBefore(alert, authContainer.firstChild);
        }
        
        // زر الإغلاق
        alert.querySelector('.alert-close').addEventListener('click', () => {
            alert.remove();
        });
        
        // إخفاء تلقائي للنجاح والمعلومات
        if (type === 'success' || type === 'info') {
            setTimeout(() => {
                if (alert.parentNode) {
                    alert.remove();
                }
            }, 5000);
        }
        
        // تمرير للأعلى
        alert.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    },
    
    // الحصول على أيقونة التنبيه
    getAlertIcon(type) {
        const icons = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle'
        };
        
        return icons[type] || icons.info;
    }
};

// تهيئة مدير المصادقة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    AuthManager.init();
});

// تصدير للاستخدام العام
window.AuthManager = AuthManager;