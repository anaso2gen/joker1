#!/bin/bash
# سكريپت إنشاء الصور البديلة المطلوبة
# منصة ترند التعليمية
# المطور: anaso2gen

echo "إنشاء الصور البديلة للمنصة..."

# إنشاء المجلدات
mkdir -p icons features categories courses instructors ui states certificates backgrounds social screenshots shortcuts

# الألوان المستخدمة
PRIMARY_COLOR="#667eea"
SECONDARY_COLOR="#764ba2"
ACCENT_COLOR="#f093fb"
SUCCESS_COLOR="#48bb78"
WARNING_COLOR="#ed8936"
ERROR_COLOR="#f56565"

# إنشاء الشعارات
convert -size 300x100 xc:white \
    -fill "$PRIMARY_COLOR" \
    -pointsize 36 \
    -gravity center \
    -annotate +0+0 'ترند أكاديمي' \
    logo.png

convert -size 300x100 xc:"$PRIMARY_COLOR" \
    -fill white \
    -pointsize 36 \
    -gravity center \
    -annotate +0+0 'ترند أكاديمي' \
    logo-white.png

# إنشاء أيقونات التطبيق
for size in 72 96 128 144 152 192 384 512; do
    convert -size ${size}x${size} xc:"$PRIMARY_COLOR" \
        -fill white \
        -pointsize $((size/4)) \
        -gravity center \
        -annotate +0+0 'ت' \
        icons/icon-${size}x${size}.png
done

# إنشاء صور الفئات
categories=("programming" "web-development" "mobile-development" "data-science" "artificial-intelligence" "cybersecurity" "digital-marketing" "graphic-design" "business" "languages")

for category in "${categories[@]}"; do
    convert -size 400x300 \
        -gradient:"$PRIMARY_COLOR"-"$SECONDARY_COLOR" \
        -fill white \
        -pointsize 24 \
        -gravity center \
        -annotate +0+0 "${category^}" \
        categories/${category}.jpg
done

# إنشاء صور الدورات
courses=("javascript-course" "python-course" "react-course" "nodejs-course" "php-course" "laravel-course" "vue-course" "angular-course" "flutter-course" "docker-course")

for course in "${courses[@]}"; do
    convert -size 600x400 \
        -gradient:"$ACCENT_COLOR"-"$PRIMARY_COLOR" \
        -fill white \
        -pointsize 28 \
        -gravity center \
        -annotate +0+0 "${course^}" \
        courses/${course}.jpg
done

# إنشاء صور المدربين
instructors=("ahmed-ali" "sara-mohamed" "omar-hassan" "fatima-ahmed" "youssef-mahmoud")

for instructor in "${instructors[@]}"; do
    convert -size 300x300 \
        -gradient:"$SUCCESS_COLOR"-"$PRIMARY_COLOR" \
        -fill white \
        -pointsize 20 \
        -gravity center \
        -annotate +0+0 "${instructor^}" \
        instructors/${instructor}.jpg
done

# صورة بديلة عامة
convert -size 800x600 \
    -gradient:"$PRIMARY_COLOR"-"$SECONDARY_COLOR" \
    -fill white \
    -pointsize 32 \
    -gravity center \
    -annotate +0+0 'صورة بديلة' \
    placeholder.jpg

# صورة بديلة للملف الشخصي
convert -size 150x150 \
    radial-gradient:"$PRIMARY_COLOR"-"$ACCENT_COLOR" \
    -fill white \
    -pointsize 48 \
    -gravity center \
    -annotate +0+0 '👤' \
    avatar-placeholder.png

echo "تم إنشاء الصور البديلة بنجاح!"