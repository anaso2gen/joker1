<?php
/**
 * دوال مساعدة عامة
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 10:00:13
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

/**
 * الحصول على العنوان الحقيقي للـ IP
 */
function getRealIpAddress() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED'])) {
        return $_SERVER['HTTP_X_FORWARDED'];
    } elseif (!empty($_SERVER['HTTP_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_FORWARDED_FOR'];
    } elseif (!empty($_SERVER['HTTP_FORWARDED'])) {
        return $_SERVER['HTTP_FORWARDED'];
    } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
        return $_SERVER['REMOTE_ADDR'];
    }
    return 'UNKNOWN';
}

/**
 * فحص قوة كلمة المرور
 */
function isStrongPassword($password) {
    if (strlen($password) < 8) {
        return false;
    }
    
    if (!preg_match('/[A-Z]/', $password)) {
        return false;
    }
    
    if (!preg_match('/[a-z]/', $password)) {
        return false;
    }
    
    if (!preg_match('/[0-9]/', $password)) {
        return false;
    }
    
    return true;
}

/**
 * تنظيف النص من HTML والـ XSS
 */
function sanitizeText($text) {
    return htmlspecialchars(trim($text), ENT_QUOTES, 'UTF-8');
}

/**
 * تنظيف HTML المسموح
 */
function sanitizeHtml($html, $allowedTags = '<p><br><strong><em><ul><ol><li><a><img>') {
    return strip_tags($html, $allowedTags);
}

/**
 * تشفير البيانات
 */
function encryptData($data, $key = null) {
    $key = $key ?: ENCRYPTION_KEY;
    $iv = random_bytes(16);
    $encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);
    return base64_encode($iv . $encrypted);
}

/**
 * فك تشفير البيانات
 */
function decryptData($encryptedData, $key = null) {
    $key = $key ?: ENCRYPTION_KEY;
    $data = base64_decode($encryptedData);
    $iv = substr($data, 0, 16);
    $encrypted = substr($data, 16);
    return openssl_decrypt($encrypted, 'AES-256-CBC', $key, 0, $iv);
}

/**
 * إنشاء رمز CSRF
 */
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * التحقق من رمز CSRF
 */
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * تسجيل حدث أمني
 */
function logSecurityEvent($description, $severity = 'medium', $additionalData = []) {
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        
        $stmt = $pdo->prepare("
            INSERT INTO security_logs (event_type, severity, description, user_id, ip_address, user_agent, additional_data, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([
            $additionalData['event_type'] ?? 'general',
            $severity,
            $description,
            $additionalData['user_id'] ?? null,
            getRealIpAddress(),
            $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
            json_encode($additionalData)
        ]);
    } catch (Exception $e) {
        error_log("Failed to log security event: " . $e->getMessage());
    }
}

/**
 * إرسال بريد إلكتروني
 */
function sendEmail($to, $subject, $message, $isHtml = true) {
    try {
        require_once __DIR__ . '/../vendor/phpmailer/phpmailer/src/PHPMailer.php';
        require_once __DIR__ . '/../vendor/phpmailer/phpmailer/src/SMTP.php';
        require_once __DIR__ . '/../vendor/phpmailer/phpmailer/src/Exception.php';
        
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        
        // إعدادات SMTP
        $mail->isSMTP();
        $mail->Host = MAIL_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = MAIL_USERNAME;
        $mail->Password = MAIL_PASSWORD;
        $mail->SMTPSecure = MAIL_ENCRYPTION;
        $mail->Port = MAIL_PORT;
        $mail->CharSet = 'UTF-8';
        
        // إعدادات المرسل والمستقبل
        $mail->setFrom(MAIL_FROM_ADDRESS, MAIL_FROM_NAME);
        $mail->addAddress($to);
        $mail->addReplyTo(MAIL_FROM_ADDRESS, MAIL_FROM_NAME);
        
        // محتوى البريد
        $mail->isHTML($isHtml);
        $mail->Subject = $subject;
        $mail->Body = $message;
        
        return $mail->send();
    } catch (Exception $e) {
        error_log("Failed to send email: " . $e->getMessage());
        return false;
    }
}

/**
 * تحويل حجم الملف لصيغة قابلة للقراءة
 */
function formatBytes($size, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    
    for ($i = 0; $size > 1024 && $i < count($units) - 1; $i++) {
        $size /= 1024;
    }
    
    return round($size, $precision) . ' ' . $units[$i];
}

/**
 * تحويل الوقت لصيغة عربية
 */
function formatArabicDate($date, $format = 'full') {
    $timestamp = is_string($date) ? strtotime($date) : $date;
    
    $arabicMonths = [
        1 => 'يناير', 2 => 'فبراير', 3 => 'مارس', 4 => 'أبريل',
        5 => 'مايو', 6 => 'يونيو', 7 => 'يوليو', 8 => 'أغسطس',
        9 => 'سبتمبر', 10 => 'أكتوبر', 11 => 'نوفمبر', 12 => 'ديسمبر'
    ];
    
    $arabicDays = [
        'Sunday' => 'الأحد', 'Monday' => 'الاثنين', 'Tuesday' => 'الثلاثاء',
        'Wednesday' => 'الأربعاء', 'Thursday' => 'الخميس', 'Friday' => 'الجمعة',
        'Saturday' => 'السبت'
    ];
    
    $day = date('j', $timestamp);
    $month = $arabicMonths[date('n', $timestamp)];
    $year = date('Y', $timestamp);
    $dayName = $arabicDays[date('l', $timestamp)];
    
    switch ($format) {
        case 'short':
            return "$day $month $year";
        case 'medium':
            return "$dayName، $day $month $year";
        case 'full':
        default:
            $time = date('H:i', $timestamp);
            return "$dayName، $day $month $year الساعة $time";
    }
}

/**
 * حساب الوقت المنقضي بالعربية
 */
function timeAgo($date) {
    $timestamp = is_string($date) ? strtotime($date) : $date;
    $diff = time() - $timestamp;
    
    if ($diff < 60) {
        return 'منذ لحظات';
    } elseif ($diff < 3600) {
        $minutes = floor($diff / 60);
        return "منذ $minutes " . ($minutes == 1 ? 'دقيقة' : 'دقائق');
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return "منذ $hours " . ($hours == 1 ? 'ساعة' : 'ساعات');
    } elseif ($diff < 2592000) {
        $days = floor($diff / 86400);
        return "منذ $days " . ($days == 1 ? 'يوم' : 'أيام');
    } elseif ($diff < 31536000) {
        $months = floor($diff / 2592000);
        return "منذ $months " . ($months == 1 ? 'شهر' : 'شهور');
    } else {
        $years = floor($diff / 31536000);
        return "منذ $years " . ($years == 1 ? 'سنة' : 'سنوات');
    }
}

/**
 * تحويل المدة بالثواني لصيغة قابلة للقراءة
 */
function formatDuration($seconds) {
    if ($seconds < 60) {
        return $seconds . ' ثانية';
    } elseif ($seconds < 3600) {
        $minutes = floor($seconds / 60);
        $remainingSeconds = $seconds % 60;
        return $minutes . ' دقيقة' . ($remainingSeconds > 0 ? ' و ' . $remainingSeconds . ' ثانية' : '');
    } else {
        $hours = floor($seconds / 3600);
        $remainingMinutes = floor(($seconds % 3600) / 60);
        return $hours . ' ساعة' . ($remainingMinutes > 0 ? ' و ' . $remainingMinutes . ' دقيقة' : '');
    }
}

/**
 * إنشاء صورة مصغرة
 */
function createThumbnail($source, $destination, $width, $height, $quality = 85) {
    $imageInfo = getimagesize($source);
    if (!$imageInfo) {
        return false;
    }
    
    $sourceWidth = $imageInfo[0];
    $sourceHeight = $imageInfo[1];
    $mimeType = $imageInfo['mime'];
    
    // إنشاء الصورة المصدر
    switch ($mimeType) {
        case 'image/jpeg':
            $sourceImage = imagecreatefromjpeg($source);
            break;
        case 'image/png':
            $sourceImage = imagecreatefrompng($source);
            break;
        case 'image/gif':
            $sourceImage = imagecreatefromgif($source);
            break;
        default:
            return false;
    }
    
    // حساب الأبعاد الجديدة مع الحفاظ على النسبة
    $sourceRatio = $sourceWidth / $sourceHeight;
    $targetRatio = $width / $height;
    
    if ($sourceRatio > $targetRatio) {
        $newWidth = $width;
        $newHeight = $width / $sourceRatio;
    } else {
        $newHeight = $height;
        $newWidth = $height * $sourceRatio;
    }
    
    // إنشاء الصورة المصغرة
    $thumbnail = imagecreatetruecolor($width, $height);
    
    // الحفاظ على الشفافية للـ PNG
    if ($mimeType === 'image/png') {
        imagealphablending($thumbnail, false);
        imagesavealpha($thumbnail, true);
        $transparent = imagecolorallocatealpha($thumbnail, 255, 255, 255, 127);
        imagefill($thumbnail, 0, 0, $transparent);
    }
    
    // تغيير حجم الصورة
    $x = ($width - $newWidth) / 2;
    $y = ($height - $newHeight) / 2;
    
    imagecopyresampled(
        $thumbnail, $sourceImage,
        $x, $y, 0, 0,
        $newWidth, $newHeight,
        $sourceWidth, $sourceHeight
    );
    
    // حفظ الصورة
    $result = imagejpeg($thumbnail, $destination, $quality);
    
    // تنظيف الذاكرة
    imagedestroy($sourceImage);
    imagedestroy($thumbnail);
    
    return $result;
}

/**
 * إنشاء slug من النص العربي
 */
function createSlug($text) {
    // تحويل النص العربي لـ transliteration
    $arabicToLatin = [
        'أ' => 'a', 'إ' => 'i', 'آ' => 'aa', 'ا' => 'a', 'ب' => 'b', 'ت' => 't',
        'ث' => 'th', 'ج' => 'j', 'ح' => 'h', 'خ' => 'kh', 'د' => 'd', 'ذ' => 'th',
        'ر' => 'r', 'ز' => 'z', 'س' => 's', 'ش' => 'sh', 'ص' => 's', 'ض' => 'd',
        'ط' => 't', 'ظ' => 'z', 'ع' => 'a', 'غ' => 'gh', 'ف' => 'f', 'ق' => 'q',
        'ك' => 'k', 'ل' => 'l', 'م' => 'm', 'ن' => 'n', 'ه' => 'h', 'و' => 'w',
        'ي' => 'y', 'ة' => 'h', 'ى' => 'a', 'ئ' => 'e', 'ء' => 'a'
    ];
    
    $text = str_replace(array_keys($arabicToLatin), array_values($arabicToLatin), $text);
    $text = strtolower($text);
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    $text = trim($text, '-');
    
    return $text;
}

/**
 * التحقق من صحة رقم الهاتف السعودي
 */
function isValidSaudiPhone($phone) {
    $phone = preg_replace('/[^0-9]/', '', $phone);
    
    // أرقام سعودية صحيحة
    if (preg_match('/^(966|0)?(5[0-9]{8})$/', $phone)) {
        return true;
    }
    
    return false;
}

/**
 * تنسيق رقم الهاتف السعودي
 */
function formatSaudiPhone($phone) {
    $phone = preg_replace('/[^0-9]/', '', $phone);
    
    if (preg_match('/^966(5[0-9]{8})$/', $phone, $matches)) {
        return '+966 ' . substr($matches[1], 0, 2) . ' ' . substr($matches[1], 2, 3) . ' ' . substr($matches[1], 5, 4);
    } elseif (preg_match('/^0(5[0-9]{8})$/', $phone, $matches)) {
        return '0' . substr($matches[1], 0, 2) . ' ' . substr($matches[1], 2, 3) . ' ' . substr($matches[1], 5, 4);
    }
    
    return $phone;
}

/**
 * إنشاء كود مرجعي عشوائي
 */
function generateReferenceCode($prefix = '', $length = 8) {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $code = '';
    
    for ($i = 0; $i < $length; $i++) {
        $code .= $characters[rand(0, strlen($characters) - 1)];
    }
    
    return $prefix . $code;
}

/**
 * التحقق من امتداد الملف
 */
function isAllowedFileType($filename, $allowedTypes) {
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($extension, $allowedTypes);
}

/**
 * تحويل النص لـ JSON آمن
 */
function safeJsonEncode($data) {
    return json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

/**
 * فك تشفير JSON مع معالجة الأخطاء
 */
function safeJsonDecode($json, $assoc = true) {
    $data = json_decode($json, $assoc);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        return $assoc ? [] : null;
    }
    
    return $data;
}

/**
 * إنشاء كلمة مرور عشوائية قوية
 */
function generateStrongPassword($length = 12) {
    $lowercase = 'abcdefghijklmnopqrstuvwxyz';
    $uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $numbers = '0123456789';
    $symbols = '!@#$%^&*()_+-=[]{}|;:,.<>?';
    
    $all = $lowercase . $uppercase . $numbers . $symbols;
    $password = '';
    
    // ضمان وجود حرف من كل نوع
    $password .= $lowercase[rand(0, strlen($lowercase) - 1)];
    $password .= $uppercase[rand(0, strlen($uppercase) - 1)];
    $password .= $numbers[rand(0, strlen($numbers) - 1)];
    $password .= $symbols[rand(0, strlen($symbols) - 1)];
    
    // إكمال باقي الطول
    for ($i = 4; $i < $length; $i++) {
        $password .= $all[rand(0, strlen($all) - 1)];
    }
    
    return str_shuffle($password);
}

/**
 * تحديد نوع المتصفح
 */
function getBrowser() {
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    if (strpos($userAgent, 'Chrome') !== false) {
        return 'Chrome';
    } elseif (strpos($userAgent, 'Firefox') !== false) {
        return 'Firefox';
    } elseif (strpos($userAgent, 'Safari') !== false) {
        return 'Safari';
    } elseif (strpos($userAgent, 'Edge') !== false) {
        return 'Edge';
    } elseif (strpos($userAgent, 'Opera') !== false) {
        return 'Opera';
    }
    
    return 'Unknown';
}

/**
 * تحديد نظام التشغيل
 */
function getOperatingSystem() {
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    if (strpos($userAgent, 'Windows') !== false) {
        return 'Windows';
    } elseif (strpos($userAgent, 'Mac') !== false) {
        return 'macOS';
    } elseif (strpos($userAgent, 'Linux') !== false) {
        return 'Linux';
    } elseif (strpos($userAgent, 'Android') !== false) {
        return 'Android';
    } elseif (strpos($userAgent, 'iOS') !== false) {
        return 'iOS';
    }
    
    return 'Unknown';
}

/**
 * إنشاء QR Code
 */
function generateQRCode($data, $size = 200) {
    // يتطلب مكتبة QR code
    // return "https://api.qrserver.com/v1/create-qr-code/?size={$size}x{$size}&data=" . urlencode($data);
    return "data:image/svg+xml;base64," . base64_encode("<!-- QR Code for: $data -->");
}

/**
 * التحقق من معدل الطلبات
 */
function checkRateLimit($identifier, $maxRequests, $timeWindow = 3600) {
    $cacheKey = "rate_limit_" . md5($identifier);
    
    // استخدام APCu إذا كان متاحاً
    if (function_exists('apcu_fetch')) {
        $requests = apcu_fetch($cacheKey, $success);
        if (!$success) {
            $requests = ['count' => 0, 'reset_time' => time() + $timeWindow];
        }
        
        if (time() > $requests['reset_time']) {
            $requests = ['count' => 0, 'reset_time' => time() + $timeWindow];
        }
        
        $requests['count']++;
        apcu_store($cacheKey, $requests, $timeWindow);
        
        return $requests['count'] <= $maxRequests;
    }
    
    // استخدام الجلسة كبديل
    if (!isset($_SESSION['rate_limits'])) {
        $_SESSION['rate_limits'] = [];
    }
    
    if (!isset($_SESSION['rate_limits'][$identifier])) {
        $_SESSION['rate_limits'][$identifier] = ['count' => 0, 'reset_time' => time() + $timeWindow];
    }
    
    $limit = &$_SESSION['rate_limits'][$identifier];
    
    if (time() > $limit['reset_time']) {
        $limit = ['count' => 0, 'reset_time' => time() + $timeWindow];
    }
    
    $limit['count']++;
    
    return $limit['count'] <= $maxRequests;
}

/**
 * تنظيف وتحسين قاعدة البيانات
 */
function optimizeDatabase() {
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        
        // الحصول على قائمة الجداول
        $stmt = $pdo->query("SHOW TABLES");
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        foreach ($tables as $table) {
            // تحسين الجدول
            $pdo->exec("OPTIMIZE TABLE `$table`");
        }
        
        return true;
    } catch (Exception $e) {
        error_log("Database optimization failed: " . $e->getMessage());
        return false;
    }
}

/**
 * حفظ إعداد النظام
 */
function setSetting($key, $value, $type = 'string') {
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        
        $stmt = $pdo->prepare("
            INSERT INTO system_settings (setting_key, setting_value, setting_type) 
            VALUES (?, ?, ?) 
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()
        ");
        
        return $stmt->execute([$key, $value, $type]);
    } catch (Exception $e) {
        error_log("Failed to save setting: " . $e->getMessage());
        return false;
    }
}

/**
 * الحصول على إعداد النظام
 */
function getSetting($key, $default = null) {
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        
        $stmt = $pdo->prepare("SELECT setting_value, setting_type FROM system_settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $result = $stmt->fetch();
        
        if (!$result) {
            return $default;
        }
        
        $value = $result['setting_value'];
        $type = $result['setting_type'];
        
        switch ($type) {
            case 'boolean':
                return (bool) $value;
            case 'number':
                return (float) $value;
            case 'json':
                return json_decode($value, true);
            default:
                return $value;
        }
    } catch (Exception $e) {
        error_log("Failed to get setting: " . $e->getMessage());
        return $default;
    }
}
?>