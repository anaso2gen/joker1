/**
 * middleware شامل للأمان
 */
function applySecurityMiddleware() {
    // فحص وضع الصيانة
    checkMaintenanceMode();
    
    // فحص IP المحظور
    checkBlockedIP();
    
    // حماية XSS
    xssProtection();
    
    // تسجيل الوصول
    logAccess();
}

/**
 * فحص صلاحية الوصول للملف
 */
function checkFileAccess($filePath, $userId = null) {
    global $sessionManager;
    
    // فحص إذا كان الملف موجود
    if (!file_exists($filePath)) {
        return false;
    }
    
    // فحص إذا كان ملف عام
    $publicDirs = ['assets', 'uploads/public'];
    foreach ($publicDirs as $dir) {
        if (strpos($filePath, $dir) !== false) {
            return true;
        }
    }
    
    // فحص تسجيل الدخول للملفات المحمية
    if (!$sessionManager || !$sessionManager->isLoggedIn()) {
        return false;
    }
    
    $user = $sessionManager->getCurrentUser();
    $currentUserId = $userId ?: $user['id'];
    
    // السماح للإداريين بالوصول لجميع الملفات
    if ($user['is_admin']) {
        return true;
    }
    
    // فحص ملفات المستخدمين
    if (strpos($filePath, 'uploads/avatars') !== false) {
        $filename = basename($filePath);
        return strpos($filename, $currentUserId . '_') === 0;
    }
    
    // فحص ملفات الدورات
    if (strpos($filePath, 'uploads/courses') !== false || strpos($filePath, 'uploads/videos') !== false) {
        // استخراج معرف الدورة من مسار الملف أو اسمه
        preg_match('/course_(\d+)/', $filePath, $matches);
        if ($matches) {
            $courseId = $matches[1];
            return checkUserCourseAccess($currentUserId, $courseId);
        }
    }
    
    return false;
}

/**
 * فحص وصول المستخدم للدورة
 */
function checkUserCourseAccess($userId, $courseId) {
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM subscriptions 
            WHERE user_id = ? AND course_id = ? AND is_active = 1
        ");
        $stmt->execute([$userId, $courseId]);
        
        return $stmt->fetchColumn() > 0;
    } catch (Exception $e) {
        return false;
    }
}

/**
 * إعادة توجيه آمنة
 */
function safeRedirect($url, $fallback = 'index.php') {
    // فحص إذا كان URL داخليا
    $parsedUrl = parse_url($url);
    $currentHost = $_SERVER['HTTP_HOST'];
    
    if (isset($parsedUrl['host']) && $parsedUrl['host'] !== $currentHost) {
        $url = $fallback;
    }
    
    // منع open redirect
    $allowedPages = [
        'index.php', 'courses.php', 'course.php', 'lesson.php', 
        'profile.php', 'dashboard.php', 'login.php', 'register.php'
    ];
    
    $page = basename($url);
    if (!in_array($page, $allowedPages) && !preg_match('/^[a-zA-Z0-9_-]+\.php$/', $page)) {
        $url = $fallback;
    }
    
    header("Location: $url");
    exit;
}
?>