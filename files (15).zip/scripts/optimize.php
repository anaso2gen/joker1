        if ($combinedJS) {
            $compressedJS = $this->compressJS($combinedJS);
            file_put_contents(APP_ROOT . '/assets/js/combined.min.js', $compressedJS);
        }
    }

    /**
     * تجميع السكريبتات مسبقاً
     */
    private function precompileScripts()
    {
        $compiledFiles = 0;
        $phpFiles = $this->findPHPFiles(APP_ROOT);
        
        foreach ($phpFiles as $file) {
            if (opcache_compile_file($file)) {
                $compiledFiles++;
            }
        }
        
        return ['compiled_files' => $compiledFiles];
    }

    /**
     * البحث عن ملفات PHP
     */
    private function findPHPFiles($directory)
    {
        $phpFiles = [];
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile() && $file->getExtension() === 'php') {
                $phpFiles[] = $file->getPathname();
            }
        }
        
        return $phpFiles;
    }

    /**
     * تحسين APCu
     */
    private function optimizeAPCu()
    {
        if (!extension_loaded('apcu')) {
            return ['status' => 'not_available'];
        }
        
        // تنظيف cache منتهي الصلاحية
        apcu_clear_cache();
        
        // تحميل البيانات المهمة في cache
        $this->preloadImportantData();
        
        return ['status' => 'optimized'];
    }

    /**
     * تحميل البيانات المهمة مسبقاً
     */
    private function preloadImportantData()
    {
        try {
            // تحميل إعدادات التطبيق
            $config = include APP_ROOT . '/config/app.php';
            apcu_store('app_config', $config, 3600);
            
            // تحميل الفئات النشطة
            $stmt = $this->db->query("SELECT * FROM categories WHERE status = 'active'");
            $categories = $stmt->fetchAll();
            apcu_store('active_categories', $categories, 1800);
            
            // تحميل الدورات المميزة
            $stmt = $this->db->query("SELECT * FROM courses WHERE is_featured = 1 AND status = 'published' LIMIT 10");
            $featuredCourses = $stmt->fetchAll();
            apcu_store('featured_courses', $featuredCourses, 900);
            
        } catch (Exception $e) {
            $this->log("خطأ في تحميل البيانات المسبقة: " . $e->getMessage(), 'WARNING');
        }
    }

    /**
     * تحسين إعدادات PHP
     */
    private function optimizePHPSettings()
    {
        $this->log("فحص إعدادات PHP");
        
        $recommendations = [];
        
        // فحص memory_limit
        $memoryLimit = ini_get('memory_limit');
        $memoryLimitBytes = $this->parseBytes($memoryLimit);
        if ($memoryLimitBytes < 512 * 1024 * 1024) { // أقل من 512MB
            $recommendations[] = "زيادة memory_limit إلى 512M على الأقل (حالياً: {$memoryLimit})";
        }
        
        // فحص max_execution_time
        $maxExecTime = ini_get('max_execution_time');
        if ($maxExecTime < 300) { // أقل من 5 دقائق
            $recommendations[] = "زيادة max_execution_time إلى 300 (حالياً: {$maxExecTime})";
        }
        
        // فحص upload_max_filesize
        $uploadMaxSize = ini_get('upload_max_filesize');
        $uploadMaxSizeBytes = $this->parseBytes($uploadMaxSize);
        if ($uploadMaxSizeBytes < 50 * 1024 * 1024) { // أقل من 50MB
            $recommendations[] = "زيادة upload_max_filesize إلى 50M (حالياً: {$uploadMaxSize})";
        }
        
        // فحص OPcache
        if (!extension_loaded('opcache')) {
            $recommendations[] = "تفعيل OPcache لتحسين الأداء";
        } elseif (!ini_get('opcache.enable')) {
            $recommendations[] = "تفعيل OPcache (opcache.enable=1)";
        }
        
        // فحص APCu
        if (!extension_loaded('apcu')) {
            $recommendations[] = "تثبيت وتفعيل APCu للتخزين المؤقت";
        }
        
        $this->optimizationResults['php_settings'] = [
            'current_settings' => [
                'memory_limit' => $memoryLimit,
                'max_execution_time' => $maxExecTime,
                'upload_max_filesize' => $uploadMaxSize,
                'opcache_enabled' => extension_loaded('opcache') && ini_get('opcache.enable'),
                'apcu_enabled' => extension_loaded('apcu')
            ],
            'recommendations' => $recommendations
        ];
        
        if (empty($recommendations)) {
            $this->log("إعدادات PHP محسنة بشكل جيد");
        } else {
            $this->log("توصيات تحسين PHP: " . count($recommendations) . " توصية");
        }
    }

    /**
     * إنشاء ملفات إعداد الخادم
     */
    private function generateServerConfig()
    {
        $this->log("إنشاء ملفات إعداد الخادم");
        
        // إنشاء .htaccess محسن
        $this->generateHtaccess();
        
        // إنشاء nginx.conf
        $this->generateNginxConfig();
        
        $this->log("تم إنشاء ملفات إعداد الخادم");
    }

    /**
     * إنشاء ملف .htaccess محسن
     */
    private function generateHtaccess()
    {
        $htaccess = '
# Trend Academy - Apache Configuration
# Generated on ' . date('Y-m-d H:i:s') . '

# Security Headers
<IfModule mod_headers.c>
    Header always set X-Content-Type-Options nosniff
    Header always set X-Frame-Options SAMEORIGIN
    Header always set X-XSS-Protection "1; mode=block"
    Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"
    Header always set Content-Security-Policy "default-src \'self\'; script-src \'self\' \'unsafe-inline\' \'unsafe-eval\'; style-src \'self\' \'unsafe-inline\'; img-src \'self\' data: https:; font-src \'self\' https://fonts.gstatic.com; connect-src \'self\'"
</IfModule>

# Compression
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript application/json
</IfModule>

# Browser Caching
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType text/css "access plus 1 year"
    ExpiresByType application/javascript "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/gif "access plus 1 year"
    ExpiresByType image/svg+xml "access plus 1 year"
    ExpiresByType image/webp "access plus 1 year"
    ExpiresByType font/woff "access plus 1 year"
    ExpiresByType font/woff2 "access plus 1 year"
</IfModule>

# URL Rewriting
<IfModule mod_rewrite.c>
    RewriteEngine On
    
    # Force HTTPS
    RewriteCond %{HTTPS} off
    RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
    
    # Remove www
    RewriteCond %{HTTP_HOST} ^www\.(.+)$ [NC]
    RewriteRule ^(.*)$ https://%1%{REQUEST_URI} [L,R=301]
    
    # Hide .php extension
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteRule ^([^\.]+)$ $1.php [NC,L]
    
    # API Routes
    RewriteRule ^api/(.*)$ api.php [QSA,L]
    
    # Admin Panel
    RewriteRule ^admin/(.*)$ admin/$1.php [QSA,L]
</IfModule>

# Protect sensitive files
<FilesMatch "\.(env|log|json|sql|md)$">
    Order Allow,Deny
    Deny from all
</FilesMatch>

# Protect directories
RedirectMatch 403 ^/storage/.*$
RedirectMatch 403 ^/config/.*$
RedirectMatch 403 ^/scripts/.*$
';
        
        file_put_contents(APP_ROOT . '/.htaccess', trim($htaccess));
    }

    /**
     * إنشاء إعداد Nginx
     */
    private function generateNginxConfig()
    {
        $nginxConfig = '
# Trend Academy - Nginx Configuration
# Generated on ' . date('Y-m-d H:i:s') . '

server {
    listen 80;
    server_name your-domain.com www.your-domain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com www.your-domain.com;
    root /path/to/trend-academy/public;
    index index.php index.html;

    # SSL Configuration
    ssl_certificate /path/to/certificate.crt;
    ssl_certificate_key /path/to/private.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512;
    ssl_prefer_server_ciphers off;

    # Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src \'self\' http: https: data: blob: \'unsafe-inline\'" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # Gzip Compression
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;

    # File Caching
    location ~* \.(css|js|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # PHP Processing
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    # API Routes
    location /api/ {
        try_files $uri /api.php?$query_string;
    }

    # Admin Panel
    location /admin/ {
        try_files $uri /admin$uri.php?$query_string;
    }

    # Protect sensitive files
    location ~* \.(env|log|json|sql|md)$ {
        deny all;
    }

    # Protect directories
    location /storage/ {
        deny all;
    }
    
    location /config/ {
        deny all;
    }
    
    location /scripts/ {
        deny all;
    }
}
';
        
        file_put_contents(APP_ROOT . '/nginx.conf', trim($nginxConfig));
    }

    /**
     * إنشاء تقرير التحسين
     */
    private function generateOptimizationReport()
    {
        $reportPath = APP_ROOT . '/storage/logs/optimization_report_' . date('Y-m-d_H-i-s') . '.json';
        
        $report = [
            'optimization_date' => date('Y-m-d H:i:s'),
            'duration' => round(microtime(true) - $this->startTime, 2),
            'results' => $this->optimizationResults,
            'system_info' => [
                'php_version' => PHP_VERSION,
                'memory_usage' => memory_get_peak_usage(true),
                'disk_free_space' => disk_free_space(APP_ROOT),
                'extensions' => get_loaded_extensions()
            ]
        ];
        
        file_put_contents($reportPath, json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        
        $this->log("تم إنشاء تقرير التحسين: " . basename($reportPath));
    }

    /**
     * الحصول على حجم المجلد
     */
    private function getDirectorySize($directory)
    {
        $size = 0;
        
        if (!is_dir($directory)) {
            return 0;
        }
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $size += $file->getSize();
            }
        }
        
        return $size;
    }

    /**
     * تنسيق الحجم بالبايت
     */
    private function formatBytes($bytes, $precision = 2)
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        
        for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
            $bytes /= 1024;
        }
        
        return round($bytes, $precision) . ' ' . $units[$i];
    }

    /**
     * تسجيل رسالة
     */
    private function log($message, $level = 'INFO')
    {
        $timestamp = date('Y-m-d H:i:s');
        $logEntry = "[{$timestamp}] [{$level}] {$message}" . PHP_EOL;
        
        file_put_contents($this->logFile, $logEntry, FILE_APPEND | LOCK_EX);
        
        // طباعة في سطر الأوامر أيضاً
        if (php_sapi_name() === 'cli') {
            echo $logEntry;
        }
    }
}

// تشغيل التحسين إذا تم استدعاؤه من سطر الأوامر
if (php_sapi_name() === 'cli') {
    $options = [];
    
    // تحليل المعاملات
    for ($i = 1; $i < $argc; $i++) {
        switch ($argv[$i]) {
            case '--skip-database':
                $options['skip_database'] = true;
                break;
            case '--skip-indexes':
                $options['skip_indexes'] = true;
                break;
            case '--skip-assets':
                $options['skip_assets'] = true;
                break;
            case '--skip-images':
                $options['skip_images'] = true;
                break;
            case '--server-config':
                $options['server_config'] = true;
                break;
            case '--remove-unused-indexes':
                $options['remove_unused_indexes'] = true;
                break;
            case '--help':
                echo "استخدام: php optimize.php [options]" . PHP_EOL;
                echo "الخيارات:" . PHP_EOL;
                echo "  --skip-database         تخطي تحسين قاعدة البيانات" . PHP_EOL;
                echo "  --skip-indexes          تخطي تحسين الفهارس" . PHP_EOL;
                echo "  --skip-assets           تخطي تحسين CSS/JS" . PHP_EOL;
                echo "  --skip-images           تخطي تحسين الصور" . PHP_EOL;
                echo "  --server-config         إنشاء ملفات إعداد الخادم" . PHP_EOL;
                echo "  --remove-unused-indexes حذف الفهارس غير المستخدمة" . PHP_EOL;
                echo "  --help                  عرض هذه الرسالة" . PHP_EOL;
                exit(0);
        }
    }
    
    $optimizer = new PerformanceOptimizer();
    $result = $optimizer->run($options);
    
    if ($result['success']) {
        echo "اكتملت عملية التحسين بنجاح!" . PHP_EOL;
        echo "المدة: {$result['duration']} ثانية" . PHP_EOL;
        exit(0);
    } else {
        echo "فشلت عملية التحسين: " . $result['error'] . PHP_EOL;
        exit(1);
    }
}