<?php
/**
 * الملف الشخصي للمستخدم
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 08:55:29
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/session.php';

// طلب تسجيل الدخول
$sessionManager->requireLogin();

$user = $sessionManager->getCurrentUser();
$error = '';
$success = '';

// معالجة تحديث الملف الشخصي
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'رمز الأمان غير صحيح. يرجى إعادة المحاولة.';
    } else {
        $action = $_POST['action'] ?? '';
        
        try {
            $pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
                DB_USER, DB_PASS,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
            
            if ($action === 'update_profile') {
                // تحديث البيانات الأساسية
                $firstName = sanitizeInput($_POST['first_name'] ?? '');
                $lastName = sanitizeInput($_POST['last_name'] ?? '');
                $phone = sanitizeInput($_POST['phone'] ?? '');
                $newsletter = isset($_POST['newsletter']);
                
                if (empty($firstName) || empty($lastName)) {
                    $error = 'الاسم الأول واسم العائلة مطلوبان';
                } else {
                    $stmt = $pdo->prepare("
                        UPDATE users 
                        SET first_name = ?, last_name = ?, phone = ?, newsletter_subscribed = ?
                        WHERE id = ?
                    ");
                    
                    $stmt->execute([$firstName, $lastName, $phone, $newsletter ? 1 : 0, $user['id']]);
                    
                    // تحديث بيانات الجلسة
                    $user['first_name'] = $firstName;
                    $user['last_name'] = $lastName;
                    $user['phone'] = $phone;
                    $user['newsletter_subscribed'] = $newsletter ? 1 : 0;
                    
                    logActivity("Profile updated successfully", 'user', $user['id']);
                    $success = 'تم تحديث البيانات بنجاح';
                }
                
            } elseif ($action === 'change_password') {
                // تغيير كلمة المرور
                $currentPassword = $_POST['current_password'] ?? '';
                $newPassword = $_POST['new_password'] ?? '';
                $confirmPassword = $_POST['confirm_password'] ?? '';
                
                if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
                    $error = 'جميع حقول كلمة المرور مطلوبة';
                } elseif (!password_verify($currentPassword, $user['password_hash'])) {
                    $error = 'كلمة المرور الحالية غير صحيحة';
                } elseif ($newPassword !== $confirmPassword) {
                    $error = 'كلمة المرور الجديدة وتأكيدها غير متطابقين';
                } elseif (!isStrongPassword($newPassword)) {
                    $error = 'كلمة المرور يجب أن تحتوي على 8 أحرف على الأقل، وتشمل أحرف كبيرة وصغيرة وأرقام';
                } else {
                    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                    
                    $stmt = $pdo->prepare("
                        UPDATE users 
                        SET password_hash = ?
                        WHERE id = ?
                    ");
                    
                    $stmt->execute([$hashedPassword, $user['id']]);
                    
                    // إنهاء جميع الجلسات الأخرى
                    $stmt = $pdo->prepare("
                        DELETE FROM user_sessions 
                        WHERE user_id = ? AND session_id != ?
                    ");
                    $stmt->execute([$user['id'], session_id()]);
                    
                    logActivity("Password changed successfully", 'security', $user['id']);
                    $success = 'تم تغيير كلمة المرور بنجاح';
                }
                
            } elseif ($action === 'upload_avatar') {
                // رفع صورة الملف الشخصي
                if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
                    $validationErrors = validateFileUpload($_FILES['avatar'], ['jpg', 'jpeg', 'png'], 2097152); // 2MB
                    
                    if (empty($validationErrors)) {
                        $uploadDir = __DIR__ . '/uploads/avatars/';
                        createSecureDirectory($uploadDir);
                        
                        $extension = pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION);
                        $fileName = 'avatar_' . $user['id'] . '_' . time() . '.' . $extension;
                        $uploadPath = $uploadDir . $fileName;
                        
                        if (move_uploaded_file($_FILES['avatar']['tmp_name'], $uploadPath)) {
                            // إنشاء صورة مصغرة
                            $thumbnailPath = $uploadDir . 'thumb_' . $fileName;
                            createThumbnail($uploadPath, $thumbnailPath, 150, 150);
                            
                            // تحديث قاعدة البيانات
                            $avatarUrl = 'uploads/avatars/' . $fileName;
                            
                            $stmt = $pdo->prepare("
                                UPDATE users 
                                SET avatar_url = ?
                                WHERE id = ?
                            ");
                            $stmt->execute([$avatarUrl, $user['id']]);
                            
                            // حذف الصورة القديمة
                            if ($user['avatar_url'] && file_exists(__DIR__ . '/' . $user['avatar_url'])) {
                                unlink(__DIR__ . '/' . $user['avatar_url']);
                            }
                            
                            $user['avatar_url'] = $avatarUrl;
                            logActivity("Avatar updated successfully", 'user', $user['id']);
                            $success = 'تم تحديث الصورة الشخصية بنجاح';
                        } else {
                            $error = 'فشل في رفع الصورة';
                        }
                    } else {
                        $error = implode('<br>', $validationErrors);
                    }
                }
            }
            
        } catch (PDOException $e) {
            logSecurityEvent('Profile operation failed', 'medium', ['error' => $e->getMessage()]);
            $error = 'حدث خطأ في النظام، يرجى المحاولة لاحقاً';
        }
    }
}

// جلب إحصائيات المستخدم
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    
    // عدد الدورات المشترك بها
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count FROM subscriptions 
        WHERE user_id = ? AND is_active = 1
    ");
    $stmt->execute([$user['id']]);
    $enrolledCourses = $stmt->fetch()['count'];
    
    // عدد الدروس المكتملة
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count FROM lesson_progress 
        WHERE user_id = ? AND completed = 1
    ");
    $stmt->execute([$user['id']]);
    $completedLessons = $stmt->fetch()['count'];
    
    // إجمالي ساعات المشاهدة
    $stmt = $pdo->prepare("
        SELECT SUM(FLOOR(last_position / 3600)) as total_hours
        FROM lesson_progress 
        WHERE user_id = ?
    ");
    $stmt->execute([$user['id']]);
    $watchedHours = $stmt->fetch()['total_hours'] ?? 0;
    
    // الدورات الحديثة
    $stmt = $pdo->prepare("
        SELECT c.*, s.created_at as enrolled_at,
               (SELECT COUNT(*) FROM lessons l 
                JOIN sections sec ON l.section_id = sec.id 
                WHERE sec.course_id = c.id) as total_lessons,
               (SELECT COUNT(*) FROM lesson_progress lp 
                JOIN lessons l ON lp.lesson_id = l.id 
                JOIN sections sec ON l.section_id = sec.id 
                WHERE sec.course_id = c.id AND lp.user_id = ? AND lp.completed = 1) as completed_lessons
        FROM subscriptions s
        JOIN courses c ON s.course_id = c.id
        WHERE s.user_id = ? AND s.is_active = 1
        ORDER BY s.created_at DESC
        LIMIT 6
    ");
    $stmt->execute([$user['id'], $user['id']]);
    $recentCourses = $stmt->fetchAll();
    
    // النشاط الأخير
    $stmt = $pdo->prepare("
        SELECT 'lesson' as type, l.name as title, c.name as course_name, 
               lp.last_accessed as activity_time, c.id as course_id, l.id as lesson_id
        FROM lesson_progress lp
        JOIN lessons l ON lp.lesson_id = l.id
        JOIN sections s ON l.section_id = s.id
        JOIN courses c ON s.course_id = c.id
        WHERE lp.user_id = ?
        ORDER BY lp.last_accessed DESC
        LIMIT 10
    ");
    $stmt->execute([$user['id']]);
    $recentActivity = $stmt->fetchAll();
    
    // شهادات الإنجاز
    $stmt = $pdo->prepare("
        SELECT c.name, c.id, s.created_at as completion_date
        FROM subscriptions s
        JOIN courses c ON s.course_id = c.id
        WHERE s.user_id = ? AND s.is_active = 1
        AND (
            SELECT COUNT(*) FROM lesson_progress lp 
            JOIN lessons l ON lp.lesson_id = l.id 
            JOIN sections sec ON l.section_id = sec.id 
            WHERE sec.course_id = c.id AND lp.user_id = ? AND lp.completed = 1
        ) = (
            SELECT COUNT(*) FROM lessons l 
            JOIN sections sec ON l.section_id = sec.id 
            WHERE sec.course_id = c.id
        )
        ORDER BY s.created_at DESC
    ");
    $stmt->execute([$user['id'], $user['id']]);
    $completedCourses = $stmt->fetchAll();
    
} catch (PDOException $e) {
    logSecurityEvent('Failed to load profile data', 'medium', ['error' => $e->getMessage()]);
    $enrolledCourses = 0;
    $completedLessons = 0;
    $watchedHours = 0;
    $recentCourses = [];
    $recentActivity = [];
    $completedCourses = [];
}

// تضمين ملف العرض
require_once __DIR__ . '/frontend/views/pages/profile.php';
?>