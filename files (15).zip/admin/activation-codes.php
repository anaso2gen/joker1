<?php
/**
 * لوحة إدارة أكواد التفعيل
 * واجهة شاملة لإدارة جميع أكواد التفعيل
 * 
 * @author anaso2gen
 * @version 1.0
 * @since 2025-05-29
 */

// بدء الجلسة والتحقق من الصلاحيات
session_start();
require_once '../config.php';
require_once '../session.php';
require_once '../backend/services/ActivationCodeService.php';

// التحقق من صلاحيات الإدارة
if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) {
    header('Location: ../login.php');
    exit();
}

$activationService = new ActivationCodeService();
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// الحصول على الفلاتر
$filters = [
    'search' => $_GET['search'] ?? '',
    'is_active' => isset($_GET['is_active']) ? intval($_GET['is_active']) : null,
    'code_type' => $_GET['code_type'] ?? '',
    'expires_from' => $_GET['expires_from'] ?? '',
    'expires_to' => $_GET['expires_to'] ?? '',
    'order_by' => $_GET['order_by'] ?? 'created_at',
    'order_dir' => $_GET['order_dir'] ?? 'DESC',
    'limit' => $limit,
    'offset' => $offset
];

// الحصول على الأكواد
$codesResult = $activationService->getAllCodes($filters);
$codes = $codesResult['success'] ? $codesResult['codes'] : [];
$totalCount = $codesResult['success'] ? $codesResult['total_count'] : 0;
$totalPages = ceil($totalCount / $limit);

// الحصول على الإحصائيات
$statsResult = $activationService->getCodesStatistics();
$stats = $statsResult['success'] ? $statsResult['statistics'] : [];

// الحصول على قائمة الدورات للنماذج
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET, DB_USER, DB_PASS);
    $stmt = $pdo->query("SELECT id, title FROM courses WHERE is_active = 1 ORDER BY title");
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $courses = [];
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة أكواد التفعيل - <?php echo SITE_NAME; ?></title>
    
    <!-- CSS Files -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/dashboard.css" rel="stylesheet">
    
    <style>
        .activation-codes-container {
            background: #f8f9fa;
            min-height: 100vh;
            padding: 20px 0;
        }
        
        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            text-align: center;
        }
        
        .stats-card .icon {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }
        
        .stats-card.total { border-left: 5px solid #007bff; }
        .stats-card.active { border-left: 5px solid #28a745; }
        .stats-card.used { border-left: 5px solid #ffc107; }
        .stats-card.expired { border-left: 5px solid #dc3545; }
        
        .codes-table {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .filter-section {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .code-badge {
            font-family: 'Courier New', monospace;
            font-weight: bold;
            padding: 5px 10px;
            background: #e9ecef;
            border-radius: 5px;
            display: inline-block;
        }
        
        .type-badge {
            font-size: 0.8rem;
            padding: 3px 8px;
        }
        
        .usage-progress {
            width: 100px;
            height: 8px;
        }
        
        .btn-action {
            padding: 5px 10px;
            margin: 2px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            font-size: 0.8rem;
        }
        
        .export-section {
            background: white;
            border-radius: 15px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <div class="activation-codes-container">
        <div class="container-fluid">
            
            <!-- العنوان والأزرار الرئيسية -->
            <div class="row mb-4">
                <div class="col-md-8">
                    <h2><i class="fas fa-ticket-alt"></i> إدارة أكواد التفعيل</h2>
                    <p class="text-muted">إنشاء وإدارة أكواد تفعيل الدورات</p>
                </div>
                <div class="col-md-4 text-end">
                    <button class="btn btn-primary me-2" data-bs-toggle="modal" data-bs-target="#createCodeModal">
                        <i class="fas fa-plus"></i> إنشاء كود جديد
                    </button>
                    <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#bulkCreateModal">
                        <i class="fas fa-layer-group"></i> إنشاء بالجملة
                    </button>
                </div>
            </div>
            
            <!-- الإحصائيات -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="stats-card total">
                        <div class="icon text-primary">
                            <i class="fas fa-ticket-alt"></i>
                        </div>
                        <h3><?php echo number_format($stats['total_codes'] ?? 0); ?></h3>
                        <p class="mb-0">إجمالي الأكواد</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card active">
                        <div class="icon text-success">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <h3><?php echo number_format($stats['active_codes'] ?? 0); ?></h3>
                        <p class="mb-0">أكواد نشطة</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card used">
                        <div class="icon text-warning">
                            <i class="fas fa-user-check"></i>
                        </div>
                        <h3><?php echo number_format($stats['successful_activations'] ?? 0); ?></h3>
                        <p class="mb-0">تفعيلات ناجحة</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card expired">
                        <div class="icon text-danger">
                            <i class="fas fa-clock"></i>
                        </div>
                        <h3><?php echo number_format($stats['expired_codes'] ?? 0); ?></h3>
                        <p class="mb-0">أكواد منتهية</p>
                    </div>
                </div>
            </div>
            
            <!-- قسم التصدير -->
            <div class="export-section">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <h6><i class="fas fa-download"></i> تصدير الأكواد</h6>
                    </div>
                    <div class="col-md-6 text-end">
                        <button class="btn btn-outline-primary btn-sm me-2" onclick="exportCodes('csv')">
                            <i class="fas fa-file-csv"></i> CSV
                        </button>
                        <button class="btn btn-outline-success btn-sm me-2" onclick="exportCodes('excel')">
                            <i class="fas fa-file-excel"></i> Excel
                        </button>
                        <button class="btn btn-outline-secondary btn-sm" onclick="exportCodes('txt')">
                            <i class="fas fa-file-alt"></i> TXT
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- فلاتر البحث -->
            <div class="filter-section">
                <form method="GET" id="filterForm">
                    <div class="row">
                        <div class="col-md-3">
                            <label class="form-label">البحث</label>
                            <input type="text" class="form-control" name="search" value="<?php echo htmlspecialchars($filters['search']); ?>" placeholder="البحث في الكود أو الملاحظات">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">الحالة</label>
                            <select class="form-select" name="is_active">
                                <option value="">جميع الحالات</option>
                                <option value="1" <?php echo $filters['is_active'] === 1 ? 'selected' : ''; ?>>نشط</option>
                                <option value="0" <?php echo $filters['is_active'] === 0 ? 'selected' : ''; ?>>معطل</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">نوع الكود</label>
                            <select class="form-select" name="code_type">
                                <option value="">جميع الأنواع</option>
                                <option value="single_course" <?php echo $filters['code_type'] === 'single_course' ? 'selected' : ''; ?>>دورة واحدة</option>
                                <option value="all_courses" <?php echo $filters['code_type'] === 'all_courses' ? 'selected' : ''; ?>>جميع الدورات</option>
                                <option value="course_bundle" <?php echo $filters['code_type'] === 'course_bundle' ? 'selected' : ''; ?>>باقة دورات</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">انتهاء من</label>
                            <input type="date" class="form-control" name="expires_from" value="<?php echo $filters['expires_from']; ?>">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">انتهاء إلى</label>
                            <input type="date" class="form-control" name="expires_to" value="<?php echo $filters['expires_to']; ?>">
                        </div>
                        <div class="col-md-1">
                            <label class="form-label">&nbsp;</label>
                            <div>
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            
            <!-- جدول الأكواد -->
            <div class="codes-table">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5><i class="fas fa-list"></i> الأكواد (<?php echo number_format($totalCount); ?>)</h5>
                    <div>
                        <select class="form-select form-select-sm d-inline-block w-auto" onchange="changeSort(this)">
                            <option value="created_at_DESC" <?php echo ($filters['order_by'] === 'created_at' && $filters['order_dir'] === 'DESC') ? 'selected' : ''; ?>>الأحدث أولاً</option>
                            <option value="created_at_ASC" <?php echo ($filters['order_by'] === 'created_at' && $filters['order_dir'] === 'ASC') ? 'selected' : ''; ?>>الأقدم أولاً</option>
                            <option value="used_count_DESC" <?php echo ($filters['order_by'] === 'used_count' && $filters['order_dir'] === 'DESC') ? 'selected' : ''; ?>>الأكثر استخداماً</option>
                            <option value="expires_at_ASC" <?php echo ($filters['order_by'] === 'expires_at' && $filters['order_dir'] === 'ASC') ? 'selected' : ''; ?>>الأقرب انتهاءً</option>
                        </select>
                    </div>
                </div>
                
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>الكود</th>
                                <th>النوع</th>
                                <th>الاستخدام</th>
                                <th>انتهاء الصلاحية</th>
                                <th>منشئ الكود</th>
                                <th>تاريخ الإنشاء</th>
                                <th>الحالة</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($codes)): ?>
                                <tr>
                                    <td colspan="8" class="text-center py-4">
                                        <i class="fas fa-inbox fa-2x text-muted mb-2"></i>
                                        <br>لا توجد أكواد تفعيل
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($codes as $code): ?>
                                    <tr>
                                        <td>
                                            <span class="code-badge"><?php echo htmlspecialchars($code['code']); ?></span>
                                            <?php if ($code['notes']): ?>
                                                <i class="fas fa-comment-alt text-info ms-1" title="<?php echo htmlspecialchars($code['notes']); ?>"></i>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php
                                            $typeColors = [
                                                'single_course' => 'primary',
                                                'all_courses' => 'success',
                                                'course_bundle' => 'warning'
                                            ];
                                            $typeTexts = [
                                                'single_course' => 'دورة واحدة',
                                                'all_courses' => 'جميع الدورات',
                                                'course_bundle' => 'باقة دورات'
                                            ];
                                            $color = $typeColors[$code['code_type']] ?? 'secondary';
                                            $text = $typeTexts[$code['code_type']] ?? $code['code_type'];
                                            ?>
                                            <span class="badge bg-<?php echo $color; ?> type-badge"><?php echo $text; ?></span>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <span class="me-2"><?php echo $code['used_count']; ?>/<?php echo $code['max_uses']; ?></span>
                                                <div class="progress usage-progress">
                                                    <?php 
                                                    $percentage = $code['max_uses'] > 0 ? ($code['used_count'] / $code['max_uses']) * 100 : 0;
                                                    $progressColor = $percentage >= 90 ? 'danger' : ($percentage >= 70 ? 'warning' : 'success');
                                                    ?>
                                                    <div class="progress-bar bg-<?php echo $progressColor; ?>" style="width: <?php echo $percentage; ?>%"></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if ($code['expires_at']): ?>
                                                <?php
                                                $expiryDate = new DateTime($code['expires_at']);
                                                $now = new DateTime();
                                                $isExpired = $expiryDate < $now;
                                                ?>
                                                <span class="<?php echo $isExpired ? 'text-danger' : 'text-success'; ?>">
                                                    <?php echo $expiryDate->format('Y-m-d'); ?>
                                                    <?php if ($isExpired): ?>
                                                        <i class="fas fa-exclamation-triangle"></i>
                                                    <?php endif; ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="text-muted">بلا انتهاء</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="../assets/images/default-avatar.png" class="rounded-circle me-2" width="30" height="30" alt="Avatar">
                                                <div>
                                                    <div class="fw-bold"><?php echo htmlspecialchars($code['creator_name']); ?></div>
                                                    <small class="text-muted"><?php echo htmlspecialchars($code['creator_email']); ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <?php 
                                            $createdDate = new DateTime($code['created_at']);
                                            echo $createdDate->format('Y-m-d H:i');
                                            ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo $code['is_active'] ? 'success' : 'secondary'; ?>">
                                                <?php echo $code['is_active'] ? 'نشط' : 'معطل'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <button class="btn btn-outline-info btn-sm" onclick="viewCode(<?php echo $code['id']; ?>)">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <button class="btn btn-outline-warning btn-sm" onclick="editCode(<?php echo $code['id']; ?>)">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button class="btn btn-outline-<?php echo $code['is_active'] ? 'secondary' : 'success'; ?> btn-sm" 
                                                        onclick="toggleCodeStatus(<?php echo $code['id']; ?>, <?php echo $code['is_active'] ? 'false' : 'true'; ?>)">
                                                    <i class="fas fa-<?php echo $code['is_active'] ? 'pause' : 'play'; ?>"></i>
                                                </button>
                                                <?php if ($code['used_count'] == 0): ?>
                                                    <button class="btn btn-outline-danger btn-sm" onclick="deleteCode(<?php echo $code['id']; ?>)">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                    <nav aria-label="Page navigation" class="mt-4">
                        <ul class="pagination justify-content-center">
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                                        <?php echo $i; ?>
                                    </a>
                                </li>
                            <?php endfor; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Modal إنشاء كود جديد -->
    <div class="modal fade" id="createCodeModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-plus-circle"></i> إنشاء كود تفعيل جديد</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="createCodeForm">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <label class="form-label">كود التفعيل</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" name="code" id="codeInput" placeholder="اتركه فارغاً للتوليد التلقائي">
                                    <button type="button" class="btn btn-outline-secondary" onclick="generateRandomCode()">
                                        <i class="fas fa-dice"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">نوع الكود</label>
                                <select class="form-select" name="code_type" id="codeType" onchange="toggleCourseSelection()">
                                    <option value="single_course">دورة واحدة</option>
                                    <option value="all_courses">جميع الدورات</option>
                                    <option value="course_bundle">باقة دورات</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row mt-3" id="courseSelectionRow">
                            <div class="col-12">
                                <label class="form-label">الدورات</label>
                                <select class="form-select" name="course_ids[]" id="courseIds" multiple>
                                    <?php foreach ($courses as $course): ?>
                                        <option value="<?php echo $course['id']; ?>"><?php echo htmlspecialchars($course['title']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <small class="text-muted">اختر الدورات المرتبطة بالكود</small>
                            </div>
                        </div>
                        
                        <div class="row mt-3">
                            <div class="col-md-4">
                                <label class="form-label">عدد مرات الاستخدام</label>
                                <input type="number" class="form-control" name="max_uses" value="1" min="1">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">مدة الاشتراك (يوم)</label>
                                <input type="number" class="form-control" name="duration_days" value="365" min="1">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">تاريخ انتهاء الكود</label>
                                <input type="datetime-local" class="form-control" name="expires_at">
                            </div>
                        </div>
                        
                        <div class="mt-3">
                            <label class="form-label">ملاحظات</label>
                            <textarea class="form-control" name="notes" rows="3" placeholder="ملاحظات حول الكود (اختياري)"></textarea>
                        </div>
                        
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-plus"></i> إنشاء الكود
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal إنشاء أكواد بالجملة -->
    <div class="modal fade" id="bulkCreateModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-layer-group"></i> إنشاء أكواد بالجملة</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="bulkCreateForm">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-4">
                                <label class="form-label">عدد الأكواد</label>
                                <input type="number" class="form-control" name="quantity" value="10" min="1" max="1000">
                                <small class="text-muted">الحد الأقصى: 1000 كود</small>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">نمط الكود</label>
                                <select class="form-select" name="code_pattern">
                                    <option value="mixed">أرقام وأحرف</option>
                                    <option value="numbers">أرقام فقط</option>
                                    <option value="letters">أحرف فقط</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">طول الكود</label>
                                <input type="number" class="form-control" name="code_length" value="8" min="4" max="20">
                            </div>
                        </div>
                        
                        <div class="row mt-3">
                            <div class="col-md-6">
                                <label class="form-label">نوع الكود</label>
                                <select class="form-select" name="code_type" id="bulkCodeType" onchange="toggleBulkCourseSelection()">
                                    <option value="single_course">دورة واحدة</option>
                                    <option value="all_courses">جميع الدورات</option>
                                    <option value="course_bundle">باقة دورات</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">عدد مرات الاستخدام</label>
                                <input type="number" class="form-control" name="max_uses" value="1" min="1">
                            </div>
                        </div>
                        
                        <div class="row mt-3" id="bulkCourseSelectionRow">
                            <div class="col-12">
                                <label class="form-label">الدورات</label>
                                <select class="form-select" name="course_ids[]" id="bulkCourseIds" multiple>
                                    <?php foreach ($courses as $course): ?>
                                        <option value="<?php echo $course['id']; ?>"><?php echo htmlspecialchars($course['title']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row mt-3">
                            <div class="col-md-6">
                                <label class="form-label">مدة الاشتراك (يوم)</label>
                                <input type="number" class="form-control" name="duration_days" value="365" min="1">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">تاريخ انتهاء الأكواد</label>
                                <input type="datetime-local" class="form-control" name="expires_at">
                            </div>
                        </div>
                        
                        <div class="mt-3">
                            <label class="form-label">ملاحظات</label>
                            <textarea class="form-control" name="notes" rows="2" placeholder="ملاحظات للأكواد (اختياري)"></textarea>
                        </div>
                        
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-layer-group"></i> إنشاء الأكواد
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- JavaScript Files -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/api.js"></script>
    
    <script>
        // متغيرات عامة
        const API_BASE = '../api.php';
        
        // تبديل اختيار الدورات
        function toggleCourseSelection() {
            const codeType = document.getElementById('codeType').value;
            const courseRow = document.getElementById('courseSelectionRow');
            
            if (codeType === 'all_courses') {
                courseRow.style.display = 'none';
            } else {
                courseRow.style.display = 'block';
            }
        }
        
        function toggleBulkCourseSelection() {
            const codeType = document.getElementById('bulkCodeType').value;
            const courseRow = document.getElementById('bulkCourseSelectionRow');
            
            if (codeType === 'all_courses') {
                courseRow.style.display = 'none';
            } else {
                courseRow.style.display = 'block';
            }
        }
        
        // توليد كود عشوائي
        function generateRandomCode() {
            const patterns = ['mixed', 'numbers', 'letters'];
            const pattern = patterns[Math.floor(Math.random() * patterns.length)];
            const length = 8;
            
            let chars = '';
            switch (pattern) {
                case 'numbers':
                    chars = '0123456789';
                    break;
                case 'letters':
                    chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                    break;
                case 'mixed':
                default:
                    chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                    break;
            }
            
            let code = '';
            for (let i = 0; i < length; i++) {
                code += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            
            document.getElementById('codeInput').value = code;
        }
        
        // إنشاء كود جديد
        document.getElementById('createCodeForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const data = Object.fromEntries(formData.entries());
            
            // معالجة الدورات المتعددة
            if (data.code_type !== 'all_courses') {
                const courseIds = formData.getAll('course_ids[]');
                data.course_ids = courseIds;
            }
            delete data['course_ids[]'];
            
            try {
                showLoadingAlert('جاري إنشاء الكود...');
                
                const response = await fetch(API_BASE, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        controller: 'activation',
                        action: 'create',
                        ...data
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showSuccessAlert('تم إنشاء الكود بنجاح: ' + result.data.code);
                    bootstrap.Modal.getInstance(document.getElementById('createCodeModal')).hide();
                    location.reload();
                } else {
                    showErrorAlert(result.message);
                }
                
            } catch (error) {
                showErrorAlert('حدث خطأ: ' + error.message);
            }
        });
        
        // إنشاء أكواد بالجملة
        document.getElementById('bulkCreateForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const data = Object.fromEntries(formData.entries());
            
            // معالجة الدورات المتعددة
            if (data.code_type !== 'all_courses') {
                const courseIds = formData.getAll('course_ids[]');
                data.course_ids = courseIds;
            }
            delete data['course_ids[]'];
            
            try {
                showLoadingAlert('جاري إنشاء الأكواد...');
                
                const response = await fetch(API_BASE, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        controller: 'activation',
                        action: 'create_bulk',
                        ...data
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showSuccessAlert(`تم إنشاء ${result.data.created_count} كود بنجاح`);
                    bootstrap.Modal.getInstance(document.getElementById('bulkCreateModal')).hide();
                    location.reload();
                } else {
                    showErrorAlert(result.message);
                }
                
            } catch (error) {
                showErrorAlert('حدث خطأ: ' + error.message);
            }
        });
        
        // تفعيل/تعطيل كود
        async function toggleCodeStatus(codeId, isActive) {
            const action = isActive ? 'تفعيل' : 'تعطيل';
            
            if (!confirm(`هل أنت متأكد من ${action} هذا الكود؟`)) {
                return;
            }
            
            try {
                const response = await fetch(API_BASE, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        controller: 'activation',
                        action: 'toggle_status',
                        code_id: codeId,
                        is_active: isActive,
                        csrf_token: '<?php echo generateCSRFToken(); ?>'
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showSuccessAlert(result.message);
                    location.reload();
                } else {
                    showErrorAlert(result.message);
                }
                
            } catch (error) {
                showErrorAlert('حدث خطأ: ' + error.message);
            }
        }
        
        // حذف كود
        async function deleteCode(codeId) {
            if (!confirm('هل أنت متأكد من حذف هذا الكود؟ لا يمكن التراجع عن هذا الإجراء.')) {
                return;
            }
            
            try {
                const response = await fetch(API_BASE, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        controller: 'activation',
                        action: 'delete',
                        code_id: codeId,
                        csrf_token: '<?php echo generateCSRFToken(); ?>'
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showSuccessAlert(result.message);
                    location.reload();
                } else {
                    showErrorAlert(result.message);
                }
                
            } catch (error) {
                showErrorAlert('حدث خطأ: ' + error.message);
            }
        }
        
        // تصدير الأكواد
        async function exportCodes(format) {
            try {
                showLoadingAlert('جاري تحضير الملف...');
                
                const params = new URLSearchParams(window.location.search);
                params.set('format', format);
                
                const response = await fetch(`${API_BASE}?controller=activation&action=export&${params.toString()}`);
                const result = await response.json();
                
                if (result.success) {
                    // تحميل الملف
                    window.open(result.data.download_url, '_blank');
                    showSuccessAlert('تم تصدير الملف بنجاح');
                } else {
                    showErrorAlert(result.message);
                }
                
            } catch (error) {
                showErrorAlert('حدث خطأ: ' + error.message);
            }
        }
        
        // تغيير الترتيب
        function changeSort(select) {
            const [orderBy, orderDir] = select.value.split('_');
            const params = new URLSearchParams(window.location.search);
            params.set('order_by', orderBy);
            params.set('order_dir', orderDir);
            params.delete('page');
            
            window.location.search = params.toString();
        }
        
        // دوال التنبيهات
        function showSuccessAlert(message) {
            // يمكن استخدام SweetAlert أو Bootstrap Toast
            alert(message);
        }
        
        function showErrorAlert(message) {
            alert('خطأ: ' + message);
        }
        
        function showLoadingAlert(message) {
            // يمكن إضافة loading spinner
            console.log(message);
        }
        
        // تهيئة الصفحة
        document.addEventListener('DOMContentLoaded', function() {
            toggleCourseSelection();
            toggleBulkCourseSelection();
        });
    </script>
</body>
</html>