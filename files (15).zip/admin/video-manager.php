<?php
/**
 * إدارة الفيديوهات - VdoCipher
 * منصة ترند التعليمية
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 11:07:54
 */

require_once '../config/config.php';
require_once '../classes/Auth.php';
require_once '../classes/VdoCipherService.php';

// التحقق من تسجيل الدخول
$auth = new Auth();
if (!$auth->isLoggedIn() || !$auth->hasPermission('manage_videos')) {
    header('Location: ../auth/login.php');
    exit;
}

$vdoCipher = new VdoCipherService();
$message = '';
$messageType = '';

// معالجة الطلبات
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'upload_video':
            $title = $_POST['title'] ?? '';
            $description = $_POST['description'] ?? '';
            $tags = explode(',', $_POST['tags'] ?? '');
            
            $result = $vdoCipher->uploadVideo($title, $description, $tags);
            
            if ($result['success']) {
                $message = 'تم إنشاء رابط الرفع بنجاح';
                $messageType = 'success';
                $uploadLink = $result['upload_link'];
                $videoId = $result['video_id'];
            } else {
                $message = $result['message'];
                $messageType = 'error';
            }
            break;
            
        case 'delete_video':
            $videoId = $_POST['video_id'] ?? '';
            $result = $vdoCipher->deleteVideo($videoId);
            
            $message = $result['message'];
            $messageType = $result['success'] ? 'success' : 'error';
            break;
            
        case 'generate_otp':
            $videoId = $_POST['video_id'] ?? '';
            $userId = $_SESSION['user_id'];
            
            $result = $vdoCipher->generateOTP($videoId, $userId);
            
            if ($result['success']) {
                $message = 'تم إنشاء OTP بنجاح';
                $messageType = 'success';
                $otp = $result['otp'];
                $playbackInfo = $result['playback_info'];
            } else {
                $message = $result['message'];
                $messageType = 'error';
            }
            break;
    }
}

// الحصول على قائمة الفيديوهات
$page = $_GET['page'] ?? 1;
$videosResult = $vdoCipher->getVideosList($page, 20);

?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة الفيديوهات - VdoCipher</title>
    <link href="../assets/css/admin.css" rel="stylesheet">
    <style>
        .video-card {
            background: white;
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .video-thumbnail {
            width: 200px;
            height: 120px;
            object-fit: cover;
            border-radius: 4px;
        }
        
        .video-info {
            flex: 1;
            margin-right: 1rem;
        }
        
        .video-actions {
            display: flex;
            gap: 0.5rem;
            align-items: center;
        }
        
        .upload-zone {
            border: 2px dashed #667eea;
            border-radius: 8px;
            padding: 2rem;
            text-align: center;
            background: #f8f9ff;
            margin-bottom: 2rem;
        }
        
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-size: 0.875rem;
            font-weight: 500;
        }
        
        .status-processing { background: #fef5e7; color: #744210; }
        .status-ready { background: #f0fff4; color: #22543d; }
        .status-error { background: #fed7d7; color: #742a2a; }
        
        .otp-display {
            background: #f7fafc;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            padding: 1rem;
            margin-top: 1rem;
            font-family: monospace;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="admin-main">
            <!-- Header -->
            <?php include 'includes/header.php'; ?>
            
            <div class="admin-content">
                <div class="page-header">
                    <h1>🎬 إدارة الفيديوهات</h1>
                    <p>إدارة فيديوهات الدورات باستخدام VdoCipher</p>
                </div>
                
                <!-- الرسائل -->
                <?php if ($message): ?>
                <div class="alert alert-<?php echo $messageType; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
                <?php endif; ?>
                
                <!-- نموذج رفع فيديو جديد -->
                <div class="card">
                    <div class="card-header">
                        <h3>📤 رفع فيديو جديد</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST" class="form-grid">
                            <input type="hidden" name="action" value="upload_video">
                            
                            <div class="form-group">
                                <label>عنوان الفيديو</label>
                                <input type="text" name="title" required class="form-control">
                            </div>
                            
                            <div class="form-group">
                                <label>وصف الفيديو</label>
                                <textarea name="description" class="form-control" rows="3"></textarea>
                            </div>
                            
                            <div class="form-group">
                                <label>العلامات (مفصولة بفاصلة)</label>
                                <input type="text" name="tags" class="form-control" placeholder="برمجة, تطوير, ويب">
                            </div>
                            
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-upload"></i> إنشاء رابط الرفع
                            </button>
                        </form>
                        
                        <?php if (isset($uploadLink)): ?>
                        <div class="upload-zone">
                            <h4>رابط الرفع جاهز!</h4>
                            <p><strong>معرف الفيديو:</strong> <?php echo htmlspecialchars($videoId); ?></p>
                            <a href="<?php echo htmlspecialchars($uploadLink); ?>" target="_blank" class="btn btn-success">
                                <i class="fas fa-external-link-alt"></i> فتح رابط الرفع
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- قائمة الفيديوهات -->
                <div class="card">
                    <div class="card-header">
                        <h3>📹 الفيديوهات المرفوعة</h3>
                    </div>
                    <div class="card-body">
                        <?php if ($videosResult['success'] && !empty($videosResult['videos'])): ?>
                            <?php foreach ($videosResult['videos'] as $video): ?>
                            <div class="video-card">
                                <div class="d-flex">
                                    <?php if (!empty($video['poster'])): ?>
                                    <img src="<?php echo htmlspecialchars($video['poster']); ?>" 
                                         alt="صورة مصغرة" class="video-thumbnail">
                                    <?php else: ?>
                                    <div class="video-thumbnail bg-gray-200 d-flex align-items-center justify-content-center">
                                        <i class="fas fa-video fa-2x text-gray-500"></i>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <div class="video-info">
                                        <h4><?php echo htmlspecialchars($video['title']); ?></h4>
                                        <p class="text-gray-600"><?php echo htmlspecialchars($video['description']); ?></p>
                                        
                                        <div class="video-meta">
                                            <span class="status-badge status-<?php echo $video['status']; ?>">
                                                <?php echo ucfirst($video['status']); ?>
                                            </span>
                                            <span class="text-sm text-gray-500">
                                                المدة: <?php echo gmdate("H:i:s", $video['length'] ?? 0); ?>
                                            </span>
                                            <span class="text-sm text-gray-500">
                                                تاريخ الرفع: <?php echo date('Y-m-d H:i', strtotime($video['createdAt'])); ?>
                                            </span>
                                        </div>
                                    </div>
                                    
                                    <div class="video-actions">
                                        <!-- إنشاء OTP -->
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="action" value="generate_otp">
                                            <input type="hidden" name="video_id" value="<?php echo $video['id']; ?>">
                                            <button type="submit" class="btn btn-sm btn-info" title="إنشاء OTP">
                                                <i class="fas fa-key"></i>
                                            </button>
                                        </form>
                                        
                                        <!-- تحديث المعلومات -->
                                        <button class="btn btn-sm btn-warning" onclick="editVideo('<?php echo $video['id']; ?>')" title="تعديل">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        
                                        <!-- حذف -->
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('هل أنت متأكد من حذف هذا الفيديو؟')">
                                            <input type="hidden" name="action" value="delete_video">
                                            <input type="hidden" name="video_id" value="<?php echo $video['id']; ?>">
                                            <button type="submit" class="btn btn-sm btn-danger" title="حذف">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                                
                                <!-- عرض OTP إذا تم إنشاؤه -->
                                <?php if (isset($otp) && isset($_POST['video_id']) && $_POST['video_id'] === $video['id']): ?>
                                <div class="otp-display">
                                    <h5>🔑 OTP للمشاهدة الآمنة:</h5>
                                    <p><strong>OTP:</strong> <?php echo htmlspecialchars($otp); ?></p>
                                    <p><strong>Playback Info:</strong> <?php echo htmlspecialchars($playbackInfo); ?></p>
                                    <p class="text-sm text-gray-600">صالح لمدة ساعة واحدة</p>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; ?>
                            
                            <!-- Pagination -->
                            <?php if ($videosResult['total'] > 20): ?>
                            <div class="pagination-wrapper">
                                <nav class="pagination">
                                    <?php
                                    $totalPages = ceil($videosResult['total'] / 20);
                                    $currentPage = $videosResult['current_page'];
                                    
                                    for ($i = 1; $i <= $totalPages; $i++):
                                    ?>
                                    <a href="?page=<?php echo $i; ?>" 
                                       class="page-link <?php echo $i == $currentPage ? 'active' : ''; ?>">
                                        <?php echo $i; ?>
                                    </a>
                                    <?php endfor; ?>
                                </nav>
                            </div>
                            <?php endif; ?>
                            
                        <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-video fa-3x text-gray-400"></i>
                            <h3>لا توجد فيديوهات</h3>
                            <p>ابدأ برفع أول فيديو للمنصة</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <!-- مودال تحديث الفيديو -->
    <div id="editVideoModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h4>تحديث معلومات الفيديو</h4>
                <button class="modal-close">&times;</button>
            </div>
            <form method="POST" id="editVideoForm">
                <input type="hidden" name="action" value="update_video">
                <input type="hidden" name="video_id" id="editVideoId">
                
                <div class="form-group">
                    <label>العنوان</label>
                    <input type="text" name="title" id="editTitle" class="form-control">
                </div>
                
                <div class="form-group">
                    <label>الوصف</label>
                    <textarea name="description" id="editDescription" class="form-control" rows="3"></textarea>
                </div>
                
                <div class="form-group">
                    <label>العلامات</label>
                    <input type="text" name="tags" id="editTags" class="form-control">
                </div>
                
                <div class="modal-actions">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
                    <button type="submit" class="btn btn-primary">تحديث</button>
                </div>
            </form>
        </div>
    </div>
    
    <script src="../assets/js/admin.js"></script>
    <script>
        function editVideo(videoId) {
            // هنا يمكنك إضافة كود لجلب بيانات الفيديو وعرضها في المودال
            document.getElementById('editVideoId').value = videoId;
            document.getElementById('editVideoModal').style.display = 'block';
        }
        
        function closeModal() {
            document.getElementById('editVideoModal').style.display = 'none';
        }
        
        // إغلاق المودال عند النقر خارجه
        window.onclick = function(event) {
            const modal = document.getElementById('editVideoModal');
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        }
    </script>
</body>
</html>