<?php
/**
 * نقطة دخول API الرئيسية - نسخة محسّنة ومفصلة
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 10:08:22
 * 
 * هذا الملف يعالج جميع طلبات API ويوجهها للمتحكمات المناسبة
 * مع معالجة شاملة للأخطاء والأمان والتوثيق
 */

// تعريف ثابت النظام لحماية الملفات
define('LEARNING_PLATFORM', true);

// إعداد معالجة الأخطاء بناءً على بيئة التطوير
if (defined('APP_ENV') && APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', 0);
}

// إعداد تسجيل الأخطاء
ini_set('log_errors', 1);
$logDir = __DIR__ . '/storage/logs';
if (!is_dir($logDir)) {
    mkdir($logDir, 0755, true);
}
ini_set('error_log', $logDir . '/api_error.log');

// تحديد المنطقة الزمنية
date_default_timezone_set('Asia/Riyadh');

// تضمين الملفات الأساسية
require_once __DIR__ . '/config/constants.php';
require_once __DIR__ . '/includes/functions.php';

// بدء الجلسة مع إعدادات أمان
if (session_status() === PHP_SESSION_NONE) {
    // إعدادات أمان الجلسة
    ini_set('session.cookie_httponly', 1);
    ini_set('session.cookie_secure', isset($_SERVER['HTTPS']) ? 1 : 0);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.use_strict_mode', 1);
    ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
    
    session_start();
}

/**
 * فئة API الرئيسية لمعالجة الطلبات
 */
class TrendAcademyAPI {
    private $pdo;
    private $sessionManager;
    private $startTime;
    private $requestId;
    private $allowedOrigins;
    private $rateLimits;
    
    public function __construct() {
        $this->startTime = microtime(true);
        $this->requestId = uniqid('req_', true);
        $this->allowedOrigins = $this->getAllowedOrigins();
        $this->rateLimits = RATE_LIMITS;
        
        $this->initializeDatabase();
        $this->setupCORS();
        $this->handlePreflightRequest();
        $this->initializeSession();
        $this->logRequest();
    }
    
    /**
     * تهيئة قاعدة البيانات
     */
    private function initializeDatabase() {
        try {
            $this->pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
                DB_USER, DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed', $e);
            $this->sendErrorResponse('Database connection failed', 500, 'DB_CONNECTION_ERROR');
        }
    }
    
    /**
     * إعداد CORS
     */
    private function setupCORS() {
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        
        if (in_array($origin, $this->allowedOrigins) || APP_ENV === 'development') {
            header("Access-Control-Allow-Origin: $origin");
        } else {
            header('Access-Control-Allow-Origin: ' . SITE_URL);
        }
        
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS, PATCH');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-CSRF-Token, X-API-Key');
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400'); // 24 hours
        
        // إضافة headers أمان إضافية
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('X-XSS-Protection: 1; mode=block');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('X-Request-ID: ' . $this->requestId);
    }
    
    /**
     * معالجة طلبات OPTIONS (CORS preflight)
     */
    private function handlePreflightRequest() {
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            http_response_code(200);
            $this->logApiCall('OPTIONS', 'preflight', 200);
            exit;
        }
    }
    
    /**
     * تهيئة مدير الجلسات
     */
    private function initializeSession() {
        try {
            require_once __DIR__ . '/includes/session_manager.php';
            $this->sessionManager = new SessionManager();
        } catch (Exception $e) {
            $this->logError('Session manager initialization failed', $e);
            $this->sendErrorResponse('Session initialization failed', 500, 'SESSION_ERROR');
        }
    }
    
    /**
     * معالجة الطلب الرئيسي
     */
    public function handleRequest() {
        try {
            // تطبيق middleware الأمان
            $this->applySecurityMiddleware();
            
            // الحصول على العمل المطلوب
            $action = $this->getAction();
            
            if (empty($action)) {
                $this->sendErrorResponse('Action parameter is required', 400, 'MISSING_ACTION');
            }
            
            // فحص معدل الطلبات
            $this->checkRateLimit($action);
            
            // توجيه الطلب للمتحكم المناسب
            $response = $this->routeRequest($action);
            
            // إرسال الاستجابة
            $this->sendSuccessResponse($response);
            
        } catch (Exception $e) {
            $this->handleException($e);
        } finally {
            $this->logApiCall($action ?? 'unknown', 'completed', http_response_code());
        }
    }
    
    /**
     * الحصول على العمل المطلوب
     */
    private function getAction() {
        return $_GET['action'] ?? $_POST['action'] ?? $_REQUEST['action'] ?? '';
    }
    
    /**
     * تطبيق middleware الأمان
     */
    private function applySecurityMiddleware() {
        // فحص وضع الصيانة
        $this->checkMaintenanceMode();
        
        // فحص IP المحظور
        $this->checkBlockedIP();
        
        // فحص CSRF للطلبات غير GET
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            $this->validateCSRF();
        }
        
        // فحص حجم البيانات المرسلة
        $this->checkRequestSize();
        
        // تنظيف البيانات المدخلة
        $this->sanitizeInput();
    }
    
    /**
     * فحص معدل الطلبات
     */
    private function checkRateLimit($action) {
        $identifier = $this->getRateLimitIdentifier($action);
        $maxRequests = $this->rateLimits[$action] ?? $this->rateLimits['api_requests'];
        $timeWindow = 3600; // ساعة واحدة
        
        if (!checkRateLimit($identifier, $maxRequests, $timeWindow)) {
            $this->logSecurityEvent('Rate limit exceeded', 'medium', [
                'action' => $action,
                'ip' => getRealIpAddress(),
                'max_requests' => $maxRequests
            ]);
            
            $this->sendErrorResponse(
                'Too many requests. Please try again later.',
                429,
                'RATE_LIMIT_EXCEEDED',
                ['retry_after' => $timeWindow]
            );
        }
    }
    
    /**
     * توجيه الطلب للمتحكم المناسب
     */
    private function routeRequest($action) {
        // خريطة توجيه الطلبات
        $routes = [
            // Auth routes
            'login' => ['controller' => 'AuthController', 'method' => 'login', 'auth' => false],
            'register' => ['controller' => 'AuthController', 'method' => 'register', 'auth' => false],
            'verify_email' => ['controller' => 'AuthController', 'method' => 'verifyEmail', 'auth' => false],
            'forgot_password' => ['controller' => 'AuthController', 'method' => 'forgotPassword', 'auth' => false],
            'reset_password' => ['controller' => 'AuthController', 'method' => 'resetPassword', 'auth' => false],
            'logout' => ['controller' => 'AuthController', 'method' => 'logout', 'auth' => true],
            'refresh_token' => ['controller' => 'AuthController', 'method' => 'refreshToken', 'auth' => true],
            
            // User routes
            'get_current_user' => ['controller' => 'UserController', 'method' => 'getCurrentUser', 'auth' => true],
            'update_profile' => ['controller' => 'UserController', 'method' => 'updateProfile', 'auth' => true],
            'change_password' => ['controller' => 'UserController', 'method' => 'changePassword', 'auth' => true],
            'upload_avatar' => ['controller' => 'UserController', 'method' => 'uploadAvatar', 'auth' => true],
            'get_user_courses' => ['controller' => 'UserController', 'method' => 'getUserCourses', 'auth' => true],
            'get_user_progress' => ['controller' => 'UserController', 'method' => 'getUserProgress', 'auth' => true],
            'get_recent_activity' => ['controller' => 'UserController', 'method' => 'getRecentActivity', 'auth' => true],
            'get_certificates' => ['controller' => 'UserController', 'method' => 'getCertificates', 'auth' => true],
            'get_user_stats' => ['controller' => 'UserController', 'method' => 'getUserStats', 'auth' => true],
            'toggle_wishlist' => ['controller' => 'UserController', 'method' => 'toggleWishlist', 'auth' => true],
            'get_wishlist' => ['controller' => 'UserController', 'method' => 'getWishlist', 'auth' => true],
            'delete_account' => ['controller' => 'UserController', 'method' => 'deleteAccount', 'auth' => true],
            
            // Course routes
            'get_courses' => ['controller' => 'CourseController', 'method' => 'getAllCourses', 'auth' => false],
            'get_course' => ['controller' => 'CourseController', 'method' => 'getCourse', 'auth' => false],
            'get_course_preview' => ['controller' => 'CourseController', 'method' => 'getCoursePreview', 'auth' => false],
            'search_courses' => ['controller' => 'CourseController', 'method' => 'searchCourses', 'auth' => false],
            'get_categories' => ['controller' => 'CourseController', 'method' => 'getCategories', 'auth' => false],
            'get_featured_courses' => ['controller' => 'CourseController', 'method' => 'getFeaturedCourses', 'auth' => false],
            'subscribe_course' => ['controller' => 'CourseController', 'method' => 'subscribeToCourse', 'auth' => true],
            'add_review' => ['controller' => 'CourseController', 'method' => 'addReview', 'auth' => true],
            'get_course_reviews' => ['controller' => 'CourseController', 'method' => 'getCourseReviews', 'auth' => false],
            'create_course' => ['controller' => 'CourseController', 'method' => 'createCourse', 'auth' => true, 'admin' => true],
            'update_course' => ['controller' => 'CourseController', 'method' => 'updateCourse', 'auth' => true, 'admin' => true],
            'delete_course' => ['controller' => 'CourseController', 'method' => 'deleteCourse', 'auth' => true, 'admin' => true],
            
            // Lesson routes
            'get_lesson' => ['controller' => 'LessonController', 'method' => 'getLesson', 'auth' => true],
            'update_progress' => ['controller' => 'LessonController', 'method' => 'updateProgress', 'auth' => true],
            'add_note' => ['controller' => 'LessonController', 'method' => 'addNote', 'auth' => true],
            'get_notes' => ['controller' => 'LessonController', 'method' => 'getNotes', 'auth' => true],
            'update_note' => ['controller' => 'LessonController', 'method' => 'updateNote', 'auth' => true],
            'delete_note' => ['controller' => 'LessonController', 'method' => 'deleteNote', 'auth' => true],
            'create_lesson' => ['controller' => 'LessonController', 'method' => 'createLesson', 'auth' => true, 'admin' => true],
            'update_lesson' => ['controller' => 'LessonController', 'method' => 'updateLesson', 'auth' => true, 'admin' => true],
            'delete_lesson' => ['controller' => 'LessonController', 'method' => 'deleteLesson', 'auth' => true, 'admin' => true],
            
            // Admin routes
            'get_dashboard_stats' => ['controller' => 'AdminController', 'method' => 'getDashboardStats', 'auth' => true, 'admin' => true],
            'get_users' => ['controller' => 'AdminController', 'method' => 'getUsers', 'auth' => true, 'admin' => true],
            'get_user_details' => ['controller' => 'AdminController', 'method' => 'getUserDetails', 'auth' => true, 'admin' => true],
            'update_user_status' => ['controller' => 'AdminController', 'method' => 'updateUserStatus', 'auth' => true, 'admin' => true],
            'delete_user' => ['controller' => 'AdminController', 'method' => 'deleteUser', 'auth' => true, 'admin' => true],
            'get_sections' => ['controller' => 'AdminController', 'method' => 'getSections', 'auth' => true, 'admin' => true],
            'create_section' => ['controller' => 'AdminController', 'method' => 'createSection', 'auth' => true, 'admin' => true],
            'update_section' => ['controller' => 'AdminController', 'method' => 'updateSection', 'auth' => true, 'admin' => true],
            'delete_section' => ['controller' => 'AdminController', 'method' => 'deleteSection', 'auth' => true, 'admin' => true],
            'get_reviews' => ['controller' => 'AdminController', 'method' => 'getReviews', 'auth' => true, 'admin' => true],
            'update_review_status' => ['controller' => 'AdminController', 'method' => 'updateReviewStatus', 'auth' => true, 'admin' => true],
            'get_activity_logs' => ['controller' => 'AdminController', 'method' => 'getActivityLogs', 'auth' => true, 'admin' => true],
            'get_security_logs' => ['controller' => 'AdminController', 'method' => 'getSecurityLogs', 'auth' => true, 'admin' => true],
            'create_backup' => ['controller' => 'AdminController', 'method' => 'createBackup', 'auth' => true, 'admin' => true],
            'download_backup' => ['controller' => 'AdminController', 'method' => 'downloadBackup', 'auth' => true, 'admin' => true],
            'get_system_info' => ['controller' => 'AdminController', 'method' => 'getSystemInfo', 'auth' => true, 'admin' => true],
            'update_settings' => ['controller' => 'AdminController', 'method' => 'updateSettings', 'auth' => true, 'admin' => true],
            
            // File upload routes
            'upload_file' => ['controller' => 'FileController', 'method' => 'uploadFile', 'auth' => true],
            'delete_file' => ['controller' => 'FileController', 'method' => 'deleteFile', 'auth' => true],
            'get_file_info' => ['controller' => 'FileController', 'method' => 'getFileInfo', 'auth' => true],
            
            // Payment routes
            'create_payment' => ['controller' => 'PaymentController', 'method' => 'createPayment', 'auth' => true],
            'verify_payment' => ['controller' => 'PaymentController', 'method' => 'verifyPayment', 'auth' => true],
            'payment_webhook' => ['controller' => 'PaymentController', 'method' => 'handleWebhook', 'auth' => false],
            
            // Notification routes
            'get_notifications' => ['controller' => 'NotificationController', 'method' => 'getNotifications', 'auth' => true],
            'mark_notification_read' => ['controller' => 'NotificationController', 'method' => 'markAsRead', 'auth' => true],
            'mark_all_read' => ['controller' => 'NotificationController', 'method' => 'markAllAsRead', 'auth' => true],
            'delete_notification' => ['controller' => 'NotificationController', 'method' => 'deleteNotification', 'auth' => true],
            
            // Certificate routes
            'download_certificate' => ['controller' => 'CertificateController', 'method' => 'downloadCertificate', 'auth' => true],
            'view_certificate' => ['controller' => 'CertificateController', 'method' => 'viewCertificate', 'auth' => true],
            'verify_certificate' => ['controller' => 'CertificateController', 'method' => 'verifyCertificate', 'auth' => false],
            
            // Subscription routes
            'activate_subscription' => ['controller' => 'SubscriptionController', 'method' => 'activateSubscription', 'auth' => true],
            'cancel_subscription' => ['controller' => 'SubscriptionController', 'method' => 'cancelSubscription', 'auth' => true],
            'get_subscription_history' => ['controller' => 'SubscriptionController', 'method' => 'getSubscriptionHistory', 'auth' => true],
            
            // System routes
            'health_check' => ['controller' => 'SystemController', 'method' => 'healthCheck', 'auth' => false],
            'get_version' => ['controller' => 'SystemController', 'method' => 'getVersion', 'auth' => false],
            'contact_form' => ['controller' => 'SystemController', 'method' => 'contactForm', 'auth' => false],
            'newsletter_subscribe' => ['controller' => 'SystemController', 'method' => 'newsletterSubscribe', 'auth' => false]
        ];
        
        if (!isset($routes[$action])) {
            $this->sendErrorResponse("Unknown action: $action", 400, 'UNKNOWN_ACTION');
        }
        
        $route = $routes[$action];
        
        // فحص المصادقة
        if ($route['auth'] && !$this->sessionManager->isLoggedIn()) {
            $this->sendErrorResponse('Authentication required', 401, 'AUTH_REQUIRED');
        }
        
        // فحص صلاحيات الإدارة
        if (isset($route['admin']) && $route['admin'] && !$this->sessionManager->isAdmin()) {
            $this->sendErrorResponse('Admin privileges required', 403, 'ADMIN_REQUIRED');
        }
        
        // تحميل وتنفيذ المتحكم
        return $this->executeController($route['controller'], $route['method']);
    }
    
    /**
     * تنفيذ المتحكم والطريقة
     */
    private function executeController($controllerName, $methodName) {
        $controllerFile = __DIR__ . "/backend/controllers/{$controllerName}.php";
        
        if (!file_exists($controllerFile)) {
            throw new Exception("Controller file not found: $controllerName");
        }
        
        require_once $controllerFile;
        
        if (!class_exists($controllerName)) {
            throw new Exception("Controller class not found: $controllerName");
        }
        
        $controller = new $controllerName();
        
        if (!method_exists($controller, $methodName)) {
            throw new Exception("Method not found: $controllerName::$methodName");
        }
        
        // تنفيذ الطريقة وإرجاع النتيجة
        ob_start();
        $result = $controller->$methodName();
        $output = ob_get_clean();
        
        // إذا كان هناك مخرجات من المتحكم، استخدمها
        if (!empty($output)) {
            echo $output;
            exit;
        }
        
        return $result;
    }
    
    /**
     * إرسال استجابة نجاح
     */
    private function sendSuccessResponse($data = null, $message = null) {
        $response = [
            'success' => true,
            'request_id' => $this->requestId,
            'timestamp' => date('c'),
            'execution_time' => round((microtime(true) - $this->startTime) * 1000, 2) . 'ms'
        ];
        
        if ($message !== null) {
            $response['message'] = $message;
        }
        
        if ($data !== null) {
            $response['data'] = $data;
        }
        
        $this->sendJsonResponse($response);
    }
    
    /**
     * إرسال استجابة خطأ
     */
    private function sendErrorResponse($message, $statusCode = 400, $errorCode = null, $details = null) {
        http_response_code($statusCode);
        
        $response = [
            'success' => false,
            'error' => [
                'message' => $message,
                'code' => $errorCode,
                'status' => $statusCode
            ],
            'request_id' => $this->requestId,
            'timestamp' => date('c')
        ];
        
        if ($details !== null) {
            $response['error']['details'] = $details;
        }
        
        if (APP_ENV === 'development') {
            $response['debug'] = [
                'execution_time' => round((microtime(true) - $this->startTime) * 1000, 2) . 'ms',
                'memory_usage' => round(memory_get_usage(true) / 1024 / 1024, 2) . 'MB',
                'request_method' => $_SERVER['REQUEST_METHOD'],
                'request_uri' => $_SERVER['REQUEST_URI']
            ];
        }
        
        $this->sendJsonResponse($response);
    }
    
    /**
     * إرسال استجابة JSON
     */
    private function sendJsonResponse($data) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        exit;
    }
    
    /**
     * معالجة الاستثناءات
     */
    private function handleException($exception) {
        $this->logError('API Exception', $exception);
        
        $message = APP_ENV === 'development' ? $exception->getMessage() : 'Internal server error';
        $statusCode = method_exists($exception, 'getStatusCode') ? $exception->getStatusCode() : 500;
        
        $details = null;
        if (APP_ENV === 'development') {
            $details = [
                'file' => $exception->getFile(),
                'line' => $exception->getLine(),
                'trace' => $exception->getTraceAsString()
            ];
        }
        
        $this->sendErrorResponse($message, $statusCode, 'INTERNAL_ERROR', $details);
    }
    
    /**
     * تسجيل طلب API
     */
    private function logRequest() {
        $this->logApiCall($this->getAction(), 'started', 0);
    }
    
    /**
     * تسجيل عملية API
     */
    private function logApiCall($action, $status, $responseCode) {
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO api_logs (action, user_id, ip_address, user_agent, request_data, response_status, execution_time, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            
            $user = $this->sessionManager ? $this->sessionManager->getCurrentUser() : null;
            $executionTime = round((microtime(true) - $this->startTime) * 1000, 2);
            
            $requestData = json_encode([
                'method' => $_SERVER['REQUEST_METHOD'],
                'uri' => $_SERVER['REQUEST_URI'],
                'get' => $_GET,
                'post' => $this->sanitizeLogData($_POST),
                'headers' => $this->getRelevantHeaders(),
                'status' => $status,
                'request_id' => $this->requestId
            ], JSON_UNESCAPED_UNICODE);
            
            $stmt->execute([
                $action,
                $user['id'] ?? null,
                getRealIpAddress(),
                $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
                $requestData,
                $responseCode,
                $executionTime
            ]);
        } catch (Exception $e) {
            error_log("Failed to log API call: " . $e->getMessage());
        }
    }
    
    /**
     * تسجيل الأخطاء
     */
    private function logError($message, $exception = null) {
        $errorData = [
            'message' => $message,
            'request_id' => $this->requestId,
            'timestamp' => date('c'),
            'ip' => getRealIpAddress(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
            'method' => $_SERVER['REQUEST_METHOD'],
            'uri' => $_SERVER['REQUEST_URI']
        ];
        
        if ($exception) {
            $errorData['exception'] = [
                'message' => $exception->getMessage(),
                'file' => $exception->getFile(),
                'line' => $exception->getLine(),
                'trace' => $exception->getTraceAsString()
            ];
        }
        
        error_log("API Error: " . json_encode($errorData, JSON_UNESCAPED_UNICODE));
    }
    
    /**
     * تسجيل أحداث الأمان
     */
    private function logSecurityEvent($description, $severity = 'medium', $additionalData = []) {
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO security_logs (event_type, severity, description, user_id, ip_address, user_agent, additional_data, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            
            $user = $this->sessionManager ? $this->sessionManager->getCurrentUser() : null;
            $additionalData['request_id'] = $this->requestId;
            
            $stmt->execute([
                'api_security',
                $severity,
                $description,
                $user['id'] ?? null,
                getRealIpAddress(),
                $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
                json_encode($additionalData, JSON_UNESCAPED_UNICODE)
            ]);
        } catch (Exception $e) {
            error_log("Failed to log security event: " . $e->getMessage());
        }
    }
    
    // دوال مساعدة إضافية
    
    private function getAllowedOrigins() {
        $origins = [SITE_URL];
        
        if (APP_ENV === 'development') {
            $origins[] = 'http://localhost:3000';
            $origins[] = 'http://localhost:8080';
            $origins[] = 'http://127.0.0.1:3000';
            $origins[] = 'http://127.0.0.1:8080';
        }
        
        return $origins;
    }
    
    private function getRateLimitIdentifier($action) {
        $user = $this->sessionManager ? $this->sessionManager->getCurrentUser() : null;
        $userId = $user ? $user['id'] : 'anonymous';
        $ip = getRealIpAddress();
        
        return "api_{$action}_{$userId}_{$ip}";
    }
    
    private function checkMaintenanceMode() {
        $maintenanceMode = getSetting('maintenance_mode', false);
        
        if ($maintenanceMode) {
            $user = $this->sessionManager ? $this->sessionManager->getCurrentUser() : null;
            $isAdmin = $user && $user['is_admin'];
            
            if (!$isAdmin) {
                $this->sendErrorResponse(
                    'System is under maintenance. Please try again later.',
                    503,
                    'MAINTENANCE_MODE'
                );
            }
        }
    }
    
    private function checkBlockedIP() {
        $ip = getRealIpAddress();
        
        try {
            $stmt = $this->pdo->prepare("
                SELECT COUNT(*) FROM blocked_ips 
                WHERE ip_address = ? AND (expires_at IS NULL OR expires_at > NOW())
            ");
            $stmt->execute([$ip]);
            
            if ($stmt->fetchColumn() > 0) {
                $this->logSecurityEvent('Blocked IP access attempt', 'high', ['ip' => $ip]);
                $this->sendErrorResponse('Access denied', 403, 'IP_BLOCKED');
            }
        } catch (Exception $e) {
            // في حالة فشل فحص IP، لا نحظر الوصول
        }
    }
    
    private function validateCSRF() {
        $token = $_POST['csrf_token'] ?? 
                $_SERVER['HTTP_X_CSRF_TOKEN'] ?? 
                $_SERVER['HTTP_X_XSRF_TOKEN'] ?? null;
        
        if (!$token || !verifyCSRFToken($token)) {
            $this->logSecurityEvent('CSRF token validation failed', 'high', [
                'action' => $this->getAction(),
                'method' => $_SERVER['REQUEST_METHOD']
            ]);
            
            $this->sendErrorResponse('Invalid CSRF token', 403, 'CSRF_INVALID');
        }
    }
    
    private function checkRequestSize() {
        $maxSize = ini_get('post_max_size');
        $maxSizeBytes = $this->parseSize($maxSize);
        
        $contentLength = $_SERVER['CONTENT_LENGTH'] ?? 0;
        
        if ($contentLength > $maxSizeBytes) {
            $this->sendErrorResponse('Request too large', 413, 'REQUEST_TOO_LARGE');
        }
    }
    
    private function parseSize($size) {
        $unit = preg_replace('/[^bkmgtpezy]/i', '', $size);
        $size = preg_replace('/[^0-9\.]/', '', $size);
        
        if ($unit) {
            return round($size * pow(1024, stripos('bkmgtpezy', $unit[0])));
        }
        
        return round($size);
    }
    
    private function sanitizeInput() {
        // تنظيف المدخلات من محاولات XSS وSQL injection
        array_walk_recursive($_GET, [$this, 'sanitizeValue']);
        array_walk_recursive($_POST, [$this, 'sanitizeValue']);
        array_walk_recursive($_REQUEST, [$this, 'sanitizeValue']);
    }
    
    private function sanitizeValue(&$value) {
        if (is_string($value)) {
            $value = trim($value);
            // إزالة null bytes
            $value = str_replace(chr(0), '', $value);
            // تحويل encoding
            $value = mb_convert_encoding($value, 'UTF-8', 'UTF-8');
        }
    }
    
    private function sanitizeLogData($data) {
        $sensitiveFields = ['password', 'password_confirm', 'token', 'api_key', 'secret'];
        
        if (is_array($data)) {
            foreach ($data as $key => $value) {
                if (in_array(strtolower($key), $sensitiveFields)) {
                    $data[$key] = '[REDACTED]';
                } elseif (is_array($value)) {
                    $data[$key] = $this->sanitizeLogData($value);
                }
            }
        }
        
        return $data;
    }
    
    private function getRelevantHeaders() {
        $headers = [];
        $relevantHeaders = [
            'HTTP_ACCEPT', 'HTTP_ACCEPT_LANGUAGE', 'HTTP_ACCEPT_ENCODING',
            'HTTP_USER_AGENT', 'HTTP_REFERER', 'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP', 'HTTP_AUTHORIZATION'
        ];
        
        foreach ($relevantHeaders as $header) {
            if (isset($_SERVER[$header])) {
                $headers[$header] = $_SERVER[$header];
            }
        }
        
        return $headers;
    }
}

// إنشاء وتشغيل API
try {
    $api = new TrendAcademyAPI();
    $api->handleRequest();
} catch (Throwable $e) {
    // معالجة الأخطاء الحرجة
    error_log("Critical API Error: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
    
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    
    $response = [
        'success' => false,
        'error' => [
            'message' => APP_ENV === 'development' ? $e->getMessage() : 'Critical system error',
            'code' => 'CRITICAL_ERROR',
            'status' => 500
        ],
        'timestamp' => date('c')
    ];
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
}
?>