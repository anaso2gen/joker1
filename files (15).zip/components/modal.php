<?php
/**
 * مكون النافذة المنبثقة القابل لإعادة الاستخدام
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

function renderModal($options = []) {
    $defaults = [
        'id' => 'modal-' . uniqid(),
        'title' => '',
        'content' => '',
        'footer' => '',
        'size' => '', // sm, lg, xl
        'centered' => true,
        'backdrop' => 'static',
        'keyboard' => true,
        'animation' => true
    ];
    
    $config = array_merge($defaults, $options);
    
    $sizeClass = $config['size'] ? 'modal-' . $config['size'] : '';
    $centeredClass = $config['centered'] ? 'modal-dialog-centered' : '';
    $animationClass = $config['animation'] ? 'fade' : '';
    
    ob_start();
    ?>
    <div class="modal <?php echo $animationClass; ?>" 
         id="<?php echo $config['id']; ?>" 
         tabindex="-1" 
         data-bs-backdrop="<?php echo $config['backdrop']; ?>"
         data-bs-keyboard="<?php echo $config['keyboard'] ? 'true' : 'false'; ?>">
        
        <div class="modal-dialog <?php echo $sizeClass; ?> <?php echo $centeredClass; ?>">
            <div class="modal-content">
                
                <?php if ($config['title']): ?>
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo htmlspecialchars($config['title']); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                </div>
                <?php endif; ?>
                
                <div class="modal-body">
                    <?php echo $config['content']; ?>
                </div>
                
                <?php if ($config['footer']): ?>
                <div class="modal-footer">
                    <?php echo $config['footer']; ?>
                </div>
                <?php endif; ?>
                
            </div>
        </div>
    </div>
    
    <style>
    .modal-content {
        border: none;
        border-radius: 1rem;
        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
    }
    
    .modal-header {
        border-bottom: 1px solid rgba(0,0,0,0.1);
        background: linear-gradient(135deg, #f8f9fa, #e9ecef);
        border-radius: 1rem 1rem 0 0;
    }
    
    .modal-footer {
        border-top: 1px solid rgba(0,0,0,0.1);
        background: #f8f9fa;
        border-radius: 0 0 1rem 1rem;
    }
    </style>
    <?php
    return ob_get_clean();
}
?>