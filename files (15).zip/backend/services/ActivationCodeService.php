<?php
/**
 * خدمة إدارة أكواد التفعيل
 * تتضمن إنشاء وإدارة وتفعيل الأكواد
 * 
 * @author anaso2gen
 * @version 1.0
 * @since 2025-05-29
 */

require_once __DIR__ . '/../models/Database.php';
require_once __DIR__ . '/../models/ActivationCode.php';

class ActivationCodeService {
    private $db;
    private $activationCodeModel;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
        $this->activationCodeModel = new ActivationCode();
    }
    
    /**
     * إنشاء كود تفعيل جديد
     */
    public function createCode($data) {
        try {
            // التحقق من البيانات المطلوبة
            $this->validateCodeData($data);
            
            // إنشاء الكود إذا لم يتم توفيره
            if (empty($data['code'])) {
                $data['code'] = $this->generateUniqueCode($data['code_pattern'] ?? 'mixed', $data['code_length'] ?? 8);
            }
            
            // التحقق من عدم تكرار الكود
            if ($this->isCodeExists($data['code'])) {
                throw new Exception('هذا الكود موجود مسبقاً');
            }
            
            // إعداد البيانات للحفظ
            $codeData = [
                'code' => strtoupper($data['code']),
                'code_type' => $data['code_type'] ?? 'single_course',
                'course_ids' => isset($data['course_ids']) ? json_encode($data['course_ids']) : null,
                'max_uses' => $data['max_uses'] ?? 1,
                'expires_at' => $data['expires_at'] ?? null,
                'duration_days' => $data['duration_days'] ?? 365,
                'created_by' => $data['created_by'],
                'notes' => $data['notes'] ?? null,
                'is_active' => 1
            ];
            
            // حفظ الكود في قاعدة البيانات
            $stmt = $this->db->prepare("
                INSERT INTO activation_codes 
                (code, code_type, course_ids, max_uses, expires_at, duration_days, created_by, notes, is_active) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $result = $stmt->execute([
                $codeData['code'],
                $codeData['code_type'],
                $codeData['course_ids'],
                $codeData['max_uses'],
                $codeData['expires_at'],
                $codeData['duration_days'],
                $codeData['created_by'],
                $codeData['notes'],
                $codeData['is_active']
            ]);
            
            if ($result) {
                $codeId = $this->db->lastInsertId();
                return [
                    'success' => true,
                    'code_id' => $codeId,
                    'code' => $codeData['code'],
                    'message' => 'تم إنشاء الكود بنجاح'
                ];
            } else {
                throw new Exception('فشل في حفظ الكود');
            }
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * إنشاء أكواد متعددة بالجملة
     */
    public function createBulkCodes($data) {
        try {
            $quantity = $data['quantity'] ?? 10;
            $pattern = $data['code_pattern'] ?? 'mixed';
            $length = $data['code_length'] ?? 8;
            
            if ($quantity > 1000) {
                throw new Exception('لا يمكن إنشاء أكثر من 1000 كود في المرة الواحدة');
            }
            
            $createdCodes = [];
            $failedCodes = [];
            
            for ($i = 0; $i < $quantity; $i++) {
                $codeData = $data;
                $codeData['code'] = $this->generateUniqueCode($pattern, $length);
                
                $result = $this->createCode($codeData);
                
                if ($result['success']) {
                    $createdCodes[] = $result['code'];
                } else {
                    $failedCodes[] = [
                        'code' => $codeData['code'],
                        'error' => $result['message']
                    ];
                }
            }
            
            return [
                'success' => true,
                'created_count' => count($createdCodes),
                'failed_count' => count($failedCodes),
                'created_codes' => $createdCodes,
                'failed_codes' => $failedCodes,
                'message' => "تم إنشاء " . count($createdCodes) . " كود من أصل $quantity"
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * تفعيل كود للمستخدم
     */
    public function activateCode($code, $userId, $userIP = null, $userAgent = null) {
        try {
            $this->db->beginTransaction();
            
            // البحث عن الكود
            $codeInfo = $this->getCodeByValue($code);
            if (!$codeInfo) {
                throw new Exception('الكود غير صحيح');
            }
            
            // التحقق من صحة الكود
            $validation = $this->validateCodeActivation($codeInfo, $userId);
            if (!$validation['valid']) {
                throw new Exception($validation['message']);
            }
            
            // تسجيل استخدام الكود
            $this->logCodeUsage($codeInfo['id'], $userId, 'success', $userIP, $userAgent);
            
            // تحديث عداد الاستخدام
            $this->updateCodeUsageCount($codeInfo['id']);
            
            // إنشاء الاشتراكات للمستخدم
            $subscriptionResult = $this->createUserSubscriptions($codeInfo, $userId);
            
            if (!$subscriptionResult['success']) {
                throw new Exception($subscriptionResult['message']);
            }
            
            $this->db->commit();
            
            return [
                'success' => true,
                'message' => 'تم تفعيل الكود بنجاح',
                'code_type' => $codeInfo['code_type'],
                'expires_at' => $subscriptionResult['expires_at'],
                'courses_count' => $subscriptionResult['courses_count']
            ];
            
        } catch (Exception $e) {
            $this->db->rollback();
            
            // تسجيل الفشل
            if (isset($codeInfo['id'])) {
                $this->logCodeUsage($codeInfo['id'], $userId, 'failed', $userIP, $userAgent, $e->getMessage());
            }
            
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * الحصول على معلومات الكود
     */
    public function getCodeInfo($code) {
        try {
            $codeInfo = $this->getCodeByValue($code);
            
            if (!$codeInfo) {
                return [
                    'success' => false,
                    'message' => 'الكود غير موجود'
                ];
            }
            
            // إضافة معلومات الدورات
            if ($codeInfo['code_type'] !== 'all_courses' && $codeInfo['course_ids']) {
                $courseIds = json_decode($codeInfo['course_ids'], true);
                $codeInfo['courses'] = $this->getCoursesByIds($courseIds);
            } else {
                $codeInfo['courses'] = 'جميع الدورات';
            }
            
            // حساب الاستخدامات المتبقية
            $codeInfo['remaining_uses'] = $codeInfo['max_uses'] - $codeInfo['used_count'];
            
            return [
                'success' => true,
                'code_info' => $codeInfo
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * الحصول على جميع الأكواد مع فلترة
     */
    public function getAllCodes($filters = []) {
        try {
            $where = ['1=1'];
            $params = [];
            
            // تطبيق الفلاتر
            if (!empty($filters['search'])) {
                $where[] = "(code LIKE ? OR notes LIKE ?)";
                $searchTerm = '%' . $filters['search'] . '%';
                $params[] = $searchTerm;
                $params[] = $searchTerm;
            }
            
            if (isset($filters['is_active'])) {
                $where[] = "is_active = ?";
                $params[] = $filters['is_active'];
            }
            
            if (!empty($filters['code_type'])) {
                $where[] = "code_type = ?";
                $params[] = $filters['code_type'];
            }
            
            if (!empty($filters['expires_from'])) {
                $where[] = "expires_at >= ?";
                $params[] = $filters['expires_from'];
            }
            
            if (!empty($filters['expires_to'])) {
                $where[] = "expires_at <= ?";
                $params[] = $filters['expires_to'];
            }
            
            // ترتيب النتائج
            $orderBy = $filters['order_by'] ?? 'created_at';
            $orderDir = $filters['order_dir'] ?? 'DESC';
            
            // تحديد حد النتائج
            $limit = intval($filters['limit'] ?? 50);
            $offset = intval($filters['offset'] ?? 0);
            
            $sql = "
                SELECT ac.*, 
                       u.first_name, u.last_name, u.email as creator_email,
                       (SELECT COUNT(*) FROM code_usage_log WHERE code_id = ac.id AND status = 'success') as successful_uses
                FROM activation_codes ac 
                LEFT JOIN users u ON ac.created_by = u.id 
                WHERE " . implode(' AND ', $where) . " 
                ORDER BY ac.$orderBy $orderDir 
                LIMIT $limit OFFSET $offset
            ";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            $codes = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // إضافة معلومات الدورات لكل كود
            foreach ($codes as &$code) {
                if ($code['code_type'] !== 'all_courses' && $code['course_ids']) {
                    $courseIds = json_decode($code['course_ids'], true);
                    $code['courses'] = $this->getCoursesByIds($courseIds);
                } else {
                    $code['courses'] = 'جميع الدورات';
                }
                
                $code['remaining_uses'] = $code['max_uses'] - $code['used_count'];
                $code['creator_name'] = $code['first_name'] . ' ' . $code['last_name'];
            }
            
            // إجمالي عدد السجلات
            $countSql = "SELECT COUNT(*) FROM activation_codes WHERE " . implode(' AND ', $where);
            $countStmt = $this->db->prepare($countSql);
            $countStmt->execute($params);
            $totalCount = $countStmt->fetchColumn();
            
            return [
                'success' => true,
                'codes' => $codes,
                'total_count' => $totalCount,
                'showing_count' => count($codes)
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * حذف كود تفعيل
     */
    public function deleteCode($codeId) {
        try {
            // التحقق من وجود الكود
            $stmt = $this->db->prepare("SELECT id, code, used_count FROM activation_codes WHERE id = ?");
            $stmt->execute([$codeId]);
            $code = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$code) {
                throw new Exception('الكود غير موجود');
            }
            
            if ($code['used_count'] > 0) {
                throw new Exception('لا يمكن حذف كود تم استخدامه');
            }
            
            // حذف الكود
            $stmt = $this->db->prepare("DELETE FROM activation_codes WHERE id = ?");
            $result = $stmt->execute([$codeId]);
            
            if ($result) {
                return [
                    'success' => true,
                    'message' => 'تم حذف الكود بنجاح'
                ];
            } else {
                throw new Exception('فشل في حذف الكود');
            }
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * تعطيل/تفعيل كود
     */
    public function toggleCodeStatus($codeId, $isActive) {
        try {
            $stmt = $this->db->prepare("UPDATE activation_codes SET is_active = ? WHERE id = ?");
            $result = $stmt->execute([$isActive ? 1 : 0, $codeId]);
            
            if ($result) {
                $status = $isActive ? 'تم تفعيل' : 'تم تعطيل';
                return [
                    'success' => true,
                    'message' => "$status الكود بنجاح"
                ];
            } else {
                throw new Exception('فشل في تحديث حالة الكود');
            }
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * تصدير الأكواد
     */
    public function exportCodes($format = 'csv', $filters = []) {
        try {
            $codesResult = $this->getAllCodes($filters);
            
            if (!$codesResult['success']) {
                throw new Exception($codesResult['message']);
            }
            
            $codes = $codesResult['codes'];
            
            switch ($format) {
                case 'csv':
                    return $this->exportToCSV($codes);
                case 'excel':
                    return $this->exportToExcel($codes);
                case 'txt':
                    return $this->exportToTXT($codes);
                default:
                    throw new Exception('صيغة التصدير غير مدعومة');
            }
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * إحصائيات الأكواد
     */
    public function getCodesStatistics() {
        try {
            $stats = [];
            
            // إجمالي الأكواد
            $stmt = $this->db->query("SELECT COUNT(*) FROM activation_codes");
            $stats['total_codes'] = $stmt->fetchColumn();
            
            // الأكواد النشطة
            $stmt = $this->db->query("SELECT COUNT(*) FROM activation_codes WHERE is_active = 1");
            $stats['active_codes'] = $stmt->fetchColumn();
            
            // الأكواد المستخدمة
            $stmt = $this->db->query("SELECT COUNT(*) FROM activation_codes WHERE used_count > 0");
            $stats['used_codes'] = $stmt->fetchColumn();
            
            // الأكواد المنتهية الصلاحية
            $stmt = $this->db->query("SELECT COUNT(*) FROM activation_codes WHERE expires_at < NOW()");
            $stats['expired_codes'] = $stmt->fetchColumn();
            
            // إجمالي الاستخدامات الناجحة
            $stmt = $this->db->query("SELECT COUNT(*) FROM code_usage_log WHERE status = 'success'");
            $stats['successful_activations'] = $stmt->fetchColumn();
            
            // إحصائيات حسب النوع
            $stmt = $this->db->query("
                SELECT code_type, COUNT(*) as count 
                FROM activation_codes 
                GROUP BY code_type
            ");
            $stats['by_type'] = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
            
            // أكثر الأكواد استخداماً
            $stmt = $this->db->query("
                SELECT code, used_count, max_uses 
                FROM activation_codes 
                WHERE used_count > 0 
                ORDER BY used_count DESC 
                LIMIT 10
            ");
            $stats['most_used'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return [
                'success' => true,
                'statistics' => $stats
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    // =================== دوال مساعدة خاصة ===================
    
    /**
     * التحقق من صحة بيانات الكود
     */
    private function validateCodeData($data) {
        if (empty($data['created_by'])) {
            throw new Exception('معرف منشئ الكود مطلوب');
        }
        
        if (!empty($data['code']) && strlen($data['code']) < 4) {
            throw new Exception('الكود يجب أن يكون 4 أحرف على الأقل');
        }
        
        if (!empty($data['max_uses']) && $data['max_uses'] < 1) {
            throw new Exception('عدد مرات الاستخدام يجب أن يكون 1 على الأقل');
        }
        
        if (!empty($data['expires_at'])) {
            $expiryDate = strtotime($data['expires_at']);
            if ($expiryDate < time()) {
                throw new Exception('تاريخ انتهاء الصلاحية لا يمكن أن يكون في الماضي');
            }
        }
    }
    
    /**
     * توليد كود فريد
     */
    private function generateUniqueCode($pattern = 'mixed', $length = 8) {
        $maxAttempts = 100;
        $attempts = 0;
        
        do {
            $code = $this->generateCode($pattern, $length);
            $attempts++;
        } while ($this->isCodeExists($code) && $attempts < $maxAttempts);
        
        if ($attempts >= $maxAttempts) {
            throw new Exception('فشل في إنشاء كود فريد');
        }
        
        return $code;
    }
    
    /**
     * توليد كود عشوائي
     */
    private function generateCode($pattern, $length) {
        switch ($pattern) {
            case 'numbers':
                $chars = '0123456789';
                break;
            case 'letters':
                $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                break;
            case 'mixed':
            default:
                $chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                break;
        }
        
        $code = '';
        for ($i = 0; $i < $length; $i++) {
            $code .= $chars[random_int(0, strlen($chars) - 1)];
        }
        
        return $code;
    }
    
    /**
     * التحقق من وجود الكود
     */
    private function isCodeExists($code) {
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM activation_codes WHERE code = ?");
        $stmt->execute([$code]);
        return $stmt->fetchColumn() > 0;
    }
    
    /**
     * الحصول على الكود بالقيمة
     */
    private function getCodeByValue($code) {
        $stmt = $this->db->prepare("SELECT * FROM activation_codes WHERE code = ?");
        $stmt->execute([$code]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * التحقق من صحة تفعيل الكود
     */
    private function validateCodeActivation($codeInfo, $userId) {
        // التحقق من نشاط الكود
        if (!$codeInfo['is_active']) {
            return ['valid' => false, 'message' => 'هذا الكود غير نشط'];
        }
        
        // التحقق من انتهاء الصلاحية
        if ($codeInfo['expires_at'] && strtotime($codeInfo['expires_at']) < time()) {
            return ['valid' => false, 'message' => 'انتهت صلاحية هذا الكود'];
        }
        
        // التحقق من عدد مرات الاستخدام
        if ($codeInfo['used_count'] >= $codeInfo['max_uses']) {
            return ['valid' => false, 'message' => 'تم استنفاد عدد مرات استخدام هذا الكود'];
        }
        
        // التحقق من عدم استخدام المستخدم للكود سابقاً
        if ($this->hasUserUsedCode($codeInfo['id'], $userId)) {
            return ['valid' => false, 'message' => 'لقد استخدمت هذا الكود مسبقاً'];
        }
        
        return ['valid' => true, 'message' => 'الكود صالح للاستخدام'];
    }
    
    /**
     * التحقق من استخدام المستخدم للكود سابقاً
     */
    private function hasUserUsedCode($codeId, $userId) {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM code_usage_log 
            WHERE code_id = ? AND user_id = ? AND status = 'success'
        ");
        $stmt->execute([$codeId, $userId]);
        return $stmt->fetchColumn() > 0;
    }
    
    /**
     * تسجيل استخدام الكود
     */
    private function logCodeUsage($codeId, $userId, $status, $ip = null, $userAgent = null, $notes = null) {
        $stmt = $this->db->prepare("
            INSERT INTO code_usage_log (code_id, user_id, status, ip_address, user_agent, notes) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        return $stmt->execute([
            $codeId,
            $userId,
            $status,
            $ip,
            $userAgent,
            $notes
        ]);
    }
    
    /**
     * تحديث عداد استخدام الكود
     */
    private function updateCodeUsageCount($codeId) {
        $stmt = $this->db->prepare("
            UPDATE activation_codes 
            SET used_count = used_count + 1 
            WHERE id = ?
        ");
        
        return $stmt->execute([$codeId]);
    }
    
    /**
     * إنشاء اشتراكات المستخدم
     */
    private function createUserSubscriptions($codeInfo, $userId) {
        try {
            $expiresAt = null;
            if ($codeInfo['duration_days']) {
                $expiresAt = date('Y-m-d H:i:s', strtotime("+{$codeInfo['duration_days']} days"));
            }
            
            $coursesCount = 0;
            
            if ($codeInfo['code_type'] === 'all_courses') {
                // اشتراك في جميع الدورات
                $stmt = $this->db->prepare("
                    INSERT INTO user_subscriptions 
                    (user_id, course_id, activation_code_id, subscription_type, expires_at) 
                    VALUES (?, NULL, ?, 'code_activated', ?)
                ");
                $stmt->execute([$userId, $codeInfo['id'], $expiresAt]);
                $coursesCount = 'جميع الدورات';
                
            } else {
                // اشتراك في دورات محددة
                $courseIds = json_decode($codeInfo['course_ids'], true);
                
                if (empty($courseIds)) {
                    throw new Exception('لا توجد دورات محددة للكود');
                }
                
                foreach ($courseIds as $courseId) {
                    $stmt = $this->db->prepare("
                        INSERT INTO user_subscriptions 
                        (user_id, course_id, activation_code_id, subscription_type, expires_at) 
                        VALUES (?, ?, ?, 'code_activated', ?)
                        ON DUPLICATE KEY UPDATE 
                        expires_at = GREATEST(expires_at, ?), 
                        activation_code_id = ?
                    ");
                    $stmt->execute([$userId, $courseId, $codeInfo['id'], $expiresAt, $expiresAt, $codeInfo['id']]);
                }
                
                $coursesCount = count($courseIds);
            }
            
            return [
                'success' => true,
                'expires_at' => $expiresAt,
                'courses_count' => $coursesCount
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'فشل في إنشاء الاشتراكات: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * الحصول على الدورات بواسطة المعرفات
     */
    private function getCoursesByIds($courseIds) {
        if (empty($courseIds)) {
            return [];
        }
        
        $placeholders = str_repeat('?,', count($courseIds) - 1) . '?';
        $stmt = $this->db->prepare("SELECT id, title FROM courses WHERE id IN ($placeholders)");
        $stmt->execute($courseIds);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * تصدير لصيغة CSV
     */
    private function exportToCSV($codes) {
        $filename = 'activation_codes_' . date('Y-m-d_H-i-s') . '.csv';
        $filepath = __DIR__ . '/../../uploads/temp/' . $filename;
        
        // التأكد من وجود المجلد
        $dir = dirname($filepath);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        
        $file = fopen($filepath, 'w');
        
        // كتابة العناوين
        fputcsv($file, [
            'الكود',
            'النوع',
            'الحد الأقصى للاستخدام',
            'المستخدم',
            'المتبقي',
            'تاريخ الانتهاء',
            'مدة الاشتراك (يوم)',
            'منشئ الكود',
            'ملاحظات',
            'الحالة',
            'تاريخ الإنشاء'
        ]);
        
        // كتابة البيانات
        foreach ($codes as $code) {
            fputcsv($file, [
                $code['code'],
                $this->getCodeTypeText($code['code_type']),
                $code['max_uses'],
                $code['used_count'],
                $code['remaining_uses'],
                $code['expires_at'],
                $code['duration_days'],
                $code['creator_name'],
                $code['notes'],
                $code['is_active'] ? 'نشط' : 'معطل',
                $code['created_at']
            ]);
        }
        
        fclose($file);
        
        return [
            'success' => true,
            'filename' => $filename,
            'filepath' => $filepath,
            'download_url' => '/uploads/temp/' . $filename
        ];
    }
    
    /**
     * تصدير لصيغة TXT
     */
    private function exportToTXT($codes) {
        $filename = 'activation_codes_' . date('Y-m-d_H-i-s') . '.txt';
        $filepath = __DIR__ . '/../../uploads/temp/' . $filename;
        
        // التأكد من وجود المجلد
        $dir = dirname($filepath);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        
        $content = "أكواد التفعيل - تم التصدير في: " . date('Y-m-d H:i:s') . "\n";
        $content .= str_repeat("=", 50) . "\n\n";
        
        foreach ($codes as $code) {
            $content .= $code['code'] . "\n";
        }
        
        file_put_contents($filepath, $content);
        
        return [
            'success' => true,
            'filename' => $filename,
            'filepath' => $filepath,
            'download_url' => '/uploads/temp/' . $filename
        ];
    }
    
    /**
     * الحصول على نص نوع الكود
     */
    private function getCodeTypeText($type) {
        $types = [
            'single_course' => 'دورة واحدة',
            'all_courses' => 'جميع الدورات',
            'course_bundle' => 'باقة دورات'
        ];
        
        return $types[$type] ?? $type;
    }
}
?>