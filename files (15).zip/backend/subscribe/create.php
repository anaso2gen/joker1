<?php
/**
 * API إنشاء اشتراك جديد باستخدام كود
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(['success' => false, 'message' => 'طريقة طلب غير صالحة'], 405);
}

try {
    $db = Database::getInstance()->getConnection();
    
    $mode = sanitizeInput($_POST['mode'] ?? 'login'); // login or register
    $email = sanitizeInput($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $code = sanitizeInput($_POST['code'] ?? '');
    
    $errors = [];
    
    // التحقق من البيانات الأساسية
    if (empty($email)) {
        $errors['email'] = 'البريد الإلكتروني مطلوب';
    } elseif (!validateEmail($email)) {
        $errors['email'] = 'البريد الإلكتروني غير صالح';
    }
    
    if (empty($password)) {
        $errors['password'] = 'كلمة المرور مطلوبة';
    }
    
    if (empty($code)) {
        $errors['code'] = 'كود الاشتراك مطلوب';
    }
    
    // التحقق من صحة كود الاشتراك
    $stmt = $db->prepare("
        SELECT c.*, co.name as course_name, co.id as course_id
        FROM codes c
        JOIN courses co ON co.id = c.course_id
        WHERE c.code = ? AND c.is_active = 1 AND co.is_active = 1
        AND (c.expires_at IS NULL OR c.expires_at > NOW())
        AND (c.max_uses = 0 OR c.uses_count < c.max_uses)
    ");
    
    $stmt->execute([$code]);
    $codeData = $stmt->fetch();
    
    if (!$codeData) {
        $errors['code'] = 'كود الاشتراك غير صالح أو منتهي الصلاحية';
    }
    
    if (!empty($errors)) {
        sendJsonResponse([
            'success' => false,
            'message' => 'بيانات غير صالحة',
            'errors' => $errors
        ]);
    }
    
    $db->beginTransaction();
    
    try {
        $userId = null;
        
        if ($mode === 'register') {
            // تسجيل مستخدم جديد
            $confirmPassword = $_POST['confirm_password'] ?? '';
            
            if (!validatePassword($password)) {
                $errors['password'] = 'كلمة المرور يجب أن تكون ' . PASSWORD_MIN_LENGTH . ' أحرف على الأقل';
            }
            
            if ($password !== $confirmPassword) {
                $errors['confirm_password'] = 'كلمة المرور غير متطابقة';
            }
            
            // التحقق من عدم وجود البريد الإلكتروني
            $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetchColumn() > 0) {
                $errors['email'] = 'البريد الإلكتروني موجود مسبقاً';
            }
            
            if (!empty($errors)) {
                $db->rollback();
                sendJsonResponse([
                    'success' => false,
                    'message' => 'بيانات غير صالحة',
                    'errors' => $errors
                ]);
            }
            
            // إنشاء المستخدم الجديد
            $userUuid = generateUUID();
            $hashedPassword = hashPassword($password);
            
            $stmt = $db->prepare("
                INSERT INTO users (email, password, user_id, is_admin, is_active) 
                VALUES (?, ?, ?, 0, 1)
            ");
            
            $stmt->execute([$email, $hashedPassword, $userUuid]);
            $userId = $userUuid;
            
        } else {
            // تسجيل دخول مستخدم موجود
            $stmt = $db->prepare("
                SELECT user_id, password, is_active
                FROM users 
                WHERE email = ?
            ");
            
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if (!$user || !verifyPassword($password, $user['password'])) {
                $db->rollback();
                sendJsonResponse([
                    'success' => false,
                    'message' => 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
                ]);
            }
            
            if (!$user['is_active']) {
                $db->rollback();
                sendJsonResponse([
                    'success' => false,
                    'message' => 'الحساب غير مفعل'
                ]);
            }
            
            $userId = $user['user_id'];
        }
        
        // التحقق من عدم وجود اشتراك مسبق
        $stmt = $db->prepare("
            SELECT COUNT(*) FROM subscriptions 
            WHERE user_id = ? AND course_id = ? AND status = 'active'
        ");
        
        $stmt->execute([$userId, $codeData['course_id']]);
        if ($stmt->fetchColumn() > 0) {
            $db->rollback();
            sendJsonResponse([
                'success' => false,
                'message' => 'أنت مشترك في هذه الدورة بالفعل'
            ]);
        }
        
        // إنشاء الاشتراك
        $stmt = $db->prepare("
            INSERT INTO subscriptions (user_id, course_id, status, subscribed_at) 
            VALUES (?, ?, 'active', NOW())
        ");
        
        $stmt->execute([$userId, $codeData['course_id']]);
        
        // تحديث عداد استخدام الكود
        $stmt = $db->prepare("
            UPDATE codes SET uses_count = uses_count + 1 WHERE id = ?
        ");
        
        $stmt->execute([$codeData['id']]);
        
        $db->commit();
        
        // إنشاء جلسة للمستخدم
        global $sessionManager;
        $sessionManager->createSession($userId, false);
        
        sendJsonResponse([
            'success' => true,
            'message' => 'تم الاشتراك في الدورة بنجاح!',
            'course' => [
                'id' => $codeData['course_id'],
                'name' => $codeData['course_name']
            ],
            'user_id' => $userId
        ]);
        
    } catch (Exception $e) {
        $db->rollback();
        throw $e;
    }
    
} catch (Exception $e) {
    logError("Subscribe error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في عملية الاشتراك'
    ], 500);
}
?>