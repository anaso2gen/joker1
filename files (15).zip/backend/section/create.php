<?php
/**
 * API إنشاء قسم جديد (للمسؤولين فقط)
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(['success' => false, 'message' => 'طريقة طلب غير صالحة'], 405);
}

try {
    $user = $sessionManager->requireAdmin();
    $db = Database::getInstance()->getConnection();
    
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    
    $courseId = intval($input['course_id'] ?? 0);
    $name = sanitizeInput($input['name'] ?? '');
    $description = sanitizeInput($input['description'] ?? '');
    $orderIndex = intval($input['order_index'] ?? 0);
    $isActive = isset($input['is_active']) ? 1 : 0;
    
    $errors = [];
    
    // التحقق من صحة البيانات
    if ($courseId <= 0) {
        $errors['course_id'] = 'معرف الدورة غير صالح';
    } else {
        // التحقق من وجود الكورس
        $stmt = $db->prepare("SELECT id FROM courses WHERE id = ?");
        $stmt->execute([$courseId]);
        if (!$stmt->fetch()) {
            $errors['course_id'] = 'الدورة غير موجودة';
        }
    }
    
    if (empty($name)) {
        $errors['name'] = 'اسم القسم مطلوب';
    }
    
    if (!empty($errors)) {
        sendJsonResponse([
            'success' => false,
            'message' => 'بيانات غير صالحة',
            'errors' => $errors
        ]);
    }
    
    // تحديد ترتيب القسم إذا لم يتم تحديده
    if ($orderIndex <= 0) {
        $stmt = $db->prepare("SELECT COALESCE(MAX(order_index), 0) + 1 FROM sections WHERE course_id = ?");
        $stmt->execute([$courseId]);
        $orderIndex = $stmt->fetchColumn();
    }
    
    // إنشاء القسم
    $stmt = $db->prepare("
        INSERT INTO sections (course_id, name, description, order_index, is_active) 
        VALUES (?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([$courseId, $name, $description, $orderIndex, $isActive]);
    $sectionId = $db->lastInsertId();
    
    // جلب القسم المنشأ
    $stmt = $db->prepare("SELECT * FROM sections WHERE id = ?");
    $stmt->execute([$sectionId]);
    $section = $stmt->fetch();
    
    sendJsonResponse([
        'success' => true,
        'message' => 'تم إنشاء القسم بنجاح',
        'section' => $section
    ]);
    
} catch (Exception $e) {
    logError("Create section error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في إنشاء القسم'
    ], 500);
}
?>