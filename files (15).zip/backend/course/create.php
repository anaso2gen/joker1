<?php
/**
 * API إنشاء كورس جديد (للمسؤولين فقط)
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(['success' => false, 'message' => 'طريقة طلب غير صالحة'], 405);
}

try {
    $user = $sessionManager->requireAdmin();
    $db = Database::getInstance()->getConnection();
    
    $name = sanitizeInput($_POST['name'] ?? '');
    $code = sanitizeInput($_POST['code'] ?? '');
    $description = sanitizeInput($_POST['description'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $sortOrder = intval($_POST['sort_order'] ?? 0);
    $isActive = isset($_POST['is_active']) ? 1 : 0;
    
    $errors = [];
    
    // التحقق من صحة البيانات
    if (empty($name)) {
        $errors['name'] = 'اسم الدورة مطلوب';
    }
    
    if (empty($code)) {
        $errors['code'] = 'كود الدورة مطلوب';
    } else {
        // التحقق من عدم تكرار الكود
        $stmt = $db->prepare("SELECT COUNT(*) FROM courses WHERE code = ?");
        $stmt->execute([$code]);
        if ($stmt->fetchColumn() > 0) {
            $errors['code'] = 'كود الدورة موجود مسبقاً';
        }
    }
    
    if ($price < 0) {
        $errors['price'] = 'السعر لا يمكن أن يكون سالباً';
    }
    
    if (!empty($errors)) {
        sendJsonResponse([
            'success' => false,
            'message' => 'بيانات غير صالحة',
            'errors' => $errors
        ]);
    }
    
    // معالجة رفع الصورة
    $imageUrl = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadResult = handleCourseImageUpload($_FILES['image'], $code);
        if ($uploadResult['success']) {
            $imageUrl = $uploadResult['url'];
        } else {
            $errors['image'] = $uploadResult['message'];
            sendJsonResponse([
                'success' => false,
                'message' => 'خطأ في رفع الصورة',
                'errors' => $errors
            ]);
        }
    }
    
    // إنشاء الكورس
    $stmt = $db->prepare("
        INSERT INTO courses (name, code, description, image_url, price, is_active, sort_order) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([$name, $code, $description, $imageUrl, $price, $isActive, $sortOrder]);
    $courseId = $db->lastInsertId();
    
    // جلب الكورس المنشأ
    $stmt = $db->prepare("SELECT * FROM courses WHERE id = ?");
    $stmt->execute([$courseId]);
    $course = $stmt->fetch();
    
    sendJsonResponse([
        'success' => true,
        'message' => 'تم إنشاء الدورة بنجاح',
        'course' => $course
    ]);
    
} catch (Exception $e) {
    logError("Create course error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في إنشاء الدورة'
    ], 500);
}

/**
 * معالجة رفع صورة الكورس
 */
function handleCourseImageUpload($file, $courseCode) {
    try {
        // التحقق من نوع الملف
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (!in_array($file['type'], $allowedTypes)) {
            return ['success' => false, 'message' => 'نوع الملف غير مدعوم'];
        }
        
        // التحقق من حجم الملف (10MB كحد أقصى)
        if ($file['size'] > 10 * 1024 * 1024) {
            return ['success' => false, 'message' => 'حجم الملف كبير جداً'];
        }
        
        // إنشاء مجلد الرفع
        $uploadDir = UPLOAD_PATH . 'courses/';
        ensureDirectoryExists($uploadDir);
        
        // تحديد اسم الملف
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = $courseCode . '_' . time() . '.' . $extension;
        $filepath = $uploadDir . $filename;
        
        // رفع الملف
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            // تغيير حجم الصورة للمعاينة
            resizeCourseImage($filepath, 800, 450); // نسبة 16:9
            
            $url = SITE_URL . '/uploads/courses/' . $filename;
            return ['success' => true, 'url' => $url];
        } else {
            return ['success' => false, 'message' => 'خطأ في رفع الملف'];
        }
        
    } catch (Exception $e) {
        logError("Course image upload error: " . $e->getMessage());
        return ['success' => false, 'message' => 'خطأ في معالجة الصورة'];
    }
}

/**
 * تغيير حجم صورة الكورس
 */
function resizeCourseImage($filepath, $maxWidth, $maxHeight) {
    try {
        $imageInfo = getimagesize($filepath);
        if (!$imageInfo) return false;
        
        $width = $imageInfo[0];
        $height = $imageInfo[1];
        $type = $imageInfo[2];
        
        // حساب النسبة الجديدة مع الحفاظ على نسبة العرض إلى الارتفاع
        $ratio = min($maxWidth / $width, $maxHeight / $height);
        $newWidth = (int)($width * $ratio);
        $newHeight = (int)($height * $ratio);
        
        // إنشاء الصورة الجديدة
        $newImage = imagecreatetruecolor($newWidth, $newHeight);
        
        switch ($type) {
            case IMAGETYPE_JPEG:
                $source = imagecreatefromjpeg($filepath);
                break;
            case IMAGETYPE_PNG:
                $source = imagecreatefrompng($filepath);
                imagealphablending($newImage, false);
                imagesavealpha($newImage, true);
                break;
            case IMAGETYPE_GIF:
                $source = imagecreatefromgif($filepath);
                break;
            default:
                return false;
        }
        
        // تغيير الحجم
        imagecopyresampled($newImage, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
        
        // حفظ الصورة الجديدة
        switch ($type) {
            case IMAGETYPE_JPEG:
                imagejpeg($newImage, $filepath, 90);
                break;
            case IMAGETYPE_PNG:
                imagepng($newImage, $filepath);
                break;
            case IMAGETYPE_GIF:
                imagegif($newImage, $filepath);
                break;
        }
        
        // تنظيف الذاكرة
        imagedestroy($source);
        imagedestroy($newImage);
        
        return true;
        
    } catch (Exception $e) {
        logError("Course image resize error: " . $e->getMessage());
        return false;
    }
}
?>