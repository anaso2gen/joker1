<?php
/**
 * API تحديث الكورس (للمسؤولين فقط)
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

if (!in_array($_SERVER['REQUEST_METHOD'], ['PUT', 'POST'])) {
    sendJsonResponse(['success' => false, 'message' => 'طريقة طلب غير صالحة'], 405);
}

try {
    $user = $sessionManager->requireAdmin();
    $db = Database::getInstance()->getConnection();
    
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    
    $courseId = intval($input['id'] ?? $_GET['id'] ?? 0);
    $name = sanitizeInput($input['name'] ?? '');
    $code = sanitizeInput($input['code'] ?? '');
    $description = sanitizeInput($input['description'] ?? '');
    $price = floatval($input['price'] ?? 0);
    $sortOrder = intval($input['sort_order'] ?? 0);
    $isActive = isset($input['is_active']) ? 1 : 0;
    
    $errors = [];
    
    if ($courseId <= 0) {
        sendJsonResponse([
            'success' => false,
            'message' => 'معرف الدورة غير صالح'
        ]);
    }
    
    // التحقق من وجود الكورس
    $stmt = $db->prepare("SELECT * FROM courses WHERE id = ?");
    $stmt->execute([$courseId]);
    $course = $stmt->fetch();
    
    if (!$course) {
        sendJsonResponse([
            'success' => false,
            'message' => 'الدورة غير موجودة'
        ], 404);
    }
    
    // التحقق من صحة البيانات
    if (empty($name)) {
        $errors['name'] = 'اسم الدورة مطلوب';
    }
    
    if (empty($code)) {
        $errors['code'] = 'كود الدورة مطلوب';
    } else {
        // التحقق من عدم تكرار الكود (باستثناء الكورس الحالي)
        $stmt = $db->prepare("SELECT COUNT(*) FROM courses WHERE code = ? AND id != ?");
        $stmt->execute([$code, $courseId]);
        if ($stmt->fetchColumn() > 0) {
            $errors['code'] = 'كود الدورة موجود مسبقاً';
        }
    }
    
    if ($price < 0) {
        $errors['price'] = 'السعر لا يمكن أن يكون سالباً';
    }
    
    if (!empty($errors)) {
        sendJsonResponse([
            'success' => false,
            'message' => 'بيانات غير صالحة',
            'errors' => $errors
        ]);
    }
    
    // معالجة رفع الصورة الجديدة
    $imageUrl = $course['image_url'];
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadResult = handleCourseImageUpload($_FILES['image'], $code);
        if ($uploadResult['success']) {
            $imageUrl = $uploadResult['url'];
            
            // حذف الصورة القديمة
            if ($course['image_url'] && file_exists(str_replace(SITE_URL, BASE_PATH, $course['image_url']))) {
                unlink(str_replace(SITE_URL, BASE_PATH, $course['image_url']));
            }
        } else {
            $errors['image'] = $uploadResult['message'];
            sendJsonResponse([
                'success' => false,
                'message' => 'خطأ في رفع الصورة',
                'errors' => $errors
            ]);
        }
    }
    
    // تحديث الكورس
    $stmt = $db->prepare("
        UPDATE courses 
        SET name = ?, code = ?, description = ?, image_url = ?, price = ?, 
            is_active = ?, sort_order = ?, updated_at = NOW()
        WHERE id = ?
    ");
    
    $stmt->execute([$name, $code, $description, $imageUrl, $price, $isActive, $sortOrder, $courseId]);
    
    // جلب الكورس المحدث
    $stmt = $db->prepare("SELECT * FROM courses WHERE id = ?");
    $stmt->execute([$courseId]);
    $updatedCourse = $stmt->fetch();
    
    sendJsonResponse([
        'success' => true,
        'message' => 'تم تحديث الدورة بنجاح',
        'course' => $updatedCourse
    ]);
    
} catch (Exception $e) {
    logError("Update course error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في تحديث الدورة'
    ], 500);
}

// تضمين دالة رفع الصورة من ملف create.php
require_once __DIR__ . '/create.php';
?>