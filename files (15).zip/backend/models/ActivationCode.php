<?php
/**
 * نموذج كود التفعيل
 * يحتوي على جميع العمليات المتعلقة بأكواد التفعيل
 * 
 * @author anaso2gen
 * @version 2.0
 * @since 2025-05-29
 */

require_once __DIR__ . '/Database.php';

class ActivationCode {
    private $db;
    private $table = 'activation_codes';
    
    // خصائص الكود
    public $id;
    public $code;
    public $code_type;
    public $course_ids;
    public $max_uses;
    public $used_count;
    public $expires_at;
    public $duration_days;
    public $created_by;
    public $notes;
    public $is_active;
    public $created_at;
    public $updated_at;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    /**
     * إنشاء كود جديد
     */
    public function create($data) {
        try {
            $sql = "INSERT INTO {$this->table} 
                    (code, code_type, course_ids, max_uses, expires_at, duration_days, created_by, notes, is_active) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = $this->db->prepare($sql);
            $result = $stmt->execute([
                $data['code'],
                $data['code_type'],
                $data['course_ids'],
                $data['max_uses'],
                $data['expires_at'],
                $data['duration_days'],
                $data['created_by'],
                $data['notes'],
                $data['is_active'] ?? 1
            ]);
            
            if ($result) {
                $this->id = $this->db->lastInsertId();
                return $this->id;
            }
            
            return false;
            
        } catch (PDOException $e) {
            error_log("خطأ في إنشاء كود التفعيل: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * البحث عن كود بالقيمة
     */
    public function findByCode($code) {
        try {
            $sql = "SELECT * FROM {$this->table} WHERE code = ? LIMIT 1";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$code]);
            
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($result) {
                $this->fillFromArray($result);
                return $this;
            }
            
            return null;
            
        } catch (PDOException $e) {
            error_log("خطأ في البحث عن الكود: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * البحث عن كود بالمعرف
     */
    public function findById($id) {
        try {
            $sql = "SELECT * FROM {$this->table} WHERE id = ? LIMIT 1";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$id]);
            
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($result) {
                $this->fillFromArray($result);
                return $this;
            }
            
            return null;
            
        } catch (PDOException $e) {
            error_log("خطأ في البحث عن الكود: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * تحديث عداد الاستخدام
     */
    public function incrementUsage() {
        try {
            $sql = "UPDATE {$this->table} SET used_count = used_count + 1 WHERE id = ?";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([$this->id]);
            
        } catch (PDOException $e) {
            error_log("خطأ في تحديث عداد الاستخدام: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * تحديث حالة الكود
     */
    public function updateStatus($isActive) {
        try {
            $sql = "UPDATE {$this->table} SET is_active = ? WHERE id = ?";
            $stmt = $this->db->prepare($sql);
            $result = $stmt->execute([$isActive ? 1 : 0, $this->id]);
            
            if ($result) {
                $this->is_active = $isActive ? 1 : 0;
            }
            
            return $result;
            
        } catch (PDOException $e) {
            error_log("خطأ في تحديث حالة الكود: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * حذف الكود
     */
    public function delete() {
        try {
            // التحقق من عدم استخدام الكود
            if ($this->used_count > 0) {
                return ['success' => false, 'message' => 'لا يمكن حذف كود مستخدم'];
            }
            
            $sql = "DELETE FROM {$this->table} WHERE id = ?";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([$this->id]);
            
        } catch (PDOException $e) {
            error_log("خطأ في حذف الكود: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * التحقق من صحة الكود للتفعيل
     */
    public function isValidForActivation($userId = null) {
        $errors = [];
        
        // التحقق من نشاط الكود
        if (!$this->is_active) {
            $errors[] = 'الكود غير نشط';
        }
        
        // التحقق من انتهاء الصلاحية
        if ($this->expires_at && strtotime($this->expires_at) < time()) {
            $errors[] = 'انتهت صلاحية الكود';
        }
        
        // التحقق من عدد مرات الاستخدام
        if ($this->used_count >= $this->max_uses) {
            $errors[] = 'تم استنفاد عدد مرات الاستخدام';
        }
        
        // التحقق من استخدام المستخدم للكود سابقاً
        if ($userId && $this->hasUserUsedCode($userId)) {
            $errors[] = 'تم استخدام هذا الكود مسبقاً';
        }
        
        return [
            'valid' => empty($errors),
            'errors' => $errors
        ];
    }
    
    /**
     * التحقق من استخدام المستخدم للكود
     */
    public function hasUserUsedCode($userId) {
        try {
            $sql = "SELECT COUNT(*) FROM code_usage_log 
                    WHERE code_id = ? AND user_id = ? AND status = 'success'";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$this->id, $userId]);
            
            return $stmt->fetchColumn() > 0;
            
        } catch (PDOException $e) {
            error_log("خطأ في التحقق من استخدام الكود: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على الدورات المرتبطة بالكود
     */
    public function getRelatedCourses() {
        try {
            if ($this->code_type === 'all_courses') {
                // إرجاع جميع الدورات النشطة
                $sql = "SELECT id, title, description, image FROM courses WHERE is_active = 1";
                $stmt = $this->db->prepare($sql);
                $stmt->execute();
                return $stmt->fetchAll(PDO::FETCH_ASSOC);
                
            } elseif ($this->course_ids) {
                $courseIds = json_decode($this->course_ids, true);
                
                if (empty($courseIds)) {
                    return [];
                }
                
                $placeholders = str_repeat('?,', count($courseIds) - 1) . '?';
                $sql = "SELECT id, title, description, image FROM courses 
                        WHERE id IN ($placeholders) AND is_active = 1";
                $stmt = $this->db->prepare($sql);
                $stmt->execute($courseIds);
                return $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
            
            return [];
            
        } catch (PDOException $e) {
            error_log("خطأ في الحصول على الدورات: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * الحصول على إحصائيات الكود
     */
    public function getStatistics() {
        try {
            $stats = [
                'total_uses' => $this->used_count,
                'remaining_uses' => $this->max_uses - $this->used_count,
                'usage_percentage' => $this->max_uses > 0 ? round(($this->used_count / $this->max_uses) * 100, 2) : 0
            ];
            
            // إحصائيات الاستخدام
            $sql = "SELECT 
                        COUNT(*) as total_attempts,
                        SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as successful_uses,
                        SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_uses,
                        MIN(used_at) as first_use,
                        MAX(used_at) as last_use
                    FROM code_usage_log 
                    WHERE code_id = ?";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$this->id]);
            $usageStats = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $stats = array_merge($stats, $usageStats);
            
            // أكثر المستخدمين نشاطاً
            $sql = "SELECT u.id, u.first_name, u.last_name, u.email, cul.used_at
                    FROM code_usage_log cul
                    JOIN users u ON cul.user_id = u.id
                    WHERE cul.code_id = ? AND cul.status = 'success'
                    ORDER BY cul.used_at DESC
                    LIMIT 10";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$this->id]);
            $stats['recent_users'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return $stats;
            
        } catch (PDOException $e) {
            error_log("خطأ في الحصول على إحصائيات الكود: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * تحويل البيانات إلى مصفوفة
     */
    public function toArray() {
        return [
            'id' => $this->id,
            'code' => $this->code,
            'code_type' => $this->code_type,
            'course_ids' => $this->course_ids,
            'max_uses' => $this->max_uses,
            'used_count' => $this->used_count,
            'expires_at' => $this->expires_at,
            'duration_days' => $this->duration_days,
            'created_by' => $this->created_by,
            'notes' => $this->notes,
            'is_active' => $this->is_active,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at
        ];
    }
    
    /**
     * ملء الخصائص من مصفوفة
     */
    private function fillFromArray($data) {
        $this->id = $data['id'] ?? null;
        $this->code = $data['code'] ?? null;
        $this->code_type = $data['code_type'] ?? null;
        $this->course_ids = $data['course_ids'] ?? null;
        $this->max_uses = $data['max_uses'] ?? 1;
        $this->used_count = $data['used_count'] ?? 0;
        $this->expires_at = $data['expires_at'] ?? null;
        $this->duration_days = $data['duration_days'] ?? 365;
        $this->created_by = $data['created_by'] ?? null;
        $this->notes = $data['notes'] ?? null;
        $this->is_active = $data['is_active'] ?? 1;
        $this->created_at = $data['created_at'] ?? null;
        $this->updated_at = $data['updated_at'] ?? null;
    }
    
    /**
     * دوال مساعدة ثابتة
     */
    
    /**
     * الحصول على أنواع الأكواد
     */
    public static function getCodeTypes() {
        return [
            'single_course' => 'دورة واحدة',
            'all_courses' => 'جميع الدورات',
            'course_bundle' => 'باقة دورات'
        ];
    }
    
    /**
     * إنشاء كود عشوائي
     */
    public static function generateRandomCode($pattern = 'mixed', $length = 8) {
        switch ($pattern) {
            case 'numbers':
                $chars = '0123456789';
                break;
            case 'letters':
                $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                break;
            case 'mixed':
            default:
                $chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                break;
        }
        
        $code = '';
        for ($i = 0; $i < $length; $i++) {
            $code .= $chars[random_int(0, strlen($chars) - 1)];
        }
        
        return $code;
    }
    
    /**
     * التحقق من تفرد الكود
     */
    public static function isCodeUnique($code) {
        try {
            $db = Database::getInstance()->getConnection();
            $sql = "SELECT COUNT(*) FROM activation_codes WHERE code = ?";
            $stmt = $db->prepare($sql);
            $stmt->execute([$code]);
            
            return $stmt->fetchColumn() == 0;
            
        } catch (PDOException $e) {
            error_log("خطأ في التحقق من تفرد الكود: " . $e->getMessage());
            return false;
        }
    }
}
?>