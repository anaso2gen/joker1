<?php
/**
 * نموذج الدرس
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:56:22
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

require_once __DIR__ . '/BaseModel.php';

class Lesson extends BaseModel {
    protected $table = 'lessons';
    protected $fillable = [
        'name', 'description', 'section_id', 'video_url', 'duration',
        'sort_order', 'is_preview', 'is_active', 'attachments'
    ];
    
    /**
     * الحقول القابلة للبحث
     */
    protected function getSearchableFields() {
        return ['name', 'description'];
    }
    
    /**
     * الحصول على درس مع التقدم
     */
    public function getLessonWithProgress($lessonId, $userId) {
        return $this->query("
            SELECT l.*, s.name as section_name, s.course_id, c.name as course_name,
                   lp.completed, lp.last_position, lp.started_at, lp.completed_at, lp.last_accessed
            FROM lessons l
            JOIN sections s ON l.section_id = s.id
            JOIN courses c ON s.course_id = c.id
            LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = ?
            WHERE l.id = ? AND l.is_active = 1
        ", [$userId, $lessonId]);
    }
    
    /**
     * الحصول على دروس القسم
     */
    public function getSectionLessons($sectionId, $userId = null) {
        $query = "
            SELECT l.*";
        
        if ($userId) {
            $query .= ",
                   lp.completed,
                   lp.last_position,
                   lp.last_accessed";
        }
        
        $query .= "
            FROM lessons l";
        
        if ($userId) {
            $query .= " 
            LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = ?";
        }
        
        $query .= "
            WHERE l.section_id = ? AND l.is_active = 1 
            ORDER BY l.sort_order";
        
        $params = $userId ? [$userId, $sectionId] : [$sectionId];
        
        return $this->query($query, $params);
    }
    
    /**
     * الحصول على دروس الدورة للتنقل
     */
    public function getCourseNavigation($courseId) {
        return $this->query("
            SELECT l.id, l.name, l.sort_order, s.sort_order as section_sort,
                   s.name as section_name
            FROM lessons l
            JOIN sections s ON l.section_id = s.id
            WHERE s.course_id = ? AND l.is_active = 1
            ORDER BY s.sort_order, l.sort_order
        ", [$courseId]);
    }
    
    /**
     * العثور على الدرس التالي/السابق
     */
    public function getNavigationLessons($lessonId, $courseId) {
        $allLessons = $this->getCourseNavigation($courseId);
        $currentIndex = array_search($lessonId, array_column($allLessons, 'id'));
        
        return [
            'previous' => $currentIndex > 0 ? $allLessons[$currentIndex - 1] : null,
            'next' => $currentIndex < count($allLessons) - 1 ? $allLessons[$currentIndex + 1] : null
        ];
    }
    
    /**
     * تحديث تقدم الدرس
     */
    public function updateProgress($userId, $lessonId, $position, $completed = false) {
        // البحث عن تقدم موجود
        $existing = $this->query("
            SELECT id FROM lesson_progress 
            WHERE lesson_id = ? AND user_id = ?
        ", [$lessonId, $userId]);
        
        if ($existing) {
            // تحديث التقدم الموجود
            $updateSql = "
                UPDATE lesson_progress 
                SET last_position = ?, last_accessed = NOW()";
            
            $params = [$position, $userId, $lessonId];
            
            if ($completed) {
                $updateSql .= ", completed = 1, completed_at = NOW()";
            }
            
            $updateSql .= " WHERE user_id = ? AND lesson_id = ?";
            
            return $this->query($updateSql, $params);
        } else {
            // إنشاء تقدم جديد
            return $this->query("
                INSERT INTO lesson_progress (user_id, lesson_id, last_position, completed, started_at, completed_at, last_accessed)
                VALUES (?, ?, ?, ?, NOW(), " . ($completed ? "NOW()" : "NULL") . ", NOW())
            ", [$userId, $lessonId, $position, $completed ? 1 : 0]);
        }
    }
    
    /**
     * تحديد الدرس كمكتمل
     */
    public function markAsCompleted($userId, $lessonId) {
        return $this->updateProgress($userId, $lessonId, 0, true);
    }
    
    /**
     * تحديد الدرس كمبدوء
     */
    public function markAsStarted($userId, $lessonId) {
        $existing = $this->query("
            SELECT id FROM lesson_progress 
            WHERE lesson_id = ? AND user_id = ?
        ", [$lessonId, $userId]);
        
        if (!$existing) {
            return $this->query("
                INSERT INTO lesson_progress (user_id, lesson_id, started_at, last_accessed)
                VALUES (?, ?, NOW(), NOW())
            ", [$userId, $lessonId]);
        } else {
            return $this->query("
                UPDATE lesson_progress 
                SET last_accessed = NOW() 
                WHERE user_id = ? AND lesson_id = ?
            ", [$userId, $lessonId]);
        }
    }
    
    /**
     * الحصول على ملاحظات الدرس
     */
    public function getLessonNotes($lessonId, $userId) {
        return $this->query("
            SELECT * FROM lesson_notes 
            WHERE lesson_id = ? AND user_id = ?
            ORDER BY timestamp ASC
        ", [$lessonId, $userId]);
    }
    
    /**
     * إضافة ملاحظة
     */
    public function addNote($userId, $lessonId, $content, $timestamp = 0) {
        return $this->query("
            INSERT INTO lesson_notes (user_id, lesson_id, content, timestamp, created_at)
            VALUES (?, ?, ?, ?, NOW())
        ", [$userId, $lessonId, $content, $timestamp]);
    }
    
    /**
     * حذف ملاحظة
     */
    public function deleteNote($noteId, $userId) {
        return $this->query("
            DELETE FROM lesson_notes 
            WHERE id = ? AND user_id = ?
        ", [$noteId, $userId]);
    }
    
    /**
     * فحص صلاحية الوصول للدرس
     */
    public function hasAccess($lessonId, $userId) {
        $result = $this->query("
            SELECT COUNT(*) as count
            FROM lessons l
            JOIN sections s ON l.section_id = s.id
            JOIN subscriptions sub ON s.course_id = sub.course_id
            WHERE l.id = ? AND sub.user_id = ? AND sub.is_active = 1
        ", [$lessonId, $userId]);
        
        return $result[0]['count'] > 0;
    }
    
    /**
     * فحص إذا كان الدرس معاينة مجانية
     */
    public function isPreview($lessonId) {
        $result = $this->query("
            SELECT is_preview FROM lessons WHERE id = ?
        ", [$lessonId]);
        
        return $result && $result[0]['is_preview'] == 1;
    }
    
    /**
     * إحصائيات الدرس
     */
    public function getLessonStats($lessonId) {
        return $this->query("
            SELECT 
                COUNT(DISTINCT lp.user_id) as total_viewers,
                COUNT(CASE WHEN lp.completed = 1 THEN 1 END) as completed_count,
                AVG(lp.last_position) as avg_watch_time,
                MAX(lp.last_position) as max_watch_time
            FROM lesson_progress lp
            WHERE lp.lesson_id = ?
        ", [$lessonId]);
    }
    
    /**
     * الحصول على الدروس الأكثر مشاهدة
     */
    public function getMostWatchedLessons($limit = 10) {
        return $this->query("
            SELECT l.*, c.name as course_name,
                   COUNT(DISTINCT lp.user_id) as viewers_count,
                   AVG(lp.last_position) as avg_watch_time
            FROM lessons l
            JOIN sections s ON l.section_id = s.id
            JOIN courses c ON s.course_id = c.id
            LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id
            WHERE l.is_active = 1
            GROUP BY l.id
            ORDER BY viewers_count DESC
            LIMIT ?
        ", [$limit]);
    }
    
    /**
     * ترقيم الدروس تلقائياً
     */
    public function reorderLessons($sectionId) {
        $lessons = $this->query("
            SELECT id FROM lessons 
            WHERE section_id = ? AND is_active = 1 
            ORDER BY sort_order, created_at
        ", [$sectionId]);
        
        foreach ($lessons as $index => $lesson) {
            $this->update($lesson['id'], ['sort_order' => $index + 1]);
        }
        
        return true;
    }
    
    /**
     * نسخ درس
     */
    public function duplicateLesson($lessonId, $newSectionId = null) {
        $lesson = $this->find($lessonId);
        if (!$lesson) {
            return false;
        }
        
        unset($lesson['id']);
        $lesson['name'] = $lesson['name'] . ' - نسخة';
        
        if ($newSectionId) {
            $lesson['section_id'] = $newSectionId;
        }
        
        // تحديد الترتيب
        $maxOrder = $this->query("
            SELECT COALESCE(MAX(sort_order), 0) + 1 as next_order
            FROM lessons WHERE section_id = ?
        ", [$lesson['section_id']]);
        
        $lesson['sort_order'] = $maxOrder[0]['next_order'];
        
        return $this->create($lesson);
    }
    
    /**
     * حذف جميع دروس القسم
     */
    public function deleteSectionLessons($sectionId) {
        return $this->transaction(function() use ($sectionId) {
            // حذف التقدم والملاحظات أولاً
            $this->query("DELETE FROM lesson_notes WHERE lesson_id IN (SELECT id FROM lessons WHERE section_id = ?)", [$sectionId]);
            $this->query("DELETE FROM lesson_progress WHERE lesson_id IN (SELECT id FROM lessons WHERE section_id = ?)", [$sectionId]);
            
            // حذف الدروس
            return $this->query("DELETE FROM lessons WHERE section_id = ?", [$sectionId]);
        });
    }
}
?>