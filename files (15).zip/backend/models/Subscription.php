<?php
/**
 * نموذج الاشتراك
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:56:22
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

require_once __DIR__ . '/BaseModel.php';

class Subscription extends BaseModel {
    protected $table = 'subscriptions';
    protected $fillable = [
        'user_id', 'course_id', 'price_paid', 'subscription_code',
        'payment_method', 'payment_id', 'is_active'
    ];
    
    /**
     * إنشاء اشتراك جديد
     */
    public function createSubscription($userId, $courseId, $pricePaid = 0, $paymentData = []) {
        $subscriptionData = [
            'user_id' => $userId,
            'course_id' => $courseId,
            'price_paid' => $pricePaid,
            'payment_method' => $paymentData['method'] ?? null,
            'payment_id' => $paymentData['id'] ?? null,
            'subscription_code' => $paymentData['code'] ?? null,
            'is_active' => 1
        ];
        
        return $this->create($subscriptionData);
    }
    
    /**
     * فحص اشتراك المستخدم
     */
    public function isUserSubscribed($userId, $courseId) {
        $result = $this->query("
            SELECT COUNT(*) as count FROM subscriptions 
            WHERE user_id = ? AND course_id = ? AND is_active = 1
        ", [$userId, $courseId]);
        
        return $result[0]['count'] > 0;
    }
    
    /**
     * الحصول على اشتراكات المستخدم
     */
    public function getUserSubscriptions($userId, $activeOnly = true) {
        $activeCondition = $activeOnly ? 'AND s.is_active = 1' : '';
        
        return $this->query("
            SELECT s.*, c.name as course_name, c.image_url, c.description,
                   COUNT(DISTINCT l.id) as total_lessons,
                   COUNT(DISTINCT CASE WHEN lp.completed = 1 THEN lp.lesson_id END) as completed_lessons,
                   ROUND((COUNT(DISTINCT CASE WHEN lp.completed = 1 THEN lp.lesson_id END) / COUNT(DISTINCT l.id)) * 100, 2) as progress_percentage
            FROM subscriptions s
            JOIN courses c ON s.course_id = c.id
            LEFT JOIN sections sec ON c.id = sec.course_id
            LEFT JOIN lessons l ON sec.id = l.section_id AND l.is_active = 1
            LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = s.user_id
            WHERE s.user_id = ? $activeCondition
            GROUP BY s.id
            ORDER BY s.created_at DESC
        ", [$userId]);
    }
    
    /**
     * الحصول على مشتركي الدورة
     */
    public function getCourseSubscribers($courseId, $activeOnly = true) {
        $activeCondition = $activeOnly ? 'AND s.is_active = 1' : '';
        
        return $this->query("
            SELECT s.*, u.first_name, u.last_name, u.email, u.avatar_url
            FROM subscriptions s
            JOIN users u ON s.user_id = u.id
            WHERE s.course_id = ? $activeCondition
            ORDER BY s.created_at DESC
        ", [$courseId]);
    }
    
    /**
     * إلغاء اشتراك
     */
    public function cancelSubscription($subscriptionId, $reason = null) {
        return $this->update($subscriptionId, [
            'is_active' => 0,
            'cancelled_at' => date('Y-m-d H:i:s'),
            'cancellation_reason' => $reason
        ]);
    }
    
    /**
     * إعادة تفعيل اشتراك
     */
    public function reactivateSubscription($subscriptionId) {
        return $this->update($subscriptionId, [
            'is_active' => 1,
            'cancelled_at' => null,
            'cancellation_reason' => null
        ]);
    }
    
    /**
     * إحصائيات الاشتراكات
     */
    public function getSubscriptionStats($dateFrom = null, $dateTo = null) {
        $dateCondition = '';
        $params = [];
        
        if ($dateFrom && $dateTo) {
            $dateCondition = 'WHERE created_at BETWEEN ? AND ?';
            $params = [$dateFrom, $dateTo];
        }
        
        return $this->query("
            SELECT 
                COUNT(*) as total_subscriptions,
                COUNT(CASE WHEN is_active = 1 THEN 1 END) as active_subscriptions,
                SUM(price_paid) as total_revenue,
                AVG(price_paid) as avg_price,
                COUNT(DISTINCT user_id) as unique_subscribers,
                COUNT(DISTINCT course_id) as courses_with_subscribers
            FROM subscriptions
            $dateCondition
        ", $params);
    }
    
    /**
     * أفضل الدورات من ناحية الاشتراكات
     */
    public function getTopCoursesBySubscriptions($limit = 10) {
        return $this->query("
            SELECT c.id, c.name, c.image_url,
                   COUNT(s.id) as subscription_count,
                   SUM(s.price_paid) as total_revenue,
                   AVG(s.price_paid) as avg_price
            FROM subscriptions s
            JOIN courses c ON s.course_id = c.id
            WHERE s.is_active = 1
            GROUP BY c.id
            ORDER BY subscription_count DESC
            LIMIT ?
        ", [$limit]);
    }
    
    /**
     * الإيرادات الشهرية
     */
    public function getMonthlyRevenue($months = 12) {
        return $this->query("
            SELECT 
                DATE_FORMAT(created_at, '%Y-%m') as month,
                COUNT(*) as subscriptions_count,
                SUM(price_paid) as revenue,
                AVG(price_paid) as avg_price
            FROM subscriptions
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? MONTH)
            GROUP BY DATE_FORMAT(created_at, '%Y-%m')
            ORDER BY month ASC
        ", [$months]);
    }
    
    /**
     * الاشتراكات اليومية
     */
    public function getDailySubscriptions($days = 30) {
        return $this->query("
            SELECT 
                DATE(created_at) as date,
                COUNT(*) as subscriptions_count,
                SUM(price_paid) as revenue
            FROM subscriptions
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
            GROUP BY DATE(created_at)
            ORDER BY date ASC
        ", [$days]);
    }
    
    /**
     * البحث في الاشتراكات
     */
    public function searchSubscriptions($filters = [], $pagination = []) {
        $query = "
            SELECT s.*, c.name as course_name, u.first_name, u.last_name, u.email
            FROM subscriptions s
            JOIN courses c ON s.course_id = c.id
            JOIN users u ON s.user_id = u.id
            WHERE 1=1
        ";
        
        $params = [];
        
        if (isset($filters['user_email']) && !empty($filters['user_email'])) {
            $query .= " AND u.email LIKE ?";
            $params[] = '%' . $filters['user_email'] . '%';
        }
        
        if (isset($filters['course_name']) && !empty($filters['course_name'])) {
            $query .= " AND c.name LIKE ?";
            $params[] = '%' . $filters['course_name'] . '%';
        }
        
        if (isset($filters['is_active']) && $filters['is_active'] !== '') {
            $query .= " AND s.is_active = ?";
            $params[] = $filters['is_active'];
        }
        
        if (isset($filters['date_from']) && !empty($filters['date_from'])) {
            $query .= " AND DATE(s.created_at) >= ?";
            $params[] = $filters['date_from'];
        }
        
        if (isset($filters['date_to']) && !empty($filters['date_to'])) {
            $query .= " AND DATE(s.created_at) <= ?";
            $params[] = $filters['date_to'];
        }
        
        // حساب العدد الإجمالي
        $countQuery = str_replace("SELECT s.*, c.name as course_name, u.first_name, u.last_name, u.email", "SELECT COUNT(*)", $query);
        $countStmt = $this->pdo->prepare($countQuery);
        $countStmt->execute($params);
        $total = $countStmt->fetchColumn();
        
        // تطبيق الترتيب والتصفح
        $query .= " ORDER BY s.created_at DESC";
        
        if (isset($pagination['page']) && isset($pagination['per_page'])) {
            $page = max(1, intval($pagination['page']));
            $perPage = max(1, intval($pagination['per_page']));
            $offset = ($page - 1) * $perPage;
            
            $query .= " LIMIT $perPage OFFSET $offset";
        }
        
        $stmt = $this->pdo->prepare($query);
        $stmt->execute($params);
        $results = $stmt->fetchAll();
        
        return [
            'data' => $results,
            'pagination' => [
                'total' => $total,
                'page' => $pagination['page'] ?? 1,
                'per_page' => $pagination['per_page'] ?? 10,
                'total_pages' => isset($pagination['per_page']) ? ceil($total / $pagination['per_page']) : 1
            ]
        ];
    }
}
?>