<?php
/**
 * API حذف المستخدم (للمسؤولين فقط)
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

// التأكد من أن الطلب DELETE
if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    sendJsonResponse(['success' => false, 'message' => 'طريقة طلب غير صالحة'], 405);
}

try {
    $user = $sessionManager->requireAdmin();
    $db = Database::getInstance()->getConnection();
    
    $input = json_decode(file_get_contents('php://input'), true);
    $targetUserId = sanitizeInput($input['user_id'] ?? '');
    
    if (empty($targetUserId)) {
        sendJsonResponse([
            'success' => false,
            'message' => 'معرف المستخدم مطلوب'
        ]);
    }
    
    // التأكد من أن المستخدم لا يحذف نفسه
    if ($targetUserId === $user['user_id']) {
        sendJsonResponse([
            'success' => false,
            'message' => 'لا يمكنك حذف حسابك الخاص'
        ]);
    }
    
    // التحقق من وجود المستخدم
    $stmt = $db->prepare("SELECT id, email, is_admin FROM users WHERE user_id = ?");
    $stmt->execute([$targetUserId]);
    $targetUser = $stmt->fetch();
    
    if (!$targetUser) {
        sendJsonResponse([
            'success' => false,
            'message' => 'المستخدم غير موجود'
        ], 404);
    }
    
    // منع حذف المسؤولين الآخرين (اختياري)
    if ($targetUser['is_admin']) {
        sendJsonResponse([
            'success' => false,
            'message' => 'لا يمكن حذف حساب مسؤول آخر'
        ]);
    }
    
    $db->beginTransaction();
    
    try {
        // حذف الجلسات
        $stmt = $db->prepare("DELETE FROM sessions WHERE user_id = ?");
        $stmt->execute([$targetUserId]);
        
        // حذف تقدم الدروس
        $stmt = $db->prepare("DELETE FROM lesson_progress WHERE user_id = ?");
        $stmt->execute([$targetUserId]);
        
        // حذف الاشتراكات
        $stmt = $db->prepare("DELETE FROM subscriptions WHERE user_id = ?");
        $stmt->execute([$targetUserId]);
        
        // حذف المستخدم
        $stmt = $db->prepare("DELETE FROM users WHERE user_id = ?");
        $stmt->execute([$targetUserId]);
        
        $db->commit();
        
        logError("User deleted by admin", [
            'admin_id' => $user['user_id'],
            'deleted_user_email' => $targetUser['email']
        ]);
        
        sendJsonResponse([
            'success' => true,
            'message' => 'تم حذف المستخدم بنجاح'
        ]);
        
    } catch (Exception $e) {
        $db->rollback();
        throw $e;
    }
    
} catch (Exception $e) {
    logError("Delete user error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في حذف المستخدم'
    ], 500);
}
?>