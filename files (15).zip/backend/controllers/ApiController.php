<?php
/**
 * تحكم API الرئيسي - توجيه الطلبات
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:47:59
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/AuthController.php';
require_once __DIR__ . '/UserController.php';
require_once __DIR__ . '/CourseController.php';
require_once __DIR__ . '/LessonController.php';
require_once __DIR__ . '/AdminController.php';

class ApiController extends BaseController {
    
    private $controllers = [];
    
    public function __construct() {
        parent::__construct();
        
        // تهيئة المتحكمات
        $this->controllers = [
            'auth' => new AuthController(),
            'user' => new UserController(),
            'course' => new CourseController(),
            'lesson' => new LessonController(),
            'admin' => new AdminController()
        ];
    }
    
    /**
     * توجيه الطلبات حسب العمل المطلوب
     */
    public function handleRequest() {
        try {
            $action = $_GET['action'] ?? $_POST['action'] ?? '';
            
            if (empty($action)) {
                $this->sendError('Action parameter is required', 400);
            }
            
            // تسجيل API call
            $this->logApiCall($action);
            
            // توجيه الطلب للمتحكم المناسب
            switch ($action) {
                // Auth actions
                case 'login':
                    $this->controllers['auth']->login();
                    break;
                case 'register':
                    $this->controllers['auth']->register();
                    break;
                case 'verify_email':
                    $this->controllers['auth']->verifyEmail();
                    break;
                case 'forgot_password':
                    $this->controllers['auth']->forgotPassword();
                    break;
                case 'reset_password':
                    $this->controllers['auth']->resetPassword();
                    break;
                case 'logout':
                    $this->controllers['auth']->logout();
                    break;
                
                // User actions
                case 'get_current_user':
                    $this->controllers['user']->getCurrentUser();
                    break;
                case 'update_profile':
                    $this->controllers['user']->updateProfile();
                    break;
                case 'change_password':
                    $this->controllers['user']->changePassword();
                    break;
                case 'upload_avatar':
                    $this->controllers['user']->uploadAvatar();
                    break;
                case 'get_user_courses':
                    $this->controllers['user']->getUserCourses();
                    break;
                case 'get_user_progress':
                    $this->controllers['user']->getUserProgress();
                    break;
                case 'get_recent_activity':
                    $this->controllers['user']->getRecentActivity();
                    break;
                case 'get_certificates':
                    $this->controllers['user']->getCertificates();
                    break;
                case 'toggle_wishlist':
                    $this->controllers['user']->toggleWishlist();
                    break;
                case 'get_wishlist':
                    $this->controllers['user']->getWishlist();
                    break;
                
                // Course actions
                case 'get_courses':
                    $this->controllers['course']->getAllCourses();
                    break;
                case 'get_course':
                    $this->controllers['course']->getCourse();
                    break;
                case 'create_course':
                    $this->controllers['course']->createCourse();
                    break;
                case 'update_course':
                    $this->controllers['course']->updateCourse();
                    break;
                case 'delete_course':
                    $this->controllers['course']->deleteCourse();
                    break;
                case 'subscribe_course':
                    $this->controllers['course']->subscribeToCourse();
                    break;
                case 'add_review':
                    $this->controllers['course']->addReview();
                    break;
                case 'get_course_preview':
                    $this->controllers['course']->getCoursePreview();
                    break;
                
                // Lesson actions
                case 'get_lesson':
                    $this->controllers['lesson']->getLesson();
                    break;
                case 'update_progress':
                    $this->controllers['lesson']->updateProgress();
                    break;
                case 'add_note':
                    $this->controllers['lesson']->addNote();
                    break;
                case 'get_notes':
                    $this->controllers['lesson']->getNotes();
                    break;
                case 'delete_note':
                    $this->controllers['lesson']->deleteNote();
                    break;
                case 'create_lesson':
                    $this->controllers['lesson']->createLesson();
                    break;
                case 'update_lesson':
                    $this->controllers['lesson']->updateLesson();
                    break;
                case 'delete_lesson':
                    $this->controllers['lesson']->deleteLesson();
                    break;
                
                // Admin actions
                case 'get_dashboard_stats':
                    $this->controllers['admin']->getDashboardStats();
                    break;
                case 'get_users':
                    $this->controllers['admin']->getUsers();
                    break;
                case 'update_user_status':
                    $this->controllers['admin']->updateUserStatus();
                    break;
                case 'delete_user':
                    $this->controllers['admin']->deleteUser();
                    break;
                case 'get_sections':
                    $this->controllers['admin']->getSections();
                    break;
                case 'create_section':
                    $this->controllers['admin']->createSection();
                    break;
                case 'update_section':
                    $this->controllers['admin']->updateSection();
                    break;
                case 'delete_section':
                    $this->controllers['admin']->deleteSection();
                    break;
                case 'get_reviews':
                    $this->controllers['admin']->getReviews();
                    break;
                case 'update_review_status':
                    $this->controllers['admin']->updateReviewStatus();
                    break;
                case 'get_activity_logs':
                    $this->controllers['admin']->getActivityLogs();
                    break;
                case 'create_backup':
                    $this->controllers['admin']->createBackup();
                    break;
                case 'download_backup':
                    $this->controllers['admin']->downloadBackup();
                    break;
                
                // Additional actions
                case 'activate_subscription':
                    $this->activateSubscription();
                    break;
                case 'get_notifications':
                    $this->getNotifications();
                    break;
                case 'mark_notification_read':
                    $this->markNotificationRead();
                    break;
                case 'download_certificate':
                    $this->downloadCertificate();
                    break;
                case 'view_certificate':
                    $this->viewCertificate();
                    break;
                case 'upload_file':
                    $this->uploadFile();
                    break;
                
                default:
                    $this->sendError('Unknown action: ' . $action, 400);
            }
            
        } catch (Exception $e) {
            $this->logSecurityEvent('API error', 'high', [
                'action' => $action ?? 'unknown',
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            $this->sendError('Internal server error', 500);
        }
    }
    
    /**
     * تفعيل اشتراك بكود
     */
    private function activateSubscription() {
        $this->requireAuth();
        
        try {
            $data = $this->getInputData();
            $code = strtoupper(trim($data['code'] ?? ''));
            
            if (empty($code)) {
                $this->sendError('كود التفعيل مطلوب');
            }
            
            // البحث عن الكود
            $stmt = $this->pdo->prepare("
                SELECT sc.*, c.name as course_name, c.price
                FROM subscription_codes sc
                JOIN courses c ON sc.course_id = c.id
                WHERE sc.code = ? AND sc.is_active = 1 AND sc.used_by IS NULL
                AND (sc.expires_at IS NULL OR sc.expires_at > NOW())
            ");
            $stmt->execute([$code]);
            $subscriptionCode = $stmt->fetch();
            
            if (!$subscriptionCode) {
                $this->sendError('كود التفعيل غير صحيح أو منتهي الصلاحية');
            }
            
            // فحص الاشتراك المسبق
            $stmt = $this->pdo->prepare("
                SELECT id FROM subscriptions 
                WHERE user_id = ? AND course_id = ? AND is_active = 1
            ");
            $stmt->execute([$this->user['id'], $subscriptionCode['course_id']]);
            
            if ($stmt->fetch()) {
                $this->sendError('أنت مشترك بالفعل في هذه الدورة');
            }
            
            $this->transaction(function($pdo) use ($subscriptionCode, $code) {
                // تحديث الكود كمستخدم
                $stmt = $pdo->prepare("
                    UPDATE subscription_codes 
                    SET used_by = ?, used_at = NOW()
                    WHERE code = ?
                ");
                $stmt->execute([$this->user['id'], $code]);
                
                // إنشاء اشتراك
                $stmt = $pdo->prepare("
                    INSERT INTO subscriptions (user_id, course_id, price_paid, subscription_code, is_active, created_at)
                    VALUES (?, ?, 0, ?, 1, NOW())
                ");
                $stmt->execute([
                    $this->user['id'],
                    $subscriptionCode['course_id'],
                    $code
                ]);
            });
            
            $this->logActivity('Subscription activated with code', 'subscription', [
                'course_id' => $subscriptionCode['course_id'],
                'code' => $code
            ]);
            
            $this->sendSuccess([
                'course_id' => $subscriptionCode['course_id'],
                'course_name' => $subscriptionCode['course_name']
            ], 'تم تفعيل الاشتراك بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to activate subscription', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تفعيل الاشتراك');
        }
    }
    
    /**
     * الحصول على الإشعارات
     */
    private function getNotifications() {
        $this->requireAuth();
        
        try {
            $stmt = $this->pdo->prepare("
                SELECT * FROM notifications 
                WHERE user_id = ?
                ORDER BY created_at DESC
                LIMIT 20
            ");
            $stmt->execute([$this->user['id']]);
            $notifications = $stmt->fetchAll();
            
            $this->sendSuccess(['notifications' => $notifications]);
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to get notifications', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحميل الإشعارات');
        }
    }
    
    /**
     * تحديد إشعار كمقروء
     */
    private function markNotificationRead() {
        $this->requireAuth();
        
        try {
            $data = $this->getInputData();
            $notificationId = intval($data['notification_id'] ?? 0);
            
            if (!$notificationId) {
                $this->sendError('معرف الإشعار مطلوب');
            }
            
            $stmt = $this->pdo->prepare("
                UPDATE notifications 
                SET is_read = 1, read_at = NOW()
                WHERE id = ? AND user_id = ?
            ");
            $stmt->execute([$notificationId, $this->user['id']]);
            
            $this->sendSuccess(null, 'تم تحديد الإشعار كمقروء');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to mark notification read', 'low', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحديث الإشعار');
        }
    }
    
    /**
     * تحميل الشهادة
     */
    private function downloadCertificate() {
        $this->requireAuth();
        
        try {
            $courseId = intval($_GET['course_id'] ?? 0);
            
            if (!$courseId) {
                $this->sendError('معرف الدورة مطلوب');
            }
            
            // التحقق من إكمال الدورة
            $stmt = $this->pdo->prepare("
                SELECT cc.*, c.name as course_name, u.first_name, u.last_name
                FROM course_completions cc
                JOIN courses c ON cc.course_id = c.id
                JOIN users u ON cc.user_id = u.id
                WHERE cc.user_id = ? AND cc.course_id = ?
            ");
            $stmt->execute([$this->user['id'], $courseId]);
            $completion = $stmt->fetch();
            
            if (!$completion) {
                $this->sendError('لم تكمل هذه الدورة بعد', 404);
            }
            
            // إنشاء PDF الشهادة
            $certificatePath = $this->generateCertificatePDF($completion);
            
            $this->logActivity('Certificate downloaded', 'certificate', ['course_id' => $courseId]);
            
            // تحميل الملف
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="certificate_' . $courseId . '.pdf"');
            header('Content-Length: ' . filesize($certificatePath));
            
            readfile($certificatePath);
            unlink($certificatePath); // حذف الملف المؤقت
            exit;
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to download certificate', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحميل الشهادة');
        }
    }
    
    /**
     * عرض الشهادة
     */
    private function viewCertificate() {
        $this->requireAuth();
        
        try {
            $courseId = intval($_GET['course_id'] ?? 0);
            
            // نفس منطق تحميل الشهادة لكن بدون تحميل
            $stmt = $this->pdo->prepare("
                SELECT cc.*, c.name as course_name, u.first_name, u.last_name
                FROM course_completions cc
                JOIN courses c ON cc.course_id = c.id
                JOIN users u ON cc.user_id = u.id
                WHERE cc.user_id = ? AND cc.course_id = ?
            ");
            $stmt->execute([$this->user['id'], $courseId]);
            $completion = $stmt->fetch();
            
            if (!$completion) {
                $this->sendError('لم تكمل هذه الدورة بعد', 404);
            }
            
            $certificateHtml = $this->generateCertificateHTML($completion);
            
            $this->sendSuccess(['certificate_html' => $certificateHtml]);
            
        } catch (Exception $e) {
            $this->sendError('فشل في عرض الشهادة');
        }
    }
    
    /**
     * رفع ملف عام
     */
    private function uploadFile() {
        $this->requireAuth();
        
        try {
            $this->validateCSRF();
            
            $fileType = $_POST['file_type'] ?? 'general';
            $allowedTypes = ['avatar', 'course_image', 'lesson_video', 'general'];
            
            if (!in_array($fileType, $allowedTypes)) {
                $this->sendError('نوع الملف غير مدعوم');
            }
            
            if (!isset($_FILES['file'])) {
                $this->sendError('لم يتم رفع أي ملف');
            }
            
            $uploadDir = __DIR__ . '/../../uploads/' . $fileType;
            $fileName = $this->handleFileUpload($_FILES['file'], $uploadDir);
            
            $fileUrl = 'uploads/' . $fileType . '/' . $fileName;
            
            $this->logActivity('File uploaded', 'file_upload', [
                'file_type' => $fileType,
                'file_name' => $fileName
            ]);
            
            $this->sendSuccess([
                'file_url' => $fileUrl,
                'file_name' => $fileName
            ], 'تم رفع الملف بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to upload file', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في رفع الملف: ' . $e->getMessage());
        }
    }
    
    // Helper Methods
    
    private function logApiCall($action) {
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO api_logs (action, user_id, ip_address, user_agent, request_data, created_at)
                VALUES (?, ?, ?, ?, ?, NOW())
            ");
            
            $requestData = json_encode([
                'get' => $_GET,
                'post' => $_POST,
                'method' => $_SERVER['REQUEST_METHOD']
            ]);
            
            $stmt->execute([
                $action,
                $this->user['id'] ?? null,
                getRealIpAddress(),
                $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
                $requestData
            ]);
        } catch (Exception $e) {
            // تجاهل أخطاء تسجيل API
        }
    }
    
    private function generateCertificatePDF($completion) {
        // يمكن استخدام مكتبة مثل TCPDF لإنشاء PDF
        // هنا مثال مبسط
        $html = $this->generateCertificateHTML($completion);
        
        // تحويل HTML إلى PDF (يحتاج مكتبة خارجية)
        $tempFile = tempnam(sys_get_temp_dir(), 'certificate_') . '.pdf';
        
        // كود إنشاء PDF هنا
        
        return $tempFile;
    }
    
    private function generateCertificateHTML($completion) {
        $template = "
        <div style='text-align: center; padding: 50px; font-family: Arial, sans-serif; direction: rtl;'>
            <h1 style='color: #667eea; font-size: 2.5em; margin-bottom: 30px;'>شهادة إتمام</h1>
            <h2 style='color: #333; margin-bottom: 40px;'>منصة " . SITE_NAME . " التعليمية</h2>
            
            <p style='font-size: 1.2em; margin-bottom: 30px;'>
                نشهد بأن
            </p>
            
            <h3 style='color: #667eea; font-size: 2em; margin: 30px 0; padding: 20px; border: 2px solid #667eea;'>
                {$completion['first_name']} {$completion['last_name']}
            </h3>
            
            <p style='font-size: 1.2em; margin-bottom: 30px;'>
                قد أتم بنجاح دورة
            </p>
            
            <h4 style='color: #333; font-size: 1.5em; margin: 30px 0;'>
                {$completion['course_name']}
            </h4>
            
            <p style='margin-top: 50px; color: #666;'>
                تاريخ الإتمام: " . formatArabicDate($completion['completed_at']) . "
            </p>
            
            <p style='margin-top: 20px; color: #666;'>
                رقم الشهادة: {$completion['certificate_code']}
            </p>
            
            <div style='margin-top: 50px; border-top: 1px solid #ccc; padding-top: 20px;'>
                <p style='color: #999; font-size: 0.9em;'>
                    يمكنك التحقق من صحة هذه الشهادة على موقعنا
                </p>
            </div>
        </div>
        ";
        
        return $template;
    }
}
?>