<?php
/**
 * تحكم المصادقة وإدارة الجلسات
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:44:27
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

require_once __DIR__ . '/BaseController.php';

class AuthController extends BaseController {
    
    /**
     * تسجيل الدخول
     */
    public function login() {
        try {
            $this->validateCSRF();
            
            $data = $this->getInputData();
            
            $errors = $this->validate($data, [
                'email' => 'required|email',
                'password' => 'required'
            ]);
            
            if (!empty($errors)) {
                $this->sendError('البيانات المدخلة غير صحيحة', 400, $errors);
            }
            
            $email = strtolower(trim($data['email']));
            $password = $data['password'];
            $rememberMe = boolval($data['remember_me'] ?? false);
            
            // فحص محاولات تسجيل الدخول المتكررة
            $this->checkLoginAttempts($email);
            
            // البحث عن المستخدم
            $stmt = $this->pdo->prepare("
                SELECT id, first_name, last_name, email, password_hash, is_admin, is_active, email_verified
                FROM users 
                WHERE email = ?
            ");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if (!$user || !password_verify($password, $user['password_hash'])) {
                $this->recordFailedAttempt($email);
                $this->logSecurityEvent('Failed login attempt', 'medium', ['email' => $email]);
                $this->sendError('البريد الإلكتروني أو كلمة المرور غير صحيحة');
            }
            
            if (!$user['is_active']) {
                $this->logSecurityEvent('Login attempt for inactive account', 'high', ['email' => $email]);
                $this->sendError('هذا الحساب غير نشط، يرجى التواصل مع الإدارة');
            }
            
            if (!$user['email_verified']) {
                $this->sendError('يرجى تفعيل بريدك الإلكتروني أولاً', 400, [
                    'needs_verification' => true,
                    'user_id' => $user['id']
                ]);
            }
            
            // تنظيف محاولات تسجيل الدخول الفاشلة
            $this->clearFailedAttempts($email);
            
            // إنشاء الجلسة
            $sessionData = $this->createUserSession($user, $rememberMe);
            
            // تحديث آخر تسجيل دخول
            $this->updateLastLogin($user['id']);
            
            $this->logActivity('User logged in', 'auth', ['user_id' => $user['id']]);
            $this->logSecurityEvent('Successful login', 'low', ['email' => $email]);
            
            $this->sendSuccess([
                'user' => [
                    'id' => $user['id'],
                    'first_name' => $user['first_name'],
                    'last_name' => $user['last_name'],
                    'email' => $user['email'],
                    'is_admin' => $user['is_admin']
                ],
                'session' => $sessionData,
                'redirect' => $user['is_admin'] ? 'editdash.php' : 'index.php'
            ], 'تم تسجيل الدخول بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Login system error', 'high', ['error' => $e->getMessage()]);
            $this->sendError('حدث خطأ في النظام، يرجى المحاولة لاحقاً');
        }
    }
    
    /**
     * تسجيل مستخدم جديد
     */
    public function register() {
        try {
            $this->validateCSRF();
            
            $data = $this->getInputData();
            
            $errors = $this->validate($data, [
                'first_name' => 'required|min:2|max:50',
                'last_name' => 'required|min:2|max:50',
                'email' => 'required|email|unique:users,email',
                'password' => 'required|min:8',
                'confirm_password' => 'required'
            ]);
            
            if (!empty($errors)) {
                $this->sendError('البيانات المدخلة غير صحيحة', 400, $errors);
            }
            
            $firstName = $this->sanitizeInput($data['first_name']);
            $lastName = $this->sanitizeInput($data['last_name']);
            $email = strtolower(trim($data['email']));
            $password = $data['password'];
            $confirmPassword = $data['confirm_password'];
            $agreeTerms = boolval($data['agree_terms'] ?? false);
            
            // التحقق من تطابق كلمة المرور
            if ($password !== $confirmPassword) {
                $this->sendError('كلمة المرور وتأكيدها غير متطابقين');
            }
            
            // التحقق من قوة كلمة المرور
            if (!isStrongPassword($password)) {
                $this->sendError('كلمة المرور يجب أن تحتوي على 8 أحرف على الأقل، وتشمل أحرف كبيرة وصغيرة وأرقام');
            }
            
            // التحقق من الموافقة على الشروط
            if (!$agreeTerms) {
                $this->sendError('يجب الموافقة على شروط الاستخدام');
            }
            
            // فحص معدل التسجيل
            $this->checkRegistrationRate();
            
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            $verificationToken = bin2hex(random_bytes(32));
            
            $userId = $this->transaction(function($pdo) use ($firstName, $lastName, $email, $passwordHash, $verificationToken) {
                $stmt = $pdo->prepare("
                    INSERT INTO users (first_name, last_name, email, password_hash, email_verification_token, created_at)
                    VALUES (?, ?, ?, ?, ?, NOW())
                ");
                
                $stmt->execute([$firstName, $lastName, $email, $passwordHash, $verificationToken]);
                
                return $pdo->lastInsertId();
            });
            
            // إرسال بريد التفعيل
            $this->sendVerificationEmail($email, $firstName, $verificationToken);
            
            $this->logActivity('User registered', 'auth', ['user_id' => $userId]);
            $this->logSecurityEvent('New user registration', 'low', ['email' => $email]);
            
            $this->sendSuccess([
                'user_id' => $userId,
                'email' => $email,
                'verification_sent' => true
            ], 'تم إنشاء الحساب بنجاح، يرجى فحص بريدك الإلكتروني لتفعيل الحساب');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Registration system error', 'high', ['error' => $e->getMessage()]);
            $this->sendError('حدث خطأ في النظام، يرجى المحاولة لاحقاً');
        }
    }
    
    /**
     * تفعيل البريد الإلكتروني
     */
    public function verifyEmail() {
        try {
            $token = $_GET['token'] ?? '';
            
            if (empty($token)) {
                $this->sendError('رمز التفعيل مطلوب');
            }
            
            $stmt = $this->pdo->prepare("
                SELECT id, email, first_name, email_verified 
                FROM users 
                WHERE email_verification_token = ? AND is_active = 1
            ");
            $stmt->execute([$token]);
            $user = $stmt->fetch();
            
            if (!$user) {
                $this->sendError('رمز التفعيل غير صحيح أو منتهي الصلاحية');
            }
            
            if ($user['email_verified']) {
                $this->sendError('البريد الإلكتروني مفعل مسبقاً');
            }
            
            $this->transaction(function($pdo) use ($user) {
                $stmt = $pdo->prepare("
                    UPDATE users 
                    SET email_verified = 1, email_verification_token = NULL, email_verified_at = NOW()
                    WHERE id = ?
                ");
                $stmt->execute([$user['id']]);
            });
            
            $this->logActivity('Email verified', 'auth', ['user_id' => $user['id']]);
            $this->logSecurityEvent('Email verification completed', 'low', ['email' => $user['email']]);
            
            $this->sendSuccess([
                'user_id' => $user['id'],
                'email' => $user['email']
            ], 'تم تفعيل البريد الإلكتروني بنجاح، يمكنك الآن تسجيل الدخول');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Email verification error', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('حدث خطأ في تفعيل البريد الإلكتروني');
        }
    }
    
    /**
     * طلب إعادة تعيين كلمة المرور
     */
    public function forgotPassword() {
        try {
            $this->validateCSRF();
            
            $data = $this->getInputData();
            $email = strtolower(trim($data['email'] ?? ''));
            
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $this->sendError('يرجى إدخال بريد إلكتروني صحيح');
            }
            
            // البحث عن المستخدم
            $stmt = $this->pdo->prepare("
                SELECT id, first_name, email FROM users 
                WHERE email = ? AND is_active = 1 AND email_verified = 1
            ");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user) {
                // فحص الطلبات المتكررة
                $this->checkPasswordResetRate($user['id']);
                
                $resetToken = bin2hex(random_bytes(32));
                $expiresAt = date('Y-m-d H:i:s', strtotime('+1 hour'));
                
                $this->transaction(function($pdo) use ($user, $resetToken, $expiresAt) {
                    // حذف الطلبات القديمة
                    $pdo->prepare("DELETE FROM password_resets WHERE user_id = ?")->execute([$user['id']]);
                    
                    // إضافة طلب جديد
                    $stmt = $pdo->prepare("
                        INSERT INTO password_resets (user_id, token, expires_at, created_at)
                        VALUES (?, ?, ?, NOW())
                    ");
                    $stmt->execute([$user['id'], $resetToken, $expiresAt]);
                });
                
                // إرسال بريد إعادة التعيين
                $this->sendPasswordResetEmail($user['email'], $user['first_name'], $resetToken);
                
                $this->logActivity('Password reset requested', 'auth', ['user_id' => $user['id']]);
                $this->logSecurityEvent('Password reset requested', 'medium', ['email' => $email]);
            }
            
            // إرسال نفس الرسالة بغض النظر عن وجود المستخدم (لأمان إضافي)
            $this->sendSuccess(null, 'إذا كان البريد الإلكتروني موجود في النظام، ستتلقى رابط إعادة تعيين كلمة المرور');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Forgot password error', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('حدث خطأ في النظام، يرجى المحاولة لاحقاً');
        }
    }
    
    /**
     * إعادة تعيين كلمة المرور
     */
    public function resetPassword() {
        try {
            $this->validateCSRF();
            
            $data = $this->getInputData();
            
            $errors = $this->validate($data, [
                'token' => 'required',
                'password' => 'required|min:8',
                'confirm_password' => 'required'
            ]);
            
            if (!empty($errors)) {
                $this->sendError('البيانات المدخلة غير صحيحة', 400, $errors);
            }
            
            $token = $data['token'];
            $password = $data['password'];
            $confirmPassword = $data['confirm_password'];
            
            if ($password !== $confirmPassword) {
                $this->sendError('كلمة المرور وتأكيدها غير متطابقين');
            }
            
            if (!isStrongPassword($password)) {
                $this->sendError('كلمة المرور يجب أن تحتوي على 8 أحرف على الأقل، وتشمل أحرف كبيرة وصغيرة وأرقام');
            }
            
            // التحقق من صحة الرمز
            $stmt = $this->pdo->prepare("
                SELECT pr.user_id, u.email, u.first_name 
                FROM password_resets pr
                JOIN users u ON pr.user_id = u.id
                WHERE pr.token = ? AND pr.expires_at > NOW() AND u.is_active = 1
            ");
            $stmt->execute([$token]);
            $resetRequest = $stmt->fetch();
            
            if (!$resetRequest) {
                $this->sendError('رمز إعادة التعيين غير صحيح أو منتهي الصلاحية');
            }
            
            $newPasswordHash = password_hash($password, PASSWORD_DEFAULT);
            
            $this->transaction(function($pdo) use ($resetRequest, $newPasswordHash) {
                // تحديث كلمة المرور
                $stmt = $pdo->prepare("
                    UPDATE users 
                    SET password_hash = ?, updated_at = NOW()
                    WHERE id = ?
                ");
                $stmt->execute([$newPasswordHash, $resetRequest['user_id']]);
                
                // حذف طلب إعادة التعيين
                $pdo->prepare("DELETE FROM password_resets WHERE user_id = ?")->execute([$resetRequest['user_id']]);
                
                // إنهاء جميع الجلسات
                $pdo->prepare("DELETE FROM user_sessions WHERE user_id = ?")->execute([$resetRequest['user_id']]);
            });
            
            $this->logActivity('Password reset completed', 'auth', ['user_id' => $resetRequest['user_id']]);
            $this->logSecurityEvent('Password reset completed', 'medium', ['email' => $resetRequest['email']]);
            
            $this->sendSuccess(null, 'تم إعادة تعيين كلمة المرور بنجاح، يمكنك الآن تسجيل الدخول بكلمة المرور الجديدة');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Password reset error', 'high', ['error' => $e->getMessage()]);
            $this->sendError('حدث خطأ في إعادة تعيين كلمة المرور');
        }
    }
    
    /**
     * تسجيل الخروج
     */
    public function logout() {
        try {
            if ($this->user) {
                // حذف الجلسة الحالية
                $stmt = $this->pdo->prepare("
                    DELETE FROM user_sessions 
                    WHERE user_id = ? AND session_id = ?
                ");
                $stmt->execute([$this->user['id'], session_id()]);
                
                $this->logActivity('User logged out', 'auth', ['user_id' => $this->user['id']]);
            }
            
            // إنهاء الجلسة
            session_destroy();
            
            $this->sendSuccess(null, 'تم تسجيل الخروج بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Logout error', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('حدث خطأ في تسجيل الخروج');
        }
    }
    
    // Helper Methods
    
    private function checkLoginAttempts($email) {
        $stmt = $this->pdo->prepare("
            SELECT COUNT(*) FROM login_attempts 
            WHERE email = ? AND attempted_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)
        ");
        $stmt->execute([$email]);
        $attempts = $stmt->fetchColumn();
        
        if ($attempts >= 5) {
            $this->logSecurityEvent('Account locked due to multiple failed login attempts', 'high', ['email' => $email]);
            $this->sendError('تم قفل الحساب مؤقتاً بسبب محاولات تسجيل دخول متكررة، يرجى المحاولة بعد 15 دقيقة');
        }
    }
    
    private function recordFailedAttempt($email) {
        $stmt = $this->pdo->prepare("
            INSERT INTO login_attempts (email, ip_address, user_agent, attempted_at)
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->execute([$email, getRealIpAddress(), $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown']);
    }
    
    private function clearFailedAttempts($email) {
        $stmt = $this->pdo->prepare("DELETE FROM login_attempts WHERE email = ?");
        $stmt->execute([$email]);
    }
    
    private function createUserSession($user, $rememberMe = false) {
        $sessionToken = bin2hex(random_bytes(32));
        $expiresAt = $rememberMe ? date('Y-m-d H:i:s', strtotime('+30 days')) : date('Y-m-d H:i:s', strtotime('+24 hours'));
        
        $stmt = $this->pdo->prepare("
            INSERT INTO user_sessions (user_id, session_id, session_token, ip_address, user_agent, expires_at, created_at)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([
            $user['id'],
            session_id(),
            $sessionToken,
            getRealIpAddress(),
            $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
            $expiresAt
        ]);
        
        return [
            'token' => $sessionToken,
            'expires_at' => $expiresAt
        ];
    }
    
    private function updateLastLogin($userId) {
        $stmt = $this->pdo->prepare("
            UPDATE users 
            SET last_login = NOW(), last_login_ip = ?
            WHERE id = ?
        ");
        $stmt->execute([getRealIpAddress(), $userId]);
    }
    
    private function checkRegistrationRate() {
        $ip = getRealIpAddress();
        
        $stmt = $this->pdo->prepare("
            SELECT COUNT(*) FROM users 
            WHERE last_login_ip = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)
        ");
        $stmt->execute([$ip]);
        $recentRegistrations = $stmt->fetchColumn();
        
        if ($recentRegistrations >= 3) {
            $this->logSecurityEvent('Registration rate limit exceeded', 'high', ['ip' => $ip]);
            $this->sendError('تم تجاوز الحد المسموح للتسجيل، يرجى المحاولة لاحقاً');
        }
    }
    
    private function checkPasswordResetRate($userId) {
        $stmt = $this->pdo->prepare("
            SELECT COUNT(*) FROM password_resets 
            WHERE user_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)
        ");
        $stmt->execute([$userId]);
        $recentRequests = $stmt->fetchColumn();
        
        if ($recentRequests >= 3) {
            $this->logSecurityEvent('Password reset rate limit exceeded', 'medium', ['user_id' => $userId]);
            $this->sendError('تم تجاوز الحد المسموح لطلبات إعادة التعيين، يرجى المحاولة لاحقاً');
        }
    }
    
    private function sendVerificationEmail($email, $firstName, $token) {
        $verificationLink = SITE_URL . "/api.php?action=verify_email&token=" . $token;
        
        $subject = "تفعيل حسابك في " . SITE_NAME;
        $message = "
            <div style='font-family: Arial, sans-serif; direction: rtl; text-align: right;'>
                <h2>مرحباً {$firstName}</h2>
                <p>شكراً لتسجيلك في منصة " . SITE_NAME . "</p>
                <p>يرجى النقر على الرابط التالي لتفعيل حسابك:</p>
                <p><a href='{$verificationLink}' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>تفعيل الحساب</a></p>
                <p>أو نسخ الرابط التالي في المتصفح:</p>
                <p>{$verificationLink}</p>
                <hr>
                <p>إذا لم تقم بإنشاء هذا الحساب، يرجى تجاهل هذا البريد.</p>
            </div>
        ";
        
        sendEmail($email, $subject, $message);
    }
    
    private function sendPasswordResetEmail($email, $firstName, $token) {
        $resetLink = SITE_URL . "/reset-password.php?token=" . $token;
        
        $subject = "إعادة تعيين كلمة المرور - " . SITE_NAME;
        $message = "
            <div style='font-family: Arial, sans-serif; direction: rtl; text-align: right;'>
                <h2>مرحباً {$firstName}</h2>
                <p>تلقينا طلب إعادة تعيين كلمة المرور لحسابك في " . SITE_NAME . "</p>
                <p>يرجى النقر على الرابط التالي لإعادة تعيين كلمة المرور:</p>
                <p><a href='{$resetLink}' style='background: #dc3545; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>إعادة تعيين كلمة المرور</a></p>
                <p>أو نسخ الرابط التالي في المتصفح:</p>
                <p>{$resetLink}</p>
                <p><strong>تنبيه:</strong> هذا الرابط صالح لمدة ساعة واحدة فقط.</p>
                <hr>
                <p>إذا لم تطلب إعادة تعيين كلمة المرور، يرجى تجاهل هذا البريد وتغيير كلمة مرورك فوراً.</p>
            </div>
        ";
        
        sendEmail($email, $subject, $message);
    }
}
?>