<?php
/**
 * معالج الأمان - مراقبة الانتهاكات الأمنية
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

require_once __DIR__ . '/../../api.php';

class SecurityController extends BaseController {
    
    /**
     * الإبلاغ عن انتهاك أمني
     */
    public function reportViolation() {
        $userId = $_SESSION['user_id'] ?? null;
        $data = $this->getJsonInput() ?: $_POST;
        
        $violationType = sanitizeInput($data['violation_type'] ?? 'unknown');
        $details = sanitizeInput($data['details'] ?? '');
        $lessonId = intval($data['lesson_id'] ?? 0);
        $sessionId = sanitizeInput($data['session_id'] ?? '');
        $userAgent = sanitizeInput($data['user_agent'] ?? $_SERVER['HTTP_USER_AGENT'] ?? '');
        
        try {
            // تسجيل الانتهاك في قاعدة البيانات
            $stmt = $this->db->prepare("
                INSERT INTO security_violations 
                (user_id, lesson_id, violation_type, details, ip_address, user_agent, session_id, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            
            $stmt->execute([
                $userId,
                $lessonId ?: null,
                $violationType,
                $details,
                getRealIpAddress(),
                $userAgent,
                $sessionId
            ]);
            
            $violationId = $this->db->lastInsertId();
            
            // تسجيل في سجل الأنشطة
            logActivity($userId, 'security_violation', 
                "Type: {$violationType}, Details: {$details}, Violation ID: {$violationId}");
            
            // إرسال تنبيه للمسؤولين في حالة الانتهاكات الخطيرة
            $criticalViolations = ['dev_tools_detected', 'screen_recording', 'bot_detected'];
            if (in_array($violationType, $criticalViolations)) {
                $this->notifyAdmins($violationType, $userId, $details);
            }
            
            // تطبيق إجراءات أمنية حسب نوع الانتهاك
            $action = $this->getSecurityAction($violationType, $userId);
            
            return $this->successResponse([
                'violation_id' => $violationId,
                'action' => $action,
                'message' => $this->getViolationMessage($violationType)
            ], 'تم تسجيل الانتهاك الأمني');
            
        } catch (Exception $e) {
            error_log("Security violation reporting error: " . $e->getMessage());
            return $this->errorResponse('خطأ في تسجيل الانتهاك', 500);
        }
    }
    
    /**
     * فحص الأمان العام
     */
    public function checkSecurity() {
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $ipAddress = getRealIpAddress();
        
        $checks = [
            'browser_supported' => $this->isBrowserSupported($userAgent),
            'ios_version_supported' => $this->isIOSVersionSupported($userAgent),
            'suspicious_activity' => $this->checkSuspiciousActivity($ipAddress),
            'vpn_detected' => $this->detectVPN($ipAddress),
            'bot_detected' => $this->detectBot($userAgent)
        ];
        
        $securityScore = $this->calculateSecurityScore($checks);
        
        return $this->successResponse([
            'checks' => $checks,
            'security_score' => $securityScore,
            'allowed' => $securityScore >= 70,
            'warnings' => $this->getSecurityWarnings($checks)
        ]);
    }
    
    /**
     * التحقق من دعم المتصفح
     */
    private function isBrowserSupported($userAgent) {
        // قائمة المتصفحات المدعومة
        $supportedBrowsers = [
            'Chrome' => 70,
            'Firefox' => 65,
            'Safari' => 12,
            'Edge' => 79,
            'Opera' => 57
        ];
        
        foreach ($supportedBrowsers as $browser => $minVersion) {
            if (stripos($userAgent, $browser) !== false) {
                preg_match("/{$browser}\/(\d+)/i", $userAgent, $matches);
                $version = intval($matches[1] ?? 0);
                
                return [
                    'supported' => $version >= $minVersion,
                    'browser' => $browser,
                    'version' => $version,
                    'min_required' => $minVersion
                ];
            }
        }
        
        return [
            'supported' => false,
            'browser' => 'Unknown',
            'version' => 0,
            'min_required' => 0
        ];
    }
    
    /**
     * التحقق من إصدار iOS
     */
    private function isIOSVersionSupported($userAgent) {
        if (stripos($userAgent, 'iPhone') !== false || stripos($userAgent, 'iPad') !== false) {
            preg_match('/OS (\d+)_(\d+)/i', $userAgent, $matches);
            $majorVersion = intval($matches[1] ?? 0);
            $minorVersion = intval($matches[2] ?? 0);
            
            // iOS 15+ مطلوب
            $isSupported = $majorVersion >= 15;
            
            return [
                'is_ios' => true,
                'supported' => $isSupported,
                'version' => "{$majorVersion}.{$minorVersion}",
                'min_required' => '15.0'
            ];
        }
        
        return [
            'is_ios' => false,
            'supported' => true,
            'version' => null,
            'min_required' => null
        ];
    }
    
    /**
     * فحص النشاط المشبوه
     */
    private function checkSuspiciousActivity($ipAddress) {
        try {
            // فحص عدد طلبات API في الدقيقة الأخيرة
            $stmt = $this->db->prepare("
                SELECT COUNT(*) as request_count 
                FROM activity_logs 
                WHERE ip_address = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 MINUTE)
            ");
            $stmt->execute([$ipAddress]);
            $result = $stmt->fetch();
            
            $requestCount = $result['request_count'] ?? 0;
            $isSuspicious = $requestCount > 100; // أكثر من 100 طلب في الدقيقة
            
            return [
                'suspicious' => $isSuspicious,
                'request_count' => $requestCount,
                'threshold' => 100
            ];
            
        } catch (Exception $e) {
            error_log("Suspicious activity check error: " . $e->getMessage());
            return [
                'suspicious' => false,
                'request_count' => 0,
                'threshold' => 100
            ];
        }
    }
    
    /**
     * كشف VPN
     */
    private function detectVPN($ipAddress) {
        // يمكن استخدام خدمات خارجية لكشف VPN
        // مثل IPQualityScore أو MaxMind
        // هنا مثال بسيط
        
        $vpnRanges = [
            '10.0.0.0/8',
            '172.16.0.0/12',
            '192.168.0.0/16',
            '127.0.0.0/8'
        ];
        
        foreach ($vpnRanges as $range) {
            if ($this->ipInRange($ipAddress, $range)) {
                return [
                    'detected' => true,
                    'type' => 'private_range',
                    'range' => $range
                ];
            }
        }
        
        return [
            'detected' => false,
            'type' => null,
            'range' => null
        ];
    }
    
    /**
     * كشف البوتات
     */
    private function detectBot($userAgent) {
        $botPatterns = [
            'bot', 'crawl', 'spider', 'scrape', 'headless',
            'phantom', 'selenium', 'automation', 'webdriver'
        ];
        
        $userAgentLower = strtolower($userAgent);
        
        foreach ($botPatterns as $pattern) {
            if (strpos($userAgentLower, $pattern) !== false) {
                return [
                    'detected' => true,
                    'pattern' => $pattern,
                    'confidence' => 90
                ];
            }
        }
        
        // فحص عدم وجود JavaScript capabilities
        if (empty($userAgent) || strlen($userAgent) < 20) {
            return [
                'detected' => true,
                'pattern' => 'suspicious_user_agent',
                'confidence' => 70
            ];
        }
        
        return [
            'detected' => false,
            'pattern' => null,
            'confidence' => 0
        ];
    }
    
    /**
     * حساب درجة الأمان
     */
    private function calculateSecurityScore($checks) {
        $score = 100;
        
        if (!$checks['browser_supported']['supported']) {
            $score -= 30;
        }
        
        if ($checks['ios_version_supported']['is_ios'] && !$checks['ios_version_supported']['supported']) {
            $score -= 40;
        }
        
        if ($checks['suspicious_activity']['suspicious']) {
            $score -= 25;
        }
        
        if ($checks['vpn_detected']['detected']) {
            $score -= 15;
        }
        
        if ($checks['bot_detected']['detected']) {
            $score -= 50;
        }
        
        return max(0, $score);
    }
    
    /**
     * الحصول على تحذيرات الأمان
     */
    private function getSecurityWarnings($checks) {
        $warnings = [];
        
        if (!$checks['browser_supported']['supported']) {
            $warnings[] = 'متصفحك غير مدعوم أو إصداره قديم';
        }
        
        if ($checks['ios_version_supported']['is_ios'] && !$checks['ios_version_supported']['supported']) {
            $warnings[] = 'إصدار iOS قديم - يرجى التحديث لـ iOS 15 أو أحدث';
        }
        
        if ($checks['suspicious_activity']['suspicious']) {
            $warnings[] = 'تم اكتشاف نشاط مشبوه من عنوان IP الخاص بك';
        }
        
        if ($checks['bot_detected']['detected']) {
            $warnings[] = 'تم اكتشاف متصفح آلي أو أدوات تشغيل تلقائي';
        }
        
        return $warnings;
    }
    
    /**
     * الحصول على الإجراء الأمني
     */
    private function getSecurityAction($violationType, $userId) {
        switch ($violationType) {
            case 'dev_tools_detected':
                return 'block_video';
            case 'screen_recording':
                return 'terminate_session';
            case 'bot_detected':
                return 'ban_ip';
            default:
                return 'log_only';
        }
    }
    
    /**
     * الحصول على رسالة الانتهاك
     */
    private function getViolationMessage($violationType) {
        $messages = [
            'dev_tools_detected' => 'تم اكتشاف أدوات التطوير - سيتم إيقاف الفيديو',
            'screen_recording' => 'تم اكتشاف تسجيل الشاشة - سيتم إنهاء الجلسة',
            'bot_detected' => 'تم اكتشاف متصفح آلي - سيتم حظر الوصول',
            'print_screen' => 'تم اكتشاف محاولة التقاط شاشة',
            'right_click' => 'النقر الأيمن غير مسموح',
            'copy_attempt' => 'محاولة نسخ محتوى محمي'
        ];
        
        return $messages[$violationType] ?? 'انتهاك أمني عام';
    }
    
    /**
     * إشعار المسؤولين
     */
    private function notifyAdmins($violationType, $userId, $details) {
        try {
            // إرسال إشعار فوري للمسؤولين
            // يمكن استخدام WebSocket أو Push Notifications
            
            logActivity(null, 'admin_notification', 
                "Critical security violation: {$violationType} by user {$userId}");
                
        } catch (Exception $e) {
            error_log("Admin notification error: " . $e->getMessage());
        }
    }
    
    /**
     * فحص IP في نطاق معين
     */
    private function ipInRange($ip, $range) {
        list($subnet, $mask) = explode('/', $range);
        return (ip2long($ip) & ~((1 << (32 - $mask)) - 1)) == ip2long($subnet);
    }
}

// إضافة جدول انتهاكات الأمان إلى قاعدة البيانات
/*
CREATE TABLE IF NOT EXISTS security_violations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NULL,
    lesson_id INT NULL,
    violation_type VARCHAR(100) NOT NULL,
    details TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    session_id VARCHAR(128),
    severity ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    resolved TINYINT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE SET NULL,
    INDEX idx_user (user_id),
    INDEX idx_type (violation_type),
    INDEX idx_severity (severity),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
*/
?>