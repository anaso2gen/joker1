<?php
/**
 * معالج API أكواد التفعيل
 * يتعامل مع جميع طلبات API المتعلقة بأكواد التفعيل
 * 
 * @author anaso2gen
 * @version 1.0
 * @since 2025-05-29
 */

require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../services/ActivationCodeService.php';

class ActivationController extends BaseController {
    private $activationService;
    
    public function __construct() {
        parent::__construct();
        $this->activationService = new ActivationCodeService();
    }
    
    /**
     * توجيه الطلبات حسب النوع
     */
    public function handleRequest() {
        $action = $this->getAction();
        
        switch ($action) {
            case 'create':
                return $this->createCode();
            case 'create_bulk':
                return $this->createBulkCodes();
            case 'activate':
                return $this->activateCode();
            case 'get_code_info':
                return $this->getCodeInfo();
            case 'list':
                return $this->listCodes();
            case 'delete':
                return $this->deleteCode();
            case 'toggle_status':
                return $this->toggleCodeStatus();
            case 'export':
                return $this->exportCodes();
            case 'statistics':
                return $this->getStatistics();
            case 'check_code':
                return $this->checkCode();
            default:
                return $this->sendError('إجراء غير صحيح', 400);
        }
    }
    
    /**
     * إنشاء كود تفعيل جديد
     */
    private function createCode() {
        try {
            // التحقق من الصلاحيات
            if (!$this->isAdmin()) {
                return $this->sendError('غير مصرح لك بهذا الإجراء', 403);
            }
            
            // التحقق من طريقة الطلب
            if (!$this->isPost()) {
                return $this->sendError('طريقة طلب غير صحيحة', 405);
            }
            
            // التحقق من رمز CSRF
            if (!$this->validateCSRF()) {
                return $this->sendError('رمز الأمان غير صحيح', 403);
            }
            
            // الحصول على البيانات
            $data = $this->getRequestData();
            $data['created_by'] = $this->getCurrentUserId();
            
            // إنشاء الكود
            $result = $this->activationService->createCode($data);
            
            if ($result['success']) {
                return $this->sendSuccess($result['message'], [
                    'code_id' => $result['code_id'],
                    'code' => $result['code']
                ]);
            } else {
                return $this->sendError($result['message'], 400);
            }
            
        } catch (Exception $e) {
            return $this->sendError('خطأ في الخادم: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * إنشاء أكواد متعددة
     */
    private function createBulkCodes() {
        try {
            // التحقق من الصلاحيات
            if (!$this->isAdmin()) {
                return $this->sendError('غير مصرح لك بهذا الإجراء', 403);
            }
            
            if (!$this->isPost()) {
                return $this->sendError('طريقة طلب غير صحيحة', 405);
            }
            
            if (!$this->validateCSRF()) {
                return $this->sendError('رمز الأمان غير صحيح', 403);
            }
            
            $data = $this->getRequestData();
            $data['created_by'] = $this->getCurrentUserId();
            
            // التحقق من الحد الأقصى
            $quantity = intval($data['quantity'] ?? 10);
            if ($quantity > 1000) {
                return $this->sendError('لا يمكن إنشاء أكثر من 1000 كود في المرة الواحدة', 400);
            }
            
            $result = $this->activationService->createBulkCodes($data);
            
            if ($result['success']) {
                return $this->sendSuccess($result['message'], [
                    'created_count' => $result['created_count'],
                    'failed_count' => $result['failed_count'],
                    'created_codes' => $result['created_codes']
                ]);
            } else {
                return $this->sendError($result['message'], 400);
            }
            
        } catch (Exception $e) {
            return $this->sendError('خطأ في الخادم: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * تفعيل كود للمستخدم
     */
    private function activateCode() {
        try {
            // التحقق من تسجيل الدخول
            if (!$this->isLoggedIn()) {
                return $this->sendError('يجب تسجيل الدخول أولاً', 401);
            }
            
            if (!$this->isPost()) {
                return $this->sendError('طريقة طلب غير صحيحة', 405);
            }
            
            if (!$this->validateCSRF()) {
                return $this->sendError('رمز الأمان غير صحيح', 403);
            }
            
            $data = $this->getRequestData();
            $code = trim($data['code'] ?? '');
            
            if (empty($code)) {
                return $this->sendError('الرجاء إدخال كود التفعيل', 400);
            }
            
            // تفعيل الكود
            $result = $this->activationService->activateCode(
                $code,
                $this->getCurrentUserId(),
                $this->getRealIpAddress(),
                $_SERVER['HTTP_USER_AGENT'] ?? null
            );
            
            if ($result['success']) {
                return $this->sendSuccess($result['message'], [
                    'code_type' => $result['code_type'],
                    'expires_at' => $result['expires_at'],
                    'courses_count' => $result['courses_count']
                ]);
            } else {
                return $this->sendError($result['message'], 400);
            }
            
        } catch (Exception $e) {
            return $this->sendError('خطأ في الخادم: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * التحقق من كود قبل التفعيل
     */
    private function checkCode() {
        try {
            if (!$this->isLoggedIn()) {
                return $this->sendError('يجب تسجيل الدخول أولاً', 401);
            }
            
            if (!$this->isPost()) {
                return $this->sendError('طريقة طلب غير صحيحة', 405);
            }
            
            $data = $this->getRequestData();
            $code = trim($data['code'] ?? '');
            
            if (empty($code)) {
                return $this->sendError('الرجاء إدخال كود التفعيل', 400);
            }
            
            $result = $this->activationService->getCodeInfo($code);
            
            if ($result['success']) {
                return $this->sendSuccess('معلومات الكود', $result['code_info']);
            } else {
                return $this->sendError($result['message'], 404);
            }
            
        } catch (Exception $e) {
            return $this->sendError('خطأ في الخادم: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * الحصول على قائمة الأكواد
     */
    private function listCodes() {
        try {
            if (!$this->isAdmin()) {
                return $this->sendError('غير مصرح لك بهذا الإجراء', 403);
            }
            
            // الحصول على الفلاتر
            $filters = [
                'search' => $_GET['search'] ?? '',
                'is_active' => isset($_GET['is_active']) ? intval($_GET['is_active']) : null,
                'code_type' => $_GET['code_type'] ?? '',
                'expires_from' => $_GET['expires_from'] ?? '',
                'expires_to' => $_GET['expires_to'] ?? '',
                'order_by' => $_GET['order_by'] ?? 'created_at',
                'order_dir' => $_GET['order_dir'] ?? 'DESC',
                'limit' => intval($_GET['limit'] ?? 50),
                'offset' => intval($_GET['offset'] ?? 0)
            ];
            
            $result = $this->activationService->getAllCodes($filters);
            
            if ($result['success']) {
                return $this->sendSuccess('قائمة الأكواد', [
                    'codes' => $result['codes'],
                    'total_count' => $result['total_count'],
                    'showing_count' => $result['showing_count'],
                    'filters' => $filters
                ]);
            } else {
                return $this->sendError($result['message'], 400);
            }
            
        } catch (Exception $e) {
            return $this->sendError('خطأ في الخادم: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * حذف كود
     */
    private function deleteCode() {
        try {
            if (!$this->isAdmin()) {
                return $this->sendError('غير مصرح لك بهذا الإجراء', 403);
            }
            
            if (!$this->isPost()) {
                return $this->sendError('طريقة طلب غير صحيحة', 405);
            }
            
            if (!$this->validateCSRF()) {
                return $this->sendError('رمز الأمان غير صحيح', 403);
            }
            
            $data = $this->getRequestData();
            $codeId = intval($data['code_id'] ?? 0);
            
            if ($codeId <= 0) {
                return $this->sendError('معرف الكود غير صحيح', 400);
            }
            
            $result = $this->activationService->deleteCode($codeId);
            
            if ($result['success']) {
                return $this->sendSuccess($result['message']);
            } else {
                return $this->sendError($result['message'], 400);
            }
            
        } catch (Exception $e) {
            return $this->sendError('خطأ في الخادم: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * تفعيل/تعطيل كود
     */
    private function toggleCodeStatus() {
        try {
            if (!$this->isAdmin()) {
                return $this->sendError('غير مصرح لك بهذا الإجراء', 403);
            }
            
            if (!$this->isPost()) {
                return $this->sendError('طريقة طلب غير صحيحة', 405);
            }
            
            if (!$this->validateCSRF()) {
                return $this->sendError('رمز الأمان غير صحيح', 403);
            }
            
            $data = $this->getRequestData();
            $codeId = intval($data['code_id'] ?? 0);
            $isActive = !empty($data['is_active']);
            
            if ($codeId <= 0) {
                return $this->sendError('معرف الكود غير صحيح', 400);
            }
            
            $result = $this->activationService->toggleCodeStatus($codeId, $isActive);
            
            if ($result['success']) {
                return $this->sendSuccess($result['message']);
            } else {
                return $this->sendError($result['message'], 400);
            }
            
        } catch (Exception $e) {
            return $this->sendError('خطأ في الخادم: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * تصدير الأكواد
     */
    private function exportCodes() {
        try {
            if (!$this->isAdmin()) {
                return $this->sendError('غير مصرح لك بهذا الإجراء', 403);
            }
            
            $format = $_GET['format'] ?? 'csv';
            $filters = [
                'search' => $_GET['search'] ?? '',
                'is_active' => isset($_GET['is_active']) ? intval($_GET['is_active']) : null,
                'code_type' => $_GET['code_type'] ?? ''
            ];
            
            $result = $this->activationService->exportCodes($format, $filters);
            
            if ($result['success']) {
                return $this->sendSuccess('تم التصدير بنجاح', [
                    'download_url' => $result['download_url'],
                    'filename' => $result['filename']
                ]);
            } else {
                return $this->sendError($result['message'], 400);
            }
            
        } catch (Exception $e) {
            return $this->sendError('خطأ في الخادم: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * إحصائيات الأكواد
     */
    private function getStatistics() {
        try {
            if (!$this->isAdmin()) {
                return $this->sendError('غير مصرح لك بهذا الإجراء', 403);
            }
            
            $result = $this->activationService->getCodesStatistics();
            
            if ($result['success']) {
                return $this->sendSuccess('إحصائيات الأكواد', $result['statistics']);
            } else {
                return $this->sendError($result['message'], 400);
            }
            
        } catch (Exception $e) {
            return $this->sendError('خطأ في الخادم: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * الحصول على معلومات الكود
     */
    private function getCodeInfo() {
        try {
            if (!$this->isAdmin()) {
                return $this->sendError('غير مصرح لك بهذا الإجراء', 403);
            }
            
            $code = $_GET['code'] ?? '';
            
            if (empty($code)) {
                return $this->sendError('كود التفعيل مطلوب', 400);
            }
            
            $result = $this->activationService->getCodeInfo($code);
            
            if ($result['success']) {
                return $this->sendSuccess('معلومات الكود', $result['code_info']);
            } else {
                return $this->sendError($result['message'], 404);
            }
            
        } catch (Exception $e) {
            return $this->sendError('خطأ في الخادم: ' . $e->getMessage(), 500);
        }
    }
}
?>