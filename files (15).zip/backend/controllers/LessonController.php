<?php
/**
 * تحكم الدروس والفيديوهات
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:44:27
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

require_once __DIR__ . '/BaseController.php';

class LessonController extends BaseController {
    
    /**
     * الحصول على تفاصيل الدرس
     */
    public function getLesson() {
        $this->requireAuth();
        
        try {
            $lessonId = intval($_GET['lesson_id'] ?? 0);
            $courseId = intval($_GET['course_id'] ?? 0);
            
            if (!$lessonId) {
                $this->sendError('معرف الدرس مطلوب');
            }
            
            // التحقق من تفاصيل الدرس
            $stmt = $this->pdo->prepare("
                SELECT l.*, s.name as section_name, s.course_id, c.name as course_name,
                       lp.completed, lp.last_position, lp.started_at, lp.completed_at, lp.last_accessed
                FROM lessons l
                JOIN sections s ON l.section_id = s.id
                JOIN courses c ON s.course_id = c.id
                LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = ?
                WHERE l.id = ? AND l.is_active = 1
            ");
            
            $stmt->execute([$this->user['id'], $lessonId]);
            $lesson = $stmt->fetch();
            
            if (!$lesson) {
                $this->sendError('الدرس غير موجود', 404);
            }
            
            // التحقق من صلاحية الوصول للدرس
            $hasAccess = $this->hasLessonAccess($lesson['course_id'], $lessonId);
            
            if (!$hasAccess && !$lesson['is_preview']) {
                $this->sendError('ليس لديك صلاحية للوصول لهذا الدرس', 403);
            }
            
            // الحصول على الدروس المجاورة
            $navigationStmt = $this->pdo->prepare("
                SELECT l.id, l.name, l.sort_order, s.sort_order as section_sort
                FROM lessons l
                JOIN sections s ON l.section_id = s.id
                WHERE s.course_id = ? AND l.is_active = 1
                ORDER BY s.sort_order, l.sort_order
            ");
            
            $navigationStmt->execute([$lesson['course_id']]);
            $allLessons = $navigationStmt->fetchAll();
            
            $currentIndex = array_search($lessonId, array_column($allLessons, 'id'));
            $previousLesson = $currentIndex > 0 ? $allLessons[$currentIndex - 1] : null;
            $nextLesson = $currentIndex < count($allLessons) - 1 ? $allLessons[$currentIndex + 1] : null;
            
            // الحصول على الملاحظات
            $notesStmt = $this->pdo->prepare("
                SELECT * FROM lesson_notes 
                WHERE lesson_id = ? AND user_id = ?
                ORDER BY timestamp ASC
            ");
            
            $notesStmt->execute([$lessonId, $this->user['id']]);
            $notes = $notesStmt->fetchAll();
            
            // تسجيل بداية الدرس إذا لم يبدأ بعد
            if (!$lesson['started_at']) {
                $this->markLessonStarted($lessonId);
            }
            
            // تحديث آخر وصول
            $this->updateLastAccessed($lessonId);
            
            $this->logActivity("Accessed lesson: {$lesson['name']}", 'lesson_access', [
                'lesson_id' => $lessonId,
                'course_id' => $lesson['course_id']
            ]);
            
            $this->sendSuccess([
                'lesson' => $lesson,
                'navigation' => [
                    'previous' => $previousLesson,
                    'next' => $nextLesson
                ],
                'notes' => $notes,
                'access' => [
                    'has_access' => $hasAccess || $lesson['is_preview'],
                    'is_preview' => $lesson['is_preview']
                ]
            ]);
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to get lesson', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحميل الدرس');
        }
    }
    
    /**
     * تحديث تقدم الدرس
     */
    public function updateProgress() {
        $this->requireAuth();
        
        try {
            $data = $this->getInputData();
            
            $lessonId = intval($data['lesson_id'] ?? 0);
            $position = floatval($data['position'] ?? 0);
            $completed = boolval($data['completed'] ?? false);
            
            if (!$lessonId) {
                $this->sendError('معرف الدرس مطلوب');
            }
            
            // التحقق من وجود الدرس وصلاحية الوصول
            $stmt = $this->pdo->prepare("
                SELECT l.*, s.course_id, l.duration
                FROM lessons l
                JOIN sections s ON l.section_id = s.id
                WHERE l.id = ? AND l.is_active = 1
            ");
            
            $stmt->execute([$lessonId]);
            $lesson = $stmt->fetch();
            
            if (!$lesson) {
                $this->sendError('الدرس غير موجود', 404);
            }
            
            if (!$this->hasLessonAccess($lesson['course_id'], $lessonId) && !$lesson['is_preview']) {
                $this->sendError('ليس لديك صلاحية للوصول لهذا الدرس', 403);
            }
            
            // تحديد ما إذا كان الدرس مكتملاً تلقائياً
            if (!$completed && $lesson['duration'] > 0) {
                $watchPercentage = ($position / $lesson['duration']) * 100;
                if ($watchPercentage >= 90) { // إكمال تلقائي عند مشاهدة 90%
                    $completed = true;
                }
            }
            
            $this->transaction(function($pdo) use ($lessonId, $position, $completed) {
                // البحث عن تقدم موجود
                $stmt = $pdo->prepare("
                    SELECT id FROM lesson_progress 
                    WHERE lesson_id = ? AND user_id = ?
                ");
                $stmt->execute([$lessonId, $this->user['id']]);
                $existingProgress = $stmt->fetch();
                
                if ($existingProgress) {
                    // تحديث التقدم الموجود
                    $updateSql = "
                        UPDATE lesson_progress 
                        SET last_position = ?, last_accessed = NOW()";
                    
                    $params = [$position, $this->user['id'], $lessonId];
                    
                    if ($completed) {
                        $updateSql .= ", completed = 1, completed_at = NOW()";
                    }
                    
                    $updateSql .= " WHERE user_id = ? AND lesson_id = ?";
                    
                    $stmt = $pdo->prepare($updateSql);
                    $stmt->execute($params);
                } else {
                    // إنشاء تقدم جديد
                    $stmt = $pdo->prepare("
                        INSERT INTO lesson_progress (user_id, lesson_id, last_position, completed, started_at, completed_at, last_accessed)
                        VALUES (?, ?, ?, ?, NOW(), " . ($completed ? "NOW()" : "NULL") . ", NOW())
                    ");
                    $stmt->execute([$this->user['id'], $lessonId, $position, $completed ? 1 : 0]);
                }
            });
            
            // فحص إكمال الدورة
            if ($completed) {
                $this->checkCourseCompletion($lesson['course_id']);
            }
            
            $this->logActivity($completed ? 'Completed lesson' : 'Updated lesson progress', 'lesson_progress', [
                'lesson_id' => $lessonId,
                'position' => $position,
                'completed' => $completed
            ]);
            
            $this->sendSuccess([
                'position' => $position,
                'completed' => $completed
            ], $completed ? 'تم إكمال الدرس بنجاح' : 'تم حفظ التقدم');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to update lesson progress', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحديث التقدم');
        }
    }
    
    /**
     * إضافة ملاحظة للدرس
     */
    public function addNote() {
        $this->requireAuth();
        
        try {
            $this->validateCSRF();
            
            $data = $this->getInputData();
            
            $errors = $this->validate($data, [
                'lesson_id' => 'required|numeric',
                'content' => 'required|min:3|max:1000',
                'timestamp' => 'numeric'
            ]);
            
            if (!empty($errors)) {
                $this->sendError('البيانات المدخلة غير صحيحة', 400, $errors);
            }
            
            $lessonId = intval($data['lesson_id']);
            $content = $this->sanitizeInput($data['content']);
            $timestamp = floatval($data['timestamp'] ?? 0);
            
            // التحقق من وجود الدرس وصلاحية الوصول
            $stmt = $this->pdo->prepare("
                SELECT s.course_id FROM lessons l
                JOIN sections s ON l.section_id = s.id
                WHERE l.id = ? AND l.is_active = 1
            ");
            
            $stmt->execute([$lessonId]);
            $lesson = $stmt->fetch();
            
            if (!$lesson) {
                $this->sendError('الدرس غير موجود', 404);
            }
            
            if (!$this->hasLessonAccess($lesson['course_id'], $lessonId)) {
                $this->sendError('ليس لديك صلاحية للوصول لهذا الدرس', 403);
            }
            
            $noteId = $this->transaction(function($pdo) use ($lessonId, $content, $timestamp) {
                $stmt = $pdo->prepare("
                    INSERT INTO lesson_notes (user_id, lesson_id, content, timestamp, created_at)
                    VALUES (?, ?, ?, ?, NOW())
                ");
                
                $stmt->execute([$this->user['id'], $lessonId, $content, $timestamp]);
                
                return $pdo->lastInsertId();
            });
            
            $this->logActivity('Added lesson note', 'lesson_note', [
                'lesson_id' => $lessonId,
                'note_id' => $noteId
            ]);
            
            $this->sendSuccess(['note_id' => $noteId], 'تم إضافة الملاحظة بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to add lesson note', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في إضافة الملاحظة');
        }
    }
    
    /**
     * الحصول على ملاحظات الدرس
     */
    public function getNotes() {
        $this->requireAuth();
        
        try {
            $lessonId = intval($_GET['lesson_id'] ?? 0);
            
            if (!$lessonId) {
                $this->sendError('معرف الدرس مطلوب');
            }
            
            $stmt = $this->pdo->prepare("
                SELECT * FROM lesson_notes 
                WHERE lesson_id = ? AND user_id = ?
                ORDER BY timestamp ASC
            ");
            
            $stmt->execute([$lessonId, $this->user['id']]);
            $notes = $stmt->fetchAll();
            
            $this->sendSuccess(['notes' => $notes]);
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to get lesson notes', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحميل الملاحظات');
        }
    }
    
    /**
     * حذف ملاحظة
     */
    public function deleteNote() {
        $this->requireAuth();
        
        try {
            $noteId = intval($_GET['note_id'] ?? $_POST['note_id'] ?? 0);
            
            if (!$noteId) {
                $this->sendError('معرف الملاحظة مطلوب');
            }
            
            // التحقق من ملكية الملاحظة
            $stmt = $this->pdo->prepare("
                SELECT id FROM lesson_notes 
                WHERE id = ? AND user_id = ?
            ");
            
            $stmt->execute([$noteId, $this->user['id']]);
            $note = $stmt->fetch();
            
            if (!$note) {
                $this->sendError('الملاحظة غير موجودة أو ليس لديك صلاحية لحذفها', 404);
            }
            
            $stmt = $this->pdo->prepare("DELETE FROM lesson_notes WHERE id = ?");
            $stmt->execute([$noteId]);
            
            $this->logActivity('Deleted lesson note', 'lesson_note', ['note_id' => $noteId]);
            
            $this->sendSuccess(null, 'تم حذف الملاحظة بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to delete lesson note', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في حذف الملاحظة');
        }
    }
    
    /**
     * إنشاء درس جديد (للإداريين)
     */
    public function createLesson() {
        $this->requireAdmin();
        
        try {
            $this->validateCSRF();
            
            $data = $this->getInputData();
            
            $errors = $this->validate($data, [
                'name' => 'required|min:3|max:255',
                'section_id' => 'required|numeric',
                'video_url' => 'required',
                'duration' => 'numeric'
            ]);
            
            if (!empty($errors)) {
                $this->sendError('البيانات المدخلة غير صحيحة', 400, $errors);
            }
            
            $lessonData = [
                'name' => $this->sanitizeInput($data['name']),
                'description' => $this->sanitizeInput($data['description'] ?? ''),
                'section_id' => intval($data['section_id']),
                'video_url' => $this->sanitizeInput($data['video_url']),
                'duration' => floatval($data['duration'] ?? 0),
                'sort_order' => intval($data['sort_order'] ?? 0),
                'is_preview' => intval($data['is_preview'] ?? 0),
                'is_active' => intval($data['is_active'] ?? 1)
            ];
            
            // التحقق من وجود القسم
            $stmt = $this->pdo->prepare("SELECT course_id FROM sections WHERE id = ?");
            $stmt->execute([$lessonData['section_id']]);
            $section = $stmt->fetch();
            
            if (!$section) {
                $this->sendError('القسم غير موجود', 404);
            }
            
            $lessonId = $this->transaction(function($pdo) use ($lessonData) {
                // تحديد ترتيب الدرس تلقائياً إذا لم يحدد
                if ($lessonData['sort_order'] == 0) {
                    $stmt = $pdo->prepare("
                        SELECT COALESCE(MAX(sort_order), 0) + 1 
                        FROM lessons WHERE section_id = ?
                    ");
                    $stmt->execute([$lessonData['section_id']]);
                    $lessonData['sort_order'] = $stmt->fetchColumn();
                }
                
                $stmt = $pdo->prepare("
                    INSERT INTO lessons (name, description, section_id, video_url, duration, sort_order, is_preview, is_active, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
                ");
                
                $stmt->execute([
                    $lessonData['name'],
                    $lessonData['description'],
                    $lessonData['section_id'],
                    $lessonData['video_url'],
                    $lessonData['duration'],
                    $lessonData['sort_order'],
                    $lessonData['is_preview'],
                    $lessonData['is_active']
                ]);
                
                return $pdo->lastInsertId();
            });
            
            $this->logActivity("Created lesson: {$lessonData['name']}", 'lesson_create', [
                'lesson_id' => $lessonId,
                'section_id' => $lessonData['section_id']
            ]);
            
            $this->sendSuccess(['lesson_id' => $lessonId], 'تم إنشاء الدرس بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to create lesson', 'high', ['error' => $e->getMessage()]);
            $this->sendError('فشل في إنشاء الدرس: ' . $e->getMessage());
        }
    }
    
    /**
     * تحديث درس (للإداريين)
     */
    public function updateLesson() {
        $this->requireAdmin();
        
        try {
            $this->validateCSRF();
            
            $lessonId = intval($_POST['lesson_id'] ?? $_GET['id'] ?? 0);
            $data = $this->getInputData();
            
            if (!$lessonId) {
                $this->sendError('معرف الدرس مطلوب');
            }
            
            // التحقق من وجود الدرس
            $stmt = $this->pdo->prepare("SELECT * FROM lessons WHERE id = ?");
            $stmt->execute([$lessonId]);
            $lesson = $stmt->fetch();
            
            if (!$lesson) {
                $this->sendError('الدرس غير موجود', 404);
            }
            
            $errors = $this->validate($data, [
                'name' => 'required|min:3|max:255',
                'video_url' => 'required',
                'duration' => 'numeric'
            ]);
            
            if (!empty($errors)) {
                $this->sendError('البيانات المدخلة غير صحيحة', 400, $errors);
            }
            
            $updateData = [
                'name' => $this->sanitizeInput($data['name']),
                'description' => $this->sanitizeInput($data['description'] ?? ''),
                'video_url' => $this->sanitizeInput($data['video_url']),
                'duration' => floatval($data['duration'] ?? $lesson['duration']),
                'sort_order' => intval($data['sort_order'] ?? $lesson['sort_order']),
                'is_preview' => intval($data['is_preview'] ?? $lesson['is_preview']),
                'is_active' => intval($data['is_active'] ?? $lesson['is_active'])
            ];
            
            $this->transaction(function($pdo) use ($lessonId, $updateData) {
                $setParts = [];
                $params = [];
                
                foreach ($updateData as $key => $value) {
                    $setParts[] = "$key = ?";
                    $params[] = $value;
                }
                
                $params[] = $lessonId;
                
                $sql = "UPDATE lessons SET " . implode(', ', $setParts) . ", updated_at = NOW() WHERE id = ?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
            });
            
            $this->logActivity("Updated lesson: {$updateData['name']}", 'lesson_update', ['lesson_id' => $lessonId]);
            
            $this->sendSuccess(null, 'تم تحديث الدرس بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to update lesson', 'high', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحديث الدرس: ' . $e->getMessage());
        }
    }
    
    /**
     * حذف درس (للإداريين)
     */
    public function deleteLesson() {
        $this->requireAdmin();
        
        try {
            $this->validateCSRF();
            
            $lessonId = intval($_POST['lesson_id'] ?? $_GET['id'] ?? 0);
            
            if (!$lessonId) {
                $this->sendError('معرف الدرس مطلوب');
            }
            
            // التحقق من وجود الدرس
            $stmt = $this->pdo->prepare("SELECT name FROM lessons WHERE id = ?");
            $stmt->execute([$lessonId]);
            $lesson = $stmt->fetch();
            
            if (!$lesson) {
                $this->sendError('الدرس غير موجود', 404);
            }
            
            $this->transaction(function($pdo) use ($lessonId) {
                // حذف البيانات المرتبطة
                $pdo->prepare("DELETE FROM lesson_notes WHERE lesson_id = ?")->execute([$lessonId]);
                $pdo->prepare("DELETE FROM lesson_progress WHERE lesson_id = ?")->execute([$lessonId]);
                $pdo->prepare("DELETE FROM lessons WHERE id = ?")->execute([$lessonId]);
            });
            
            $this->logActivity("Deleted lesson: {$lesson['name']}", 'lesson_delete', ['lesson_id' => $lessonId]);
            
            $this->sendSuccess(null, 'تم حذف الدرس بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to delete lesson', 'high', ['error' => $e->getMessage()]);
            $this->sendError('فشل في حذف الدرس: ' . $e->getMessage());
        }
    }
    
    // Helper Methods
    
    private function hasLessonAccess($courseId, $lessonId) {
        if (!$this->user) return false;
        
        // التحقق من الاشتراك في الدورة
        $stmt = $this->pdo->prepare("
            SELECT COUNT(*) FROM subscriptions 
            WHERE user_id = ? AND course_id = ? AND is_active = 1
        ");
        $stmt->execute([$this->user['id'], $courseId]);
        
        return $stmt->fetchColumn() > 0;
    }
    
    private function markLessonStarted($lessonId) {
        $stmt = $this->pdo->prepare("
            INSERT IGNORE INTO lesson_progress (user_id, lesson_id, started_at, last_accessed)
            VALUES (?, ?, NOW(), NOW())
        ");
        $stmt->execute([$this->user['id'], $lessonId]);
    }
    
    private function updateLastAccessed($lessonId) {
        $stmt = $this->pdo->prepare("
            UPDATE lesson_progress 
            SET last_accessed = NOW() 
            WHERE user_id = ? AND lesson_id = ?
        ");
        $stmt->execute([$this->user['id'], $lessonId]);
    }
    
    private function checkCourseCompletion($courseId) {
        // فحص ما إذا كانت جميع دروس الدورة مكتملة
        $stmt = $this->pdo->prepare("
            SELECT 
                COUNT(DISTINCT l.id) as total_lessons,
                COUNT(DISTINCT CASE WHEN lp.completed = 1 THEN lp.lesson_id END) as completed_lessons
            FROM lessons l
            JOIN sections s ON l.section_id = s.id
            LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = ?
            WHERE s.course_id = ? AND l.is_active = 1
        ");
        
        $stmt->execute([$this->user['id'], $courseId]);
        $progress = $stmt->fetch();
        
        if ($progress['total_lessons'] > 0 && $progress['completed_lessons'] == $progress['total_lessons']) {
            // إنشاء شهادة إكمال
            $this->createCertificate($courseId);
        }
    }
    
    private function createCertificate($courseId) {
        // التحقق من عدم وجود شهادة مسبقة
        $stmt = $this->pdo->prepare("
            SELECT id FROM course_completions 
            WHERE user_id = ? AND course_id = ?
        ");
        $stmt->execute([$this->user['id'], $courseId]);
        
        if ($stmt->fetch()) {
            return; // الشهادة موجودة مسبقاً
        }
        
        // إنشاء كود شهادة فريد
        $certificateCode = 'CERT-' . strtoupper(uniqid()) . '-' . $courseId;
        
        $stmt = $this->pdo->prepare("
            INSERT INTO course_completions (user_id, course_id, certificate_code, completed_at)
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->execute([$this->user['id'], $courseId, $certificateCode]);
        
        $this->logActivity('Course completed - Certificate generated', 'course_completion', [
            'course_id' => $courseId,
            'certificate_code' => $certificateCode
        ]);
    }
}
?>