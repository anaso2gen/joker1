<?php
/**
 * تحكم المستخدمين
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:40:51
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

require_once __DIR__ . '/BaseController.php';

class UserController extends BaseController {
    
    /**
     * الحصول على بيانات المستخدم الحالي
     */
    public function getCurrentUser() {
        $this->requireAuth();
        
        try {
            $stmt = $this->pdo->prepare("
                SELECT u.id, u.first_name, u.last_name, u.email, u.phone, u.avatar_url, 
                       u.is_admin, u.newsletter_subscribed, u.created_at, u.last_login,
                       COUNT(DISTINCT s.id) as enrolled_courses,
                       COUNT(DISTINCT CASE WHEN lp.completed = 1 THEN lp.id END) as completed_lessons,
                       COUNT(DISTINCT CASE WHEN cc.id IS NOT NULL THEN cc.id END) as certificates_earned
                FROM users u
                LEFT JOIN subscriptions s ON u.id = s.user_id AND s.is_active = 1
                LEFT JOIN lesson_progress lp ON u.id = lp.user_id
                LEFT JOIN course_completions cc ON u.id = cc.user_id
                WHERE u.id = ?
                GROUP BY u.id
            ");
            
            $stmt->execute([$this->user['id']]);
            $userData = $stmt->fetch();
            
            // إزالة البيانات الحساسة
            unset($userData['password_hash']);
            
            $this->sendSuccess(['user' => $userData]);
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to get current user data', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحميل بيانات المستخدم');
        }
    }
    
    /**
     * تحديث الملف الشخصي
     */
    public function updateProfile() {
        $this->requireAuth();
        
        try {
            $this->validateCSRF();
            
            $data = $this->getInputData();
            
            $errors = $this->validate($data, [
                'first_name' => 'required|min:2|max:50',
                'last_name' => 'required|min:2|max:50',
                'phone' => 'max:20'
            ]);
            
            if (!empty($errors)) {
                $this->sendError('البيانات المدخلة غير صحيحة', 400, $errors);
            }
            
            $updateData = [
                'first_name' => $this->sanitizeInput($data['first_name']),
                'last_name' => $this->sanitizeInput($data['last_name']),
                'phone' => $this->sanitizeInput($data['phone'] ?? ''),
                'newsletter_subscribed' => intval($data['newsletter_subscribed'] ?? 0)
            ];
            
            $this->transaction(function($pdo) use ($updateData) {
                $stmt = $pdo->prepare("
                    UPDATE users 
                    SET first_name = ?, last_name = ?, phone = ?, newsletter_subscribed = ?, updated_at = NOW()
                    WHERE id = ?
                ");
                
                $stmt->execute([
                    $updateData['first_name'],
                    $updateData['last_name'],
                    $updateData['phone'],
                    $updateData['newsletter_subscribed'],
                    $this->user['id']
                ]);
            });
            
            $this->logActivity('Profile updated', 'user_update');
            
            $this->sendSuccess(null, 'تم تحديث الملف الشخصي بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to update profile', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحديث الملف الشخصي: ' . $e->getMessage());
        }
    }
    
    /**
     * تغيير كلمة المرور
     */
    public function changePassword() {
        $this->requireAuth();
        
        try {
            $this->validateCSRF();
            
            $data = $this->getInputData();
            
            $errors = $this->validate($data, [
                'current_password' => 'required',
                'new_password' => 'required|min:8',
                'confirm_password' => 'required'
            ]);
            
            if (!empty($errors)) {
                $this->sendError('البيانات المدخلة غير صحيحة', 400, $errors);
            }
            
            // التحقق من كلمة المرور الحالية
            if (!password_verify($data['current_password'], $this->user['password_hash'])) {
                $this->sendError('كلمة المرور الحالية غير صحيحة');
            }
            
            // التحقق من تطابق كلمة المرور الجديدة
            if ($data['new_password'] !== $data['confirm_password']) {
                $this->sendError('كلمة المرور الجديدة وتأكيدها غير متطابقين');
            }
            
            // التحقق من قوة كلمة المرور
            if (!isStrongPassword($data['new_password'])) {
                $this->sendError('كلمة المرور يجب أن تحتوي على 8 أحرف على الأقل، وتشمل أحرف كبيرة وصغيرة وأرقام');
            }
            
            $newPasswordHash = password_hash($data['new_password'], PASSWORD_DEFAULT);
            
            $this->transaction(function($pdo) use ($newPasswordHash) {
                // تحديث كلمة المرور
                $stmt = $pdo->prepare("
                    UPDATE users 
                    SET password_hash = ?, updated_at = NOW()
                    WHERE id = ?
                ");
                $stmt->execute([$newPasswordHash, $this->user['id']]);
                
                // إنهاء جميع الجلسات الأخرى
                $stmt = $pdo->prepare("
                    DELETE FROM user_sessions 
                    WHERE user_id = ? AND session_id != ?
                ");
                $stmt->execute([$this->user['id'], session_id()]);
            });
            
            $this->logActivity('Password changed', 'security');
            $this->logSecurityEvent('Password changed successfully', 'low');
            
            $this->sendSuccess(null, 'تم تغيير كلمة المرور بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to change password', 'high', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تغيير كلمة المرور: ' . $e->getMessage());
        }
    }
    
    /**
     * رفع الصورة الشخصية
     */
    public function uploadAvatar() {
        $this->requireAuth();
        
        try {
            $this->validateCSRF();
            
            if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
                $this->sendError('لم يتم رفع أي صورة');
            }
            
            $uploadDir = __DIR__ . '/../../uploads/avatars';
            $avatarName = $this->handleFileUpload($_FILES['avatar'], $uploadDir, ['jpg', 'jpeg', 'png'], 2097152); // 2MB
            
            // إنشاء صورة مصغرة
            $originalPath = $uploadDir . '/' . $avatarName;
            $thumbnailPath = $uploadDir . '/thumb_' . $avatarName;
            
            createThumbnail($originalPath, $thumbnailPath, 150, 150);
            
            $avatarUrl = 'uploads/avatars/' . $avatarName;
            
            $this->transaction(function($pdo) use ($avatarUrl) {
                // حذف الصورة القديمة
                $stmt = $pdo->prepare("SELECT avatar_url FROM users WHERE id = ?");
                $stmt->execute([$this->user['id']]);
                $oldAvatar = $stmt->fetchColumn();
                
                if ($oldAvatar && file_exists(__DIR__ . '/../../' . $oldAvatar)) {
                    unlink(__DIR__ . '/../../' . $oldAvatar);
                }
                
                // تحديث الصورة الجديدة
                $stmt = $pdo->prepare("
                    UPDATE users 
                    SET avatar_url = ?, updated_at = NOW()
                    WHERE id = ?
                ");
                $stmt->execute([$avatarUrl, $this->user['id']]);
            });
            
            $this->logActivity('Avatar updated', 'user_update');
            
            $this->sendSuccess(['avatar_url' => $avatarUrl], 'تم تحديث الصورة الشخصية بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to upload avatar', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في رفع الصورة: ' . $e->getMessage());
        }
    }
    
    /**
     * الحصول على دورات المستخدم
     */
    public function getUserCourses() {
        $this->requireAuth();
        
        try {
            $stmt = $this->pdo->prepare("
                SELECT c.*, s.created_at as enrolled_at, s.price_paid,
                       COUNT(DISTINCT l.id) as total_lessons,
                       COUNT(DISTINCT CASE WHEN lp.completed = 1 THEN lp.lesson_id END) as completed_lessons,
                       ROUND((COUNT(DISTINCT CASE WHEN lp.completed = 1 THEN lp.lesson_id END) / COUNT(DISTINCT l.id)) * 100, 2) as progress_percentage
                FROM subscriptions s
                JOIN courses c ON s.course_id = c.id
                LEFT JOIN sections sec ON c.id = sec.course_id
                LEFT JOIN lessons l ON sec.id = l.section_id AND l.is_active = 1
                LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = s.user_id
                WHERE s.user_id = ? AND s.is_active = 1
                GROUP BY c.id, s.id
                ORDER BY s.created_at DESC
            ");
            
            $stmt->execute([$this->user['id']]);
            $courses = $stmt->fetchAll();
            
            $this->sendSuccess(['courses' => $courses]);
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to get user courses', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحميل دورات المستخدم');
        }
    }
    
    /**
     * الحصول على تقدم المستخدم
     */
    public function getUserProgress() {
        $this->requireAuth();
        
        try {
            // الإحصائيات العامة
            $statsStmt = $this->pdo->prepare("
                SELECT 
                    COUNT(DISTINCT s.course_id) as total_courses,
                    COUNT(DISTINCT CASE WHEN lp.completed = 1 THEN lp.lesson_id END) as completed_lessons,
                    COALESCE(SUM(FLOOR(lp.last_position / 3600)), 0) as watch_hours
                FROM subscriptions s
                LEFT JOIN sections sec ON s.course_id = sec.course_id
                LEFT JOIN lessons l ON sec.id = l.section_id AND l.is_active = 1
                LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = s.user_id
                WHERE s.user_id = ? AND s.is_active = 1
            ");
            
            $statsStmt->execute([$this->user['id']]);
            $stats = $statsStmt->fetch();
            
            // تقدم الدورات
            $coursesStmt = $this->pdo->prepare("
                SELECT c.id, c.name, c.image_url,
                       COUNT(DISTINCT l.id) as total_lessons,
                       COUNT(DISTINCT CASE WHEN lp.completed = 1 THEN lp.lesson_id END) as completed_lessons,
                       ROUND((COUNT(DISTINCT CASE WHEN lp.completed = 1 THEN lp.lesson_id END) / COUNT(DISTINCT l.id)) * 100, 2) as progress
                FROM subscriptions s
                JOIN courses c ON s.course_id = c.id
                LEFT JOIN sections sec ON c.id = sec.course_id
                LEFT JOIN lessons l ON sec.id = l.section_id AND l.is_active = 1
                LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = s.user_id
                WHERE s.user_id = ? AND s.is_active = 1
                GROUP BY c.id
                ORDER BY progress DESC, s.created_at DESC
                LIMIT 10
            ");
            
            $coursesStmt->execute([$this->user['id']]);
            $courses = $coursesStmt->fetchAll();
            
            $this->sendSuccess([
                'stats' => $stats,
                'courses' => $courses
            ]);
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to get user progress', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحميل تقدم المستخدم');
        }
    }
    
    /**
     * الحصول على النشاط الأخير
     */
    public function getRecentActivity() {
        $this->requireAuth();
        
        try {
            $stmt = $this->pdo->prepare("
                SELECT 'lesson' as type, l.name as title, c.name as course_name, 
                       lp.last_accessed as activity_time, c.id as course_id, l.id as lesson_id
                FROM lesson_progress lp
                JOIN lessons l ON lp.lesson_id = l.id
                JOIN sections s ON l.section_id = s.id
                JOIN courses c ON s.course_id = c.id
                WHERE lp.user_id = ?
                ORDER BY lp.last_accessed DESC
                LIMIT 20
            ");
            
            $stmt->execute([$this->user['id']]);
            $activities = $stmt->fetchAll();
            
            $this->sendSuccess(['activities' => $activities]);
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to get recent activity', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحميل النشاط الأخير');
        }
    }
    
    /**
     * الحصول على الشهادات
     */
    public function getCertificates() {
        $this->requireAuth();
        
        try {
            $stmt = $this->pdo->prepare("
                SELECT c.id, c.name, c.image_url, cc.completed_at, cc.certificate_code
                FROM course_completions cc
                JOIN courses c ON cc.course_id = c.id
                WHERE cc.user_id = ?
                ORDER BY cc.completed_at DESC
            ");
            
            $stmt->execute([$this->user['id']]);
            $certificates = $stmt->fetchAll();
            
            $this->sendSuccess(['certificates' => $certificates]);
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to get certificates', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحميل الشهادات');
        }
    }
    
    /**
     * إدارة قائمة المفضلة
     */
    public function toggleWishlist() {
        $this->requireAuth();
        
        try {
            $data = $this->getInputData();
            $courseId = intval($data['course_id'] ?? 0);
            
            if (!$courseId) {
                $this->sendError('معرف الدورة مطلوب');
            }
            
            // التحقق من وجود الدورة
            $stmt = $this->pdo->prepare("SELECT name FROM courses WHERE id = ? AND is_active = 1");
            $stmt->execute([$courseId]);
            $course = $stmt->fetch();
            
            if (!$course) {
                $this->sendError('الدورة غير موجودة', 404);
            }
            
            // التحقق من وجودها في المفضلة
            $stmt = $this->pdo->prepare("
                SELECT id FROM wishlist WHERE user_id = ? AND course_id = ?
            ");
            $stmt->execute([$this->user['id'], $courseId]);
            $wishlistItem = $stmt->fetch();
            
            $added = false;
            
            if ($wishlistItem) {
                // إزالة من المفضلة
                $stmt = $this->pdo->prepare("DELETE FROM wishlist WHERE id = ?");
                $stmt->execute([$wishlistItem['id']]);
                $message = 'تم إزالة الدورة من المفضلة';
            } else {
                // إضافة للمفضلة
                $stmt = $this->pdo->prepare("
                    INSERT INTO wishlist (user_id, course_id, created_at)
                    VALUES (?, ?, NOW())
                ");
                $stmt->execute([$this->user['id'], $courseId]);
                $added = true;
                $message = 'تم إضافة الدورة للمفضلة';
            }
            
            $this->logActivity($added ? 'Added to wishlist' : 'Removed from wishlist', 'wishlist', [
                'course_id' => $courseId,
                'course_name' => $course['name']
            ]);
            
            $this->sendSuccess(['added' => $added], $message);
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to toggle wishlist', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحديث المفضلة: ' . $e->getMessage());
        }
    }
    
    /**
     * الحصول على قائمة المفضلة
     */
    public function getWishlist() {
        $this->requireAuth();
        
        try {
            $stmt = $this->pdo->prepare("
                SELECT c.*, w.created_at as added_at,
                       COUNT(DISTINCT s.id) as students_count,
                       AVG(cr.rating) as avg_rating
                FROM wishlist w
                JOIN courses c ON w.course_id = c.id
                LEFT JOIN subscriptions s ON c.id = s.course_id AND s.is_active = 1
                LEFT JOIN course_reviews cr ON c.id = cr.course_id AND cr.is_approved = 1
                WHERE w.user_id = ? AND c.is_active = 1
                GROUP BY c.id
                ORDER BY w.created_at DESC
            ");
            
            $stmt->execute([$this->user['id']]);
            $wishlist = $stmt->fetchAll();
            
            $this->sendSuccess(['wishlist' => $wishlist]);
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to get wishlist', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحميل المفضلة');
        }
    }
}
?>