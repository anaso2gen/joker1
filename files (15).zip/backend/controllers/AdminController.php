<?php
/**
 * تحكم لوحة الإدارة
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:47:59
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

require_once __DIR__ . '/BaseController.php';

class AdminController extends BaseController {
    
    /**
     * الحصول على إحصائيات لوحة الإدارة
     */
    public function getDashboardStats() {
        $this->requireAdmin();
        
        try {
            // الإحصائيات الأساسية
            $stats = [];
            
            // إجمالي المستخدمين
            $stmt = $this->pdo->prepare("
                SELECT COUNT(*) as total_users,
                       COUNT(CASE WHEN is_active = 1 THEN 1 END) as active_users,
                       COUNT(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 END) as new_users_30d
                FROM users
            ");
            $stmt->execute();
            $userStats = $stmt->fetch();
            $stats['users'] = $userStats;
            
            // إجمالي الدورات
            $stmt = $this->pdo->prepare("
                SELECT COUNT(*) as total_courses,
                       COUNT(CASE WHEN is_active = 1 THEN 1 END) as active_courses,
                       COUNT(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 END) as new_courses_30d
                FROM courses
            ");
            $stmt->execute();
            $courseStats = $stmt->fetch();
            $stats['courses'] = $courseStats;
            
            // الاشتراكات والإيرادات
            $stmt = $this->pdo->prepare("
                SELECT COUNT(*) as total_subscriptions,
                       COUNT(CASE WHEN is_active = 1 THEN 1 END) as active_subscriptions,
                       SUM(price_paid) as total_revenue,
                       SUM(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN price_paid ELSE 0 END) as revenue_30d
                FROM subscriptions
            ");
            $stmt->execute();
            $subscriptionStats = $stmt->fetch();
            $stats['subscriptions'] = $subscriptionStats;
            
            // الدروس والتقدم
            $stmt = $this->pdo->prepare("
                SELECT COUNT(DISTINCT l.id) as total_lessons,
                       COUNT(DISTINCT lp.id) as total_progress,
                       COUNT(DISTINCT CASE WHEN lp.completed = 1 THEN lp.id END) as completed_lessons
                FROM lessons l
                LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id
                WHERE l.is_active = 1
            ");
            $stmt->execute();
            $lessonStats = $stmt->fetch();
            $stats['lessons'] = $lessonStats;
            
            // الشهادات
            $stmt = $this->pdo->prepare("
                SELECT COUNT(*) as total_certificates,
                       COUNT(CASE WHEN completed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 END) as certificates_30d
                FROM course_completions
            ");
            $stmt->execute();
            $certificateStats = $stmt->fetch();
            $stats['certificates'] = $certificateStats;
            
            // النشاط الأخير
            $stmt = $this->pdo->prepare("
                SELECT al.*, u.first_name, u.last_name, u.email
                FROM activity_logs al
                LEFT JOIN users u ON al.user_id = u.id
                ORDER BY al.created_at DESC
                LIMIT 20
            ");
            $stmt->execute();
            $recentActivity = $stmt->fetchAll();
            
            // أفضل الدورات
            $stmt = $this->pdo->prepare("
                SELECT c.id, c.name, c.image_url,
                       COUNT(s.id) as enrollment_count,
                       SUM(s.price_paid) as revenue,
                       AVG(cr.rating) as avg_rating
                FROM courses c
                LEFT JOIN subscriptions s ON c.id = s.course_id AND s.is_active = 1
                LEFT JOIN course_reviews cr ON c.id = cr.course_id AND cr.is_approved = 1
                WHERE c.is_active = 1
                GROUP BY c.id
                ORDER BY enrollment_count DESC
                LIMIT 10
            ");
            $stmt->execute();
            $topCourses = $stmt->fetchAll();
            
            // الإيرادات الشهرية (آخر 12 شهر)
            $stmt = $this->pdo->prepare("
                SELECT DATE_FORMAT(created_at, '%Y-%m') as month,
                       SUM(price_paid) as revenue,
                       COUNT(*) as subscriptions
                FROM subscriptions
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
                GROUP BY DATE_FORMAT(created_at, '%Y-%m')
                ORDER BY month ASC
            ");
            $stmt->execute();
            $monthlyRevenue = $stmt->fetchAll();
            
            $this->sendSuccess([
                'stats' => $stats,
                'recent_activity' => $recentActivity,
                'top_courses' => $topCourses,
                'monthly_revenue' => $monthlyRevenue
            ]);
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to get dashboard stats', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحميل إحصائيات لوحة الإدارة');
        }
    }
    
    /**
     * إدارة المستخدمين
     */
    public function getUsers() {
        $this->requireAdmin();
        
        try {
            $filters = $this->getInputData();
            $page = max(1, intval($filters['page'] ?? 1));
            $perPage = min(100, max(1, intval($filters['per_page'] ?? 20)));
            
            $baseQuery = "
                SELECT u.*, 
                       COUNT(DISTINCT s.id) as courses_enrolled,
                       COUNT(DISTINCT cc.id) as certificates_earned,
                       SUM(s.price_paid) as total_spent
                FROM users u
                LEFT JOIN subscriptions s ON u.id = s.user_id AND s.is_active = 1
                LEFT JOIN course_completions cc ON u.id = cc.user_id
            ";
            
            $allowedFilters = ['search', 'status', 'is_admin', 'email_verified', 'date_from', 'date_to'];
            list($query, $params) = $this->applyFilters($baseQuery, $filters, $allowedFilters);
            
            $query .= " GROUP BY u.id";
            
            // حساب العدد الإجمالي
            $totalUsers = $this->getTotalCount(str_replace("SELECT u.*, COUNT(DISTINCT s.id) as courses_enrolled, COUNT(DISTINCT cc.id) as certificates_earned, SUM(s.price_paid) as total_spent", "SELECT COUNT(DISTINCT u.id)", $query), $params);
            
            // تطبيق الترتيب والتصفح
            $orderBy = $filters['sort'] ?? 'u.created_at';
            $orderDir = $filters['order'] ?? 'DESC';
            $query = $this->applyPagination($query, $page, $perPage, $orderBy, $orderDir);
            
            $stmt = $this->pdo->prepare($query);
            $stmt->execute($params);
            $users = $stmt->fetchAll();
            
            // إزالة البيانات الحساسة
            foreach ($users as &$user) {
                unset($user['password_hash'], $user['email_verification_token']);
            }
            
            $this->sendSuccess([
                'users' => $users,
                'pagination' => [
                    'current_page' => $page,
                    'per_page' => $perPage,
                    'total' => $totalUsers,
                    'total_pages' => ceil($totalUsers / $perPage)
                ]
            ]);
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to get users list', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحميل قائمة المستخدمين');
        }
    }
    
    /**
     * تحديث حالة المستخدم
     */
    public function updateUserStatus() {
        $this->requireAdmin();
        
        try {
            $this->validateCSRF();
            
            $data = $this->getInputData();
            $userId = intval($data['user_id'] ?? 0);
            $isActive = intval($data['is_active'] ?? 0);
            
            if (!$userId) {
                $this->sendError('معرف المستخدم مطلوب');
            }
            
            // التحقق من وجود المستخدم
            $stmt = $this->pdo->prepare("SELECT email, first_name, last_name FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();
            
            if (!$user) {
                $this->sendError('المستخدم غير موجود', 404);
            }
            
            // منع المستخدم من إلغاء تفعيل نفسه
            if ($userId == $this->user['id'] && !$isActive) {
                $this->sendError('لا يمكنك إلغاء تفعيل حسابك الخاص');
            }
            
            $stmt = $this->pdo->prepare("
                UPDATE users 
                SET is_active = ?, updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$isActive, $userId]);
            
            $this->logActivity($isActive ? 'User activated' : 'User deactivated', 'user_management', [
                'target_user_id' => $userId,
                'target_user_email' => $user['email']
            ]);
            
            $this->sendSuccess(null, $isActive ? 'تم تفعيل المستخدم بنجاح' : 'تم إلغاء تفعيل المستخدم بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to update user status', 'high', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحديث حالة المستخدم');
        }
    }
    
    /**
     * حذف مستخدم
     */
    public function deleteUser() {
        $this->requireAdmin();
        
        try {
            $this->validateCSRF();
            
            $userId = intval($_POST['user_id'] ?? $_GET['id'] ?? 0);
            
            if (!$userId) {
                $this->sendError('معرف المستخدم مطلوب');
            }
            
            // منع المستخدم من حذف نفسه
            if ($userId == $this->user['id']) {
                $this->sendError('لا يمكنك حذف حسابك الخاص');
            }
            
            // التحقق من وجود المستخدم
            $stmt = $this->pdo->prepare("SELECT email, first_name, last_name, avatar_url FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();
            
            if (!$user) {
                $this->sendError('المستخدم غير موجود', 404);
            }
            
            $this->transaction(function($pdo) use ($userId, $user) {
                // حذف البيانات المرتبطة
                $pdo->prepare("DELETE FROM lesson_notes WHERE user_id = ?")->execute([$userId]);
                $pdo->prepare("DELETE FROM lesson_progress WHERE user_id = ?")->execute([$userId]);
                $pdo->prepare("DELETE FROM course_reviews WHERE user_id = ?")->execute([$userId]);
                $pdo->prepare("DELETE FROM course_completions WHERE user_id = ?")->execute([$userId]);
                $pdo->prepare("DELETE FROM subscriptions WHERE user_id = ?")->execute([$userId]);
                $pdo->prepare("DELETE FROM wishlist WHERE user_id = ?")->execute([$userId]);
                $pdo->prepare("DELETE FROM user_sessions WHERE user_id = ?")->execute([$userId]);
                $pdo->prepare("DELETE FROM password_resets WHERE user_id = ?")->execute([$userId]);
                $pdo->prepare("DELETE FROM activity_logs WHERE user_id = ?")->execute([$userId]);
                $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$userId]);
                
                // حذف الصورة الشخصية
                if ($user['avatar_url'] && file_exists(__DIR__ . '/../../' . $user['avatar_url'])) {
                    unlink(__DIR__ . '/../../' . $user['avatar_url']);
                }
            });
            
            $this->logActivity('User deleted', 'user_management', [
                'target_user_id' => $userId,
                'target_user_email' => $user['email']
            ]);
            
            $this->sendSuccess(null, 'تم حذف المستخدم بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to delete user', 'high', ['error' => $e->getMessage()]);
            $this->sendError('فشل في حذف المستخدم');
        }
    }
    
    /**
     * إدارة الأقسام
     */
    public function getSections() {
        $this->requireAdmin();
        
        try {
            $courseId = intval($_GET['course_id'] ?? 0);
            
            if (!$courseId) {
                $this->sendError('معرف الدورة مطلوب');
            }
            
            $stmt = $this->pdo->prepare("
                SELECT s.*, 
                       COUNT(l.id) as lessons_count,
                       SUM(l.duration) as total_duration
                FROM sections s
                LEFT JOIN lessons l ON s.id = l.section_id AND l.is_active = 1
                WHERE s.course_id = ?
                GROUP BY s.id
                ORDER BY s.sort_order ASC
            ");
            
            $stmt->execute([$courseId]);
            $sections = $stmt->fetchAll();
            
            $this->sendSuccess(['sections' => $sections]);
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to get sections', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحميل الأقسام');
        }
    }
    
    /**
     * إنشاء قسم جديد
     */
    public function createSection() {
        $this->requireAdmin();
        
        try {
            $this->validateCSRF();
            
            $data = $this->getInputData();
            
            $errors = $this->validate($data, [
                'name' => 'required|min:3|max:255',
                'course_id' => 'required|numeric'
            ]);
            
            if (!empty($errors)) {
                $this->sendError('البيانات المدخلة غير صحيحة', 400, $errors);
            }
            
            $sectionData = [
                'name' => $this->sanitizeInput($data['name']),
                'description' => $this->sanitizeInput($data['description'] ?? ''),
                'course_id' => intval($data['course_id']),
                'sort_order' => intval($data['sort_order'] ?? 0)
            ];
            
            // التحقق من وجود الدورة
            $stmt = $this->pdo->prepare("SELECT name FROM courses WHERE id = ?");
            $stmt->execute([$sectionData['course_id']]);
            $course = $stmt->fetch();
            
            if (!$course) {
                $this->sendError('الدورة غير موجودة', 404);
            }
            
            $sectionId = $this->transaction(function($pdo) use ($sectionData) {
                // تحديد الترتيب تلقائياً إذا لم يحدد
                if ($sectionData['sort_order'] == 0) {
                    $stmt = $pdo->prepare("
                        SELECT COALESCE(MAX(sort_order), 0) + 1 
                        FROM sections WHERE course_id = ?
                    ");
                    $stmt->execute([$sectionData['course_id']]);
                    $sectionData['sort_order'] = $stmt->fetchColumn();
                }
                
                $stmt = $pdo->prepare("
                    INSERT INTO sections (name, description, course_id, sort_order, created_at)
                    VALUES (?, ?, ?, ?, NOW())
                ");
                
                $stmt->execute([
                    $sectionData['name'],
                    $sectionData['description'],
                    $sectionData['course_id'],
                    $sectionData['sort_order']
                ]);
                
                return $pdo->lastInsertId();
            });
            
            $this->logActivity("Created section: {$sectionData['name']}", 'section_create', [
                'section_id' => $sectionId,
                'course_id' => $sectionData['course_id']
            ]);
            
            $this->sendSuccess(['section_id' => $sectionId], 'تم إنشاء القسم بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to create section', 'high', ['error' => $e->getMessage()]);
            $this->sendError('فشل في إنشاء القسم');
        }
    }
    
    /**
     * تحديث قسم
     */
    public function updateSection() {
        $this->requireAdmin();
        
        try {
            $this->validateCSRF();
            
            $sectionId = intval($_POST['section_id'] ?? $_GET['id'] ?? 0);
            $data = $this->getInputData();
            
            if (!$sectionId) {
                $this->sendError('معرف القسم مطلوب');
            }
            
            // التحقق من وجود القسم
            $stmt = $this->pdo->prepare("SELECT * FROM sections WHERE id = ?");
            $stmt->execute([$sectionId]);
            $section = $stmt->fetch();
            
            if (!$section) {
                $this->sendError('القسم غير موجود', 404);
            }
            
            $errors = $this->validate($data, [
                'name' => 'required|min:3|max:255'
            ]);
            
            if (!empty($errors)) {
                $this->sendError('البيانات المدخلة غير صحيحة', 400, $errors);
            }
            
            $updateData = [
                'name' => $this->sanitizeInput($data['name']),
                'description' => $this->sanitizeInput($data['description'] ?? ''),
                'sort_order' => intval($data['sort_order'] ?? $section['sort_order'])
            ];
            
            $stmt = $this->pdo->prepare("
                UPDATE sections 
                SET name = ?, description = ?, sort_order = ?, updated_at = NOW()
                WHERE id = ?
            ");
            
            $stmt->execute([
                $updateData['name'],
                $updateData['description'],
                $updateData['sort_order'],
                $sectionId
            ]);
            
            $this->logActivity("Updated section: {$updateData['name']}", 'section_update', ['section_id' => $sectionId]);
            
            $this->sendSuccess(null, 'تم تحديث القسم بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to update section', 'high', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحديث القسم');
        }
    }
    
    /**
     * حذف قسم
     */
    public function deleteSection() {
        $this->requireAdmin();
        
        try {
            $this->validateCSRF();
            
            $sectionId = intval($_POST['section_id'] ?? $_GET['id'] ?? 0);
            
            if (!$sectionId) {
                $this->sendError('معرف القسم مطلوب');
            }
            
            // التحقق من وجود القسم
            $stmt = $this->pdo->prepare("SELECT name FROM sections WHERE id = ?");
            $stmt->execute([$sectionId]);
            $section = $stmt->fetch();
            
            if (!$section) {
                $this->sendError('القسم غير موجود', 404);
            }
            
            // التحقق من وجود دروس
            $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM lessons WHERE section_id = ?");
            $stmt->execute([$sectionId]);
            $lessonsCount = $stmt->fetchColumn();
            
            if ($lessonsCount > 0) {
                $this->sendError('لا يمكن حذف القسم لوجود دروس به، يرجى حذف الدروس أولاً');
            }
            
            $stmt = $this->pdo->prepare("DELETE FROM sections WHERE id = ?");
            $stmt->execute([$sectionId]);
            
            $this->logActivity("Deleted section: {$section['name']}", 'section_delete', ['section_id' => $sectionId]);
            
            $this->sendSuccess(null, 'تم حذف القسم بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to delete section', 'high', ['error' => $e->getMessage()]);
            $this->sendError('فشل في حذف القسم');
        }
    }
    
    /**
     * الحصول على التقييمات
     */
    public function getReviews() {
        $this->requireAdmin();
        
        try {
            $filters = $this->getInputData();
            $page = max(1, intval($filters['page'] ?? 1));
            $perPage = min(100, max(1, intval($filters['per_page'] ?? 20)));
            
            $baseQuery = "
                SELECT cr.*, c.name as course_name, u.first_name, u.last_name, u.email
                FROM course_reviews cr
                JOIN courses c ON cr.course_id = c.id
                JOIN users u ON cr.user_id = u.id
            ";
            
            $allowedFilters = ['search', 'course_id', 'rating', 'is_approved', 'date_from', 'date_to'];
            list($query, $params) = $this->applyFilters($baseQuery, $filters, $allowedFilters);
            
            // حساب العدد الإجمالي
            $totalReviews = $this->getTotalCount($query, $params);
            
            // تطبيق الترتيب والتصفح
            $orderBy = $filters['sort'] ?? 'cr.created_at';
            $orderDir = $filters['order'] ?? 'DESC';
            $query = $this->applyPagination($query, $page, $perPage, $orderBy, $orderDir);
            
            $stmt = $this->pdo->prepare($query);
            $stmt->execute($params);
            $reviews = $stmt->fetchAll();
            
            $this->sendSuccess([
                'reviews' => $reviews,
                'pagination' => [
                    'current_page' => $page,
                    'per_page' => $perPage,
                    'total' => $totalReviews,
                    'total_pages' => ceil($totalReviews / $perPage)
                ]
            ]);
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to get reviews', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحميل التقييمات');
        }
    }
    
    /**
     * الموافقة على التقييم أو رفضه
     */
    public function updateReviewStatus() {
        $this->requireAdmin();
        
        try {
            $this->validateCSRF();
            
            $data = $this->getInputData();
            $reviewId = intval($data['review_id'] ?? 0);
            $isApproved = intval($data['is_approved'] ?? 0);
            
            if (!$reviewId) {
                $this->sendError('معرف التقييم مطلوب');
            }
            
            // التحقق من وجود التقييم
            $stmt = $this->pdo->prepare("
                SELECT cr.*, c.name as course_name, u.email as user_email
                FROM course_reviews cr
                JOIN courses c ON cr.course_id = c.id
                JOIN users u ON cr.user_id = u.id
                WHERE cr.id = ?
            ");
            $stmt->execute([$reviewId]);
            $review = $stmt->fetch();
            
            if (!$review) {
                $this->sendError('التقييم غير موجود', 404);
            }
            
            $stmt = $this->pdo->prepare("
                UPDATE course_reviews 
                SET is_approved = ?, approved_at = NOW(), approved_by = ?
                WHERE id = ?
            ");
            $stmt->execute([$isApproved, $this->user['id'], $reviewId]);
            
            $this->logActivity($isApproved ? 'Review approved' : 'Review rejected', 'review_moderation', [
                'review_id' => $reviewId,
                'course_name' => $review['course_name'],
                'user_email' => $review['user_email']
            ]);
            
            $this->sendSuccess(null, $isApproved ? 'تم قبول التقييم' : 'تم رفض التقييم');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to update review status', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحديث حالة التقييم');
        }
    }
    
    /**
     * الحصول على سجلات النشاط
     */
    public function getActivityLogs() {
        $this->requireAdmin();
        
        try {
            $filters = $this->getInputData();
            $page = max(1, intval($filters['page'] ?? 1));
            $perPage = min(100, max(1, intval($filters['per_page'] ?? 50)));
            
            $baseQuery = "
                SELECT al.*, u.first_name, u.last_name, u.email
                FROM activity_logs al
                LEFT JOIN users u ON al.user_id = u.id
            ";
            
            $allowedFilters = ['search', 'category', 'user_id', 'date_from', 'date_to'];
            list($query, $params) = $this->applyFilters($baseQuery, $filters, $allowedFilters);
            
            // حساب العدد الإجمالي
            $totalLogs = $this->getTotalCount($query, $params);
            
            // تطبيق الترتيب والتصفح
            $query = $this->applyPagination($query, $page, $perPage, 'al.created_at', 'DESC');
            
            $stmt = $this->pdo->prepare($query);
            $stmt->execute($params);
            $logs = $stmt->fetchAll();
            
            $this->sendSuccess([
                'logs' => $logs,
                'pagination' => [
                    'current_page' => $page,
                    'per_page' => $perPage,
                    'total' => $totalLogs,
                    'total_pages' => ceil($totalLogs / $perPage)
                ]
            ]);
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to get activity logs', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحميل سجلات النشاط');
        }
    }
    
    /**
     * النسخ الاحتياطي للبيانات
     */
    public function createBackup() {
        $this->requireAdmin();
        
        try {
            $this->validateCSRF();
            
            $backupDir = __DIR__ . '/../../backups';
            if (!is_dir($backupDir)) {
                mkdir($backupDir, 0755, true);
            }
            
            $timestamp = date('Y-m-d_H-i-s');
            $backupFile = $backupDir . "/backup_{$timestamp}.sql";
            
            // تشغيل mysqldump
            $command = sprintf(
                'mysqldump --host=%s --user=%s --password=%s %s > %s 2>&1',
                escapeshellarg(DB_HOST),
                escapeshellarg(DB_USER),
                escapeshellarg(DB_PASS),
                escapeshellarg(DB_NAME),
                escapeshellarg($backupFile)
            );
            
            $output = [];
            $returnVar = 0;
            exec($command, $output, $returnVar);
            
            if ($returnVar !== 0) {
                throw new Exception('فشل في إنشاء النسخة الاحتياطية: ' . implode("\n", $output));
            }
            
            // ضغط الملف
            $zipFile = $backupFile . '.zip';
            $zip = new ZipArchive();
            
            if ($zip->open($zipFile, ZipArchive::CREATE) === TRUE) {
                $zip->addFile($backupFile, basename($backupFile));
                $zip->close();
                unlink($backupFile); // حذف الملف غير المضغوط
                $backupFile = $zipFile;
            }
            
            $this->logActivity('Database backup created', 'system', [
                'backup_file' => basename($backupFile),
                'file_size' => filesize($backupFile)
            ]);
            
            $this->sendSuccess([
                'backup_file' => basename($backupFile),
                'file_size' => formatBytes(filesize($backupFile)),
                'download_url' => 'api.php?action=download_backup&file=' . basename($backupFile)
            ], 'تم إنشاء النسخة الاحتياطية بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to create backup', 'high', ['error' => $e->getMessage()]);
            $this->sendError('فشل في إنشاء النسخة الاحتياطية: ' . $e->getMessage());
        }
    }
    
    /**
     * تحميل النسخة الاحتياطية
     */
    public function downloadBackup() {
        $this->requireAdmin();
        
        try {
            $fileName = $_GET['file'] ?? '';
            
            if (empty($fileName) || !preg_match('/^backup_[\d\-_]+\.sql\.zip$/', $fileName)) {
                $this->sendError('اسم الملف غير صحيح');
            }
            
            $filePath = __DIR__ . '/../../backups/' . $fileName;
            
            if (!file_exists($filePath)) {
                $this->sendError('الملف غير موجود', 404);
            }
            
            $this->logActivity('Backup downloaded', 'system', ['backup_file' => $fileName]);
            
            // تحميل الملف
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="' . $fileName . '"');
            header('Content-Length: ' . filesize($filePath));
            header('Cache-Control: no-cache, must-revalidate');
            header('Pragma: no-cache');
            
            readfile($filePath);
            exit;
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to download backup', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحميل النسخة الاحتياطية');
        }
    }
}
?>