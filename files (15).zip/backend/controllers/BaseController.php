<?php
/**
 * الكلاس الأساسي للتحكم
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:36:31
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

abstract class BaseController {
    protected $pdo;
    protected $sessionManager;
    protected $user;
    
    public function __construct() {
        try {
            $this->pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
                DB_USER, DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
        } catch (PDOException $e) {
            $this->sendError('Database connection failed', 500);
        }
        
        // تهيئة مدير الجلسات
        require_once __DIR__ . '/../../session.php';
        $this->sessionManager = $sessionManager ?? null;
        
        // الحصول على المستخدم الحالي
        if ($this->sessionManager && $this->sessionManager->isLoggedIn()) {
            $this->user = $this->sessionManager->getCurrentUser();
        }
    }
    
    /**
     * إرسال استجابة JSON ناجحة
     */
    protected function sendSuccess($data = null, $message = null) {
        $response = ['success' => true];
        
        if ($message !== null) {
            $response['message'] = $message;
        }
        
        if ($data !== null) {
            $response['data'] = $data;
        }
        
        $this->sendResponse($response);
    }
    
    /**
     * إرسال استجابة JSON خطأ
     */
    protected function sendError($message, $code = 400, $errors = null) {
        http_response_code($code);
        
        $response = [
            'success' => false,
            'message' => $message
        ];
        
        if ($errors !== null) {
            $response['errors'] = $errors;
        }
        
        $this->sendResponse($response);
    }
    
    /**
     * إرسال استجابة JSON
     */
    protected function sendResponse($data) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    /**
     * التحقق من تسجيل الدخول
     */
    protected function requireAuth() {
        if (!$this->user) {
            $this->sendError('Authentication required', 401);
        }
    }
    
    /**
     * التحقق من صلاحيات الإدارة
     */
    protected function requireAdmin() {
        $this->requireAuth();
        
        if (!$this->user['is_admin']) {
            $this->sendError('Admin privileges required', 403);
        }
    }
    
    /**
     * التحقق من رمز CSRF
     */
    protected function validateCSRF($token = null) {
        if ($token === null) {
            $input = json_decode(file_get_contents('php://input'), true);
            $token = $input['csrf_token'] ?? $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? null;
        }
        
        if (!$token || !verifyCSRFToken($token)) {
            $this->sendError('Invalid CSRF token', 403);
        }
    }
    
    /**
     * تنظيف المدخلات
     */
    protected function sanitizeInput($input) {
        if (is_array($input)) {
            return array_map([$this, 'sanitizeInput'], $input);
        }
        
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    }
    
    /**
     * التحقق من صحة البيانات
     */
    protected function validate($data, $rules) {
        $errors = [];
        
        foreach ($rules as $field => $rule) {
            $value = $data[$field] ?? null;
            $rulesParts = explode('|', $rule);
            
            foreach ($rulesParts as $rulePart) {
                $ruleName = $rulePart;
                $ruleValue = null;
                
                if (strpos($rulePart, ':') !== false) {
                    list($ruleName, $ruleValue) = explode(':', $rulePart, 2);
                }
                
                switch ($ruleName) {
                    case 'required':
                        if (empty($value)) {
                            $errors[$field] = "الحقل $field مطلوب";
                        }
                        break;
                        
                    case 'email':
                        if ($value && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                            $errors[$field] = "الحقل $field يجب أن يكون بريد إلكتروني صحيح";
                        }
                        break;
                        
                    case 'min':
                        if ($value && strlen($value) < intval($ruleValue)) {
                            $errors[$field] = "الحقل $field يجب أن يكون $ruleValue أحرف على الأقل";
                        }
                        break;
                        
                    case 'max':
                        if ($value && strlen($value) > intval($ruleValue)) {
                            $errors[$field] = "الحقل $field يجب أن يكون $ruleValue أحرف كحد أقصى";
                        }
                        break;
                        
                    case 'numeric':
                        if ($value && !is_numeric($value)) {
                            $errors[$field] = "الحقل $field يجب أن يكون رقماً";
                        }
                        break;
                        
                    case 'unique':
                        list($table, $column) = explode(',', $ruleValue);
                        if ($value && $this->recordExists($table, $column, $value)) {
                            $errors[$field] = "القيمة في الحقل $field موجودة مسبقاً";
                        }
                        break;
                }
            }
        }
        
        return $errors;
    }
    
    /**
     * التحقق من وجود السجل
     */
    protected function recordExists($table, $column, $value, $excludeId = null) {
        $sql = "SELECT COUNT(*) FROM $table WHERE $column = ?";
        $params = [$value];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetchColumn() > 0;
    }
    
    /**
     * تسجيل نشاط النظام
     */
    protected function logActivity($description, $category = 'general', $additionalData = []) {
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO activity_logs (user_id, category, description, ip_address, user_agent, additional_data, created_at)
                VALUES (?, ?, ?, ?, ?, ?, NOW())
            ");
            
            $stmt->execute([
                $this->user['id'] ?? null,
                $category,
                $description,
                getRealIpAddress(),
                $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
                json_encode($additionalData)
            ]);
        } catch (Exception $e) {
            error_log("Failed to log activity: " . $e->getMessage());
        }
    }
    
    /**
     * تسجيل حدث أمني
     */
    protected function logSecurityEvent($description, $severity = 'medium', $additionalData = []) {
        logSecurityEvent($description, $severity, array_merge($additionalData, [
            'user_id' => $this->user['id'] ?? null,
            'endpoint' => $_SERVER['REQUEST_URI'] ?? null,
            'method' => $_SERVER['REQUEST_METHOD'] ?? null
        ]));
    }
    
    /**
     * الحصول على البيانات المرسلة
     */
    protected function getInputData() {
        $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
        
        if (strpos($contentType, 'application/json') !== false) {
            $jsonData = json_decode(file_get_contents('php://input'), true);
            return $jsonData ?: [];
        }
        
        return array_merge($_GET, $_POST);
    }
    
    /**
     * تطبيق التصفيات على الاستعلام
     */
    protected function applyFilters($query, $filters, $allowedFilters = []) {
        $conditions = [];
        $params = [];
        
        foreach ($filters as $key => $value) {
            if (empty($value) || !in_array($key, $allowedFilters)) {
                continue;
            }
            
            switch ($key) {
                case 'search':
                    $conditions[] = "(name LIKE ? OR description LIKE ?)";
                    $params[] = "%$value%";
                    $params[] = "%$value%";
                    break;
                    
                case 'category':
                    $conditions[] = "category = ?";
                    $params[] = $value;
                    break;
                    
                case 'level':
                    $conditions[] = "level = ?";
                    $params[] = $value;
                    break;
                    
                case 'status':
                    $conditions[] = "status = ?";
                    $params[] = $value;
                    break;
                    
                case 'date_from':
                    $conditions[] = "DATE(created_at) >= ?";
                    $params[] = $value;
                    break;
                    
                case 'date_to':
                    $conditions[] = "DATE(created_at) <= ?";
                    $params[] = $value;
                    break;
            }
        }
        
        if (!empty($conditions)) {
            $query .= (strpos($query, 'WHERE') !== false ? ' AND ' : ' WHERE ') . implode(' AND ', $conditions);
        }
        
        return [$query, $params];
    }
    
    /**
     * تطبيق الترتيب والتصفح
     */
    protected function applyPagination($query, $page = 1, $perPage = 10, $orderBy = 'id', $orderDir = 'DESC') {
        $allowedOrders = ['ASC', 'DESC'];
        $orderDir = in_array(strtoupper($orderDir), $allowedOrders) ? strtoupper($orderDir) : 'DESC';
        
        $query .= " ORDER BY $orderBy $orderDir";
        
        $offset = ($page - 1) * $perPage;
        $query .= " LIMIT $perPage OFFSET $offset";
        
        return $query;
    }
    
    /**
     * حساب العدد الإجمالي للسجلات
     */
    protected function getTotalCount($baseQuery, $params = []) {
        // تحويل الاستعلام لحساب العدد
        $countQuery = preg_replace('/SELECT .+ FROM/', 'SELECT COUNT(*) FROM', $baseQuery);
        $countQuery = preg_replace('/ORDER BY .+/', '', $countQuery);
        $countQuery = preg_replace('/LIMIT .+/', '', $countQuery);
        
        $stmt = $this->pdo->prepare($countQuery);
        $stmt->execute($params);
        
        return $stmt->fetchColumn();
    }
    
    /**
     * تحسين الصور
     */
    protected function optimizeImage($sourcePath, $targetPath, $maxWidth = 800, $quality = 85) {
        $imageInfo = getimagesize($sourcePath);
        if (!$imageInfo) {
            return false;
        }
        
        $sourceWidth = $imageInfo[0];
        $sourceHeight = $imageInfo[1];
        $mimeType = $imageInfo['mime'];
        
        // حساب الأبعاد الجديدة
        if ($sourceWidth > $maxWidth) {
            $targetWidth = $maxWidth;
            $targetHeight = ($sourceHeight * $maxWidth) / $sourceWidth;
        } else {
            $targetWidth = $sourceWidth;
            $targetHeight = $sourceHeight;
        }
        
        // إنشاء الصورة المصدر
        switch ($mimeType) {
            case 'image/jpeg':
                $sourceImage = imagecreatefromjpeg($sourcePath);
                break;
            case 'image/png':
                $sourceImage = imagecreatefrompng($sourcePath);
                break;
            case 'image/gif':
                $sourceImage = imagecreatefromgif($sourcePath);
                break;
            default:
                return false;
        }
        
        // إنشاء الصورة المستهدفة
        $targetImage = imagecreatetruecolor($targetWidth, $targetHeight);
        
        // الحفاظ على الشفافية للـ PNG
        if ($mimeType === 'image/png') {
            imagealphablending($targetImage, false);
            imagesavealpha($targetImage, true);
            $transparent = imagecolorallocatealpha($targetImage, 255, 255, 255, 127);
            imagefill($targetImage, 0, 0, $transparent);
        }
        
        // تغيير حجم الصورة
        imagecopyresampled(
            $targetImage, $sourceImage,
            0, 0, 0, 0,
            $targetWidth, $targetHeight,
            $sourceWidth, $sourceHeight
        );
        
        // حفظ الصورة
        $result = imagejpeg($targetImage, $targetPath, $quality);
        
        // تنظيف الذاكرة
        imagedestroy($sourceImage);
        imagedestroy($targetImage);
        
        return $result;
    }
    
    /**
     * معالجة رفع الملفات
     */
    protected function handleFileUpload($file, $uploadDir, $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'], $maxSize = 5242880) {
        // التحقق من الأخطاء
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('فشل في رفع الملف');
        }
        
        // التحقق من الحجم
        if ($file['size'] > $maxSize) {
            throw new Exception('حجم الملف كبير جداً');
        }
        
        // التحقق من النوع
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($extension, $allowedTypes)) {
            throw new Exception('نوع الملف غير مدعوم');
        }
        
        // إنشاء اسم ملف فريد
        $fileName = uniqid() . '_' . time() . '.' . $extension;
        $targetPath = $uploadDir . '/' . $fileName;
        
        // إنشاء المجلد إذا لم يكن موجوداً
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        // نقل الملف
        if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
            throw new Exception('فشل في حفظ الملف');
        }
        
        return $fileName;
    }
    
    /**
     * تنفيذ العمليات في transaction
     */
    protected function transaction($callback) {
        $this->pdo->beginTransaction();
        
        try {
            $result = $callback($this->pdo);
            $this->pdo->commit();
            return $result;
        } catch (Exception $e) {
            $this->pdo->rollback();
            throw $e;
        }
    }
}
?>