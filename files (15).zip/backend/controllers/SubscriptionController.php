<?php
/**
 * معالج الاشتراكات - التحقق من الأكواد وتفعيل الاشتراكات
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

require_once __DIR__ . '/../../api.php';

class SubscriptionController extends BaseController {
    
    /**
     * التحقق من صحة كود الاشتراك
     */
    public function checkCode() {
        $data = $_POST;
        
        // التحقق من صحة البيانات
        $errors = $this->validate($data, [
            'code' => 'required|min:3'
        ]);
        
        if (!empty($errors)) {
            return $this->errorResponse('بيانات غير صالحة', 422, $errors);
        }
        
        $code = sanitizeInput($data['code']);
        
        try {
            // البحث عن الكود
            $stmt = $this->db->prepare("
                SELECT sc.*, c.name as course_name, c.description as course_description,
                       c.image_url, c.id as course_id
                FROM subscription_codes sc
                JOIN courses c ON sc.course_id = c.id
                WHERE sc.code = ? AND sc.is_active = 1 AND c.is_active = 1
            ");
            $stmt->execute([$code]);
            $codeData = $stmt->fetch();
            
            if (!$codeData) {
                return $this->errorResponse('كود الاشتراك غير صالح أو منتهي الصلاحية', 404);
            }
            
            // التحقق من انتهاء الصلاحية
            if ($codeData['expires_at'] && strtotime($codeData['expires_at']) < time()) {
                return $this->errorResponse('كود الاشتراك منتهي الصلاحية', 410);
            }
            
            // التحقق من عدد الاستخدامات
            if ($codeData['max_uses'] > 0 && $codeData['uses_count'] >= $codeData['max_uses']) {
                return $this->errorResponse('تم استنفاد عدد الاستخدامات المسموحة لهذا الكود', 410);
            }
            
            // إحصائيات الدورة
            $courseStats = $this->getCourseStats($codeData['course_id']);
            
            return $this->successResponse([
                'valid' => true,
                'code_info' => [
                    'code' => $codeData['code'],
                    'course_id' => $codeData['course_id'],
                    'course_name' => $codeData['course_name'],
                    'course_description' => $codeData['course_description'],
                    'course_image' => $codeData['image_url'],
                    'remaining_uses' => $codeData['max_uses'] > 0 ? 
                        ($codeData['max_uses'] - $codeData['uses_count']) : 'غير محدود',
                    'expires_at' => $codeData['expires_at'],
                    'stats' => $courseStats
                ]
            ], 'كود الاشتراك صالح');
            
        } catch (Exception $e) {
            error_log("Check code error: " . $e->getMessage());
            return $this->errorResponse('خطأ في التحقق من الكود', 500);
        }
    }
    
    /**
     * تفعيل الاشتراك باستخدام الكود
     */
    public function activate() {
        // التأكد من تسجيل الدخول
        if (!$this->sessionManager->isLoggedIn()) {
            return $this->errorResponse('يجب تسجيل الدخول أولاً', 401);
        }
        
        $data = $_POST;
        $userId = $_SESSION['user_id'];
        
        // التحقق من صحة البيانات
        $errors = $this->validate($data, [
            'code' => 'required|min:3'
        ]);
        
        if (!empty($errors)) {
            return $this->errorResponse('بيانات غير صالحة', 422, $errors);
        }
        
        $code = sanitizeInput($data['code']);
        
        try {
            $this->db->beginTransaction();
            
            // البحث عن الكود والتحقق من صحته
            $stmt = $this->db->prepare("
                SELECT sc.*, c.name as course_name
                FROM subscription_codes sc
                JOIN courses c ON sc.course_id = c.id
                WHERE sc.code = ? AND sc.is_active = 1 AND c.is_active = 1
                FOR UPDATE
            ");
            $stmt->execute([$code]);
            $codeData = $stmt->fetch();
            
            if (!$codeData) {
                $this->db->rollback();
                return $this->errorResponse('كود الاشتراك غير صالح', 404);
            }
            
            // التحقق من انتهاء الصلاحية
            if ($codeData['expires_at'] && strtotime($codeData['expires_at']) < time()) {
                $this->db->rollback();
                return $this->errorResponse('كود الاشتراك منتهي الصلاحية', 410);
            }
            
            // التحقق من عدد الاستخدامات
            if ($codeData['max_uses'] > 0 && $codeData['uses_count'] >= $codeData['max_uses']) {
                $this->db->rollback();
                return $this->errorResponse('تم استنفاد عدد الاستخدامات المسموحة', 410);
            }
            
            // التحقق من عدم وجود اشتراك مسبق
            $stmt = $this->db->prepare("
                SELECT id FROM subscriptions 
                WHERE user_id = ? AND course_id = ? AND is_active = 1
            ");
            $stmt->execute([$userId, $codeData['course_id']]);
            
            if ($stmt->fetch()) {
                $this->db->rollback();
                return $this->errorResponse('أنت مشترك بالفعل في هذه الدورة', 409);
            }
            
            // إنشاء الاشتراك
            $stmt = $this->db->prepare("
                INSERT INTO subscriptions (user_id, course_id, subscription_code_id, subscribed_at, is_active)
                VALUES (?, ?, ?, NOW(), 1)
            ");
            $stmt->execute([$userId, $codeData['course_id'], $codeData['id']]);
            
            // تحديث عداد الاستخدامات
            $stmt = $this->db->prepare("
                UPDATE subscription_codes 
                SET uses_count = uses_count + 1 
                WHERE id = ?
            ");
            $stmt->execute([$codeData['id']]);
            
            $this->db->commit();
            
            // تسجيل العملية
            logActivity($userId, 'subscription_activated', 
                "Activated subscription for course: {$codeData['course_name']} using code: {$code}");
            
            return $this->successResponse([
                'subscription' => [
                    'course_id' => $codeData['course_id'],
                    'course_name' => $codeData['course_name'],
                    'subscribed_at' => date('Y-m-d H:i:s')
                ]
            ], 'تم تفعيل الاشتراك بنجاح! يمكنك الآن الوصول للدورة');
            
        } catch (Exception $e) {
            $this->db->rollback();
            error_log("Subscription activation error: " . $e->getMessage());
            return $this->errorResponse('خطأ في تفعيل الاشتراك', 500);
        }
    }
    
    /**
     * التحقق من اشتراكات المستخدم
     */
    public function checkSubscription() {
        $userId = $_SESSION['user_id'];
        $courseId = $_GET['course_id'] ?? null;
        
        try {
            if ($courseId) {
                // التحقق من اشتراك محدد
                $stmt = $this->db->prepare("
                    SELECT s.*, c.name as course_name, 
                           COUNT(l.id) as total_lessons,
                           COUNT(lp.id) as completed_lessons,
                           COALESCE(AVG(CASE WHEN lp.is_completed = 1 THEN 100 ELSE (lp.last_position / l.duration * 100) END), 0) as progress_percentage
                    FROM subscriptions s
                    JOIN courses c ON s.course_id = c.id
                    LEFT JOIN sections sec ON c.id = sec.course_id AND sec.is_active = 1
                    LEFT JOIN lessons l ON sec.id = l.section_id AND l.is_active = 1
                    LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = s.user_id
                    WHERE s.user_id = ? AND s.course_id = ? AND s.is_active = 1
                    GROUP BY s.id
                ");
                $stmt->execute([$userId, $courseId]);
                $subscription = $stmt->fetch();
                
                return $this->successResponse([
                    'subscribed' => $subscription ? true : false,
                    'subscription' => $subscription
                ]);
            } else {
                // الحصول على جميع الاشتراكات
                return $this->getMyCourses();
            }
            
        } catch (Exception $e) {
            error_log("Check subscription error: " . $e->getMessage());
            return $this->errorResponse('خطأ في التحقق من الاشتراك', 500);
        }
    }
    
    /**
     * الحصول على دورات المستخدم
     */
    public function getMyCourses() {
        $userId = $_SESSION['user_id'];
        
        try {
            $stmt = $this->db->prepare("
                SELECT s.*, c.name, c.description, c.image_url,
                       COUNT(DISTINCT sec.id) as sections_count,
                       COUNT(DISTINCT l.id) as lessons_count,
                       COUNT(DISTINCT CASE WHEN lp.is_completed = 1 THEN lp.id END) as completed_lessons,
                       COALESCE(ROUND(COUNT(DISTINCT CASE WHEN lp.is_completed = 1 THEN lp.id END) * 100.0 / NULLIF(COUNT(DISTINCT l.id), 0), 2), 0) as progress_percentage,
                       SEC_TO_TIME(SUM(DISTINCT l.duration)) as total_duration,
                       MAX(lp.updated_at) as last_activity
                FROM subscriptions s
                JOIN courses c ON s.course_id = c.id AND c.is_active = 1
                LEFT JOIN sections sec ON c.id = sec.course_id AND sec.is_active = 1
                LEFT JOIN lessons l ON sec.id = l.section_id AND l.is_active = 1
                LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = s.user_id
                WHERE s.user_id = ? AND s.is_active = 1
                GROUP BY s.id, c.id
                ORDER BY s.subscribed_at DESC
            ");
            $stmt->execute([$userId]);
            $subscriptions = $stmt->fetchAll();
            
            return $this->successResponse([
                'subscriptions' => $subscriptions
            ]);
            
        } catch (Exception $e) {
            error_log("Get my courses error: " . $e->getMessage());
            return $this->errorResponse('خطأ في جلب الدورات', 500);
        }
    }
    
    /**
     * الحصول على إحصائيات الدورة
     */
    private function getCourseStats($courseId) {
        try {
            $stmt = $this->db->prepare("
                SELECT 
                    COUNT(DISTINCT sec.id) as sections_count,
                    COUNT(DISTINCT l.id) as lessons_count,
                    SEC_TO_TIME(SUM(DISTINCT l.duration)) as total_duration,
                    COUNT(DISTINCT s.user_id) as subscribers_count
                FROM courses c
                LEFT JOIN sections sec ON c.id = sec.course_id AND sec.is_active = 1
                LEFT JOIN lessons l ON sec.id = l.section_id AND l.is_active = 1
                LEFT JOIN subscriptions s ON c.id = s.course_id AND s.is_active = 1
                WHERE c.id = ? AND c.is_active = 1
            ");
            $stmt->execute([$courseId]);
            
            return $stmt->fetch();
        } catch (Exception $e) {
            error_log("Get course stats error: " . $e->getMessage());
            return [
                'sections_count' => 0,
                'lessons_count' => 0,
                'total_duration' => '00:00:00',
                'subscribers_count' => 0
            ];
        }
    }
}
?>