<?php
/**
 * API إنشاء درس جديد (للمسؤولين فقط)
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(['success' => false, 'message' => 'طريقة طلب غير صالحة'], 405);
}

try {
    $user = $sessionManager->requireAdmin();
    $db = Database::getInstance()->getConnection();
    
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    
    $sectionId = intval($input['section_id'] ?? 0);
    $title = sanitizeInput($input['title'] ?? '');
    $description = sanitizeInput($input['description'] ?? '');
    $vdocipherVideoId = sanitizeInput($input['vdocipher_video_id'] ?? '');
    $duration = intval($input['duration'] ?? 0);
    $orderIndex = intval($input['order_index'] ?? 0);
    $isPreview = isset($input['is_preview']) ? 1 : 0;
    $isActive = isset($input['is_active']) ? 1 : 0;
    
    $errors = [];
    
    // التحقق من صحة البيانات
    if ($sectionId <= 0) {
        $errors['section_id'] = 'معرف القسم غير صالح';
    } else {
        // التحقق من وجود القسم
        $stmt = $db->prepare("SELECT id FROM sections WHERE id = ?");
        $stmt->execute([$sectionId]);
        if (!$stmt->fetch()) {
            $errors['section_id'] = 'القسم غير موجود';
        }
    }
    
    if (empty($title)) {
        $errors['title'] = 'عنوان الدرس مطلوب';
    }
    
    if (empty($vdocipherVideoId)) {
        $errors['vdocipher_video_id'] = 'معرف فيديو VdoCipher مطلوب';
    }
    
    if ($duration < 0) {
        $errors['duration'] = 'مدة الدرس لا يمكن أن تكون سالبة';
    }
    
    if (!empty($errors)) {
        sendJsonResponse([
            'success' => false,
            'message' => 'بيانات غير صالحة',
            'errors' => $errors
        ]);
    }
    
    // تحديد ترتيب الدرس إذا لم يتم تحديده
    if ($orderIndex <= 0) {
        $stmt = $db->prepare("SELECT COALESCE(MAX(order_index), 0) + 1 FROM lessons WHERE section_id = ?");
        $stmt->execute([$sectionId]);
        $orderIndex = $stmt->fetchColumn();
    }
    
    // إنشاء الدرس
    $stmt = $db->prepare("
        INSERT INTO lessons (section_id, title, description, vdocipher_video_id, duration, order_index, is_preview, is_active) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([$sectionId, $title, $description, $vdocipherVideoId, $duration, $orderIndex, $isPreview, $isActive]);
    $lessonId = $db->lastInsertId();
    
    // جلب الدرس المنشأ
    $stmt = $db->prepare("SELECT * FROM lessons WHERE id = ?");
    $stmt->execute([$lessonId]);
    $lesson = $stmt->fetch();
    
    sendJsonResponse([
        'success' => true,
        'message' => 'تم إنشاء الدرس بنجاح',
        'lesson' => $lesson
    ]);
    
} catch (Exception $e) {
    logError("Create lesson error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في إنشاء الدرس'
    ], 500);
}
?>