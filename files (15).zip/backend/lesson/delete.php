<?php
/**
 * API حذف الدرس (للمسؤولين فقط)
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    sendJsonResponse(['success' => false, 'message' => 'طريقة طلب غير صالحة'], 405);
}

try {
    $user = $sessionManager->requireAdmin();
    $db = Database::getInstance()->getConnection();
    
    $lessonId = intval($_GET['id'] ?? 0);
    
    if ($lessonId <= 0) {
        sendJsonResponse([
            'success' => false,
            'message' => 'معرف الدرس غير صالح'
        ]);
    }
    
    // التحقق من وجود الدرس
    $stmt = $db->prepare("SELECT * FROM lessons WHERE id = ?");
    $stmt->execute([$lessonId]);
    $lesson = $stmt->fetch();
    
    if (!$lesson) {
        sendJsonResponse([
            'success' => false,
            'message' => 'الدرس غير موجود'
        ], 404);
    }
    
    $db->beginTransaction();
    
    try {
        // حذف تقدم الدرس
        $stmt = $db->prepare("DELETE FROM lesson_progress WHERE lesson_id = ?");
        $stmt->execute([$lessonId]);
        
        // حذف الدرس
        $stmt = $db->prepare("DELETE FROM lessons WHERE id = ?");
        $stmt->execute([$lessonId]);
        
        $db->commit();
        
        sendJsonResponse([
            'success' => true,
            'message' => 'تم حذف الدرس بنجاح'
        ]);
        
    } catch (Exception $e) {
        $db->rollback();
        throw $e;
    }
    
} catch (Exception $e) {
    logError("Delete lesson error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في حذف الدرس'
    ], 500);
}
?>