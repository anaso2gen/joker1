<?php
/**
 * API تحديث الدرس (للمسؤولين فقط)
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

if (!in_array($_SERVER['REQUEST_METHOD'], ['PUT', 'POST'])) {
    sendJsonResponse(['success' => false, 'message' => 'طريقة طلب غير صالحة'], 405);
}

try {
    $user = $sessionManager->requireAdmin();
    $db = Database::getInstance()->getConnection();
    
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    
    $lessonId = intval($input['id'] ?? $_GET['id'] ?? 0);
    $title = sanitizeInput($input['title'] ?? '');
    $description = sanitizeInput($input['description'] ?? '');
    $vdocipherVideoId = sanitizeInput($input['vdocipher_video_id'] ?? '');
    $duration = intval($input['duration'] ?? 0);
    $orderIndex = intval($input['order_index'] ?? 0);
    $isPreview = isset($input['is_preview']) ? 1 : 0;
    $isActive = isset($input['is_active']) ? 1 : 0;
    
    $errors = [];
    
    if ($lessonId <= 0) {
        sendJsonResponse([
            'success' => false,
            'message' => 'معرف الدرس غير صالح'
        ]);
    }
    
    // التحقق من وجود الدرس
    $stmt = $db->prepare("SELECT * FROM lessons WHERE id = ?");
    $stmt->execute([$lessonId]);
    $lesson = $stmt->fetch();
    
    if (!$lesson) {
        sendJsonResponse([
            'success' => false,
            'message' => 'الدرس غير موجود'
        ], 404);
    }
    
    // التحقق من صحة البيانات
    if (empty($title)) {
        $errors['title'] = 'عنوان الدرس مطلوب';
    }
    
    if (empty($vdocipherVideoId)) {
        $errors['vdocipher_video_id'] = 'معرف فيديو VdoCipher مطلوب';
    }
    
    if ($duration < 0) {
        $errors['duration'] = 'مدة الدرس لا يمكن أن تكون سالبة';
    }
    
    if (!empty($errors)) {
        sendJsonResponse([
            'success' => false,
            'message' => 'بيانات غير صالحة',
            'errors' => $errors
        ]);
    }
    
    // تحديث الدرس
    $stmt = $db->prepare("
        UPDATE lessons 
        SET title = ?, description = ?, vdocipher_video_id = ?, duration = ?, 
            order_index = ?, is_preview = ?, is_active = ?, updated_at = NOW()
        WHERE id = ?
    ");
    
    $stmt->execute([$title, $description, $vdocipherVideoId, $duration, $orderIndex, $isPreview, $isActive, $lessonId]);
    
    // جلب الدرس المحدث
    $stmt = $db->prepare("SELECT * FROM lessons WHERE id = ?");
    $stmt->execute([$lessonId]);
    $updatedLesson = $stmt->fetch();
    
    sendJsonResponse([
        'success' => true,
        'message' => 'تم تحديث الدرس بنجاح',
        'lesson' => $updatedLesson
    ]);
    
} catch (Exception $e) {
    logError("Update lesson error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في تحديث الدرس'
    ], 500);
}
?>