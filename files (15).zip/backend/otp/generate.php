<?php
/**
 * API توليد OTP من VdoCipher مع حماية متقدمة
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

// التحقق من طريقة الطلب
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(['success' => false, 'message' => 'طريقة طلب غير صالحة'], 405);
}

// التحقق من أن الطلب AJAX
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || $_SERVER['HTTP_X_REQUESTED_WITH'] !== 'XMLHttpRequest') {
    sendJsonResponse(['success' => false, 'message' => 'طلب غير صالح'], 400);
}

try {
    $user = $sessionManager->requireLogin();
    $db = Database::getInstance()->getConnection();
    
    // جلب البيانات المرسلة
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        sendJsonResponse(['success' => false, 'message' => 'بيانات غير صالحة'], 400);
    }
    
    $lessonId = intval($input['lesson_id'] ?? 0);
    $videoId = sanitizeInput($input['video_id'] ?? '');
    $sessionId = sanitizeInput($input['session_id'] ?? '');
    
    // التحقق من البيانات
    if ($lessonId <= 0 || empty($videoId) || empty($sessionId)) {
        sendJsonResponse([
            'success' => false,
            'message' => 'معاملات مفقودة أو غير صالحة'
        ], 400);
    }
    
    // التحقق من وجود الدرس والصلاحية
    $stmt = $db->prepare("
        SELECT l.*, s.course_id, c.name as course_name, c.is_active as course_active
        FROM lessons l
        JOIN sections s ON s.id = l.section_id
        JOIN courses c ON c.id = s.course_id
        WHERE l.id = ? AND l.vdocipher_video_id = ? 
        AND l.is_active = 1 AND s.is_active = 1 AND c.is_active = 1
    ");
    
    $stmt->execute([$lessonId, $videoId]);
    $lesson = $stmt->fetch();
    
    if (!$lesson) {
        sendJsonResponse([
            'success' => false,
            'message' => 'الدرس غير موجود أو غير متاح'
        ], 404);
    }
    
    // التحقق من الاشتراك أو المعاينة المجانية
    $hasAccess = $lesson['is_preview'] || $sessionManager->hasSubscription($lesson['course_id'], $user['user_id']);
    
    if (!$hasAccess) {
        sendJsonResponse([
            'success' => false,
            'message' => 'ليس لديك صلاحية لمشاهدة هذا الدرس'
        ], 403);
    }
    
    // فحص أمني إضافي
    $clientIP = getRealIpAddress();
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    // منع الطلبات السريعة المتتالية (Rate Limiting)
    $stmt = $db->prepare("
        SELECT COUNT(*) FROM lesson_progress 
        WHERE user_id = ? AND updated_at > DATE_SUB(NOW(), INTERVAL 30 SECOND)
    ");
    $stmt->execute([$user['user_id']]);
    
    if ($stmt->fetchColumn() > 5) {
        sendJsonResponse([
            'success' => false,
            'message' => 'طلبات كثيرة جداً. يرجى الانتظار'
        ], 429);
    }
    
    // توليد OTP من VdoCipher
    $otpResult = generateVdoCipherOTP($videoId, $user['user_id'], $sessionId);
    
    if (!$otpResult['success']) {
        logError("VdoCipher OTP generation failed", [
            'user_id' => $user['user_id'],
            'lesson_id' => $lessonId,
            'video_id' => $videoId,
            'error' => $otpResult['message']
        ]);
        
        sendJsonResponse([
            'success' => false,
            'message' => 'خطأ في توليد رمز التشغيل'
        ], 500);
    }
    
    // تسجيل محاولة المشاهدة
    $stmt = $db->prepare("
        INSERT INTO lesson_progress (user_id, lesson_id, last_position, watch_time, created_at, updated_at)
        VALUES (?, ?, 0, 0, NOW(), NOW())
        ON DUPLICATE KEY UPDATE updated_at = NOW()
    ");
    $stmt->execute([$user['user_id'], $lessonId]);
    
    // تسجيل الجلسة
    $stmt = $db->prepare("
        INSERT INTO video_sessions (user_id, lesson_id, session_id, ip_address, user_agent, started_at)
        VALUES (?, ?, ?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE started_at = NOW()
    ");
    $stmt->execute([$user['user_id'], $lessonId, $sessionId, $clientIP, $userAgent]);
    
    sendJsonResponse([
        'success' => true,
        'otp' => $otpResult['otp'],
        'playback_info' => $otpResult['playback_info'],
        'lesson' => [
            'id' => $lesson['id'],
            'title' => $lesson['title'],
            'duration' => (int)$lesson['duration']
        ],
        'session_id' => $sessionId
    ]);
    
} catch (Exception $e) {
    logError("OTP generation error: " . $e->getMessage(), [
        'user_id' => $user['user_id'] ?? 'unknown',
        'lesson_id' => $lessonId ?? 0,
        'ip' => getRealIpAddress()
    ]);
    
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في الخادم'
    ], 500);
}

/**
 * توليد OTP من VdoCipher مع watermark متقدم
 */
function generateVdoCipherOTP($videoId, $userId, $sessionId) {
    try {
        $apiSecret = Settings::get('vdocipher_api_secret', VDOCIPHER_API_SECRET);
        
        if (empty($apiSecret)) {
            return ['success' => false, 'message' => 'VdoCipher API secret not configured'];
        }
        
        $url = VDOCIPHER_BASE_URL . '/videos/' . $videoId . '/otp';
        
        // إعداد watermark متقدم
        $watermarkText = substr($userId, 0, 8) . '-' . substr($sessionId, -4);
        
        $postData = [
            'ttl' => 1800, // 30 دقيقة
            'annotate' => json_encode([
                [
                    'type' => 'rtext',
                    'text' => $watermarkText,
                    'alpha' => '0.7',
                    'color' => '0xFFFFFF',
                    'size' => '14',
                    'interval' => '15000', // كل 15 ثانية
                    'skip' => '5000' // تخطي أول 5 ثوان
                ],
                [
                    'type' => 'rtext',
                    'text' => date('Y-m-d H:i'),
                    'alpha' => '0.5',
                    'color' => '0xCCCCCC',
                    'size' => '10',
                    'interval' => '30000', // كل 30 ثانية
                    'skip' => '10000'
                ]
            ]),
            'player_options' => [
                'controls' => true,
                'playbackRates' => [0.5, 0.75, 1, 1.25, 1.5, 2],
                'seekStep' => 10,
                'volume' => 0.8,
                'muted' => false,
                'autoplay' => false,
                'loop' => false,
                'preload' => 'metadata'
            ]
        ];
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($postData),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Apisecret ' . $apiSecret,
                'Content-Type: application/json',
                'Accept: application/json',
                'User-Agent: LearningPlatform/1.0'
            ],
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_MAXREDIRS => 0
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        
        curl_close($ch);
        
        if ($curlError) {
            logError("VdoCipher cURL error: " . $curlError);
            return ['success' => false, 'message' => 'Network connection error'];
        }
        
        if ($httpCode !== 200) {
            logError("VdoCipher API error: HTTP {$httpCode}", ['response' => $response]);
            return ['success' => false, 'message' => 'API request failed'];
        }
        
        $data = json_decode($response, true);
        
        if (!$data || !isset($data['otp'])) {
            logError("Invalid VdoCipher response", ['response' => $response]);
            return ['success' => false, 'message' => 'Invalid API response'];
        }
        
        return [
            'success' => true,
            'otp' => $data['otp'],
            'playback_info' => $data['playbackInfo'] ?? ''
        ];
        
    } catch (Exception $e) {
        logError("VdoCipher OTP generation exception: " . $e->getMessage());
        return ['success' => false, 'message' => 'OTP generation failed'];
    }
}
?>