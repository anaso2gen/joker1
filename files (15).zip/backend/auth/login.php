<?php
/**
 * API تسجيل الدخول
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

// التأكد من أن الطلب POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(['success' => false, 'message' => 'طريقة طلب غير صالحة'], 405);
}

try {
    $email = sanitizeInput($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $rememberMe = isset($_POST['remember']) && $_POST['remember'];
    
    $errors = [];
    
    // التحقق من صحة البيانات
    if (empty($email)) {
        $errors['email'] = 'البريد الإلكتروني مطلوب';
    } elseif (!validateEmail($email)) {
        $errors['email'] = 'البريد الإلكتروني غير صالح';
    }
    
    if (empty($password)) {
        $errors['password'] = 'كلمة المرور مطلوبة';
    }
    
    if (!empty($errors)) {
        sendJsonResponse([
            'success' => false,
            'message' => 'بيانات غير صالحة',
            'errors' => $errors
        ]);
    }
    
    // البحث عن المستخدم
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("
        SELECT id, user_id, email, password, full_name, is_admin, is_active 
        FROM users 
        WHERE email = ? AND is_active = 1
    ");
    
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if (!$user) {
        sendJsonResponse([
            'success' => false,
            'message' => 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
        ]);
    }
    
    // التحقق من كلمة المرور
    if (!verifyPassword($password, $user['password'])) {
        // تسجيل محاولة دخول فاشلة
        logError("Failed login attempt for: " . $email, ['ip' => getRealIpAddress()]);
        
        sendJsonResponse([
            'success' => false,
            'message' => 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
        ]);
    }
    
    // إنشاء جلسة جديدة
    $sessionToken = $sessionManager->createSession($user['user_id'], $rememberMe);
    
    if ($sessionToken) {
        sendJsonResponse([
            'success' => true,
            'message' => 'تم تسجيل الدخول بنجاح',
            'user' => [
                'user_id' => $user['user_id'],
                'email' => $user['email'],
                'full_name' => $user['full_name'],
                'is_admin' => (bool)$user['is_admin']
            ]
        ]);
    } else {
        sendJsonResponse([
            'success' => false,
            'message' => 'خطأ في إنشاء الجلسة'
        ], 500);
    }
    
} catch (Exception $e) {
    logError("Login error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في الخادم'
    ], 500);
}
?>