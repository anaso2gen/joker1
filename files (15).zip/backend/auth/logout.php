<?php
/**
 * API تسجيل الخروج
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

try {
    // تدمير الجلسة
    $sessionManager->destroySession();
    
    sendJsonResponse([
        'success' => true,
        'message' => 'تم تسجيل الخروج بنجاح'
    ]);
    
} catch (Exception $e) {
    logError("Logout error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في تسجيل الخروج'
    ], 500);
}
?>