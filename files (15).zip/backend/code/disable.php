<?php
/**
 * API تعطيل كود الاشتراك (للمسؤولين فقط)
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

if (!in_array($_SERVER['REQUEST_METHOD'], ['PUT', 'POST'])) {
    sendJsonResponse(['success' => false, 'message' => 'طريقة طلب غير صالحة'], 405);
}

try {
    $user = $sessionManager->requireAdmin();
    $db = Database::getInstance()->getConnection();
    
    $codeId = intval($_GET['id'] ?? 0);
    
    if ($codeId <= 0) {
        sendJsonResponse([
            'success' => false,
            'message' => 'معرف الكود غير صالح'
        ]);
    }
    
    // التحقق من وجود الكود
    $stmt = $db->prepare("SELECT * FROM codes WHERE id = ?");
    $stmt->execute([$codeId]);
    $code = $stmt->fetch();
    
    if (!$code) {
        sendJsonResponse([
            'success' => false,
            'message' => 'الكود غير موجود'
        ], 404);
    }
    
    // تعطيل الكود
    $stmt = $db->prepare("UPDATE codes SET is_active = 0, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$codeId]);
    
    sendJsonResponse([
        'success' => true,
        'message' => 'تم تعطيل الكود بنجاح'
    ]);
    
} catch (Exception $e) {
    logError("Disable code error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في تعطيل الكود'
    ], 500);
}
?>