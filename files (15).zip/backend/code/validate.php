<?php
/**
 * API التحقق من صحة كود الاشتراك
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(['success' => false, 'message' => 'طريقة طلب غير صالحة'], 405);
}

try {
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $code = sanitizeInput($input['code'] ?? '');
    
    if (empty($code)) {
        sendJsonResponse([
            'success' => false,
            'message' => 'كود الاشتراك مطلوب'
        ]);
    }
    
    $db = Database::getInstance()->getConnection();
    
    // البحث عن الكود
    $stmt = $db->prepare("
        SELECT c.*, co.name as course_name, co.description as course_description,
               co.image_url, co.price,
               COUNT(DISTINCT s.id) as sections_count,
               COUNT(DISTINCT l.id) as lessons_count,
               SUM(l.duration) as total_duration
        FROM codes c
        JOIN courses co ON co.id = c.course_id
        LEFT JOIN sections s ON s.course_id = co.id AND s.is_active = 1
        LEFT JOIN lessons l ON l.section_id = s.id AND l.is_active = 1
        WHERE c.code = ?
        GROUP BY c.id
    ");
    
    $stmt->execute([$code]);
    $codeData = $stmt->fetch();
    
    if (!$codeData) {
        sendJsonResponse([
            'success' => false,
            'message' => 'كود الاشتراك غير موجود'
        ]);
    }
    
    // فحص صحة الكود
    $errors = [];
    
    if (!$codeData['is_active']) {
        $errors[] = 'الكود غير مفعل';
    }
    
    if ($codeData['expires_at'] && strtotime($codeData['expires_at']) <= time()) {
        $errors[] = 'الكود منتهي الصلاحية';
    }
    
    if ($codeData['max_uses'] > 0 && $codeData['uses_count'] >= $codeData['max_uses']) {
        $errors[] = 'تم استنفاد عدد الاستخدامات المسموح';
    }
    
    if (!empty($errors)) {
        sendJsonResponse([
            'success' => false,
            'message' => implode(', ', $errors),
            'errors' => $errors
        ]);
    }
    
    // إعداد بيانات الكورس
    $courseData = [
        'id' => $codeData['course_id'],
        'name' => $codeData['course_name'],
        'description' => $codeData['course_description'],
        'image_url' => $codeData['image_url'],
        'price' => $codeData['price'],
        'sections_count' => (int)$codeData['sections_count'],
        'lessons_count' => (int)$codeData['lessons_count'],
        'total_duration' => formatDuration($codeData['total_duration'] ?: 0)
    ];
    
    sendJsonResponse([
        'success' => true,
        'message' => 'الكود صالح',
        'code' => [
            'code' => $codeData['code'],
            'uses_count' => (int)$codeData['uses_count'],
            'max_uses' => (int)$codeData['max_uses'],
            'expires_at' => $codeData['expires_at']
        ],
        'course' => $courseData
    ]);
    
} catch (Exception $e) {
    logError("Validate code error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في التحقق من الكود'
    ], 500);
}
?>