<?php
/**
 * الصفحة الرئيسية
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 10:04:46
 */

define('LEARNING_PLATFORM', true);

require_once 'config/constants.php';
require_once 'includes/functions.php';
require_once 'includes/session_manager.php';
require_once 'includes/auth_middleware.php';

// بدء الجلسة
$sessionManager = new SessionManager();
applySecurityMiddleware();

// الحصول على بيانات الصفحة الرئيسية
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    
    // أحدث الدورات
    $latestCoursesStmt = $pdo->prepare("
        SELECT c.*, u.first_name as instructor_first_name, u.last_name as instructor_last_name,
               COUNT(DISTINCT s.id) as students_count,
               AVG(cr.rating) as avg_rating,
               COUNT(DISTINCT cr.id) as reviews_count
        FROM courses c
        JOIN users u ON c.instructor_id = u.id
        LEFT JOIN subscriptions s ON c.id = s.course_id AND s.is_active = 1
        LEFT JOIN course_reviews cr ON c.id = cr.course_id AND cr.is_approved = 1
        WHERE c.is_active = 1
        GROUP BY c.id
        ORDER BY c.created_at DESC
        LIMIT 8
    ");
    $latestCoursesStmt->execute();
    $latestCourses = $latestCoursesStmt->fetchAll();
    
    // أشهر الدورات
    $popularCoursesStmt = $pdo->prepare("
        SELECT c.*, u.first_name as instructor_first_name, u.last_name as instructor_last_name,
               COUNT(DISTINCT s.id) as students_count,
               AVG(cr.rating) as avg_rating,
               COUNT(DISTINCT cr.id) as reviews_count
        FROM courses c
        JOIN users u ON c.instructor_id = u.id
        LEFT JOIN subscriptions s ON c.id = s.course_id AND s.is_active = 1
        LEFT JOIN course_reviews cr ON c.id = cr.course_id AND cr.is_approved = 1
        WHERE c.is_active = 1
        GROUP BY c.id
        ORDER BY students_count DESC, avg_rating DESC
        LIMIT 8
    ");
    $popularCoursesStmt->execute();
    $popularCourses = $popularCoursesStmt->fetchAll();
    
    // الفئات
    $categoriesStmt = $pdo->prepare("
        SELECT category, COUNT(*) as count 
        FROM courses 
        WHERE is_active = 1 
        GROUP BY category 
        ORDER BY count DESC 
        LIMIT 8
    ");
    $categoriesStmt->execute();
    $categories = $categoriesStmt->fetchAll();
    
    // إحصائيات عامة
    $statsStmt = $pdo->prepare("
        SELECT 
            (SELECT COUNT(*) FROM courses WHERE is_active = 1) as total_courses,
            (SELECT COUNT(DISTINCT user_id) FROM subscriptions WHERE is_active = 1) as total_students,
            (SELECT COUNT(*) FROM course_completions) as total_certificates,
            (SELECT COUNT(*) FROM users WHERE is_admin = 1) as total_instructors
    ");
    $statsStmt->execute();
    $stats = $statsStmt->fetch();
    
} catch (Exception $e) {
    error_log("Homepage data error: " . $e->getMessage());
    $latestCourses = [];
    $popularCourses = [];
    $categories = [];
    $stats = ['total_courses' => 0, 'total_students' => 0, 'total_certificates' => 0, 'total_instructors' => 0];
}

$pageTitle = 'الصفحة الرئيسية - ' . SITE_NAME;
$pageDescription = SITE_DESCRIPTION;
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta name="keywords" content="<?php echo SEO_SETTINGS['keywords']; ?>">
    <meta name="author" content="<?php echo SEO_SETTINGS['author']; ?>">
    
    <!-- Open Graph -->
    <meta property="og:title" content="<?php echo htmlspecialchars($pageTitle); ?>">
    <meta property="og:description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta property="og:type" content="<?php echo SEO_SETTINGS['og_type']; ?>">
    <meta property="og:url" content="<?php echo SITE_URL; ?>">
    <meta property="og:image" content="<?php echo SITE_URL; ?>/assets/images/og-image.jpg">
    
    <!-- Twitter Card -->
    <meta name="twitter:card" content="<?php echo SEO_SETTINGS['twitter_card']; ?>">
    <meta name="twitter:title" content="<?php echo htmlspecialchars($pageTitle); ?>">
    <meta name="twitter:description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="/assets/images/favicon.ico">
    <link rel="apple-touch-icon" href="/assets/images/apple-touch-icon.png">
    
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link href="/assets/css/style.css" rel="stylesheet">
    
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo generateCSRFToken(); ?>">
</head>
<body>
    <!-- Header -->
    <?php include 'includes/header.php'; ?>
    
    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center min-vh-75">
                <div class="col-lg-6">
                    <div class="hero-content">
                        <h1 class="hero-title">
                            ابدأ رحلتك التعليمية مع 
                            <span class="text-primary">ترند الأكاديمية</span>
                        </h1>
                        <p class="hero-description">
                            منصة تعليمية متقدمة تقدم أفضل الدورات في التكنولوجيا والبرمجة والتصميم 
                            مع خبراء محترفين في المجال
                        </p>
                        <div class="hero-stats">
                            <div class="row">
                                <div class="col-6 col-md-3">
                                    <div class="stat-item">
                                        <h3><?php echo number_format($stats['total_courses']); ?></h3>
                                        <p>دورة تدريبية</p>
                                    </div>
                                </div>
                                <div class="col-6 col-md-3">
                                    <div class="stat-item">
                                        <h3><?php echo number_format($stats['total_students']); ?></h3>
                                        <p>طالب مسجل</p>
                                    </div>
                                </div>
                                <div class="col-6 col-md-3">
                                    <div class="stat-item">
                                        <h3><?php echo number_format($stats['total_certificates']); ?></h3>
                                        <p>شهادة مُنحت</p>
                                    </div>
                                </div>
                                <div class="col-6 col-md-3">
                                    <div class="stat-item">
                                        <h3><?php echo number_format($stats['total_instructors']); ?></h3>
                                        <p>مدرب خبير</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="hero-actions">
                            <a href="courses.php" class="btn btn-primary btn-lg me-3">
                                <i class="fas fa-play-circle me-2"></i>
                                ابدأ التعلم الآن
                            </a>
                            <a href="about.php" class="btn btn-outline-primary btn-lg">
                                تعرف علينا
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="hero-image">
                        <img src="/assets/images/hero-image.svg" alt="التعلم الإلكتروني" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Background Elements -->
        <div class="hero-bg-elements">
            <div class="floating-element element-1"></div>
            <div class="floating-element element-2"></div>
            <div class="floating-element element-3"></div>
        </div>
    </section>
    
    <!-- Categories Section -->
    <section class="categories-section py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-header text-center mb-5">
                        <h2>تصفح حسب الفئة</h2>
                        <p>اختر المجال الذي يناسب اهتماماتك وابدأ رحلة التعلم</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php foreach ($categories as $category): ?>
                <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                    <a href="courses.php?category=<?php echo urlencode($category['category']); ?>" class="category-card">
                        <div class="category-icon">
                            <i class="<?php echo getCategoryIcon($category['category']); ?>"></i>
                        </div>
                        <h5><?php echo COURSE_CATEGORIES[$category['category']] ?? $category['category']; ?></h5>
                        <p><?php echo $category['count']; ?> دورة</p>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    
    <!-- Latest Courses Section -->
    <section class="courses-section py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-header text-center mb-5">
                        <h2>أحدث الدورات</h2>
                        <p>اكتشف أحدث الدورات التي أضفناها لك</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php foreach ($latestCourses as $course): ?>
                <div class="col-lg-3 col-md-6 mb-4">
                    <?php include 'includes/course_card.php'; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="text-center mt-4">
                <a href="courses.php" class="btn btn-primary">
                    عرض جميع الدورات
                    <i class="fas fa-arrow-left ms-2"></i>
                </a>
            </div>
        </div>
    </section>
    
    <!-- Popular Courses Section -->
    <section class="courses-section py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-header text-center mb-5">
                        <h2>الدورات الأكثر شعبية</h2>
                        <p>الدورات التي اختارها أكثر الطلاب</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php foreach ($popularCourses as $course): ?>
                <div class="col-lg-3 col-md-6 mb-4">
                    <?php include 'includes/course_card.php'; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    
    <!-- Features Section -->
    <section class="features-section py-5 bg-primary text-white">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-header text-center mb-5">
                        <h2>لماذا ترند الأكاديمية؟</h2>
                        <p>نقدم لك أفضل تجربة تعليمية مع مزايا فريدة</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="feature-item text-center">
                        <div class="feature-icon">
                            <i class="fas fa-chalkboard-teacher"></i>
                        </div>
                        <h4>مدربون خبراء</h4>
                        <p>تعلم من أفضل الخبراء في المجال مع سنوات من الخبرة العملية</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="feature-item text-center">
                        <div class="feature-icon">
                            <i class="fas fa-laptop"></i>
                        </div>
                        <h4>تعلم عملي</h4>
                        <p>مشاريع حقيقية وتطبيق عملي لما تتعلمه في بيئة تفاعلية</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="feature-item text-center">
                        <div class="feature-icon">
                            <i class="fas fa-certificate"></i>
                        </div>
                        <h4>شهادات معتمدة</h4>
                        <p>احصل على شهادات معتمدة تؤهلك لسوق العمل</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="feature-item text-center">
                        <div class="feature-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <h4>تعلم في أي وقت</h4>
                        <p>وصول مدى الحياة للمحتوى التعليمي في أي وقت ومن أي مكان</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="feature-item text-center">
                        <div class="feature-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <h4>مجتمع تفاعلي</h4>
                        <p>انضم لمجتمع من المتعلمين وشارك خبراتك واستفد من تجارب الآخرين</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="feature-item text-center">
                        <div class="feature-icon">
                            <i class="fas fa-headset"></i>
                        </div>
                        <h4>دعم فني متميز</h4>
                        <p>فريق دعم متاح على مدار الساعة لمساعدتك في رحلتك التعليمية</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Newsletter Section -->
    <section class="newsletter-section py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="newsletter-content text-center">
                        <h3>ابق على اطلاع بأحدث الدورات</h3>
                        <p>اشترك في نشرتنا البريدية لتكون أول من يعرف عن الدورات الجديدة والعروض الخاصة</p>
                        <form class="newsletter-form" id="newsletterForm">
                            <div class="input-group">
                                <input type="email" class="form-control" placeholder="أدخل بريدك الإلكتروني" required>
                                <button class="btn btn-primary" type="submit">
                                    <i class="fas fa-paper-plane"></i>
                                    اشترك
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>
    
    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/app.js"></script>
    
    <!-- Analytics -->
    <?php if (defined('GOOGLE_ANALYTICS_ID') && GOOGLE_ANALYTICS_ID): ?>
    <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo GOOGLE_ANALYTICS_ID; ?>"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', '<?php echo GOOGLE_ANALYTICS_ID; ?>');
    </script>
    <?php endif; ?>
</body>
</html>

<?php
/**
 * دالة مساعدة للحصول على أيقونة الفئة
 */
function getCategoryIcon($category) {
    $icons = [
        'programming' => 'fas fa-code',
        'web-development' => 'fas fa-globe',
        'mobile-development' => 'fas fa-mobile-alt',
        'data-science' => 'fas fa-chart-bar',
        'artificial-intelligence' => 'fas fa-robot',
        'cybersecurity' => 'fas fa-shield-alt',
        'digital-marketing' => 'fas fa-bullhorn',
        'graphic-design' => 'fas fa-paint-brush',
        'photography' => 'fas fa-camera',
        'business' => 'fas fa-briefcase',
        'languages' => 'fas fa-language',
        'personal-development' => 'fas fa-user-plus'
    ];
    
    return $icons[$category] ?? 'fas fa-book';
}
?>