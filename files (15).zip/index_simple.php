<?php
// ملف اختبار مبسط للصفحة الرئيسية
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "🔍 اختبار الصفحة الرئيسية...<br><br>";

// 1. اختبار ملف الإعدادات
if (file_exists('config.php')) {
    echo "✅ ملف config.php موجود<br>";
    
    try {
        define('LEARNING_PLATFORM', true);
        require_once 'config.php';
        echo "✅ تم تحميل الإعدادات بنجاح<br>";
        
        // 2. اختبار قاعدة البيانات
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", 
                       DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        echo "✅ الاتصال بقاعدة البيانات ناجح<br>";
        
        // 3. اختبار الجلسات
        session_start();
        echo "✅ الجلسات تعمل بشكل طبيعي<br>";
        
        echo "<br><h2>✅ الموقع جاهز للعمل!</h2>";
        echo '<p><a href="login.php">اذهب لصفحة تسجيل الدخول</a></p>';
        echo '<p><a href="courses.php">اذهب لصفحة الدورات</a></p>';
        
    } catch (Exception $e) {
        echo "❌ خطأ: " . $e->getMessage();
    }
} else {
    echo "❌ ملف config.php مفقود!<br>";
    echo "يرجى التأكد من وجود ملف الإعدادات";
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>اختبار الموقع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h3 class="mb-0">🔍 تشخيص الموقع</h3>
            </div>
            <div class="card-body">
                <div class="alert alert-info">
                    إذا ظهرت هذه الصفحة، فالموقع يعمل جزئياً على الأقل.
                </div>
                
                <h5>الخطوات التالية:</h5>
                <ol>
                    <li>شغل ملف <code>debug.php</code> للحصول على تشخيص شامل</li>
                    <li>تأكد من وجود ملف <code>config.php</code></li>
                    <li>اختبر تسجيل الدخول باستخدام الحساب الذي أنشأته</li>
                </ol>
                
                <div class="mt-4">
                    <a href="login.php" class="btn btn-primary">تسجيل الدخول</a>
                    <a href="debug.php" class="btn btn-warning">تشخيص شامل</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>