<?php
/**
 * تذييل الصفحة العام
 * منصة ترند التعليمية - Learning Management System
 */
?>
    <!-- Footer -->
    <footer class="bg-dark text-light py-5 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <h5><i class="fas fa-graduation-cap me-2"></i><?= SITE_NAME ?></h5>
                    <p>منصة تعليمية إلكترونية متطورة تهدف إلى تقديم أفضل تجربة تعليمية رقمية.</p>
                </div>
                <div class="col-lg-2">
                    <h6>روابط سريعة</h6>
                    <ul class="list-unstyled">
                        <li><a href="index.php" class="text-light text-decoration-none">الرئيسية</a></li>
                        <li><a href="courses.php" class="text-light text-decoration-none">الدورات</a></li>
                        <li><a href="#" class="text-light text-decoration-none">من نحن</a></li>
                        <li><a href="#" class="text-light text-decoration-none">اتصل بنا</a></li>
                    </ul>
                </div>
                <div class="col-lg-2">
                    <h6>الدعم</h6>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-light text-decoration-none">مركز المساعدة</a></li>
                        <li><a href="#" class="text-light text-decoration-none">الأسئلة الشائعة</a></li>
                        <li><a href="#" class="text-light text-decoration-none">سياسة الخصوصية</a></li>
                        <li><a href="#" class="text-light text-decoration-none">الشروط والأحكام</a></li>
                    </ul>
                </div>
                <div class="col-lg-4">
                    <h6>تواصل معنا</h6>
                    <p><i class="fas fa-envelope me-2"></i><?= ADMIN_EMAIL ?></p>
                    <div class="social-links">
                        <a href="#" class="text-light me-3"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-light me-3"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-light me-3"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-light"><i class="fab fa-linkedin"></i></a>
                    </div>
                </div>
            </div>
            <hr class="my-4">
            <div class="text-center">
                <p>&copy; <?= date('Y') ?> <?= SITE_NAME ?>. جميع الحقوق محفوظة.</p>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>