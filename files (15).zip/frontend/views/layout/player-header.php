<?php
/**
 * رأس صفحة مشغل الفيديو
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 08:57:21
 */
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? $pageTitle : 'مشغل الفيديو' ?> - <?= SITE_NAME ?></title>
    
    <!-- Meta Tags -->
    <meta name="description" content="مشغل الفيديو المحمي لمنصة ترند التعليمية">
    <meta name="robots" content="noindex, nofollow">
    
    <!-- Security Headers -->
    <meta http-equiv="X-Content-Type-Options" content="nosniff">
    <meta http-equiv="X-Frame-Options" content="SAMEORIGIN">
    <meta http-equiv="X-XSS-Protection" content="1; mode=block">
    <meta http-equiv="Content-Security-Policy" content="
        default-src 'self' 'unsafe-inline' 'unsafe-eval' 
        *.vdocipher.com *.googleapis.com *.gstatic.com 
        *.jsdelivr.net *.cdnjs.cloudflare.com;
        img-src 'self' data: *.vdocipher.com *.gravatar.com;
        media-src 'self' *.vdocipher.com;
        frame-src 'self' *.vdocipher.com;
    ">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/images/favicon.ico">
    
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700&display=swap" rel="stylesheet">
    
    <!-- VdoCipher CSS -->
    <style>
        * { 
            font-family: 'Tajawal', sans-serif; 
        }
        
        body {
            background: #000;
            margin: 0;
            padding: 0;
            overflow: hidden;
        }
        
        .player-container {
            position: relative;
            width: 100vw;
            height: 100vh;
            background: #000;
        }
        
        .player-header {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            background: linear-gradient(to bottom, rgba(0,0,0,0.8) 0%, transparent 100%);
            color: white;
            padding: 1rem;
            z-index: 1000;
            transition: opacity 0.3s ease;
        }
        
        .player-header.hidden {
            opacity: 0;
            pointer-events: none;
        }
        
        .player-controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .player-title {
            font-size: 1.1rem;
            font-weight: 500;
            margin: 0;
            max-width: 60%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        .player-actions {
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        
        .player-btn {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 25px;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }
        
        .player-btn:hover {
            background: rgba(255,255,255,0.3);
            color: white;
            transform: translateY(-2px);
        }
        
        .player-sidebar {
            position: absolute;
            top: 0;
            right: -400px;
            width: 400px;
            height: 100vh;
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(20px);
            border-left: 1px solid rgba(255,255,255,0.2);
            transition: right 0.3s ease;
            z-index: 999;
            overflow-y: auto;
            color: #333;
        }
        
        .player-sidebar.open {
            right: 0;
        }
        
        .sidebar-header {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(0,0,0,0.1);
            background: white;
        }
        
        .sidebar-content {
            padding: 1rem;
        }
        
        .lesson-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .lesson-item {
            padding: 0.8rem;
            border-radius: 10px;
            margin-bottom: 0.5rem;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid transparent;
        }
        
        .lesson-item:hover {
            background: rgba(102, 126, 234, 0.1);
        }
        
        .lesson-item.active {
            background: #667eea;
            color: white;
        }
        
        .lesson-item.completed {
            background: #28a745;
            color: white;
        }
        
        .lesson-duration {
            font-size: 0.8rem;
            opacity: 0.7;
        }
        
        .progress-bar-custom {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: rgba(255,255,255,0.2);
            z-index: 1001;
        }
        
        .progress-fill {
            height: 100%;
            background: #667eea;
            width: 0%;
            transition: width 0.1s ease;
        }
        
        .video-player {
            width: 100%;
            height: 100%;
        }
        
        .player-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: none;
            justify-content: center;
            align-items: center;
            color: white;
            z-index: 998;
        }
        
        .loading-spinner {
            width: 60px;
            height: 60px;
            border: 4px solid rgba(255,255,255,0.3);
            border-top: 4px solid white;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .notes-section {
            margin-top: 2rem;
        }
        
        .note-item {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1rem;
            border-left: 4px solid #667eea;
        }
        
        .note-time {
            font-size: 0.8rem;
            color: #667eea;
            font-weight: 500;
        }
        
        .note-content {
            margin-top: 0.5rem;
        }
        
        /* تحسينات الموبايل */
        @media (max-width: 768px) {
            .player-sidebar {
                width: 100vw;
                right: -100vw;
            }
            
            .player-title {
                max-width: 50%;
                font-size: 1rem;
            }
            
            .player-actions {
                gap: 0.5rem;
            }
            
            .player-btn {
                padding: 0.4rem 0.8rem;
                font-size: 0.9rem;
            }
        }
        
        /* منع التحديد والنسخ */
        .no-select {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
        
        /* منع النقر بالزر الأيمن */
        .no-context {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
        
        /* منع سحب الصور */
        img {
            -webkit-user-drag: none;
            -khtml-user-drag: none;
            -moz-user-drag: none;
            -o-user-drag: none;
            user-drag: none;
        }
    </style>
</head>
<body class="no-select no-context">
    <!-- منع النسخ والطباعة -->
    <script>
        // منع النقر بالزر الأيمن
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
            return false;
        });
        
        // منع اختصارات لوحة المفاتيح
        document.addEventListener('keydown', function(e) {
            // منع F12, Ctrl+Shift+I, Ctrl+U, Ctrl+S, Ctrl+P
            if (e.keyCode === 123 || 
                (e.ctrlKey && e.shiftKey && e.keyCode === 73) ||
                (e.ctrlKey && e.keyCode === 85) ||
                (e.ctrlKey && e.keyCode === 83) ||
                (e.ctrlKey && e.keyCode === 80)) {
                e.preventDefault();
                return false;
            }
        });
        
        // منع السحب
        document.addEventListener('dragstart', function(e) {
            e.preventDefault();
            return false;
        });
        
        // منع التحديد
        document.addEventListener('selectstart', function(e) {
            e.preventDefault();
            return false;
        });
        
        // إخفاء أدوات المطور
        setInterval(function() {
            if (window.outerHeight - window.innerHeight > 200 || 
                window.outerWidth - window.innerWidth > 200) {
                document.body.innerHTML = '<div style="text-align:center;padding:50px;color:white;">غير مسموح بفتح أدوات المطور</div>';
            }
        }, 1000);
    </script>