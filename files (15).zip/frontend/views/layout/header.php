<?php
/**
 * رأس الصفحة العام
 * منصة ترند التعليمية - Learning Management System
 */
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? $pageTitle . ' - ' . SITE_NAME : SITE_NAME ?></title>
    
    <!-- Meta Tags -->
    <meta name="description" content="<?= isset($pageDescription) ? $pageDescription : 'منصة تعليمية إلكترونية متقدمة' ?>">
    <meta name="keywords" content="تعليم, دورات, منصة, تدريب">
    <meta name="author" content="<?= SITE_NAME ?>">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/images/favicon.ico">
    
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700&display=swap" rel="stylesheet">
    
    <style>
        * { 
            font-family: 'Tajawal', sans-serif; 
        }
        body { 
            padding-top: 80px; 
            background: #f8f9fa;
        }
        .navbar { 
            background: rgba(255,255,255,0.95) !important; 
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
        }
        .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
        }
        .nav-link {
            font-weight: 500;
            margin: 0 0.2rem;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .nav-link:hover {
            background: rgba(0,123,255,0.1);
            color: #007bff !important;
        }
        .dropdown-menu {
            border: none;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            border-radius: 15px;
        }
        .dropdown-item {
            padding: 0.7rem 1rem;
            border-radius: 8px;
            margin: 0.2rem;
        }
        .dropdown-item:hover {
            background: #f8f9fa;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-graduation-cap text-primary me-2"></i>
                <?= SITE_NAME ?>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <div class="navbar-nav me-auto">
                    <a class="nav-link" href="index.php">
                        <i class="fas fa-home me-1"></i>الرئيسية
                    </a>
                    <a class="nav-link" href="courses.php">
                        <i class="fas fa-book me-1"></i>الدورات
                    </a>
                    <?php if (isset($sessionManager) && $sessionManager->isLoggedIn()): ?>
                        <a class="nav-link" href="subscribe.php">
                            <i class="fas fa-key me-1"></i>تفعيل كود
                        </a>
                    <?php endif; ?>
                </div>
                
                <div class="navbar-nav">
                    <?php if (isset($sessionManager) && $sessionManager->isLoggedIn()): ?>
                        <?php $currentUser = $sessionManager->getCurrentUser(); ?>
                        <div class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <img src="<?= htmlspecialchars($currentUser['avatar_url'] ?? 'https://via.placeholder.com/32x32/007bff/ffffff?text=' . substr($currentUser['first_name'], 0, 1)) ?>" 
                                     class="rounded-circle me-2" width="32" height="32" alt="الصورة الشخصية">
                                <span><?= htmlspecialchars($currentUser['first_name']) ?></span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li>
                                    <a class="dropdown-item" href="profile.php">
                                        <i class="fas fa-user me-2 text-primary"></i>الملف الشخصي
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="courses.php">
                                        <i class="fas fa-book me-2 text-success"></i>دوراتي
                                    </a>
                                </li>
                                <?php if ($currentUser['is_admin']): ?>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <a class="dropdown-item" href="editdash.php">
                                            <i class="fas fa-cog me-2 text-warning"></i>لوحة التحكم
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item text-danger" href="logout.php?token=<?= generateCSRFToken() ?>">
                                        <i class="fas fa-sign-out-alt me-2"></i>تسجيل الخروج
                                    </a>
                                </li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a class="nav-link" href="login.php">
                            <i class="fas fa-sign-in-alt me-1"></i>تسجيل الدخول
                        </a>
                        <a class="nav-link" href="register.php">
                            <span class="btn btn-primary btn-sm">
                                <i class="fas fa-user-plus me-1"></i>إنشاء حساب
                            </span>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>