<?php
/**
 * واجهة لوحة التحكم الشاملة
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

// تضمين رأس الصفحة
include_once __DIR__ . '/../layout/header.php';
?>

<div class="dashboard-container">
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-lg-3 col-xl-2">
                <div class="dashboard-sidebar" id="dashboardSidebar">
                    <div class="sidebar-header">
                        <h5 class="mb-0">
                            <i class="fas fa-tachometer-alt me-2"></i>
                            لوحة التحكم
                        </h5>
                        <button class="btn btn-sm btn-outline-secondary d-lg-none" id="sidebarToggle">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    
                    <div class="sidebar-menu">
                        <div class="menu-section">
                            <h6 class="menu-title">الإحصائيات</h6>
                            <a href="#overview" class="menu-item active" data-section="overview">
                                <i class="fas fa-chart-line"></i>
                                <span>نظرة عامة</span>
                            </a>
                            <a href="#analytics" class="menu-item" data-section="analytics">
                                <i class="fas fa-chart-bar"></i>
                                <span>التحليلات</span>
                            </a>
                        </div>
                        
                        <div class="menu-section">
                            <h6 class="menu-title">إدارة المحتوى</h6>
                            <a href="#courses" class="menu-item" data-section="courses">
                                <i class="fas fa-graduation-cap"></i>
                                <span>الدورات</span>
                                <span class="badge bg-primary ms-auto" id="coursesCount">0</span>
                            </a>
                            <a href="#sections" class="menu-item" data-section="sections">
                                <i class="fas fa-folder"></i>
                                <span>الأقسام</span>
                                <span class="badge bg-info ms-auto" id="sectionsCount">0</span>
                            </a>
                            <a href="#lessons" class="menu-item" data-section="lessons">
                                <i class="fas fa-play-circle"></i>
                                <span>الدروس</span>
                                <span class="badge bg-success ms-auto" id="lessonsCount">0</span>
                            </a>
                        </div>
                        
                        <div class="menu-section">
                            <h6 class="menu-title">إدارة المستخدمين</h6>
                            <a href="#users" class="menu-item" data-section="users">
                                <i class="fas fa-users"></i>
                                <span>المستخدمين</span>
                                <span class="badge bg-warning ms-auto" id="usersCount">0</span>
                            </a>
                            <a href="#subscriptions" class="menu-item" data-section="subscriptions">
                                <i class="fas fa-ticket-alt"></i>
                                <span>الاشتراكات</span>
                                <span class="badge bg-secondary ms-auto" id="subscriptionsCount">0</span>
                            </a>
                        </div>
                        
                        <div class="menu-section">
                            <h6 class="menu-title">إدارة الأكواد</h6>
                            <a href="#codes" class="menu-item" data-section="codes">
                                <i class="fas fa-key"></i>
                                <span>أكواد التفعيل</span>
                                <span class="badge bg-danger ms-auto" id="codesCount">0</span>
                            </a>
                        </div>
                        
                        <div class="menu-section">
                            <h6 class="menu-title">النظام</h6>
                            <a href="#settings" class="menu-item" data-section="settings">
                                <i class="fas fa-cog"></i>
                                <span>الإعدادات</span>
                            </a>
                            <a href="#security" class="menu-item" data-section="security">
                                <i class="fas fa-shield-alt"></i>
                                <span>الأمان</span>
                            </a>
                            <a href="#logs" class="menu-item" data-section="logs">
                                <i class="fas fa-list-alt"></i>
                                <span>سجل الأنشطة</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-lg-9 col-xl-10">
                <div class="dashboard-content">
                    <!-- Mobile Sidebar Toggle -->
                    <div class="d-lg-none mb-3">
                        <button class="btn btn-outline-primary" id="mobileSidebarToggle">
                            <i class="fas fa-bars me-2"></i>القائمة
                        </button>
                    </div>
                    
                    <!-- Content Sections -->
                    <div id="contentContainer">
                        <!-- Overview Section -->
                        <div id="overview-section" class="content-section active">
                            <!-- سيتم تحميل المحتوى هنا -->
                        </div>
                        
                        <!-- Analytics Section -->
                        <div id="analytics-section" class="content-section">
                            <!-- سيتم تحميل المحتوى هنا -->
                        </div>
                        
                        <!-- Courses Section -->
                        <div id="courses-section" class="content-section">
                            <!-- سيتم تحميل المحتوى هنا -->
                        </div>
                        
                        <!-- Sections Section -->
                        <div id="sections-section" class="content-section">
                            <!-- سيتم تحميل المحتوى هنا -->
                        </div>
                        
                        <!-- Lessons Section -->
                        <div id="lessons-section" class="content-section">
                            <!-- سيتم تحميل المحتوى هنا -->
                        </div>
                        
                        <!-- Users Section -->
                        <div id="users-section" class="content-section">
                            <!-- سيتم تحميل المحتوى هنا -->
                        </div>
                        
                        <!-- Subscriptions Section -->
                        <div id="subscriptions-section" class="content-section">
                            <!-- سيتم تحميل المحتوى هنا -->
                        </div>
                        
                        <!-- Codes Section -->
                        <div id="codes-section" class="content-section">
                            <!-- سيتم تحميل المحتوى هنا -->
                        </div>
                        
                        <!-- Settings Section -->
                        <div id="settings-section" class="content-section">
                            <!-- سيتم تحميل المحتوى هنا -->
                        </div>
                        
                        <!-- Security Section -->
                        <div id="security-section" class="content-section">
                            <!-- سيتم تحميل المحتوى هنا -->
                        </div>
                        
                        <!-- Logs Section -->
                        <div id="logs-section" class="content-section">
                            <!-- سيتم تحميل المحتوى هنا -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* تنسيقات لوحة التحكم */
.dashboard-page {
    background: #f8f9fa;
}

.dashboard-container {
    min-height: 100vh;
}

.dashboard-sidebar {
    background: linear-gradient(180deg, #2c3e50 0%, #34495e 100%);
    color: white;
    height: 100vh;
    position: fixed;
    top: 0;
    right: 0;
    width: 280px;
    z-index: 1040;
    transform: translateX(100%);
    transition: transform 0.3s ease;
    overflow-y: auto;
    box-shadow: -5px 0 20px rgba(0,0,0,0.1);
}

.dashboard-sidebar.show {
    transform: translateX(0);
}

@media (min-width: 992px) {
    .dashboard-sidebar {
        position: sticky;
        top: 0;
        transform: translateX(0);
        width: 100%;
        box-shadow: none;
    }
}

.sidebar-header {
    padding: 2rem 1.5rem 1rem;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.sidebar-header h5 {
    color: #ecf0f1;
    font-weight: 600;
}

.sidebar-menu {
    padding: 1rem 0;
}

.menu-section {
    margin-bottom: 2rem;
}

.menu-title {
    color: #bdc3c7;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    padding: 0 1.5rem;
    margin-bottom: 0.75rem;
}

.menu-item {
    display: flex;
    align-items: center;
    padding: 0.875rem 1.5rem;
    color: #ecf0f1;
    text-decoration: none;
    transition: all 0.3s ease;
    border-left: 3px solid transparent;
    position: relative;
}

.menu-item:hover {
    background: rgba(255,255,255,0.1);
    color: #3498db;
    border-left-color: #3498db;
}

.menu-item.active {
    background: linear-gradient(90deg, rgba(52,152,219,0.2), rgba(52,152,219,0.05));
    border-left-color: #3498db;
    color: #3498db;
}

.menu-item i {
    width: 20px;
    margin-left: 1rem;
    font-size: 0.9rem;
}

.menu-item .badge {
    font-size: 0.7rem;
    padding: 0.25rem 0.5rem;
}

.dashboard-content {
    padding: 2rem;
    min-height: 100vh;
}

.content-section {
    display: none;
    animation: fadeIn 0.3s ease-in;
}

.content-section.active {
    display: block;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

.section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    padding-bottom: 1rem;
    border-bottom: 2px solid #e9ecef;
}

.section-title {
    font-size: 2rem;
    font-weight: 700;
    color: #2c3e50;
    margin: 0;
}

.section-actions {
    display: flex;
    gap: 0.5rem;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.stats-card {
    background: white;
    border-radius: 15px;
    padding: 2rem;
    box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    border: 1px solid #e9ecef;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.stats-card::before {
    content: '';
    position: absolute;
    top: 0;
    right: 0;
    width: 100%;
    height: 4px;
    background: linear-gradient(90deg, #3498db, #2980b9);
}

.stats-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 40px rgba(0,0,0,0.12);
}

.stats-card.primary::before {
    background: linear-gradient(90deg, #007bff, #0056b3);
}

.stats-card.success::before {
    background: linear-gradient(90deg, #28a745, #1e7e34);
}

.stats-card.warning::before {
    background: linear-gradient(90deg, #ffc107, #e0a800);
}

.stats-card.danger::before {
    background: linear-gradient(90deg, #dc3545, #c82333);
}

.stats-card.info::before {
    background: linear-gradient(90deg, #17a2b8, #138496);
}

.stats-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
}

.stats-icon {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: white;
}

.stats-icon.primary {
    background: linear-gradient(135deg, #007bff, #0056b3);
}

.stats-icon.success {
    background: linear-gradient(135deg, #28a745, #1e7e34);
}

.stats-icon.warning {
    background: linear-gradient(135deg, #ffc107, #e0a800);
}

.stats-icon.danger {
    background: linear-gradient(135deg, #dc3545, #c82333);
}

.stats-icon.info {
    background: linear-gradient(135deg, #17a2b8, #138496);
}

.stats-number {
    font-size: 2.5rem;
    font-weight: 700;
    color: #2c3e50;
    margin-bottom: 0.5rem;
}

.stats-label {
    color: #6c757d;
    font-size: 0.9rem;
    font-weight: 500;
}

.stats-change {
    font-size: 0.8rem;
    margin-top: 0.5rem;
}

.stats-change.positive {
    color: #28a745;
}

.stats-change.negative {
    color: #dc3545;
}

.management-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 2rem;
}

.management-card {
    background: white;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    border: 1px solid #e9ecef;
    overflow: hidden;
}

.management-header {
    background: linear-gradient(135deg, #f8f9fa, #e9ecef);
    padding: 1.5rem 2rem;
    border-bottom: 1px solid #e9ecef;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.management-title {
    font-size: 1.25rem;
    font-weight: 600;
    color: #2c3e50;
    margin: 0;
}

.management-body {
    padding: 0;
}

.management-table {
    width: 100%;
    margin: 0;
}

.management-table th,
.management-table td {
    padding: 1rem 2rem;
    border-bottom: 1px solid #f8f9fa;
    vertical-align: middle;
}

.management-table th {
    background: #f8f9fa;
    font-weight: 600;
    color: #495057;
    border-bottom: 2px solid #e9ecef;
}

.management-table tbody tr:hover {
    background: #f8f9fa;
}

.action-buttons {
    display: flex;
    gap: 0.5rem;
}

.btn-action {
    padding: 0.375rem 0.75rem;
    border-radius: 8px;
    border: none;
    font-size: 0.875rem;
    transition: all 0.3s ease;
}

.btn-edit {
    background: #17a2b8;
    color: white;
}

.btn-edit:hover {
    background: #138496;
    color: white;
}

.btn-delete {
    background: #dc3545;
    color: white;
}

.btn-delete:hover {
    background: #c82333;
    color: white;
}

.btn-view {
    background: #28a745;
    color: white;
}

.btn-view:hover {
    background: #1e7e34;
    color: white;
}

.loading-container {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 300px;
    flex-direction: column;
}

.loading-spinner {
    width: 3rem;
    height: 3rem;
    border: 0.3rem solid #f3f3f3;
    border-top: 0.3rem solid #007bff;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

/* Responsive Design */
@media (max-width: 992px) {
    .dashboard-content {
        padding: 1rem;
    }
    
    .section-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 1rem;
    }
    
    .section-actions {
        width: 100%;
        justify-content: flex-start;
    }
    
    .stats-grid {
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
    }
    
    .stats-card {
        padding: 1.5rem;
    }
    
    .stats-number {
        font-size: 2rem;
    }
    
    .management-table {
        font-size: 0.875rem;
    }
    
    .management-table th,
    .management-table td {
        padding: 0.75rem 1rem;
    }
}

@media (max-width: 576px) {
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .action-buttons {
        flex-direction: column;
    }
    
    .management-table {
        font-size: 0.8rem;
    }
    
    .management-table th,
    .management-table td {
        padding: 0.5rem;
    }
}

/* Dark Theme Support */
.theme-dark .dashboard-sidebar {
    background: linear-gradient(180deg, #1a1a1a 0%, #2d2d2d 100%);
}

.theme-dark .stats-card,
.theme-dark .management-card {
    background: #2d2d2d;
    border-color: #404040;
    color: #fff;
}

.theme-dark .management-header {
    background: linear-gradient(135deg, #404040, #555);
    border-bottom-color: #555;
}

.theme-dark .management-title,
.theme-dark .section-title {
    color: #fff;
}

.theme-dark .management-table th {
    background: #404040;
    color: #fff;
    border-bottom-color: #555;
}

.theme-dark .management-table td {
    border-bottom-color: #404040;
    color: #fff;
}

.theme-dark .management-table tbody tr:hover {
    background: #404040;
}

.theme-dark .stats-number {
    color: #fff;
}

.theme-dark .stats-label {
    color: #b3b3b3;
}

/* Animations */
.fade-in {
    animation: fadeInUp 0.6s ease-out;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.scale-in {
    animation: scaleIn 0.3s ease-out;
}

@keyframes scaleIn {
    from {
        opacity: 0;
        transform: scale(0.9);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}
</style>

<?php
// JavaScript مخصص للوحة التحكم
$additionalScripts = '
<script>
document.addEventListener("DOMContentLoaded", function() {
    initializeDashboard();
});

// متغيرات عامة
let currentSection = "overview";
let dashboardData = {};

// تهيئة لوحة التحكم
function initializeDashboard() {
    setupSidebarNavigation();
    setupMobileSidebar();
    loadInitialData();
    loadDashboardStats();
    
    // تحميل القسم الأول
    loadSection("overview");
}

// إعداد التنقل في الشريط الجانبي
function setupSidebarNavigation() {
    const menuItems = document.querySelectorAll(".menu-item[data-section]");
    
    menuItems.forEach(item => {
        item.addEventListener("click", function(e) {
            e.preventDefault();
            
            const section = this.getAttribute("data-section");
            if (section !== currentSection) {
                switchSection(section);
            }
        });
    });
}

// إعداد الشريط الجانبي للموبايل
function setupMobileSidebar() {
    const mobileToggle = document.getElementById("mobileSidebarToggle");
    const sidebarToggle = document.getElementById("sidebarToggle");
    const sidebar = document.getElementById("dashboardSidebar");