<?php
/**
 * محتوى لوحة التحكم مع العناصر المرئية المحسنة
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

// تضمين رأس الصفحة
include_once __DIR__ . '/../layout/header.php';
?>

<div class="dashboard-container">
    <div class="container-fluid">
        <!-- Header Section -->
        <div class="dashboard-header mb-4" data-aos="fade-down">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="dashboard-title">
                        <i class="fas fa-tachometer-alt me-3 text-primary" data-aos="pulse" data-aos-delay="500"></i>
                        لوحة التحكم
                    </h1>
                    <p class="dashboard-subtitle text-muted">
                        إدارة شاملة للمنصة التعليمية والمحتوى
                    </p>
                </div>
                <div class="col-md-4 text-md-end">
                    <div class="dashboard-actions">
                        <button class="btn btn-primary me-2" onclick="refreshDashboard()">
                            <i class="fas fa-sync-alt me-2"></i>تحديث البيانات
                        </button>
                        <div class="dropdown d-inline-block">
                            <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                <i class="fas fa-cog me-2"></i>إعدادات
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#"><i class="fas fa-user me-2"></i>الملف الشخصي</a></li>
                                <li><a class="dropdown-item" href="#"><i class="fas fa-bell me-2"></i>الإشعارات</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="/api/auth/logout"><i class="fas fa-sign-out-alt me-2"></i>تسجيل خروج</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="stats-section mb-5">
            <div class="row g-4">
                <div class="col-xl-3 col-md-6" data-aos="fade-up" data-aos-delay="100">
                    <div class="stats-card">
                        <div class="stats-icon courses-icon">
                            <lottie-player
                                src="https://assets3.lottiefiles.com/packages/lf20_khtt8brq.json"
                                background="transparent"
                                speed="1"
                                style="width: 60px; height: 60px;"
                                loop
                                autoplay>
                            </lottie-player>
                        </div>
                        <div class="stats-content">
                            <h3 class="stats-number" data-count="0" id="coursesCount">0</h3>
                            <p class="stats-label">إجمالي الدورات</p>
                            <div class="stats-change positive">
                                <i class="fas fa-arrow-up"></i>
                                <span>+12%</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6" data-aos="fade-up" data-aos-delay="200">
                    <div class="stats-card">
                        <div class="stats-icon users-icon">
                            <lottie-player
                                src="https://assets6.lottiefiles.com/packages/lf20_jvsq0s29.json"
                                background="transparent"
                                speed="1"
                                style="width: 60px; height: 60px;"
                                loop
                                autoplay>
                            </lottie-player>
                        </div>
                        <div class="stats-content">
                            <h3 class="stats-number" data-count="0" id="usersCount">0</h3>
                            <p class="stats-label">المستخدمين النشطين</p>
                            <div class="stats-change positive">
                                <i class="fas fa-arrow-up"></i>
                                <span>+8%</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6" data-aos="fade-up" data-aos-delay="300">
                    <div class="stats-card">
                        <div class="stats-icon subscriptions-icon">
                            <lottie-player
                                src="https://assets8.lottiefiles.com/packages/lf20_rvp4iz4u.json"
                                background="transparent"
                                speed="1"
                                style="width: 60px; height: 60px;"
                                loop
                                autoplay>
                            </lottie-player>
                        </div>
                        <div class="stats-content">
                            <h3 class="stats-number" data-count="0" id="subscriptionsCount">0</h3>
                            <p class="stats-label">الاشتراكات الفعالة</p>
                            <div class="stats-change positive">
                                <i class="fas fa-arrow-up"></i>
                                <span>+25%</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6" data-aos="fade-up" data-aos-delay="400">
                    <div class="stats-card">
                        <div class="stats-icon revenue-icon">
                            <lottie-player
                                src="https://assets10.lottiefiles.com/packages/lf20_u26w0bxf.json"
                                background="transparent"
                                speed="1"
                                style="width: 60px; height: 60px;"
                                loop
                                autoplay>
                            </lottie-player>
                        </div>
                        <div class="stats-content">
                            <h3 class="stats-number" data-count="0" id="codesCount">0</h3>
                            <p class="stats-label">أكواد الاشتراك</p>
                            <div class="stats-change neutral">
                                <i class="fas fa-minus"></i>
                                <span>0%</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Management Sections -->
        <div class="management-sections">
            <div class="row g-4">
                <!-- Courses Management -->
                <div class="col-lg-6" data-aos="fade-right">
                    <div class="management-card">
                        <div class="card-header">
                            <h5 class="card-title">
                                <i class="fas fa-graduation-cap me-2 text-primary"></i>
                                إدارة الدورات
                            </h5>
                            <button class="btn btn-sm btn-primary" onclick="openCourseModal('create')">
                                <i class="fas fa-plus me-1"></i>إضافة دورة
                            </button>
                        </div>
                        <div class="card-body">
                            <div class="management-actions mb-3">
                                <div class="row g-2">
                                    <div class="col-md-8">
                                        <input type="text" class="form-control" id="courseSearch" 
                                               placeholder="البحث عن دورة...">
                                    </div>
                                    <div class="col-md-4">
                                        <select class="form-select" id="courseFilter">
                                            <option value="">جميع الدورات</option>
                                            <option value="active">نشطة</option>
                                            <option value="inactive">غير نشطة</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="courses-list" id="coursesList">
                                <div class="text-center p-4">
                                    <div class="spinner-border text-primary"></div>
                                    <p class="mt-2 text-muted">جاري تحميل الدورات...</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Users Management -->
                <div class="col-lg-6" data-aos="fade-left">
                    <div class="management-card">
                        <div class="card-header">
                            <h5 class="card-title">
                                <i class="fas fa-users me-2 text-success"></i>
                                إدارة المستخدمين
                            </h5>
                            <button class="btn btn-sm btn-success" onclick="exportUsers()">
                                <i class="fas fa-download me-1"></i>تصدير
                            </button>
                        </div>
                        <div class="card-body">
                            <div class="management-actions mb-3">
                                <div class="row g-2">
                                    <div class="col-md-8">
                                        <input type="text" class="form-control" id="userSearch" 
                                               placeholder="البحث عن مستخدم...">
                                    </div>
                                    <div class="col-md-4">
                                        <select class="form-select" id="userFilter">
                                            <option value="">جميع المستخدمين</option>
                                            <option value="admin">مسؤولين</option>
                                            <option value="user">مستخدمين</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="users-list" id="usersList">
                                <div class="text-center p-4">
                                    <div class="spinner-border text-success"></div>
                                    <p class="mt-2 text-muted">جاري تحميل المستخدمين...</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Codes Management -->
                <div class="col-lg-6" data-aos="fade-right" data-aos-delay="200">
                    <div class="management-card">
                        <div class="card-header">
                            <h5 class="card-title">
                                <i class="fas fa-key me-2 text-warning"></i>
                                إدارة أكواد الاشتراك
                            </h5>
                            <button class="btn btn-sm btn-warning" onclick="openCodeModal('create')">
                                <i class="fas fa-plus me-1"></i>إنشاء كود
                            </button>
                        </div>
                        <div class="card-body">
                            <div class="management-actions mb-3">
                                <div class="row g-2">
                                    <div class="col-md-8">
                                        <input type="text" class="form-control" id="codeSearch" 
                                               placeholder="البحث عن كود...">
                                    </div>
                                    <div class="col-md-4">
                                        <select class="form-select" id="codeFilter">
                                            <option value="">جميع الأكواد</option>
                                            <option value="active">نشطة</option>
                                            <option value="expired">منتهية</option>
                                            <option value="used">مستخدمة</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="codes-list" id="codesList">
                                <div class="text-center p-4">
                                    <div class="spinner-border text-warning"></div>
                                    <p class="mt-2 text-muted">جاري تحميل الأكواد...</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Analytics & Reports -->
                <div class="col-lg-6" data-aos="fade-left" data-aos-delay="200">
                    <div class="management-card">
                        <div class="card-header">
                            <h5 class="card-title">
                                <i class="fas fa-chart-line me-2 text-info"></i>
                                التحليلات والتقارير
                            </h5>
                            <div class="dropdown">
                                <button class="btn btn-sm btn-info dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                    <i class="fas fa-download me-1"></i>تصدير تقرير
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="#" onclick="exportReport('daily')">
                                        <i class="fas fa-calendar-day me-2"></i>تقرير يومي
                                    </a></li>
                                    <li><a class="dropdown-item" href="#" onclick="exportReport('weekly')">
                                        <i class="fas fa-calendar-week me-2"></i>تقرير أسبوعي
                                    </a></li>
                                    <li><a class="dropdown-item" href="#" onclick="exportReport('monthly')">
                                        <i class="fas fa-calendar-alt me-2"></i>تقرير شهري
                                    </a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="analytics-summary">
                                <div class="row g-3">
                                    <div class="col-6">
                                        <div class="metric-item">
                                            <div class="metric-icon">
                                                <i class="fas fa-eye text-primary"></i>
                                            </div>
                                            <div class="metric-content">
                                                <h6 class="metric-value" id="totalViews">0</h6>
                                                <p class="metric-label">مشاهدات اليوم</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="metric-item">
                                            <div class="metric-icon">
                                                <i class="fas fa-clock text-success"></i>
                                            </div>
                                            <div class="metric-content">
                                                <h6 class="metric-value" id="avgWatchTime">0</h6>
                                                <p class="metric-label">متوسط المشاهدة</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="metric-item">
                                            <div class="metric-icon">
                                                <i class="fas fa-user-plus text-warning"></i>
                                            </div>
                                            <div class="metric-content">
                                                <h6 class="metric-value" id="newUsers">0</h6>
                                                <p class="metric-label">مستخدمين جدد</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="metric-item">
                                            <div class="metric-icon">
                                                <i class="fas fa-percentage text-info"></i>
                                            </div>
                                            <div class="metric-content">
                                                <h6 class="metric-value" id="completionRate">0%</h6>
                                                <p class="metric-label">معدل الإكمال</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Chart Container -->
                            <div class="chart-container mt-4">
                                <canvas id="analyticsChart" width="400" height="200"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions-section mt-5" data-aos="fade-up">
            <h4 class="section-title mb-4">
                <i class="fas fa-bolt me-2 text-warning"></i>
                إجراءات سريعة
            </h4>
            <div class="row g-3">
                <div class="col-md-2">
                    <button class="btn btn-outline-primary w-100 quick-action-btn" onclick="backupDatabase()">
                        <i class="fas fa-database fa-2x mb-2"></i>
                        <br>نسخ احتياطي
                    </button>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-outline-success w-100 quick-action-btn" onclick="clearCache()">
                        <i class="fas fa-broom fa-2x mb-2"></i>
                        <br>مسح الكاش
                    </button>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-outline-info w-100 quick-action-btn" onclick="checkSystemHealth()">
                        <i class="fas fa-heartbeat fa-2x mb-2"></i>
                        <br>فحص النظام
                    </button>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-outline-warning w-100 quick-action-btn" onclick="viewLogs()">
                        <i class="fas fa-list fa-2x mb-2"></i>
                        <br>سجلات النظام
                    </button>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-outline-secondary w-100 quick-action-btn" onclick="manageSettings()">
                        <i class="fas fa-cogs fa-2x mb-2"></i>
                        <br>الإعدادات
                    </button>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-outline-danger w-100 quick-action-btn" onclick="securityReport()">
                        <i class="fas fa-shield-alt fa-2x mb-2"></i>
                        <br>تقرير الأمان
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modals -->
<!-- Course Modal -->
<div class="modal fade" id="courseModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="courseModalTitle">
                    <i class="fas fa-graduation-cap me-2"></i>إضافة دورة جديدة
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="courseForm">
                    <input type="hidden" id="courseId" name="id">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="courseName" class="form-label">
                                <i class="fas fa-book me-1"></i>اسم الدورة *
                            </label>
                            <input type="text" class="form-control" id="courseName" name="name" required>
                        </div>
                        <div class="col-md-6">
                            <label for="courseCode" class="form-label">
                                <i class="fas fa-code me-1"></i>كود الدورة *
                            </label>
                            <input type="text" class="form-control" id="courseCode" name="code" required>
                        </div>
                        <div class="col-12">
                            <label for="courseDescription" class="form-label">
                                <i class="fas fa-align-left me-1"></i>وصف الدورة
                            </label>
                            <textarea class="form-control" id="courseDescription" name="description" rows="3"></textarea>
                        </div>
                        <div class="col-md-6">
                            <label for="coursePrice" class="form-label">
                                <i class="fas fa-dollar-sign me-1"></i>السعر
                            </label>
                            <input type="number" class="form-control" id="coursePrice" name="price" min="0" step="0.01">
                        </div>
                        <div class="col-md-6">
                            <label for="courseOrder" class="form-label">
                                <i class="fas fa-sort me-1"></i>ترتيب العرض
                            </label>
                            <input type="number" class="form-control" id="courseOrder" name="sort_order" min="0">
                        </div>
                        <div class="col-12">
                            <label for="courseImage" class="form-label">
                                <i class="fas fa-image me-1"></i>صورة الدورة
                            </label>
                            <input type="file" class="form-control" id="courseImage" name="image" accept="image/*">
                        </div>
                        <div class="col-12">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="courseActive" name="is_active" checked>
                                <label class="form-check-label" for="courseActive">
                                    <i class="fas fa-eye me-1"></i>دورة نشطة
                                </label>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="fas fa-times me-1"></i>إلغاء
                </button>
                <button type="button" class="btn btn-primary" onclick="saveCourse()">
                    <i class="fas fa-save me-1"></i>حفظ
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Code Modal -->
<div class="modal fade" id="codeModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="codeModalTitle">
                    <i class="fas fa-key me-2"></i>إنشاء كود اشتراك
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="codeForm">
                    <input type="hidden" id="codeIdInput" name="id">
                    <div class="mb-3">
                        <label for="codeValue" class="form-label">
                            <i class="fas fa-ticket-alt me-1"></i>الكود *
                        </label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="codeValue" name="code" required>
                            <button class="btn btn-outline-secondary" type="button" onclick="generateRandomCode()">
                                <i class="fas fa-random"></i>توليد
                            </button>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="codeCourse" class="form-label">
                            <i class="fas fa-graduation-cap me-1"></i>الدورة *
                        </label>
                        <select class="form-select" id="codeCourse" name="course_id" required>
                            <option value="">اختر الدورة...</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="codeMaxUses" class="form-label">
                            <i class="fas fa-users me-1"></i>عدد الاستخدامات المسموح (0 = غير محدود)
                        </label>
                        <input type="number" class="form-control" id="codeMaxUses" name="max_uses" min="0" value="1">
                    </div>
                    <div class="mb-3">
                        <label for="codeExpiry" class="form-label">
                            <i class="fas fa-calendar me-1"></i>تاريخ انتهاء الصلاحية
                        </label>
                        <input type="datetime-local" class="form-control" id="codeExpiry" name="expires_at">
                    </div>
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="codeActive" name="is_active" checked>
                            <label class="form-check-label" for="codeActive">
                                <i class="fas fa-check me-1"></i>كود نشط
                            </label>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="fas fa-times me-1"></i>إلغاء
                </button>
                <button type="button" class="btn btn-warning" onclick="saveCode()">
                    <i class="fas fa-save me-1"></i>حفظ
                </button>
            </div>
        </div>
    </div>
</div>

<style>
/* تنسيقات لوحة التحكم */
.dashboard-page {
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    min-height: 100vh;
    padding: 2rem 0;
}

.dashboard-header {
    background: white;
    padding: 2rem;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.1);
    margin-bottom: 2rem;
}

.dashboard-title {
    font-size: 2.5rem;
    font-weight: 700;
    color: #2c3e50;
    margin-bottom: 0.5rem;
}

.dashboard-subtitle {
    font-size: 1.125rem;
    margin-bottom: 0;
}

.stats-card {
    background: white;
    border-radius: 20px;
    padding: 2rem;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
    height: 100%;
    position: relative;
    overflow: hidden;
}

.stats-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: linear-gradient(90deg, #667eea, #764ba2);
}

.stats-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.15);
}

.stats-icon {
    width: 80px;
    height: 80px;
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 1.5rem;
    position: relative;
}

.courses-icon { background: linear-gradient(135deg, #667eea, #764ba2); }
.users-icon { background: linear-gradient(135deg, #f093fb, #f5576c); }
.subscriptions-icon { background: linear-gradient(135deg, #4facfe, #00f2fe); }
.revenue-icon { background: linear-gradient(135deg, #43e97b, #38f9d7); }

.stats-number {
    font-size: 2.5rem;
    font-weight: 700;
    color: #2c3e50;
    margin-bottom: 0.5rem;
}

.stats-label {
    color: #6c757d;
    font-size: 1rem;
    margin-bottom: 1rem;
}

.stats-change {
    display: flex;
    align-items: center;
    font-size: 0.9rem;
    font-weight: 600;
}

.stats-change.positive { color: #28a745; }
.stats-change.negative { color: #dc3545; }
.stats-change.neutral { color: #6c757d; }

.management-card {
    background: white;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.1);
    overflow: hidden;
    height: 100%;
}

.management-card .card-header {
    background: linear-gradient(135deg, #f8f9fa, #e9ecef);
    border-bottom: 1px solid #dee2e6;
    padding: 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.management-card .card-title {
    margin: 0;
    font-size: 1.25rem;
    font-weight: 600;
}

.management-actions {
    padding: 0 1.5rem;
}

.courses-list, .users-list, .codes-list {
    max-height: 400px;
    overflow-y: auto;
    padding: 0 1.5rem 1.5rem;
}

.list-item {
    display: flex;
    justify-content: between;
    align-items: center;
    padding: 1rem;
    border: 1px solid #e9ecef;
    border-radius: 8px;
    margin-bottom: 0.75rem;
    transition: all 0.3s ease;
}

.list-item:hover {
    border-color: #007bff;
    background-color: #f8f9fa;
}

.item-info {
    flex: 1;
}

.item-title {
    font-weight: 600;
    margin-bottom: 0.25rem;
}

.item-meta {
    color: #6c757d;
    font-size: 0.875rem;
}

.item-actions {
    display: flex;
    gap: 0.5rem;
}

.quick-action-btn {
    padding: 1.5rem;
    border: 2px dashed #dee2e6;
    transition: all 0.3s ease;
    text-align: center;
    background: white;
}

.quick-action-btn:hover {
    border-style: solid;
    transform: translateY(-3px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.metric-item {
    display: flex;
    align-items: center;
    padding: 1rem;
    background: #f8f9fa;
    border-radius: 10px;
    margin-bottom: 1rem;
}

.metric-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: white;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 1rem;
}

.metric-content {
    flex: 1;
}

.metric-value {
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 0.25rem;
}

.metric-label {
    color: #6c757d;
    font-size: 0.875rem;
    margin: 0;
}

.chart-container {
    position: relative;
    height: 200px;
    background: #f8f9fa;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Responsive Design */
@media (max-width: 768px) {
    .dashboard-title {
        font-size: 2rem;
    }
    
    .stats-card {
        padding: 1.5rem;
        margin-bottom: 1rem;
    }
    
    .stats-number {
        font-size: 2rem;
    }
    
    .management-card .card-header {
        flex-direction: column;
        gap: 1rem;
        text-align: center;
    }
    
    .quick-action-btn {
        padding: 1rem;
        font-size: 0.875rem;
    }
}
</style>

<?php
// تضمين تذييل الصفحة
$additionalScripts = '
<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    initializeDashboard();
});

// تهيئة لوحة التحكم
function initializeDashboard() {
    loadStatistics();
    loadCourses();
    loadUsers();
    loadCodes();
    loadAnalytics();
    setupSearchFilters();
    initializeChart();
}

// تحميل الإحصائيات
async function loadStatistics() {
    try {
        const response = await fetchAPI("/api/dashboard/stats");
        
        if (response.success) {
            animateStatNumber("coursesCount", response.stats.courses || 0);
            animateStatNumber("usersCount", response.stats.users || 0);
            animateStatNumber("subscriptionsCount", response.stats.subscriptions || 0);
            animateStatNumber("codesCount", response.stats.codes || 0);
        }
    } catch (error) {
        console.error("Error loading statistics:", error);
    }
}

// تحريك أرقام الإحصائيات
function animateStatNumber(elementId, target) {
    const element = document.getElementById(elementId);
    if (!element) return;
    
    const duration = 2000;
    const step = target / (duration / 16);
    let current = 0;
    
    const timer = setInterval(() => {
        current += step;
        if (current >= target) {
            current = target;
            clearInterval(timer);
        }
        element.textContent = Math.floor(current).toLocaleString("ar-SA");
    }, 16);
}

// تحميل الدورات
async function loadCourses() {
    try {
        const response = await fetchAPI("/api/course/get_all?admin=1");
        const container = document.getElementById("coursesList");
        
        if (response.success && response.courses.length > 0) {
            container.innerHTML = "";
            
            response.courses.forEach(course => {
                const item = createCourseListItem(course);
                container.appendChild(item);
            });
        } else {
            container.innerHTML =