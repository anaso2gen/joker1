<?php
/**
 * محتوى الصفحة الرئيسية مع العناصر المرئية المحسنة
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

// تضمين رأس الصفحة
include_once __DIR__ . '/../layout/header.php';
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center min-vh-100">
            <div class="col-lg-6" data-aos="fade-right">
                <div class="hero-content">
                    <h1 class="display-3 fw-bold text-white mb-4">
                        <span class="text-gradient">تعلم</span> بلا حدود
                        <br>مع <span class="highlight"><?php echo SITE_NAME; ?></span>
                    </h1>
                    <p class="lead text-white-50 mb-4">
                        <i class="fas fa-graduation-cap me-2"></i>
                        منصة تعليمية متطورة تقدم أفضل الدورات التدريبية 
                        بجودة عالية وبمحتوى احترافي يساعدك على تطوير مهاراتك
                    </p>
                    
                    <?php if ($user): ?>
                    <div class="hero-actions mb-4">
                        <a href="#my-courses" class="btn btn-light btn-lg me-3">
                            <i class="fas fa-book-open me-2"></i>دوراتي
                        </a>
                        <a href="#all-courses" class="btn btn-outline-light btn-lg">
                            <i class="fas fa-search me-2"></i>استكشف المزيد
                        </a>
                    </div>
                    <?php else: ?>
                    <div class="hero-actions mb-4">
                        <a href="<?php echo SITE_URL; ?>/subscribe.php" class="btn btn-light btn-lg me-3">
                            <i class="fas fa-rocket me-2"></i>ابدأ الآن
                        </a>
                        <a href="<?php echo SITE_URL; ?>/login.php" class="btn btn-outline-light btn-lg">
                            <i class="fas fa-sign-in-alt me-2"></i>تسجيل الدخول
                        </a>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Hero Stats -->
                    <div class="hero-stats" id="heroStats">
                        <div class="stat-item" data-aos="fade-up" data-aos-delay="200">
                            <div class="stat-number" data-count="150">0</div>
                            <div class="stat-label">
                                <i class="fas fa-video me-1"></i>ساعة فيديو
                            </div>
                        </div>
                        <div class="stat-item" data-aos="fade-up" data-aos-delay="300">
                            <div class="stat-number" data-count="25">0</div>
                            <div class="stat-label">
                                <i class="fas fa-graduation-cap me-1"></i>دورة تدريبية
                            </div>
                        </div>
                        <div class="stat-item" data-aos="fade-up" data-aos-delay="400">
                            <div class="stat-number" data-count="1000">0</div>
                            <div class="stat-label">
                                <i class="fas fa-users me-1"></i>طالب نشط
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-6" data-aos="fade-left" data-aos-delay="200">
                <div class="hero-illustration">
                    <!-- Lottie Animation for Learning -->
                    <lottie-player
                        src="https://assets3.lottiefiles.com/packages/lf20_dmw2awwg.json"
                        background="transparent"
                        speed="1"
                        style="width: 100%; height: 500px;"
                        loop
                        autoplay>
                    </lottie-player>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Floating Elements -->
    <div class="floating-elements">
        <div class="floating-icon" style="top: 20%; left: 10%;" data-aos="fade-in" data-aos-delay="1000">
            <i class="fas fa-code text-info"></i>
        </div>
        <div class="floating-icon" style="top: 60%; right: 15%;" data-aos="fade-in" data-aos-delay="1200">
            <i class="fas fa-palette text-warning"></i>
        </div>
        <div class="floating-icon" style="top: 80%; left: 20%;" data-aos="fade-in" data-aos-delay="1400">
            <i class="fas fa-chart-line text-success"></i>
        </div>
    </div>
</section>

<?php if ($user): ?>
<!-- My Courses Section -->
<section class="my-courses-section py-5" id="my-courses">
    <div class="container">
        <div class="section-header text-center mb-5" data-aos="fade-up">
            <h2 class="section-title">
                <i class="fas fa-bookmark me-3 text-primary"></i>
                دوراتي المشتركة
            </h2>
            <p class="section-subtitle text-muted">
                تابع تقدمك في الدورات التي اشتركت بها
            </p>
        </div>
        
        <div class="courses-loading text-center" id="myCoursesLoading">
            <div class="spinner-border text-primary me-2"></div>
            <span>جاري تحميل دوراتك...</span>
        </div>
        
        <div class="row" id="myCoursesContainer" style="display: none;">
            <!-- سيتم ملء الكورسات هنا عبر JavaScript -->
        </div>
        
        <div class="no-courses text-center" id="noMyCourses" style="display: none;">
            <div class="empty-state" data-aos="zoom-in">
                <lottie-player
                    src="https://assets1.lottiefiles.com/packages/lf20_UJNc2t.json"
                    background="transparent"
                    speed="1"
                    style="width: 200px; height: 200px; margin: 0 auto;"
                    loop
                    autoplay>
                </lottie-player>
                <h4 class="mt-3">لم تشترك في أي دورة بعد</h4>
                <p class="text-muted">اشترك في دورة للبدء في رحلتك التعليمية</p>
                <a href="<?php echo SITE_URL; ?>/subscribe.php" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>اشترك في دورة
                </a>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- All Courses Section -->
<section class="all-courses-section py-5 bg-light" id="all-courses">
    <div class="container">
        <div class="section-header text-center mb-5" data-aos="fade-up">
            <h2 class="section-title">
                <i class="fas fa-star me-3 text-warning"></i>
                جميع الدورات المتاحة
            </h2>
            <p class="section-subtitle text-muted">
                اكتشف مجموعة واسعة من الدورات في مختلف المجالات
            </p>
        </div>
        
        <!-- Filters -->
        <div class="filters-section mb-4" data-aos="fade-up" data-aos-delay="100">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="search-box">
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="fas fa-search text-primary"></i>
                            </span>
                            <input type="text" class="form-control" id="courseSearch" 
                                   placeholder="ابحث عن دورة...">
                            <button class="btn btn-outline-secondary" type="button" id="clearSearch">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="sort-controls">
                        <select class="form-select" id="courseSort">
                            <option value="created_at">الأحدث</option>
                            <option value="name">الاسم</option>
                            <option value="popular">الأكثر شعبية</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="courses-loading text-center" id="allCoursesLoading">
            <div class="d-flex justify-content-center align-items-center">
                <div class="spinner-border text-primary me-3"></div>
                <span>جاري تحميل الدورات...</span>
            </div>
        </div>
        
        <div class="row" id="allCoursesContainer" style="display: none;">
            <!-- سيتم ملء الكورسات هنا عبر JavaScript -->
        </div>
        
        <!-- Load More Button -->
        <div class="text-center mt-4" id="loadMoreContainer" style="display: none;">
            <button class="btn btn-outline-primary btn-lg" id="loadMoreBtn">
                <i class="fas fa-plus me-2"></i>تحميل المزيد
            </button>
        </div>
        
        <div class="no-courses text-center" id="noAllCourses" style="display: none;">
            <div class="empty-state" data-aos="zoom-in">
                <i class="fas fa-search fa-5x text-muted mb-3"></i>
                <h4>لم يتم العثور على دورات</h4>
                <p class="text-muted">جرب تغيير كلمات البحث أو الفلاتر</p>
            </div>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="features-section py-5">
    <div class="container">
        <div class="section-header text-center mb-5" data-aos="fade-up">
            <h2 class="section-title">
                <i class="fas fa-gem me-3 text-danger"></i>
                لماذا تختار منصتنا؟
            </h2>
            <p class="section-subtitle text-muted">
                نقدم تجربة تعليمية متميزة ومتطورة
            </p>
        </div>
        
        <div class="row g-4">
            <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
                <div class="feature-card modern-card">
                    <div class="feature-icon-modern mb-4">
                        <i class="fas fa-play-circle text-danger"></i>
                        <div class="icon-bg-modern"></div>
                    </div>
                    <h5 class="fw-bold mb-3">فيديوهات عالية الجودة</h5>
                    <p class="text-muted">
                        محتوى مرئي احترافي بدقة 4K مع تقنيات حديثة لضمان أفضل تجربة مشاهدة
                    </p>
                    <div class="feature-highlight">
                        <i class="fas fa-check text-success me-2"></i>
                        <span>تحكم في سرعة التشغيل</span>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
                <div class="feature-card modern-card">
                    <div class="feature-icon-modern mb-4">
                        <i class="fas fa-shield-alt text-success"></i>
                        <div class="icon-bg-modern"></div>
                    </div>
                    <h5 class="fw-bold mb-3">حماية عالية</h5>
                    <p class="text-muted">
                        نظام حماية متطور يمنع التحميل والنسخ غير المشروع للمحتوى التعليمي
                    </p>
                    <div class="feature-highlight">
                        <i class="fas fa-check text-success me-2"></i>
                        <span>تشفير متقدم للفيديوهات</span>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="300">
                <div class="feature-card modern-card">
                    <div class="feature-icon-modern mb-4">
                        <i class="fas fa-mobile-alt text-info"></i>
                        <div class="icon-bg-modern"></div>
                    </div>
                    <h5 class="fw-bold mb-3">متوافق مع جميع الأجهزة</h5>
                    <p class="text-muted">
                        شاهد دوراتك على أي جهاز - كمبيوتر، تابلت، أو هاتف ذكي بنفس الجودة
                    </p>
                    <div class="feature-highlight">
                        <i class="fas fa-check text-success me-2"></i>
                        <span>تصميم متجاوب بالكامل</span>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="400">
                <div class="feature-card modern-card">
                    <div class="feature-icon-modern mb-4">
                        <i class="fas fa-chart-line text-warning"></i>
                        <div class="icon-bg-modern"></div>
                    </div>
                    <h5 class="fw-bold mb-3">تتبع التقدم</h5>
                    <p class="text-muted">
                        راقب تقدمك في كل درس ودورة مع إحصائيات مفصلة وتقارير شاملة
                    </p>
                    <div class="feature-highlight">
                        <i class="fas fa-check text-success me-2"></i>
                        <span>إحصائيات تفاعلية</span>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="500">
                <div class="feature-card modern-card">
                    <div class="feature-icon-modern mb-4">
                        <i class="fas fa-headset text-primary"></i>
                        <div class="icon-bg-modern"></div>
                    </div>
                    <h5 class="fw-bold mb-3">دعم فني متطور</h5>
                    <p class="text-muted">
                        فريق دعم فني محترف متاح على مدار الساعة لحل أي مشكلة تقنية
                    </p>
                    <div class="feature-highlight">
                        <i class="fas fa-check text-success me-2"></i>
                        <span>استجابة سريعة</span>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="600">
                <div class="feature-card modern-card">
                    <div class="feature-icon-modern mb-4">
                        <i class="fas fa-certificate text-purple"></i>
                        <div class="icon-bg-modern"></div>
                    </div>
                    <h5 class="fw-bold mb-3">شهادات معتمدة</h5>
                    <p class="text-muted">
                        احصل على شهادة إتمام معتمدة عند انتهائك من أي دورة تدريبية
                    </p>
                    <div class="feature-highlight">
                        <i class="fas fa-check text-success me-2"></i>
                        <span>شهادات قابلة للتحقق</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta-section py-5 bg-primary text-white">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8" data-aos="fade-right">
                <h3 class="fw-bold mb-3">
                    <i class="fas fa-rocket me-3"></i>
                    ابدأ رحلتك التعليمية اليوم
                </h3>
                <p class="lead mb-0">
                    انضم إلى آلاف الطلاب الذين طوروا مهاراتهم معنا واحصل على أفضل المحتوى التعليمي
                </p>
            </div>
            <div class="col-lg-4 text-lg-end" data-aos="fade-left" data-aos-delay="200">
                <?php if (!$user): ?>
                <a href="<?php echo SITE_URL; ?>/subscribe.php" class="btn btn-light btn-lg px-5">
                    <i class="fas fa-play me-2"></i>ابدأ الآن
                </a>
                <?php else: ?>
                <a href="#all-courses" class="btn btn-light btn-lg px-5">
                    <i class="fas fa-search me-2"></i>استكشف الدورات
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<style>
/* تحسينات CSS للصفحة الرئيسية */
.home-page {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.hero-section {
    position: relative;
    min-height: 100vh;
    background: var(--gradient-primary);
    overflow: hidden;
}

.hero-section::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000"><polygon fill="%23ffffff" fill-opacity="0.1" points="0,1000 1000,0 1000,1000"/></svg>');
    background-size: cover;
}

.text-gradient {
    background: linear-gradient(45deg, #ffd700, #ff6b6b);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.highlight {
    position: relative;
    color: #ffd700;
}

.highlight::after {
    content: '';
    position: absolute;
    bottom: -5px;
    left: 0;
    width: 100%;
    height: 3px;
    background: linear-gradient(90deg, #ffd700, #ff6b6b);
    border-radius: 2px;
}

.hero-stats {
    display: flex;
    gap: 2rem;
    margin-top: 3rem;
}

.stat-item {
    text-align: center;
    color: white;
}

.stat-number {
    font-size: 2.5rem;
    font-weight: 700;
    line-height: 1;
    color: #ffd700;
}

.stat-label {
    font-size: 0.9rem;
    opacity: 0.9;
    margin-top: 0.5rem;
}

.floating-elements {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    z-index: 1;
}

.floating-icon {
    position: absolute;
    font-size: 2rem;
    opacity: 0.6;
    animation: float 3s ease-in-out infinite;
}

@keyframes float {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-20px); }
}

.floating-icon:nth-child(1) { animation-delay: 0s; }
.floating-icon:nth-child(2) { animation-delay: 1s; }
.floating-icon:nth-child(3) { animation-delay: 2s; }

.section-header {
    margin-bottom: 4rem;
}

.section-title {
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 1rem;
}

.section-subtitle {
    font-size: 1.125rem;
    max-width: 600px;
    margin: 0 auto;
}

.modern-card {
    background: white;
    border-radius: 20px;
    padding: 2.5rem;
    box-shadow: 0 10px 40px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
    border: none;
    height: 100%;
    position: relative;
    overflow: hidden;
}

.modern-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: linear-gradient(90deg, #667eea, #764ba2);
}

.modern-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 60px rgba(0,0,0,0.15);
}

.feature-icon-modern {
    position: relative;
    width: 80px;
    height: 80px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto;
}

.feature-icon-modern i {
    font-size: 2.5rem;
    z-index: 2;
    position: relative;
}

.icon-bg-modern {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border-radius: 50%;
    background: linear-gradient(135deg, rgba(102,126,234,0.1), rgba(118,75,162,0.1));
    animation: iconPulse 2s infinite;
}

.feature-highlight {
    display: flex;
    align-items: center;
    margin-top: 1rem;
    padding: 0.75rem;
    background: rgba(40,167,69,0.1);
    border-radius: 8px;
    font-size: 0.9rem;
    font-weight: 500;
}

.search-box .input-group {
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

.search-box .form-control {
    border: none;
    padding: 1rem 1.5rem;
    font-size: 1.1rem;
}

.search-box .form-control:focus {
    box-shadow: none;
}

.courses-loading {
    padding: 3rem 0;
    font-size: 1.125rem;
    color: #6c757d;
}

.empty-state {
    padding: 3rem 0;
}

.cta-section {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    position: relative;
}

.cta-section::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000"><polygon fill="%23ffffff" fill-opacity="0.05" points="0,0 1000,1000 0,1000"/></svg>');
    background-size: cover;
}

.text-purple {
    color: #6f42c1;
}

/* Responsive Design */
@media (max-width: 768px) {
    .hero-stats {
        flex-direction: column;
        gap: 1rem;
        text-align: center;
    }
    
    .section-title {
        font-size: 2rem;
    }
    
    .hero-actions {
        text-align: center;
    }
    
    .hero-actions .btn {
        margin-bottom: 1rem;
    }
    
    .floating-elements {
        display: none;
    }
    
    .modern-card {
        padding: 2rem;
    }
}

@media (max-width: 576px) {
    .hero-section {
        padding: 2rem 0;
    }
    
    .display-3 {
        font-size: 2.5rem;
    }
    
    .stat-number {
        font-size: 2rem;
    }
}
</style>

<?php
// تضمين تذييل الصفحة
$additionalScripts = '
<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
<script>
let currentPage = 1;
let isLoading = false;
let hasMoreCourses = true;

document.addEventListener("DOMContentLoaded", function() {
    initializeHomePage();
});

// تهيئة الصفحة الرئيسية
function initializeHomePage() {
    animateStats();
    setupSearch();
    loadMyCourses();
    loadAllCourses();
    setupInfiniteScroll();
}

// تحريك الإحصائيات
function animateStats() {
    const statNumbers = document.querySelectorAll(".stat-number");
    
    statNumbers.forEach(stat => {
        const target = parseInt(stat.getAttribute("data-count"));
        const duration = 2000;
        const step = target / (duration / 16);
        let current = 0;
        
        const timer = setInterval(() => {
            current += step;
            if (current >= target) {
                current = target;
                clearInterval(timer);
            }
            stat.textContent = Math.floor(current).toLocaleString("ar-SA");
        }, 16);
    });
}

// إعداد البحث
function setupSearch() {
    const searchInput = document.getElementById("courseSearch");
    const clearBtn = document.getElementById("clearSearch");
    const sortSelect = document.getElementById("courseSort");
    
    let searchTimeout;
    
    searchInput.addEventListener("input", function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            currentPage = 1;
            hasMoreCourses = true;
            loadAllCourses(true);
        }, 500);
    });
    
    clearBtn.addEventListener("click", function() {
        searchInput.value = "";
        currentPage = 1;
        hasMoreCourses = true;
        loadAllCourses(true);
    });
    
    sortSelect.addEventListener("change", function() {
        currentPage = 1;
        hasMoreCourses = true;
        loadAllCourses(true);
    });
}

// تحميل دوراتي
async function loadMyCourses() {
    const container = document.getElementById("myCoursesContainer");
    const loading = document.getElementById("myCoursesLoading");
    const noCourses = document.getElementById("noMyCourses");
    
    if (!container) return; // للزوار غير المسجلين
    
    try {
        const response = await fetchAPI("/api/subscribe/check");
        
        if (response.success && response.subscriptions.length > 0) {
            loading.style.display = "none";
            container.style.display = "flex";
            
            container.innerHTML = "";
            response.subscriptions.forEach((course, index) => {
                const courseCard = createCourseCard(course, true, index * 100);
                container.appendChild(courseCard);
            });
            
            // تحديث AOS
            AOS.refresh();
        } else {
            loading.style.display = "none";
            noCourses.style.display = "block";
        }
        
    } catch (error) {
        console.error("Error loading my courses:", error);
        loading.style.display = "none";
        noCourses.style.display = "block";
    }
}

// تحميل جميع الدورات
async function loadAllCourses(reset = false) {
    if (isLoading) return;
    
    const container = document.getElementById("allCoursesContainer");
    const loading = document.getElementById("allCoursesLoading");
    const noCourses = document.getElementById("noAllCourses");
    const loadMoreContainer = document.getElementById("loadMoreContainer");
    
    if (reset) {
        container.innerHTML = "";
        container.style.display = "none";
        noCourses.style.display = "none";
        loadMoreContainer.style.display = "none";
    }
    
    isLoading = true;
    loading.style.display = "block";
    
    try {
        const searchQuery = document.getElementById("courseSearch").value;
        const sortBy = document.getElementById("courseSort").value;
        
        const params = new URLSearchParams({
            page: currentPage,
            limit: 6,
            search: searchQuery,
            sort: sortBy
        });
        
        const response = await fetchAPI(`/api/course/get_all?${params}`);
        
        if (response.success) {
            loading.style.display = "none";
            
            if (response.courses.length > 0) {
                container.style.display = "flex";
                
                response.courses.forEach((course, index) => {
                    const courseCard = createCourseCard(course, false, index * 100);
                    container.appendChild(courseCard);
                });
                
                // التحقق من وجود المزيد
                hasMoreCourses = response.pagination.has_more;
                
                if (hasMoreCourses) {
                    loadMoreContainer.style.display = "block";
                } else {
                    loadMoreContainer.style.display = "none";
                }
                
                // تحديث AOS
                AOS.refresh();
            } else if (currentPage === 1) {
                noCourses.style.display = "block";
            }
        } else {
            throw new Error(response.message);
        }
        
    } catch (error) {
        console.error("Error loading courses:", error);
        loading.style.display = "none";
        if (currentPage === 1) {
            noCourses.style.display = "block";
        }
    } finally {
        isLoading = false;
    }
}

// إنشاء كارت الكورس
function createCourseCard(course, isSubscribed = false, delay = 0) {
    const col = document.createElement("div");
    col.className = "col-lg-4 col-md-6 mb-4";
    col.setAttribute("data-aos", "fade-up");
    col.setAttribute("data-aos-delay", delay);
    
    const progressHtml = isSubscribed ? `
        <div class="progress-section mt-3">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-muted">التقدم</span>
                <span class="badge bg-success">${course.progress_percentage}%</span>
            </div>
            <div class="progress" style="height: 6px;">
                <div class="progress-bar bg-success" style="width: ${course.progress_percentage}%"></div>
            </div>
            <div class="d-flex justify-content-between mt-2">
                <small class="text-muted">${course.completed_lessons} من ${course.lessons_count} درس</small>
                <small class="text-muted">${course.total_duration}</small>
            </div>
        </div>
    ` : "";
    
    const subscriptionBadge = course.subscribed ? 
        `<div class="subscription-badge"><i class="fas fa-check me-1"></i>مشترك</div>` : "";
    
    const actionButton = course.subscribed ? 
        `<a href="#" onclick="openCourse(${course.id})" class="btn btn-success">
            <i class="fas fa-play me-2"></i>متابعة التعلم
        </a>` : 
        `<a href="/subscribe.php" class="btn btn-primary">
            <i class="fas fa-unlock me-2"></i>اشترك الآن
        </a>`;
    
    col.innerHTML = `
        <div class="course-card">
            <div class="course-image">
                <img src="${course.image_url || '/assets/images/default-course.jpg'}" 
                     alt="${course.name}" loading="lazy">
                ${subscriptionBadge}
                <div class="course-overlay">
                    <div class="overlay-content">
                        <i class="fas fa-play-circle"></i>
                        <p class="mb-0">شاهد الآن</p>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <h5 class="card-title">
                    <i class="fas fa-graduation-cap me-2 text-primary"></i>
                    ${course.name}
                </h5>
                <p class="card-text">${course.description || 'وصف الدورة غير متوفر'}</p>
                
                <div class="course-meta">
                    <div class="meta-item">
                        <i class="fas fa-folder text-info"></i>
                        <span>${course.sections_count || 0} قسم</span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-video text-success"></i>
                        <span>${course.lessons_count || 0} درس</span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-clock text-warning"></i>
                        <span>${course.total_duration || '0 دقيقة'}</span>
                    </div>
                    ${course.subscribers_count ? `
                    <div class="meta-item">
                        <i class="fas fa-users text-primary"></i>
                        <span>${course.subscribers_count} طالب</span>
                    </div>
                    ` : ''}
                </div>
                
                ${progressHtml}
                
                <div class="d-grid mt-3">
                    ${actionButton}
                </div>
            </div>
        </div>
    `;
    
    return col;
}

// فتح الكورس
function openCourse(courseId) {
    // هنا يمكن فتح صفحة الكورس أو أول درس
    window.location.href = `/course.php?id=${courseId}`;
}

// إعداد التمرير اللانهائي
function setupInfiniteScroll() {
    const loadMoreBtn = document.getElementById("loadMoreBtn");
    
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener("click", function() {
            if (hasMoreCourses && !isLoading) {
                currentPage++;
                loadAllCourses();
            }
        });
    }
    
    // التمرير التلقائي (اختياري)
    window.addEventListener("scroll", function() {
        if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 1000) {
            if (hasMoreCourses && !isLoading && currentPage > 1) {
                currentPage++;
                loadAllCourses();
            }
        }
    });
}
</script>
';

include_once __DIR__ . '/../layout/footer.php';
?>