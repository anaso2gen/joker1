<?php
/**
 * صفحة تسجيل الدخول - العرض
 * منصة ترند التعليمية - Learning Management System
 */

$pageTitle = 'تسجيل الدخول';
$pageDescription = 'سجل دخولك للوصول إلى دوراتك التدريبية';

include __DIR__ . '/../layout/auth-header.php';
?>

<style>
    body {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        display: flex;
        align-items: center;
        padding: 2rem 0;
    }
    
    .login-container {
        max-width: 450px;
        margin: 0 auto;
    }
    
    .login-card {
        background: white;
        border-radius: 20px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.1);
        overflow: hidden;
        backdrop-filter: blur(10px);
    }
    
    .login-header {
        background: linear-gradient(135deg, #007bff, #0056b3);
        color: white;
        padding: 2rem;
        text-align: center;
        position: relative;
    }
    
    .login-header::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="pattern" width="20" height="20" patternUnits="userSpaceOnUse"><circle cx="10" cy="10" r="2" fill="rgba(255,255,255,0.1)"/></pattern></defs><rect width="100" height="100" fill="url(%23pattern)"/></svg>');
        opacity: 0.3;
    }
    
    .login-header > * {
        position: relative;
        z-index: 1;
    }
    
    .form-control {
        border-radius: 10px;
        border: 2px solid #e9ecef;
        padding: 12px 15px;
        transition: all 0.3s ease;
        background: #f8f9fa;
    }
    
    .form-control:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        background: white;
    }
    
    .input-group-text {
        background: #667eea;
        border: 2px solid #667eea;
        color: white;
        border-radius: 10px 0 0 10px;
    }
    
    .input-group .form-control {
        border-radius: 0 10px 10px 0;
        border-left: 0;
    }
    
    .btn-primary {
        background: linear-gradient(45deg, #667eea, #764ba2);
        border: none;
        border-radius: 10px;
        padding: 12px;
        font-weight: 500;
        transition: all 0.3s ease;
    }
    
    .btn-primary:hover {
        background: linear-gradient(45deg, #5a6fd8, #6a4190);
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
    }
    
    .alert {
        border-radius: 10px;
        border: none;
        position: relative;
        overflow: hidden;
    }
    
    .alert::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 4px;
        height: 100%;
        background: currentColor;
    }
    
    .back-link {
        position: absolute;
        top: 20px;
        right: 20px;
        color: white;
        text-decoration: none;
        background: rgba(255,255,255,0.2);
        padding: 10px 15px;
        border-radius: 25px;
        transition: all 0.3s ease;
        backdrop-filter: blur(5px);
    }
    
    .back-link:hover {
        background: rgba(255,255,255,0.3);
        color: white;
        transform: translateY(-2px);
    }
    
    .form-check-input:checked {
        background-color: #667eea;
        border-color: #667eea;
    }
    
    .form-check-input:focus {
        box-shadow: 0 0 0 0.25rem rgba(102, 126, 234, 0.25);
    }
    
    .social-login {
        border-top: 1px solid #e9ecef;
        margin-top: 1rem;
        padding-top: 1rem;
    }
    
    .btn-social {
        width: 100%;
        margin-bottom: 0.5rem;
        border-radius: 10px;
        font-weight: 500;
    }
    
    .btn-google {
        background: #db4437;
        border-color: #db4437;
        color: white;
    }
    
    .btn-facebook {
        background: #4267B2;
        border-color: #4267B2;
        color: white;
    }
    
    @media (max-width: 576px) {
        .login-container {
            margin: 1rem;
        }
        
        .login-header {
            padding: 1.5rem;
        }
        
        .back-link {
            position: relative;
            top: auto;
            right: auto;
            display: block;
            margin-bottom: 1rem;
            text-align: center;
        }
    }
    
    .fade-in {
        animation: fadeIn 0.5s ease-in;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>

<div class="container">
    <a href="index.php" class="back-link" data-aos="fade-down">
        <i class="fas fa-arrow-right me-2"></i>العودة للرئيسية
    </a>
    
    <div class="login-container">
        <div class="login-card" data-aos="fade-up" data-aos-duration="600">
            <div class="login-header">
                <h2><i class="fas fa-sign-in-alt me-2"></i>تسجيل الدخول</h2>
                <p class="mb-0">مرحباً بعودتك! سجل دخولك لمتابعة التعلم</p>
            </div>
            
            <div class="p-4">
                <?php if ($error): ?>
                    <div class="alert alert-danger fade-in" data-aos="shake">
                        <i class="fas fa-exclamation-triangle me-2"></i><?= $error ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success fade-in" data-aos="bounce">
                        <i class="fas fa-check-circle me-2"></i><?= $success ?>
                    </div>
                <?php endif; ?>
                
                <form method="post" id="loginForm" novalidate>
                    <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                    
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-envelope me-1"></i>البريد الإلكتروني
                        </label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="fas fa-envelope"></i>
                            </span>
                            <input type="email" class="form-control" name="email" 
                                   value="<?= htmlspecialchars($email) ?>" 
                                   placeholder="أدخل بريدك الإلكتروني" required autocomplete="email">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-lock me-1"></i>كلمة المرور
                        </label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="fas fa-lock"></i>
                            </span>
                            <input type="password" class="form-control" name="password" id="password"
                                   placeholder="أدخل كلمة المرور" required autocomplete="current-password">
                            <button type="button" class="btn btn-outline-secondary" id="togglePassword">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="row">
                            <div class="col">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" name="remember_me" id="rememberMe">
                                    <label class="form-check-label" for="rememberMe">
                                        تذكرني
                                    </label>
                                </div>
                            </div>
                            <div class="col text-end">
                                <a href="#" class="text-decoration-none small" data-bs-toggle="modal" data-bs-target="#forgotPasswordModal">
                                    نسيت كلمة المرور؟
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100 mb-3" id="submitBtn">
                        <i class="fas fa-sign-in-alt me-2"></i>تسجيل الدخول
                        <span class="spinner-border spinner-border-sm ms-2 d-none" id="submitSpinner"></span>
                    </button>
                </form>
                
                <!-- Social Login (Optional) -->
                <div class="social-login">
                    <p class="text-center text-muted mb-3">أو سجل دخولك باستخدام</p>
                    <button type="button" class="btn btn-google btn-social">
                        <i class="fab fa-google me-2"></i>الدخول بـ Google
                    </button>
                    <button type="button" class="btn btn-facebook btn-social">
                        <i class="fab fa-facebook-f me-2"></i>الدخول بـ Facebook
                    </button>
                </div>
            </div>
            
            <div class="p-4 bg-light text-center">
                <p class="mb-0">ليس لديك حساب؟ 
                    <a href="register.php" class="text-decoration-none fw-bold">إنشاء حساب جديد</a>
                </p>
            </div>
        </div>
    </div>
</div>

<!-- Forgot Password Modal -->
<div class="modal fade" id="forgotPasswordModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">استعادة كلمة المرور</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="forgotPasswordForm">
                    <div class="mb-3">
                        <label class="form-label">البريد الإلكتروني</label>
                        <input type="email" class="form-control" name="email" placeholder="أدخل بريدك الإلكتروني" required>
                    </div>
                    <div class="text-muted small mb-3">
                        سنرسل لك رابط لإعادة تعيين كلمة المرور عبر البريد الإلكتروني
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                <button type="button" class="btn btn-primary">إرسال الرابط</button>
            </div>
        </div>
    </div>
</div>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    // تهيئة AOS
    AOS.init({
        duration: 600,
        easing: 'ease-in-out',
        once: true
    });
    
    // تبديل إظهار كلمة المرور
    document.getElementById('togglePassword').addEventListener('click', function() {
        const password = document.getElementById('password');
        const icon = this.querySelector('i');
        
        if (password.type === 'password') {
            password.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            password.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    });
    
    // التحقق من النموذج قبل الإرسال
    document.getElementById('loginForm').addEventListener('submit', function(e) {
        const email = this.querySelector('input[name="email"]').value;
        const password = this.querySelector('input[name="password"]').value;
        
        if (!email || !password) {
            e.preventDefault();
            alert('يرجى إدخال البريد الإلكتروني وكلمة المرور');
            return;
        }
        
        // إظهار مؤشر التحميل
        const submitBtn = document.getElementById('submitBtn');
        const spinner = document.getElementById('submitSpinner');
        
        submitBtn.disabled = true;
        spinner.classList.remove('d-none');
    });
    
    // تحسين تجربة المستخدم مع الرسوم المتحركة
    document.querySelectorAll('.form-control').forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.style.transform = 'scale(1.02)';
        });
        
        input.addEventListener('blur', function() {
            this.parentElement.style.transform = 'scale(1)';
        });
    });
    
    // التركيز التلقائي على حقل البريد الإلكتروني
    document.addEventListener('DOMContentLoaded', function() {
        const emailInput = document.querySelector('input[name="email"]');
        if (emailInput && !emailInput.value) {
            emailInput.focus();
        }
    });
</script>

<?php include __DIR__ . '/../layout/auth-footer.php'; ?>