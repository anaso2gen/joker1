<?php
/**
 * صفحة تفاصيل الدورة - العرض
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:01:55
 */

$pageTitle = $course['name'];
$pageDescription = $course['short_description'] ?: substr($course['description'], 0, 160);

include __DIR__ . '/../layout/header.php';
?>

<style>
    .course-hero {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 3rem 0;
        position: relative;
        overflow: hidden;
    }
    
    .course-hero::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="pattern" width="20" height="20" patternUnits="userSpaceOnUse"><circle cx="10" cy="10" r="2" fill="rgba(255,255,255,0.1)"/></pattern></defs><rect width="100" height="100" fill="url(%23pattern)"/></svg>');
        opacity: 0.5;
    }
    
    .course-hero > * {
        position: relative;
        z-index: 1;
    }
    
    .course-thumbnail {
        border-radius: 20px;
        box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        overflow: hidden;
        transition: transform 0.3s ease;
    }
    
    .course-thumbnail:hover {
        transform: scale(1.02);
    }
    
    .course-info-card {
        background: white;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        padding: 2rem;
        margin-top: -3rem;
        position: relative;
        z-index: 2;
    }
    
    .course-stats {
        display: flex;
        gap: 2rem;
        flex-wrap: wrap;
        margin-bottom: 2rem;
    }
    
    .stat-item {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        color: #6c757d;
    }
    
    .stat-icon {
        width: 40px;
        height: 40px;
        background: linear-gradient(45deg, #667eea, #764ba2);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
    }
    
    .price-box {
        background: linear-gradient(135deg, #28a745, #20c997);
        color: white;
        padding: 1.5rem;
        border-radius: 15px;
        text-align: center;
        position: sticky;
        top: 100px;
    }
    
    .price-amount {
        font-size: 2rem;
        font-weight: 700;
        margin-bottom: 0.5rem;
    }
    
    .btn-enroll {
        background: white;
        color: #28a745;
        border: none;
        padding: 12px 30px;
        border-radius: 25px;
        font-weight: 600;
        width: 100%;
        transition: all 0.3s ease;
    }
    
    .btn-enroll:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        color: #28a745;
    }
    
    .btn-enrolled {
        background: #17a2b8;
        color: white;
    }
    
    .btn-enrolled:hover {
        color: white;
    }
    
    .section-card {
        background: white;
        border-radius: 15px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        margin-bottom: 1rem;
        overflow: hidden;
    }
    
    .section-header {
        background: #f8f9fa;
        padding: 1rem 1.5rem;
        border-bottom: 1px solid #e9ecef;
        cursor: pointer;
        transition: all 0.3s ease;
    }
    
    .section-header:hover {
        background: #e9ecef;
    }
    
    .section-header.active {
        background: linear-gradient(45deg, #667eea, #764ba2);
        color: white;
    }
    
    .lesson-list {
        list-style: none;
        padding: 0;
        margin: 0;
    }
    
    .lesson-item {
        padding: 1rem 1.5rem;
        border-bottom: 1px solid #f0f0f0;
        display: flex;
        align-items: center;
        justify-content: space-between;
        transition: all 0.3s ease;
    }
    
    .lesson-item:hover {
        background: #f8f9fa;
    }
    
    .lesson-item:last-child {
        border-bottom: none;
    }
    
    .lesson-item.completed {
        background: rgba(40, 167, 69, 0.1);
        border-left: 4px solid #28a745;
    }
    
    .lesson-item.locked {
        opacity: 0.6;
        cursor: not-allowed;
    }
    
    .lesson-title {
        display: flex;
        align-items: center;
        gap: 1rem;
        flex-grow: 1;
    }
    
    .lesson-icon {
        width: 35px;
        height: 35px;
        background: #e9ecef;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
    }
    
    .lesson-icon.completed {
        background: #28a745;
        color: white;
    }
    
    .lesson-icon.preview {
        background: #007bff;
        color: white;
    }
    
    .lesson-meta {
        display: flex;
        align-items: center;
        gap: 1rem;
        color: #6c757d;
        font-size: 0.9rem;
    }
    
    .progress-section {
        background: white;
        border-radius: 15px;
        padding: 1.5rem;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        margin-bottom: 2rem;
    }
    
    .progress-bar-custom {
        height: 10px;
        border-radius: 5px;
        background: #e9ecef;
        overflow: hidden;
    }
    
    .progress-fill {
        height: 100%;
        background: linear-gradient(45deg, #28a745, #20c997);
        border-radius: 5px;
        transition: width 0.3s ease;
    }
    
    .instructor-card {
        background: white;
        border-radius: 15px;
        padding: 1.5rem;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        text-align: center;
    }
    
    .instructor-avatar {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        margin: 0 auto 1rem;
        border: 4px solid #667eea;
    }
    
    .reviews-section {
        background: white;
        border-radius: 15px;
        padding: 2rem;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    }
    
    .review-item {
        padding: 1.5rem;
        border: 1px solid #e9ecef;
        border-radius: 10px;
        margin-bottom: 1rem;
    }
    
    .review-header {
        display: flex;
        align-items: center;
        gap: 1rem;
        margin-bottom: 1rem;
    }
    
    .review-avatar {
        width: 50px;
        height: 50px;
        border-radius: 50%;
    }
    
    .review-rating {
        color: #ffc107;
    }
    
    .related-courses {
        background: #f8f9fa;
        padding: 3rem 0;
        margin-top: 3rem;
    }
    
    .tab-content {
        background: white;
        border-radius: 0 15px 15px 15px;
        padding: 2rem;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    }
    
    .nav-tabs {
        border: none;
    }
    
    .nav-tabs .nav-link {
        border: none;
        border-radius: 15px 15px 0 0;
        background: #e9ecef;
        color: #6c757d;
        margin-left: 2px;
    }
    
    .nav-tabs .nav-link.active {
        background: white;
        color: #667eea;
        border-bottom: 2px solid #667eea;
    }
    
    @media (max-width: 768px) {
        .course-stats {
            flex-direction: column;
            gap: 1rem;
        }
        
        .price-box {
            position: static;
            margin-top: 2rem;
        }
        
        .lesson-meta {
            flex-direction: column;
            align-items: flex-start;
            gap: 0.5rem;
        }
    }
</style>

<!-- Hero Section -->
<section class="course-hero">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <!-- إحصائيات سريعة -->
                <div class="course-stats mb-4" data-aos="fade-up">
                    <div class="stat-item">
                        <div class="stat-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <div>
                            <div class="fw-bold"><?= number_format($course['students_count']) ?></div>
                            <div class="small">طالب مسجل</div>
                        </div>
                    </div>
                    
                    <div class="stat-item">
                        <div class="stat-icon">
                            <i class="fas fa-play-circle"></i>
                        </div>
                        <div>
                            <div class="fw-bold"><?= $totalLessons ?></div>
                            <div class="small">درس</div>
                        </div>
                    </div>
                    
                    <div class="stat-item">
                        <div class="stat-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div>
                            <div class="fw-bold"><?= formatDuration($totalDuration) ?></div>
                            <div class="small">إجمالي المدة</div>
                        </div>
                    </div>
                    
                    <?php if ($course['avg_rating']): ?>
                        <div class="stat-item">
                            <div class="stat-icon">
                                <i class="fas fa-star"></i>
                            </div>
                            <div>
                                <div class="fw-bold"><?= number_format($course['avg_rating'], 1) ?></div>
                                <div class="small">(<?= $course['reviews_count'] ?> تقييم)</div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <h1 class="display-5 fw-bold mb-3" data-aos="fade-up" data-aos-delay="100">
                    <?= htmlspecialchars($course['name']) ?>
                </h1>
                
                <p class="lead mb-4" data-aos="fade-up" data-aos-delay="200">
                    <?= htmlspecialchars($course['short_description'] ?: substr($course['description'], 0, 200) . '...') ?>
                </p>
                
                <!-- مؤشر التقدم للمستخدمين المسجلين -->
                <?php if ($userSubscribed && $progressPercentage > 0): ?>
                    <div class="progress-section" data-aos="fade-up" data-aos-delay="300">
                        <div class="d-flex justify-content-between mb-2">
                            <span class="fw-bold">تقدمك في الدورة</span>
                            <span class="text-success fw-bold"><?= $progressPercentage ?>%</span>
                        </div>
                        <div class="progress-bar-custom">
                            <div class="progress-fill" style="width: <?= $progressPercentage ?>%"></div>
                        </div>
                        <div class="mt-2 text-muted small">
                            أكملت <?= $completedLessons ?> من أصل <?= $totalLessons ?> درس
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="col-lg-4">
                <div class="course-thumbnail" data-aos="fade-left" data-aos-delay="100">
                    <img src="<?= htmlspecialchars($course['image_url'] ?: 'https://via.placeholder.com/600x400?text=دورة+تدريبية') ?>" 
                         alt="<?= htmlspecialchars($course['name']) ?>" class="img-fluid w-100">
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Main Content -->
<div class="container">
    <div class="row">
        <!-- Course Content -->
        <div class="col-lg-8">
            <!-- Course Info Card -->
            <div class="course-info-card" data-aos="fade-up">
                <!-- Navigation Tabs -->
                <ul class="nav nav-tabs" id="courseTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="overview-tab" data-bs-toggle="tab" data-bs-target="#overview" type="button">
                            <i class="fas fa-info-circle me-1"></i>نظرة عامة
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="curriculum-tab" data-bs-toggle="tab" data-bs-target="#curriculum" type="button">
                            <i class="fas fa-list me-1"></i>المنهج
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="reviews-tab" data-bs-toggle="tab" data-bs-target="#reviews" type="button">
                            <i class="fas fa-star me-1"></i>التقييمات
                        </button>
                    </li>
                </ul>

                <!-- Tab Content -->
                <div class="tab-content" id="courseTabContent">
                    <!-- Overview Tab -->
                    <div class="tab-pane fade show active" id="overview" role="tabpanel">
                        <h3 class="mb-3">وصف الدورة</h3>
                        <div class="course-description">
                            <?= nl2br(htmlspecialchars($course['description'])) ?>
                        </div>
                        
                        <h4 class="mt-4 mb-3">ماذا ستتعلم؟</h4>
                        <div class="learning-objectives">
                            <?php if ($course['learning_objectives']): ?>
                                <?php $objectives = json_decode($course['learning_objectives'], true); ?>
                                <?php if ($objectives): ?>
                                    <div class="row">
                                        <?php foreach ($objectives as $objective): ?>
                                            <div class="col-md-6 mb-2">
                                                <div class="d-flex align-items-start">
                                                    <i class="fas fa-check-circle text-success me-2 mt-1"></i>
                                                    <span><?= htmlspecialchars($objective) ?></span>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        
                        <h4 class="mt-4 mb-3">متطلبات الدورة</h4>
                        <div class="course-requirements">
                            <?php if ($course['requirements']): ?>
                                <?php $requirements = json_decode($course['requirements'], true); ?>
                                <?php if ($requirements): ?>
                                    <ul class="list-unstyled">
                                        <?php foreach ($requirements as $requirement): ?>
                                            <li class="mb-2">
                                                <i class="fas fa-exclamation-circle text-warning me-2"></i>
                                                <?= htmlspecialchars($requirement) ?>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php else: ?>
                                    <p class="text-muted">لا توجد متطلبات مسبقة لهذه الدورة</p>
                                <?php endif; ?>
                            <?php else: ?>
                                <p class="text-muted">لا توجد متطلبات مسبقة لهذه الدورة</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Curriculum Tab -->
                    <div class="tab-pane fade" id="curriculum" role="tabpanel">
                        <h3 class="mb-4">محتوى الدورة</h3>
                        
                        <?php foreach ($sections as $sectionIndex => $section): ?>
                            <div class="section-card" data-aos="fade-up" data-aos-delay="<?= $sectionIndex * 100 ?>">
                                <div class="section-header" data-bs-toggle="collapse" data-bs-target="#section-<?= $section['id'] ?>">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h5 class="mb-1"><?= htmlspecialchars($section['name']) ?></h5>
                                            <small class="opacity-75">
                                                <?= count($section['lessons']) ?> دروس
                                                <?php if ($section['total_duration']): ?>
                                                    • <?= formatDuration($section['total_duration']) ?>
                                                <?php endif; ?>
                                            </small>
                                        </div>
                                        <i class="fas fa-chevron-down"></i>
                                    </div>
                                </div>
                                
                                <div class="collapse" id="section-<?= $section['id'] ?>">
                                    <ul class="lesson-list">
                                        <?php foreach ($section['lessons'] as $lesson): ?>
                                            <?php 
                                            $canAccess = canAccessLesson($lesson, $userSubscribed);
                                            $isCompleted = isset($userProgress[$lesson['id']]) && $userProgress[$lesson['id']]['completed'];
                                            ?>
                                            <li class="lesson-item <?= $isCompleted ? 'completed' : '' ?> <?= !$canAccess ? 'locked' : '' ?>">
                                                <div class="lesson-title">
                                                    <div class="lesson-icon <?= $isCompleted ? 'completed' : ($lesson['is_preview'] ? 'preview' : '') ?>">
                                                        <?php if ($isCompleted): ?>
                                                            <i class="fas fa-check"></i>
                                                        <?php elseif ($lesson['is_preview']): ?>
                                                            <i class="fas fa-play"></i>
                                                        <?php elseif ($canAccess): ?>
                                                            <i class="fas fa-play-circle"></i>
                                                        <?php else: ?>
                                                            <i class="fas fa-lock"></i>
                                                        <?php endif; ?>
                                                    </div>
                                                    
                                                    <div>
                                                        <div class="fw-medium"><?= htmlspecialchars($lesson['name']) ?></div>
                                                        <?php if ($lesson['description']): ?>
                                                            <div class="text-muted small">
                                                                <?= htmlspecialchars(substr($lesson['description'], 0, 100)) ?>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                
                                                <div class="lesson-meta">
                                                    <?php if ($lesson['duration']): ?>
                                                        <span>
                                                            <i class="fas fa-clock me-1"></i>
                                                            <?= formatDuration($lesson['duration']) ?>
                                                        </span>
                                                    <?php endif; ?>
                                                    
                                                    <?php if ($lesson['is_preview']): ?>
                                                        <span class="badge bg-info">معاينة مجانية</span>
                                                    <?php endif; ?>
                                                    
                                                    <?php if ($canAccess): ?>
                                                        <a href="player.php?course=<?= $course['id'] ?>&lesson=<?= $lesson['id'] ?>" 
                                                           class="btn btn-sm btn-outline-primary">
                                                            <i class="fas fa-play me-1"></i>مشاهدة
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Reviews Tab -->
                    <div class="tab-pane fade" id="reviews" role="tabpanel">
                        <div class="reviews-section">
                            <h3 class="mb-4">تقييمات الطلاب</h3>
                            
                            <?php if ($course['avg_rating']): ?>
                                <div class="rating-summary mb-4 p-3 bg-light rounded">
                                    <div class="row align-items-center">
                                        <div class="col-md-4 text-center">
                                            <div class="display-4 fw-bold text-warning">
                                                <?= number_format($course['avg_rating'], 1) ?>
                                            </div>
                                            <div class="rating-stars mb-2">
                                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                                    <i class="fas fa-star <?= $i <= round($course['avg_rating']) ? 'text-warning' : 'text-muted' ?>"></i>
                                                <?php endfor; ?>
                                            </div>
                                            <div class="text-muted">
                                                <?= number_format($course['reviews_count']) ?> تقييم
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <!-- Rating Breakdown يمكن إضافته لاحقاً -->
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            <?php if (empty($reviews)): ?>
                                <div class="text-center text-muted py-5">
                                    <i class="fas fa-comments fa-3x mb-3 opacity-50"></i>
                                    <h5>لا توجد تقييمات بعد</h5>
                                    <p>كن أول من يقيم هذه الدورة</p>
                                </div>
                            <?php else: ?>
                                <?php foreach ($reviews as $review): ?>
                                    <div class="review-item" data-aos="fade-up">
                                        <div class="review-header">
                                            <img src="<?= htmlspecialchars($review['avatar_url'] ?: 'assets/images/default-avatar.png') ?>" 
                                                 alt="صورة المراجع" class="review-avatar">
                                            <div class="flex-grow-1">
                                                <div class="fw-bold">
                                                    <?= htmlspecialchars($review['first_name'] . ' ' . $review['last_name']) ?>
                                                </div>
                                                <div class="review-rating">
                                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                                        <i class="fas fa-star <?= $i <= $review['rating'] ? '' : 'text-muted' ?>"></i>
                                                    <?php endfor; ?>
                                                </div>
                                                <div class="text-muted small">
                                                    <?= timeAgo($review['created_at']) ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="review-content">
                                            <?= nl2br(htmlspecialchars($review['review_text'])) ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- Price Box -->
            <div class="price-box" data-aos="fade-left">
                <?php if ($course['price'] == 0): ?>
                    <div class="price-amount">مجاني</div>
                    <p class="mb-3">دورة مجانية بالكامل</p>
                <?php else: ?>
                    <div class="price-amount"><?= number_format($course['price'], 2) ?> ر.س</div>
                    <p class="mb-3">دفعة واحدة - وصول مدى الحياة</p>
                <?php endif; ?>
                
                <?php if ($userSubscribed): ?>
                    <button class="btn btn-enrolled mb-3" disabled>
                        <i class="fas fa-check-circle me-2"></i>مشترك بالفعل
                    </button>
                    <a href="player.php?course=<?= $course['id'] ?>" class="btn btn-enroll">
                        <i class="fas fa-play me-2"></i>متابعة التعلم
                    </a>
                <?php else: ?>
                    <?php if ($user): ?>
                        <button class="btn btn-enroll" onclick="subscribeToCourse(<?= $course['id'] ?>)">
                            <i class="fas fa-shopping-cart me-2"></i>اشترك الآن
                        </button>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-enroll">
                            <i class="fas fa-sign-in-alt me-2"></i>سجل دخولك للاشتراك
                        </a>
                    <?php endif; ?>
                <?php endif; ?>
                
                <!-- Preview Lessons -->
                <?php if ($previewLessons > 0): ?>
                    <div class="mt-3 pt-3 border-top border-light">
                        <div class="small mb-2">
                            <i class="fas fa-eye me-1"></i>
                            <?= $previewLessons ?> دروس معاينة مجانية
                        </div>
                        <a href="#curriculum" class="btn btn-sm btn-outline-light w-100">
                            شاهد المعاينات
                        </a>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Course Features -->
            <div class="course-features mt-4" data-aos="fade-left" data-aos-delay="100">
                <div class="card">
                    <div class="card-header">
                        <h6 class="mb-0">
                            <i class="fas fa-star me-2"></i>مميزات الدورة
                        </h6>
                    </div>
                    <div class="card-body">
                        <ul class="list-unstyled mb-0">
                            <li class="mb-2">
                                <i class="fas fa-infinity text-primary me-2"></i>
                                وصول مدى الحياة
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-mobile-alt text-primary me-2"></i>
                                متوافق مع الهاتف والكمبيوتر
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-certificate text-primary me-2"></i>
                                شهادة إتمام
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-headset text-primary me-2"></i>
                                دعم فني متواصل
                            </li>
                            <li>
                                <i class="fas fa-download text-primary me-2"></i>
                                مواد قابلة للتحميل
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Share Course -->
            <div class="share-course mt-4" data-aos="fade-left" data-aos-delay="200">
                <div class="card">
                    <div class="card-header">
                        <h6 class="mb-0">
                            <i class="fas fa-share-alt me-2"></i>شارك الدورة
                        </h6>
                    </div>
                    <div class="card-body text-center">
                        <div class="share-buttons">
                            <a href="#" class="btn btn-outline-primary btn-sm me-2 mb-2" onclick="shareOnFacebook()">
                                <i class="fab fa-facebook-f me-1"></i>فيسبوك
                            </a>
                            <a href="#" class="btn btn-outline-info btn-sm me-2 mb-2" onclick="shareOnTwitter()">
                                <i class="fab fa-twitter me-1"></i>تويتر
                            </a>
                            <a href="#" class="btn btn-outline-success btn-sm mb-2" onclick="shareOnWhatsApp()">
                                <i class="fab fa-whatsapp me-1"></i>واتساب
                            </a>
                        </div>
                        <button class="btn btn-outline-secondary btn-sm w-100 mt-2" onclick="copyLink()">
                            <i class="fas fa-copy me-1"></i>نسخ الرابط
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Related Courses -->
<?php if (!empty($relatedCourses)): ?>
    <section class="related-courses">
        <div class="container">
            <h3 class="text-center mb-5" data-aos="fade-up">دورات مشابهة</h3>
            <div class="row">
                <?php foreach ($relatedCourses as $index => $relatedCourse): ?>
                    <div class="col-lg-3 col-md-6 mb-4" data-aos="fade-up" data-aos-delay="<?= $index * 100 ?>">
                        <?php 
                        $course = $relatedCourse; // للتوافق مع course_card.php
                        include __DIR__ . '/../components/course_card.php'; 
                        ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    // تهيئة AOS
    AOS.init({
        duration: 600,
        easing: 'ease-in-out',
        once: true
    });
    
    // الاشتراك في الدورة
    function subscribeToCourse(courseId) {
        if (!confirm('هل تريد الاشتراك في هذه الدورة؟')) {
            return;
        }
        
        fetch('api.php?action=subscribe_course', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ course_id: courseId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert(data.message || 'حدث خطأ أثناء الاشتراك');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('حدث خطأ في الشبكة');
        });
    }
    
    // مشاركة على فيسبوك
    function shareOnFacebook() {
        const url = encodeURIComponent(window.location.href);
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, '_blank');
    }
    
    // مشاركة على تويتر
    function shareOnTwitter() {
        const url = encodeURIComponent(window.location.href);
        const text = encodeURIComponent('<?= htmlspecialchars($course['name']) ?>');
        window.open(`https://twitter.com/intent/tweet?url=${url}&text=${text}`, '_blank');
    }
    
    // مشاركة على واتساب
    function shareOnWhatsApp() {
        const url = encodeURIComponent(window.location.href);
        const text = encodeURIComponent('<?= htmlspecialchars($course['name']) ?>');
        window.open(`https://wa.me/?text=${text} ${url}`, '_blank');
    }
    
    // نسخ الرابط
    function copyLink() {
        navigator.clipboard.writeText(window.location.href).then(() => {
            alert('تم نسخ الرابط');
        });
    }
    
    // تحسين تجربة التنقل بين التبويبات
    document.addEventListener('DOMContentLoaded', function() {
        const hash = window.location.hash;
        if (hash === '#curriculum') {
            document.getElementById('curriculum-tab').click();
        } else if (hash === '#reviews') {
            document.getElementById('reviews-tab').click();
        }
    });
</script>

<?php include __DIR__ . '/../layout/footer.php'; ?>