<!-- ملف العرض - HTML + CSS + JS -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <!-- HEAD content -->
</head>
<body>
    <?php include __DIR__ . '/../layout/header.php'; ?>
    
    <!-- محتوى الصفحة -->
    
    <?php include __DIR__ . '/../layout/footer.php'; ?>
</body>
</html>