<?php
/**
 * صفحة الملف الشخصي - العرض
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:13:48
 */

$pageTitle = 'الملف الشخصي';
$pageDescription = 'إدارة حسابك ومتابعة تقدمك في الدورات التدريبية';

include __DIR__ . '/../layout/header.php';
?>

<style>
    .profile-hero {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 3rem 0 2rem;
        position: relative;
        overflow: hidden;
    }
    
    .profile-hero::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="pattern" width="20" height="20" patternUnits="userSpaceOnUse"><circle cx="10" cy="10" r="2" fill="rgba(255,255,255,0.1)"/></pattern></defs><rect width="100" height="100" fill="url(%23pattern)"/></svg>');
        opacity: 0.3;
    }
    
    .profile-hero > * {
        position: relative;
        z-index: 1;
    }
    
    .profile-avatar {
        width: 120px;
        height: 120px;
        border-radius: 50%;
        border: 4px solid white;
        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        transition: transform 0.3s ease;
    }
    
    .profile-avatar:hover {
        transform: scale(1.05);
    }
    
    .profile-info {
        margin-top: -2rem;
        position: relative;
        z-index: 2;
    }
    
    .profile-card {
        background: white;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        padding: 2rem;
        margin-bottom: 2rem;
    }
    
    .stats-container {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1.5rem;
        margin-bottom: 2rem;
    }
    
    .stat-card {
        background: white;
        border-radius: 15px;
        padding: 1.5rem;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        text-align: center;
        transition: transform 0.3s ease;
        position: relative;
        overflow: hidden;
    }
    
    .stat-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(45deg, #667eea, #764ba2);
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
    }
    
    .stat-icon {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 1rem;
        color: white;
        font-size: 1.5rem;
    }
    
    .stat-number {
        font-size: 2rem;
        font-weight: 700;
        color: #333;
        margin-bottom: 0.5rem;
    }
    
    .stat-label {
        color: #6c757d;
        font-weight: 500;
    }
    
    .nav-pills .nav-link {
        border-radius: 25px;
        padding: 0.8rem 1.5rem;
        margin: 0 0.2rem;
        transition: all 0.3s ease;
        border: 2px solid transparent;
    }
    
    .nav-pills .nav-link.active {
        background: linear-gradient(45deg, #667eea, #764ba2);
        border-color: transparent;
    }
    
    .nav-pills .nav-link:not(.active) {
        background: #f8f9fa;
        color: #6c757d;
        border-color: #e9ecef;
    }
    
    .nav-pills .nav-link:not(.active):hover {
        background: #e9ecef;
        color: #667eea;
        border-color: #667eea;
    }
    
    .course-progress-card {
        background: white;
        border-radius: 15px;
        padding: 1.5rem;
        margin-bottom: 1.5rem;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        transition: transform 0.3s ease;
    }
    
    .course-progress-card:hover {
        transform: translateY(-2px);
    }
    
    .progress-header {
        display: flex;
        align-items: center;
        gap: 1rem;
        margin-bottom: 1rem;
    }
    
    .course-thumbnail {
        width: 80px;
        height: 60px;
        border-radius: 10px;
        object-fit: cover;
    }
    
    .progress-bar-custom {
        height: 8px;
        border-radius: 4px;
        background: #e9ecef;
        overflow: hidden;
        margin-bottom: 0.5rem;
    }
    
    .progress-fill {
        height: 100%;
        background: linear-gradient(45deg, #28a745, #20c997);
        border-radius: 4px;
        transition: width 0.3s ease;
    }
    
    .activity-item {
        display: flex;
        align-items: start;
        gap: 1rem;
        padding: 1rem;
        border-radius: 10px;
        margin-bottom: 1rem;
        transition: background 0.3s ease;
    }
    
    .activity-item:hover {
        background: #f8f9fa;
    }
    
    .activity-icon {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 1rem;
        flex-shrink: 0;
    }
    
    .activity-content {
        flex-grow: 1;
    }
    
    .activity-title {
        font-weight: 600;
        color: #333;
        margin-bottom: 0.25rem;
    }
    
    .activity-description {
        color: #6c757d;
        font-size: 0.9rem;
        margin-bottom: 0.25rem;
    }
    
    .activity-time {
        color: #adb5bd;
        font-size: 0.8rem;
    }
    
    .certificate-card {
        background: linear-gradient(135deg, #f8f9fa, #e9ecef);
        border: 2px solid #e9ecef;
        border-radius: 15px;
        padding: 1.5rem;
        margin-bottom: 1rem;
        position: relative;
        overflow: hidden;
    }
    
    .certificate-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(45deg, #ffc107, #fd7e14);
    }
    
    .certificate-icon {
        width: 60px;
        height: 60px;
        background: linear-gradient(45deg, #ffc107, #fd7e14);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 1.5rem;
        margin-bottom: 1rem;
    }
    
    .form-floating {
        margin-bottom: 1rem;
    }
    
    .form-floating > .form-control:focus ~ label {
        color: #667eea;
    }
    
    .form-floating > .form-control:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 0.25rem rgba(102, 126, 234, 0.25);
    }
    
    .avatar-upload {
        position: relative;
        display: inline-block;
    }
    
    .avatar-upload-overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.7);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0;
        transition: opacity 0.3s ease;
        cursor: pointer;
    }
    
    .avatar-upload:hover .avatar-upload-overlay {
        opacity: 1;
    }
    
    .empty-state {
        text-align: center;
        padding: 3rem 1rem;
        color: #6c757d;
    }
    
    .empty-state i {
        font-size: 3rem;
        margin-bottom: 1rem;
        opacity: 0.5;
    }
    
    @media (max-width: 768px) {
        .profile-hero {
            padding: 2rem 0 1rem;
        }
        
        .profile-avatar {
            width: 100px;
            height: 100px;
        }
        
        .stats-container {
            grid-template-columns: repeat(2, 1fr);
            gap: 1rem;
        }
        
        .stat-card {
            padding: 1rem;
        }
        
        .stat-number {
            font-size: 1.5rem;
        }
        
        .nav-pills {
            flex-wrap: nowrap;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        
        .nav-pills .nav-link {
            white-space: nowrap;
            margin: 0 0.1rem;
            padding: 0.6rem 1rem;
        }
    }
</style>

<!-- Hero Section -->
<section class="profile-hero">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-3 text-center">
                <div class="avatar-upload" data-aos="fade-right">
                    <img src="<?= htmlspecialchars($user['avatar_url'] ?: 'assets/images/default-avatar.png') ?>" 
                         alt="صورة المستخدم" class="profile-avatar">
                    <div class="avatar-upload-overlay" onclick="document.getElementById('avatarInput').click()">
                        <i class="fas fa-camera fa-lg text-white"></i>
                    </div>
                    <input type="file" id="avatarInput" accept="image/*" style="display: none;" onchange="uploadAvatar(this)">
                </div>
            </div>
            <div class="col-md-9">
                <div class="profile-details" data-aos="fade-left">
                    <h1 class="display-6 fw-bold mb-2">
                        <?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?>
                    </h1>
                    <p class="lead mb-3">
                        <i class="fas fa-envelope me-2"></i><?= htmlspecialchars($user['email']) ?>
                    </p>
                    <p class="mb-0">
                        <i class="fas fa-calendar me-2"></i>
                        عضو منذ <?= formatArabicDate($user['created_at']) ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Profile Info -->
<div class="container profile-info">
    <!-- Statistics -->
    <div class="stats-container" data-aos="fade-up">
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(45deg, #667eea, #764ba2);">
                <i class="fas fa-graduation-cap"></i>
            </div>
            <div class="stat-number"><?= number_format($enrolledCourses) ?></div>
            <div class="stat-label">دورة مسجل بها</div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(45deg, #28a745, #20c997);">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-number"><?= number_format($completedLessons) ?></div>
            <div class="stat-label">درس مكتمل</div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(45deg, #ffc107, #fd7e14);">
                <i class="fas fa-clock"></i>
            </div>
            <div class="stat-number"><?= number_format($watchedHours) ?></div>
            <div class="stat-label">ساعة مشاهدة</div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(45deg, #dc3545, #e83e8c);">
                <i class="fas fa-certificate"></i>
            </div>
            <div class="stat-number"><?= count($completedCourses) ?></div>
            <div class="stat-label">شهادة حصلت عليها</div>
        </div>
    </div>
    
    <!-- Navigation Tabs -->
    <div class="profile-card" data-aos="fade-up" data-aos-delay="100">
        <ul class="nav nav-pills nav-fill mb-4" id="profileTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="courses-tab" data-bs-toggle="pill" data-bs-target="#courses" type="button">
                    <i class="fas fa-graduation-cap me-2"></i>دوراتي
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="activity-tab" data-bs-toggle="pill" data-bs-target="#activity" type="button">
                    <i class="fas fa-chart-line me-2"></i>النشاط
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="certificates-tab" data-bs-toggle="pill" data-bs-target="#certificates" type="button">
                    <i class="fas fa-certificate me-2"></i>الشهادات
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="settings-tab" data-bs-toggle="pill" data-bs-target="#settings" type="button">
                    <i class="fas fa-cog me-2"></i>الإعدادات
                </button>
            </li>
        </ul>
        
        <!-- Tab Content -->
        <div class="tab-content" id="profileTabContent">
            <!-- My Courses Tab -->
            <div class="tab-pane fade show active" id="courses" role="tabpanel">
                <h4 class="mb-4">دوراتي المسجل بها</h4>
                
                <?php if (empty($recentCourses)): ?>
                    <div class="empty-state">
                        <i class="fas fa-graduation-cap"></i>
                        <h5>لا توجد دورات بعد</h5>
                        <p>لم تسجل في أي دورة حتى الآن. استكشف دوراتنا وابدأ رحلة التعلم!</p>
                        <a href="courses.php" class="btn btn-primary">
                            <i class="fas fa-search me-2"></i>استكشف الدورات
                        </a>
                    </div>
                <?php else: ?>
                    <?php foreach ($recentCourses as $course): ?>
                        <?php 
                        $progressPercentage = $course['total_lessons'] > 0 ? 
                            round(($course['completed_lessons'] / $course['total_lessons']) * 100) : 0;
                        ?>
                        <div class="course-progress-card">
                            <div class="progress-header">
                                <img src="<?= htmlspecialchars($course['image_url'] ?: 'https://via.placeholder.com/80x60?text=دورة') ?>" 
                                     alt="<?= htmlspecialchars($course['name']) ?>" class="course-thumbnail">
                                <div class="flex-grow-1">
                                    <h6 class="mb-1">
                                        <a href="course.php?id=<?= $course['id'] ?>" class="text-decoration-none">
                                            <?= htmlspecialchars($course['name']) ?>
                                        </a>
                                    </h6>
                                    <small class="text-muted">
                                        اشتركت في <?= formatArabicDate($course['enrolled_at']) ?>
                                    </small>
                                </div>
                                <div class="text-end">
                                    <div class="fw-bold text-primary mb-1"><?= $progressPercentage ?>%</div>
                                    <div class="small text-muted">
                                        <?= $course['completed_lessons'] ?>/<?= $course['total_lessons'] ?> دروس
                                    </div>
                                </div>
                            </div>
                            
                            <div class="progress-bar-custom">
                                <div class="progress-fill" style="width: <?= $progressPercentage ?>%"></div>
                            </div>
                            
                            <div class="d-flex justify-content-between align-items-center mt-2">
                                <small class="text-muted">
                                    <?php if ($progressPercentage === 100): ?>
                                        <i class="fas fa-check-circle text-success me-1"></i>مكتملة
                                    <?php elseif ($progressPercentage > 0): ?>
                                        <i class="fas fa-play-circle text-primary me-1"></i>قيد التقدم
                                    <?php else: ?>
                                        <i class="fas fa-bookmark text-warning me-1"></i>لم تبدأ بعد
                                    <?php endif; ?>
                                </small>
                                
                                <div class="btn-group btn-group-sm">
                                    <a href="course.php?id=<?= $course['id'] ?>" class="btn btn-outline-primary">
                                        <i class="fas fa-info-circle me-1"></i>التفاصيل
                                    </a>
                                    <a href="player.php?course=<?= $course['id'] ?>" class="btn btn-primary">
                                        <i class="fas fa-play me-1"></i>متابعة
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <!-- Activity Tab -->
            <div class="tab-pane fade" id="activity" role="tabpanel">
                <h4 class="mb-4">النشاط الأخير</h4>
                
                <?php if (empty($recentActivity)): ?>
                    <div class="empty-state">
                        <i class="fas fa-chart-line"></i>
                        <h5>لا يوجد نشاط بعد</h5>
                        <p>ابدأ بمشاهدة الدروس لرؤية نشاطك هنا</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($recentActivity as $activity): ?>
                        <div class="activity-item">
                            <div class="activity-icon" style="background: linear-gradient(45deg, #667eea, #764ba2);">
                                <i class="fas fa-play"></i>
                            </div>
                            <div class="activity-content">
                                <div class="activity-title"><?= htmlspecialchars($activity['title']) ?></div>
                                <div class="activity-description">
                                    في دورة: <?= htmlspecialchars($activity['course_name']) ?>
                                </div>
                                <div class="activity-time">
                                    <?= timeAgo($activity['activity_time']) ?>
                                </div>
                            </div>
                            <a href="player.php?course=<?= $activity['course_id'] ?>&lesson=<?= $activity['lesson_id'] ?>" 
                               class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-play me-1"></i>متابعة
                            </a>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <!-- Certificates Tab -->
            <div class="tab-pane fade" id="certificates" role="tabpanel">
                <h4 class="mb-4">شهادات الإنجاز</h4>
                
                <?php if (empty($completedCourses)): ?>
                    <div class="empty-state">
                        <i class="fas fa-certificate"></i>
                        <h5>لا توجد شهادات بعد</h5>
                        <p>أكمل دورة واحدة على الأقل للحصول على شهادة إنجاز</p>
                        <a href="courses.php" class="btn btn-primary">
                            <i class="fas fa-graduation-cap me-2"></i>ابدأ التعلم
                        </a>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <?php foreach ($completedCourses as $certificate): ?>
                            <div class="col-md-6 mb-3">
                                <div class="certificate-card">
                                    <div class="certificate-icon">
                                        <i class="fas fa-certificate"></i>
                                    </div>
                                    <h6 class="fw-bold"><?= htmlspecialchars($certificate['name']) ?></h6>
                                    <p class="text-muted mb-3">
                                        تاريخ الإنجاز: <?= formatArabicDate($certificate['completion_date']) ?>
                                    </p>
                                    <div class="d-flex gap-2">
                                        <button class="btn btn-primary btn-sm" onclick="downloadCertificate(<?= $certificate['id'] ?>)">
                                            <i class="fas fa-download me-1"></i>تحميل
                                        </button>
                                        <button class="btn btn-outline-primary btn-sm" onclick="viewCertificate(<?= $certificate['id'] ?>)">
                                            <i class="fas fa-eye me-1"></i>عرض
                                        </button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Settings Tab -->
            <div class="tab-pane fade" id="settings" role="tabpanel">
                <h4 class="mb-4">إعدادات الحساب</h4>
                
                <!-- Display Messages -->
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-circle me-2"></i><?= $error ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle me-2"></i><?= $success ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <!-- Personal Info Form -->
                <div class="row">
                    <div class="col-lg-6">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h6 class="mb-0">
                                    <i class="fas fa-user me-2"></i>المعلومات الشخصية
                                </h6>
                            </div>
                            <div class="card-body">
                                <form method="post" action="">
                                    <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                                    <input type="hidden" name="action" value="update_profile">
                                    
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="first_name" name="first_name" 
                                               value="<?= htmlspecialchars($user['first_name']) ?>" required>
                                        <label for="first_name">الاسم الأول</label>
                                    </div>
                                    
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="last_name" name="last_name" 
                                               value="<?= htmlspecialchars($user['last_name']) ?>" required>
                                        <label for="last_name">اسم العائلة</label>
                                    </div>
                                    
                                    <div class="form-floating">
                                        <input type="tel" class="form-control" id="phone" name="phone" 
                                               value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
                                        <label for="phone">رقم الهاتف</label>
                                    </div>
                                    
                                    <div class="form-check mb-3">
                                        <input class="form-check-input" type="checkbox" id="newsletter" name="newsletter" 
                                               <?= $user['newsletter_subscribed'] ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="newsletter">
                                            الاشتراك في النشرة البريدية
                                        </label>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>حفظ التغييرات
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-6">
                        <!-- Change Password -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h6 class="mb-0">
                                    <i class="fas fa-lock me-2"></i>تغيير كلمة المرور
                                </h6>
                            </div>
                            <div class="card-body">
                                <form method="post" action="">
                                    <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                                    <input type="hidden" name="action" value="change_password">
                                    
                                    <div class="form-floating">
                                        <input type="password" class="form-control" id="current_password" name="current_password" required>
                                        <label for="current_password">كلمة المرور الحالية</label>
                                    </div>
                                    
                                    <div class="form-floating">
                                        <input type="password" class="form-control" id="new_password" name="new_password" required>
                                        <label for="new_password">كلمة المرور الجديدة</label>
                                    </div>
                                    
                                    <div class="form-floating">
                                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                        <label for="confirm_password">تأكيد كلمة المرور</label>
                                    </div>
                                    
                                    <div class="password-strength mb-3">
                                        <small class="text-muted">
                                            يجب أن تحتوي كلمة المرور على 8 أحرف على الأقل، وتشمل أحرف كبيرة وصغيرة وأرقام
                                        </small>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-warning">
                                        <i class="fas fa-key me-2"></i>تغيير كلمة المرور
                                    </button>
                                </form>
                            </div>
                        </div>
                        
                        <!-- Upload Avatar -->
                        <div class="card">
                            <div class="card-header">
                                <h6 class="mb-0">
                                    <i class="fas fa-image me-2"></i>الصورة الشخصية
                                </h6>
                            </div>
                            <div class="card-body">
                                <form method="post" action="" enctype="multipart/form-data">
                                    <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                                    <input type="hidden" name="action" value="upload_avatar">
                                    
                                    <div class="text-center mb-3">
                                        <img src="<?= htmlspecialchars($user['avatar_url'] ?: 'assets/images/default-avatar.png') ?>" 
                                             alt="صورة المستخدم" class="rounded-circle" width="100" height="100">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <input type="file" class="form-control" id="avatar" name="avatar" accept="image/*">
                                        <div class="form-text">
                                            اختر صورة بصيغة JPG أو PNG، حجم أقصى 2 ميجابايت
                                        </div>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-info w-100">
                                        <i class="fas fa-upload me-2"></i>رفع الصورة
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    // تهيئة AOS
    AOS.init({
        duration: 600,
        easing: 'ease-in-out',
        once: true
    });
    
    // رفع الصورة الشخصية
    function uploadAvatar(input) {
        if (input.files && input.files[0]) {
            const formData = new FormData();
            formData.append('avatar', input.files[0]);
            formData.append('csrf_token', '<?= generateCSRFToken() ?>');
            formData.append('action', 'upload_avatar');
            
            fetch('profile.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                location.reload();
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ في رفع الصورة');
            });
        }
    }
    
    // تحميل الشهادة
    function downloadCertificate(courseId) {
        window.open(`api.php?action=download_certificate&course_id=${courseId}`, '_blank');
    }
    
    // عرض الشهادة
    function viewCertificate(courseId) {
        window.open(`api.php?action=view_certificate&course_id=${courseId}`, '_blank');
    }
    
    // التحقق من قوة كلمة المرور
    document.getElementById('new_password')?.addEventListener('input', function() {
        const password = this.value;
        const strength = checkPasswordStrength(password);
        
        // يمكن إضافة مؤشر قوة كلمة المرور هنا
    });
    
    function checkPasswordStrength(password) {
        let strength = 0;
        if (password.length >= 8) strength++;
        if (/[a-z]/.test(password)) strength++;
        if (/[A-Z]/.test(password)) strength++;
        if (/[0-9]/.test(password)) strength++;
        if (/[^A-Za-z0-9]/.test(password)) strength++;
        
        return strength;
    }
    
    // التحقق من تطابق كلمات المرور
    document.getElementById('confirm_password')?.addEventListener('input', function() {
        const newPassword = document.getElementById('new_password').value;
        const confirmPassword = this.value;
        
        if (newPassword !== confirmPassword) {
            this.setCustomValidity('كلمات المرور غير متطابقة');
        } else {
            this.setCustomValidity('');
        }
    });
    
    // حفظ التبويب النشط
    document.addEventListener('DOMContentLoaded', function() {
        const hash = window.location.hash;
        if (hash) {
            const tabId = hash.substring(1) + '-tab';
            const tab = document.getElementById(tabId);
            if (tab) {
                tab.click();
            }
        }
        
        // حفظ التبويب عند التغيير
        document.querySelectorAll('#profileTab button').forEach(tab => {
            tab.addEventListener('shown.bs.tab', function(e) {
                const targetId = e.target.getAttribute('data-bs-target').substring(1);
                window.history.replaceState(null, null, '#' + targetId);
            });
        });
    });
</script>

<?php include __DIR__ . '/../layout/footer.php'; ?>