<?php
/**
 * واجهة مشغل الفيديو المحمي
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

// تضمين رأس الصفحة مع إعدادات خاصة للمشغل
include_once __DIR__ . '/../layout/player-header.php';
?>

<div class="player-container">
    <!-- Security Warning Modal -->
    <div class="modal fade" id="securityWarningModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-danger">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title">
                        <i class="fas fa-shield-alt me-2"></i>تحذير أمني
                    </h5>
                </div>
                <div class="modal-body text-center">
                    <lottie-player
                        src="https://assets3.lottiefiles.com/packages/lf20_khtt8brq.json"
                        background="transparent"
                        speed="1"
                        style="width: 150px; height: 150px; margin: 0 auto;"
                        loop
                        autoplay>
                    </lottie-player>
                    <h6 class="mt-3 text-danger">انتهاك أمني مكتشف!</h6>
                    <p id="securityMessage" class="text-muted"></p>
                </div>
                <div class="modal-footer justify-content-center">
                    <button type="button" class="btn btn-danger" onclick="handleSecurityViolation()">
                        <i class="fas fa-sign-out-alt me-2"></i>إنهاء الجلسة
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Browser Warning Modal -->
    <div class="modal fade" id="browserWarningModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-warning">
                <div class="modal-header bg-warning">
                    <h5 class="modal-title text-dark">
                        <i class="fas fa-exclamation-triangle me-2"></i>تحذير المتصفح
                    </h5>
                </div>
                <div class="modal-body text-center">
                    <i class="fas fa-browser fa-3x text-warning mb-3"></i>
                    <h6>متصفحك غير مدعوم أو إصداره قديم</h6>
                    <p class="text-muted">للحصول على أفضل تجربة، يرجى استخدام:</p>
                    <div class="browser-recommendations">
                        <div class="row g-2">
                            <div class="col-6">
                                <div class="browser-item">
                                    <i class="fab fa-chrome fa-2x text-info"></i>
                                    <small>Chrome 70+</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="browser-item">
                                    <i class="fab fa-firefox fa-2x text-orange"></i>
                                    <small>Firefox 65+</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" data-bs-dismiss="modal">
                        المتابعة على مسؤوليتي
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Player Interface -->
    <div class="row g-0 min-vh-100">
        <!-- Video Player Section -->
        <div class="col-lg-8">
            <div class="video-section">
                <!-- Video Container -->
                <div class="video-container" id="videoContainer">
                    <div class="video-overlay" id="videoOverlay">
                        <div class="loading-screen" id="loadingScreen">
                            <lottie-player
                                src="https://assets2.lottiefiles.com/packages/lf20_a2chheio.json"
                                background="transparent"
                                speed="1"
                                style="width: 100px; height: 100px;"
                                loop
                                autoplay>
                            </lottie-player>
                            <p class="loading-text">جاري تحضير الفيديو...</p>
                        </div>
                        
                        <div class="play-button" id="playButton">
                            <lottie-player
                                src="https://assets9.lottiefiles.com/packages/lf20_yDEJBJ.json"
                                background="transparent"
                                speed="1"
                                style="width: 80px; height: 80px;"
                                autoplay>
                            </lottie-player>
                        </div>
                    </div>
                    
                    <!-- VdoCipher Player will be embedded here -->
                    <div id="vdocipherPlayer"></div>
                </div>
                
                <!-- Video Controls -->
                <div class="video-controls">
                    <div class="controls-row">
                        <div class="lesson-info">
                            <h4 class="lesson-title"><?php echo htmlspecialchars($lesson['title']); ?></h4>
                            <p class="lesson-meta">
                                <span class="course-name"><?php echo htmlspecialchars($lesson['course_name']); ?></span>
                                <span class="separator">•</span>
                                <span class="section-name"><?php echo htmlspecialchars($lesson['section_name']); ?></span>
                                <?php if ($lesson['duration']): ?>
                                <span class="separator">•</span>
                                <span class="duration">
                                    <i class="fas fa-clock me-1"></i>
                                    <?php echo gmdate('H:i:s', $lesson['duration']); ?>
                                </span>
                                <?php endif; ?>
                            </p>
                        </div>
                        
                        <div class="video-actions">
                            <button class="btn btn-outline-primary btn-sm" id="fullscreenBtn" title="ملء الشاشة">
                                <i class="fas fa-expand"></i>
                            </button>
                            <button class="btn btn-outline-success btn-sm" id="completeBtn" title="تم إكمال الدرس">
                                <i class="fas fa-check"></i>
                            </button>
                        </div>
                    </div>
                    
                    <!-- Progress Bar -->
                    <div class="lesson-progress">
                        <div class="progress">
                            <div class="progress-bar" id="progressBar" style="width: <?php echo $progress ? min(100, ($progress['last_position'] / $lesson['duration']) * 100) : 0; ?>%"></div>
                        </div>
                        <small class="progress-text">
                            <span id="currentTime">00:00</span> / <span id="totalTime"><?php echo gmdate('H:i:s', $lesson['duration'] ?: 0); ?></span>
                        </small>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Sidebar Section -->
        <div class="col-lg-4">
            <div class="sidebar-section">
                <!-- Course Navigation -->
                <div class="course-navigation">
                    <div class="nav-header">
                        <h5>
                            <i class="fas fa-list me-2"></i>محتوى الدورة
                        </h5>
                        <button class="btn btn-sm btn-outline-secondary" id="toggleSidebar">
                            <i class="fas fa-compress-alt"></i>
                        </button>
                    </div>
                    
                    <div class="lessons-list" id="lessonsList">
                        <!-- سيتم تحميل قائمة الدروس هنا -->
                        <div class="loading-lessons text-center py-4">
                            <div class="spinner-border spinner-border-sm text-primary"></div>
                            <p class="mt-2 small text-muted">جاري تحميل الدروس...</p>
                        </div>
                    </div>
                </div>
                
                <!-- Lesson Notes -->
                <div class="lesson-notes mt-4">
                    <div class="notes-header">
                        <h6>
                            <i class="fas fa-sticky-note me-2"></i>ملاحظاتي
                        </h6>
                        <button class="btn btn-sm btn-outline-primary" id="addNoteBtn">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                    
                    <div class="notes-content">
                        <textarea class="form-control" id="notesTextarea" rows="4" 
                                  placeholder="اكتب ملاحظاتك حول هذا الدرس..."></textarea>
                        <button class="btn btn-sm btn-primary mt-2" id="saveNotesBtn">
                            <i class="fas fa-save me-1"></i>حفظ الملاحظات
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Hidden data for JavaScript -->
<script>
window.playerData = {
    lessonId: <?php echo $lessonId; ?>,
    videoId: '<?php echo $lesson['vdocipher_video_id'] ?? ''; ?>',
    userId: <?php echo $user['id']; ?>,
    sessionId: '<?php echo session_id(); ?>',
    csrfToken: '<?php echo generateCSRFToken(); ?>',
    isPreview: <?php echo $lesson['is_preview'] ? 'true' : 'false'; ?>,
    lastPosition: <?php echo $progress['last_position'] ?? 0; ?>,
    duration: <?php echo $lesson['duration'] ?? 0; ?>
};
</script>

<style>
/* تنسيقات مشغل الفيديو */
.player-page {
    background: #000;
    color: #fff;
    overflow: hidden;
}

.player-container {
    height: 100vh;
    overflow: hidden;
}

.video-section {
    background: #000;
    height: 100vh;
    display: flex;
    flex-direction: column;
}

.video-container {
    flex: 1;
    position: relative;
    background: #000;
    display: flex;
    align-items: center;
    justify-content: center;
}

.video-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10;
}

.loading-screen {
    text-align: center;
}

.loading-text {
    color: #fff;
    margin-top: 1rem;
    font-size: 0.9rem;
}

.play-button {
    cursor: pointer;
    transition: transform 0.3s ease;
}

.play-button:hover {
    transform: scale(1.1);
}

.video-controls {
    background: #1a1a1a;
    padding: 1rem;
    border-top: 1px solid #333;
}

.controls-row {
    display: flex;
    justify-content: between;
    align-items: flex-start;
    margin-bottom: 1rem;
}

.lesson-info {
    flex: 1;
}

.lesson-title {
    color: #fff;
    font-size: 1.25rem;
    font-weight: 600;
    margin-bottom: 0.5rem;
}

.lesson-meta {
    color: #b3b3b3;
    font-size: 0.9rem;
    margin: 0;
}

.separator {
    margin: 0 0.5rem;
    opacity: 0.6;
}

.video-actions {
    display: flex;
    gap: 0.5rem;
}

.video-actions .btn {
    border-color: #444;
    color: #b3b3b3;
}

.video-actions .btn:hover {
    background: #333;
    border-color: #555;
    color: #fff;
}

.lesson-progress {
    margin-top: 1rem;
}

.progress {
    height: 6px;
    background: #333;
    border-radius: 3px;
    margin-bottom: 0.5rem;
}

.progress-bar {
    background: linear-gradient(90deg, #007bff, #0056b3);
    border-radius: 3px;
    transition: width 0.3s ease;
}

.progress-text {
    color: #b3b3b3;
    font-size: 0.8rem;
    display: flex;
    justify-content: space-between;
}

.sidebar-section {
    background: #f8f9fa;
    height: 100vh;
    overflow-y: auto;
    border-left: 1px solid #dee2e6;
    color: #333;
}

.course-navigation {
    padding: 1rem;
}

.nav-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
    padding-bottom: 0.75rem;
    border-bottom: 2px solid #dee2e6;
}

.nav-header h5 {
    margin: 0;
    font-weight: 600;
    color: #2c3e50;
}

.lessons-list {
    max-height: 400px;
    overflow-y: auto;
}

.lesson-item {
    display: flex;
    align-items: center;
    padding: 0.75rem;
    border-radius: 8px;
    margin-bottom: 0.5rem;
    cursor: pointer;
    transition: all 0.3s ease;
    border: 1px solid transparent;
}

.lesson-item:hover {
    background: #e9ecef;
    border-color: #007bff;
}

.lesson-item.active {
    background: #007bff;
    color: #fff;
}

.lesson-item.completed {
    background: #d4edda;
    border-color: #28a745;
}

.lesson-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #007bff;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 0.75rem;
    font-size: 0.9rem;
}

.lesson-item.completed .lesson-icon {
    background: #28a745;
}

.lesson-info {
    flex: 1;
}

.lesson-name {
    font-weight: 500;
    font-size: 0.9rem;
    margin-bottom: 0.25rem;
}

.lesson-duration {
    font-size: 0.8rem;
    opacity: 0.7;
}

.lesson-notes {
    padding: 1rem;
    border-top: 1px solid #dee2e6;
}

.notes-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
}

.notes-header h6 {
    margin: 0;
    color: #2c3e50;
}

/* Security Features */
.no-select {
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

.no-context-menu {
    pointer-events: none;
}

/* Browser Recommendations */
.browser-recommendations {
    margin: 1rem 0;
}

.browser-item {
    text-align: center;
    padding: 0.5rem;
    border-radius: 8px;
    background: #f8f9fa;
}

.browser-item i {
    display: block;
    margin-bottom: 0.25rem;
}

.text-orange {
    color: #ff6600;
}

/* Responsive Design */
@media (max-width: 992px) {
    .sidebar-section {
        display: none;
    }
    
    .sidebar-section.show {
        display: block;
        position: fixed;
        top: 0;
        right: 0;
        width: 100%;
        z-index: 1050;
    }
    
    .controls-row {
        flex-direction: column;
        gap: 1rem;
    }
    
    .video-actions {
        align-self: stretch;
        justify-content: space-between;
    }
}

@media (max-width: 576px) {
    .lesson-title {
        font-size: 1rem;
    }
    
    .lesson-meta {
        font-size: 0.8rem;
    }
    
    .video-controls {
        padding: 0.75rem;
    }
}

/* Dark Theme Support */
.theme-dark .sidebar-section {
    background: #2d2d2d;
    color: #fff;
    border-left-color: #404040;
}

.theme-dark .nav-header {
    border-bottom-color: #404040;
}

.theme-dark .nav-header h5 {
    color: #fff;
}

.theme-dark .lesson-item {
    border-color: transparent;
}

.theme-dark .lesson-item:hover {
    background: #404040;
    border-color: #007bff;
}

.theme-dark .notes-header h6 {
    color: #fff;
}

.theme-dark .form-control {
    background: #404040;
    border-color: #555;
    color: #fff;
}

/* Video Protection Styles */
.video-protected {
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    pointer-events: none;
}

.video-protected video {
    pointer-events: none;
}

/* Loading States */
.loading-lessons {
    animation: pulse 1.5s ease-in-out infinite;
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}

/* Modal Customizations */
.modal-content.border-danger {
    border-width: 2px;
}

.modal-content.border-warning {
    border-width: 2px;
}
</style>

<?php
// تضمين JavaScript المخصص للمشغل
$additionalScripts = '
<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
<script src="https://player.vdocipher.com/v2/api.js"></script>
<script src="/assets/js/player.js"></script>
';

include_once __DIR__ . '/../layout/footer.php';
?>