<?php
/**
 * مكون التنبيهات المتقدم
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:16:04
 */

// التأكد من وجود البيانات المطلوبة
if (!isset($alertConfig)) {
    return;
}

$type = $alertConfig['type'] ?? 'info'; // success, danger, warning, info, primary, secondary
$message = $alertConfig['message'] ?? '';
$title = $alertConfig['title'] ?? '';
$dismissible = $alertConfig['dismissible'] ?? true;
$icon = $alertConfig['icon'] ?? '';
$autoHide = $alertConfig['autoHide'] ?? false;
$hideDelay = $alertConfig['hideDelay'] ?? 5000;
$actions = $alertConfig['actions'] ?? [];
$className = $alertConfig['class'] ?? '';
$id = $alertConfig['id'] ?? 'alert-' . uniqid();

// تحديد الأيقونة التلقائية حسب النوع
if (!$icon) {
    $icons = [
        'success' => 'fas fa-check-circle',
        'danger' => 'fas fa-exclamation-triangle',
        'warning' => 'fas fa-exclamation-circle',
        'info' => 'fas fa-info-circle',
        'primary' => 'fas fa-bell',
        'secondary' => 'fas fa-comment'
    ];
    $icon = $icons[$type] ?? 'fas fa-bell';
}
?>

<div id="<?= $id ?>" 
     class="alert alert-<?= $type ?> <?= $dismissible ? 'alert-dismissible' : '' ?> <?= $className ?> custom-alert fade show" 
     role="alert"
     data-auto-hide="<?= $autoHide ? 'true' : 'false' ?>"
     data-hide-delay="<?= $hideDelay ?>">
    
    <div class="alert-content d-flex align-items-start">
        <!-- Alert Icon -->
        <?php if ($icon): ?>
            <div class="alert-icon me-3">
                <i class="<?= $icon ?> fa-lg"></i>
            </div>
        <?php endif; ?>
        
        <!-- Alert Text -->
        <div class="alert-text flex-grow-1">
            <?php if ($title): ?>
                <h6 class="alert-heading mb-2"><?= htmlspecialchars($title) ?></h6>
            <?php endif; ?>
            
            <div class="alert-message">
                <?= is_array($message) ? implode('<br>', array_map('htmlspecialchars', $message)) : htmlspecialchars($message) ?>
            </div>
            
            <!-- Alert Actions -->
            <?php if (!empty($actions)): ?>
                <div class="alert-actions mt-3">
                    <?php foreach ($actions as $action): ?>
                        <?php
                        $actionType = $action['type'] ?? 'button'; // button, link
                        $actionText = $action['text'] ?? '';
                        $actionClass = $action['class'] ?? 'btn-sm btn-outline-' . $type;
                        $actionUrl = $action['url'] ?? '#';
                        $actionClick = $action['onclick'] ?? '';
                        $actionIcon = $action['icon'] ?? '';
                        ?>
                        
                        <?php if ($actionType === 'link'): ?>
                            <a href="<?= htmlspecialchars($actionUrl) ?>" 
                               class="btn <?= $actionClass ?> me-2"
                               <?= $actionClick ? 'onclick="' . htmlspecialchars($actionClick) . '"' : '' ?>>
                                <?php if ($actionIcon): ?>
                                    <i class="<?= $actionIcon ?> me-1"></i>
                                <?php endif; ?>
                                <?= htmlspecialchars($actionText) ?>
                            </a>
                        <?php else: ?>
                            <button type="button" 
                                    class="btn <?= $actionClass ?> me-2"
                                    <?= $actionClick ? 'onclick="' . htmlspecialchars($actionClick) . '"' : '' ?>>
                                <?php if ($actionIcon): ?>
                                    <i class="<?= $actionIcon ?> me-1"></i>
                                <?php endif; ?>
                                <?= htmlspecialchars($actionText) ?>
                            </button>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Dismiss Button -->
        <?php if ($dismissible): ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="إغلاق"></button>
        <?php endif; ?>
    </div>
    
    <!-- Progress Bar for Auto Hide -->
    <?php if ($autoHide): ?>
        <div class="alert-progress">
            <div class="alert-progress-bar"></div>
        </div>
    <?php endif; ?>
</div>

<style>
.custom-alert {
    border: none;
    border-radius: 15px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    margin-bottom: 1.5rem;
    position: relative;
    overflow: hidden;
}

.custom-alert::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: currentColor;
    opacity: 0.8;
}

.alert-content {
    padding: 1rem 1.5rem;
}

.alert-icon {
    opacity: 0.8;
    min-width: 24px;
}

.alert-text {
    line-height: 1.5;
}

.alert-heading {
    font-weight: 600;
    margin-bottom: 0.5rem;
    color: inherit;
}

.alert-message {
    margin-bottom: 0;
}

.alert-actions {
    border-top: 1px solid rgba(255,255,255,0.2);
    padding-top: 1rem;
    margin-top: 1rem;
}

.alert-progress {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: rgba(255,255,255,0.2);
    overflow: hidden;
}

.alert-progress-bar {
    height: 100%;
    background: rgba(255,255,255,0.6);
    width: 100%;
    transform: translateX(-100%);
    transition: transform linear;
}

/* Alert Types Customization */
.alert-success {
    background: linear-gradient(135deg, #d4edda, #c3e6cb);
    color: #155724;
    border-left: 4px solid #28a745;
}

.alert-danger {
    background: linear-gradient(135deg, #f8d7da, #f1b0b7);
    color: #721c24;
    border-left: 4px solid #dc3545;
}

.alert-warning {
    background: linear-gradient(135deg, #fff3cd, #ffeaa7);
    color: #856404;
    border-left: 4px solid #ffc107;
}

.alert-info {
    background: linear-gradient(135deg, #d1ecf1, #bee5eb);
    color: #0c5460;
    border-left: 4px solid #17a2b8;
}

.alert-primary {
    background: linear-gradient(135deg, #cce8ff, #b3d9ff);
    color: #004085;
    border-left: 4px solid #007bff;
}

.alert-secondary {
    background: linear-gradient(135deg, #e2e3e5, #d6d8db);
    color: #383d41;
    border-left: 4px solid #6c757d;
}

/* Animations */
.custom-alert.fade.show {
    animation: slideInDown 0.5s ease-out;
}

@keyframes slideInDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.custom-alert.fade:not(.show) {
    animation: slideOutUp 0.3s ease-in;
}

@keyframes slideOutUp {
    from {
        opacity: 1;
        transform: translateY(0);
    }
    to {
        opacity: 0;
        transform: translateY(-20px);
    }
}

/* Responsive */
@media (max-width: 768px) {
    .alert-content {
        padding: 0.8rem 1rem;
    }
    
    .alert-icon {
        font-size: 1rem;
    }
    
    .alert-actions {
        text-align: center;
    }
    
    .alert-actions .btn {
        margin: 0.2rem;
        font-size: 0.8rem;
    }
}

/* Toast Style (Floating) */
.custom-alert.alert-toast {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 1055;
    min-width: 300px;
    max-width: 400px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
}

.custom-alert.alert-toast.alert-bottom {
    top: auto;
    bottom: 20px;
}

.custom-alert.alert-toast.alert-left {
    right: auto;
    left: 20px;
}

.custom-alert.alert-toast.alert-center {
    left: 50%;
    transform: translateX(-50%);
}

/* Dark mode support */
@media (prefers-color-scheme: dark) {
    .custom-alert {
        background: #2d3748 !important;
        color: #e2e8f0 !important;
    }
    
    .alert-actions {
        border-top-color: rgba(255,255,255,0.1);
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const alert = document.getElementById('<?= $id ?>');
    if (!alert) return;
    
    const autoHide = alert.dataset.autoHide === 'true';
    const hideDelay = parseInt(alert.dataset.hideDelay) || 5000;
    
    if (autoHide) {
        const progressBar = alert.querySelector('.alert-progress-bar');
        
        if (progressBar) {
            // Start progress animation
            progressBar.style.transitionDuration = (hideDelay / 1000) + 's';
            progressBar.style.transform = 'translateX(0)';
        }
        
        // Auto hide after delay
        setTimeout(() => {
            hideAlert(alert);
        }, hideDelay);
        
        // Pause on hover
        alert.addEventListener('mouseenter', function() {
            if (progressBar) {
                progressBar.style.animationPlayState = 'paused';
            }
        });
        
        alert.addEventListener('mouseleave', function() {
            if (progressBar) {
                progressBar.style.animationPlayState = 'running';
            }
        });
    }
    
    // Manual dismiss handling
    const dismissBtn = alert.querySelector('.btn-close');
    if (dismissBtn) {
        dismissBtn.addEventListener('click', function() {
            hideAlert(alert);
        });
    }
    
    function hideAlert(alertElement) {
        alertElement.classList.remove('show');
        
        setTimeout(() => {
            alertElement.remove();
        }, 300);
    }
});

// Global alert functions
window.showAlert = function(type, message, options = {}) {
    const alertConfig = {
        type: type,
        message: message,
        ...options
    };
    
    const alertHtml = generateAlertHtml(alertConfig);
    const container = document.querySelector('.alert-container') || document.body;
    
    const alertElement = document.createElement('div');
    alertElement.innerHTML = alertHtml;
    
    if (options.position === 'toast') {
        alertElement.firstElementChild.classList.add('alert-toast');
        if (options.toastPosition) {
            alertElement.firstElementChild.classList.add('alert-' + options.toastPosition);
        }
    }
    
    container.appendChild(alertElement.firstElementChild);
};

window.showSuccess = function(message, options = {}) {
    showAlert('success', message, options);
};

window.showError = function(message, options = {}) {
    showAlert('danger', message, options);
};

window.showWarning = function(message, options = {}) {
    showAlert('warning', message, options);
};

window.showInfo = function(message, options = {}) {
    showAlert('info', message, options);
};

function generateAlertHtml(config) {
    // يمكن توليد HTML للتنبيه ديناميكياً هنا
    // للبساطة، سنستخدم template بسيط
    return `
        <div class="alert alert-${config.type} alert-dismissible custom-alert fade show" role="alert">
            <div class="alert-content d-flex align-items-start">
                <div class="alert-icon me-3">
                    <i class="${getAlertIcon(config.type)} fa-lg"></i>
                </div>
                <div class="alert-text flex-grow-1">
                    <div class="alert-message">${config.message}</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        </div>
    `;
}

function getAlertIcon(type) {
    const icons = {
        'success': 'fas fa-check-circle',
        'danger': 'fas fa-exclamation-triangle',
        'warning': 'fas fa-exclamation-circle',
        'info': 'fas fa-info-circle',
        'primary': 'fas fa-bell',
        'secondary': 'fas fa-comment'
    };
    return icons[type] || 'fas fa-bell';
}
</script>