<?php
/**
 * مكونات النوافذ المنبثقة المتقدمة - تحسينات إضافية
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:36:31
 */
?>

<!-- Course Preview Modal -->
<div class="modal fade" id="coursePreviewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header border-0">
                <h5 class="modal-title">
                    <i class="fas fa-play-circle me-2"></i>معاينة الدورة
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-0">
                <div class="video-container">
                    <div id="previewVideoPlayer" class="preview-player"></div>
                </div>
                <div class="preview-info p-4">
                    <h6 id="previewTitle" class="fw-bold mb-2"></h6>
                    <p id="previewDescription" class="text-muted mb-3"></p>
                    <div class="preview-stats d-flex gap-3">
                        <span class="badge bg-primary">
                            <i class="fas fa-clock me-1"></i>
                            <span id="previewDuration">0 دقيقة</span>
                        </span>
                        <span class="badge bg-success">
                            <i class="fas fa-users me-1"></i>
                            <span id="previewStudents">0 طالب</span>
                        </span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                <button type="button" class="btn btn-primary" id="enrollFromPreview">
                    <i class="fas fa-graduation-cap me-2"></i>اشترك في الدورة
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Quick Subscription Modal -->
<div class="modal fade" id="quickSubscribeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">
                    <i class="fas fa-key me-2"></i>تفعيل كود اشتراك
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="quickSubscribeForm">
                    <div class="text-center mb-4">
                        <div class="subscription-icon">
                            <i class="fas fa-key fa-3x text-primary"></i>
                        </div>
                        <h6 class="mt-3">أدخل كود التفعيل</h6>
                        <p class="text-muted">استخدم الكود الذي حصلت عليه للوصول للدورة</p>
                    </div>
                    
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control text-center" id="subscriptionCode" 
                               placeholder="كود التفعيل" style="letter-spacing: 2px; font-size: 1.2rem;">
                        <label for="subscriptionCode">كود التفعيل</label>
                    </div>
                    
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        تأكد من إدخال الكود كما هو مكتوب، مع مراعاة الأحرف الكبيرة والصغيرة
                    </div>
                    
                    <div id="subscribeResult"></div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                <button type="button" class="btn btn-primary" onclick="activateSubscription()">
                    <i class="fas fa-check me-2"></i>تفعيل الكود
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Progress Tracking Modal -->
<div class="modal fade" id="progressModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-chart-line me-2"></i>تتبع التقدم
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="progress-overview mb-4">
                    <div class="row text-center">
                        <div class="col-4">
                            <div class="progress-stat">
                                <div class="stat-number text-primary" id="totalCourses">0</div>
                                <div class="stat-label">دورة مسجل</div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="progress-stat">
                                <div class="stat-number text-success" id="completedLessons">0</div>
                                <div class="stat-label">درس مكتمل</div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="progress-stat">
                                <div class="stat-number text-warning" id="watchTime">0</div>
                                <div class="stat-label">ساعة مشاهدة</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="courses-progress" id="coursesProgressList">
                    <!-- يتم ملؤها ديناميكياً -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                <a href="profile.php" class="btn btn-primary">
                    <i class="fas fa-user me-2"></i>الملف الشخصي
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Share Course Modal -->
<div class="modal fade" id="shareModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-share-alt me-2"></i>مشاركة الدورة
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="share-options">
                    <div class="row g-3">
                        <div class="col-6">
                            <button class="btn btn-primary w-100 share-btn" onclick="shareOnPlatform('facebook')">
                                <i class="fab fa-facebook-f fa-lg mb-2"></i><br>
                                فيسبوك
                            </button>
                        </div>
                        <div class="col-6">
                            <button class="btn btn-info w-100 share-btn" onclick="shareOnPlatform('twitter')">
                                <i class="fab fa-twitter fa-lg mb-2"></i><br>
                                تويتر
                            </button>
                        </div>
                        <div class="col-6">
                            <button class="btn btn-success w-100 share-btn" onclick="shareOnPlatform('whatsapp')">
                                <i class="fab fa-whatsapp fa-lg mb-2"></i><br>
                                واتساب
                            </button>
                        </div>
                        <div class="col-6">
                            <button class="btn btn-dark w-100 share-btn" onclick="shareOnPlatform('telegram')">
                                <i class="fab fa-telegram fa-lg mb-2"></i><br>
                                تليجرام
                            </button>
                        </div>
                    </div>
                </div>
                
                <hr>
                
                <div class="copy-link">
                    <label class="form-label">رابط الدورة</label>
                    <div class="input-group">
                        <input type="text" class="form-control" id="courseLink" readonly>
                        <button class="btn btn-outline-secondary" onclick="copyToClipboard()">
                            <i class="fas fa-copy"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Certificate Modal -->
<div class="modal fade" id="certificateModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-gradient-primary text-white">
                <h5 class="modal-title">
                    <i class="fas fa-certificate me-2"></i>شهادة الإنجاز
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-0">
                <div class="certificate-preview" id="certificatePreview">
                    <!-- يتم ملؤها ديناميكياً -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                <button type="button" class="btn btn-primary" onclick="downloadCertificate()">
                    <i class="fas fa-download me-2"></i>تحميل الشهادة
                </button>
                <button type="button" class="btn btn-success" onclick="shareCertificate()">
                    <i class="fas fa-share me-2"></i>مشاركة
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Notes Modal -->
<div class="modal fade" id="notesModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-sticky-note me-2"></i>ملاحظاتي
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="notes-container">
                    <div class="add-note mb-4">
                        <div class="form-floating">
                            <textarea class="form-control" id="newNoteText" 
                                    placeholder="اكتب ملاحظة جديدة..." style="height: 100px;"></textarea>
                            <label for="newNoteText">ملاحظة جديدة</label>
                        </div>
                        <div class="mt-2">
                            <button class="btn btn-primary" onclick="addNote()">
                                <i class="fas fa-plus me-2"></i>إضافة ملاحظة
                            </button>
                        </div>
                    </div>
                    
                    <div class="notes-list" id="notesList">
                        <!-- يتم ملؤها ديناميكياً -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Modal Enhancements */
.modal-content {
    border-radius: 15px;
    border: none;
    box-shadow: 0 15px 35px rgba(0,0,0,0.2);
}

.modal-header {
    border-radius: 15px 15px 0 0;
}

.video-container {
    position: relative;
    width: 100%;
    height: 400px;
    background: #000;
    border-radius: 10px;
    overflow: hidden;
}

.preview-player {
    width: 100%;
    height: 100%;
}

.subscription-icon {
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.1); }
    100% { transform: scale(1); }
}

.progress-stat {
    padding: 1rem;
    background: #f8f9fa;
    border-radius: 10px;
    margin: 0.5rem 0;
}

.stat-number {
    font-size: 2rem;
    font-weight: bold;
}

.stat-label {
    font-size: 0.9rem;
    color: #6c757d;
}

.share-btn {
    height: 80px;
    transition: all 0.3s ease;
}

.share-btn:hover {
    transform: translateY(-3px);
}

.course-progress-item {
    background: white;
    border-radius: 10px;
    padding: 1rem;
    margin-bottom: 1rem;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
}

.progress-bar-custom {
    height: 8px;
    border-radius: 4px;
    background: #e9ecef;
    overflow: hidden;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(45deg, #28a745, #20c997);
    border-radius: 4px;
    transition: width 0.3s ease;
}

.certificate-preview {
    background: linear-gradient(135deg, #f8f9fa, #e9ecef);
    padding: 2rem;
    text-align: center;
    min-height: 400px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.note-item {
    background: #f8f9fa;
    border-radius: 10px;
    padding: 1rem;
    margin-bottom: 1rem;
    border-left: 4px solid #667eea;
}

.note-meta {
    font-size: 0.8rem;
    color: #6c757d;
    margin-bottom: 0.5rem;
}

.note-text {
    line-height: 1.6;
}

.note-actions {
    text-align: left;
    margin-top: 0.5rem;
}

/* Responsive */
@media (max-width: 768px) {
    .modal-dialog {
        margin: 0.5rem;
    }
    
    .video-container {
        height: 250px;
    }
    
    .share-btn {
        height: 60px;
        font-size: 0.8rem;
    }
    
    .stat-number {
        font-size: 1.5rem;
    }
}
</style>

<script>
// Course Preview Functions
let currentCourseId = null;

function showCoursePreview(courseId) {
    currentCourseId = courseId;
    
    fetch(`api.php?action=get_course_preview&course_id=${courseId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('previewTitle').textContent = data.course.name;
                document.getElementById('previewDescription').textContent = data.course.description;
                document.getElementById('previewDuration').textContent = data.course.duration + ' دقيقة';
                document.getElementById('previewStudents').textContent = data.course.students_count + ' طالب';
                
                if (data.course.preview_video) {
                    loadPreviewVideo(data.course.preview_video);
                }
                
                const modal = new bootstrap.Modal(document.getElementById('coursePreviewModal'));
                modal.show();
            }
        })
        .catch(error => console.error('Error:', error));
}

function loadPreviewVideo(videoUrl) {
    const player = document.getElementById('previewVideoPlayer');
    player.innerHTML = `
        <video controls width="100%" height="100%">
            <source src="${videoUrl}" type="video/mp4">
            متصفحك لا يدعم تشغيل الفيديو
        </video>
    `;
}

document.getElementById('enrollFromPreview')?.addEventListener('click', function() {
    if (currentCourseId) {
        subscribeToCourse(currentCourseId);
    }
});

// Quick Subscription Functions
function showQuickSubscribe() {
    const modal = new bootstrap.Modal(document.getElementById('quickSubscribeModal'));
    modal.show();
}

function activateSubscription() {
    const code = document.getElementById('subscriptionCode').value.trim();
    const resultDiv = document.getElementById('subscribeResult');
    
    if (!code) {
        resultDiv.innerHTML = '<div class="alert alert-danger">يرجى إدخال كود التفعيل</div>';
        return;
    }
    
    fetch('api.php?action=activate_subscription', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ code: code })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            resultDiv.innerHTML = `
                <div class="alert alert-success">
                    <i class="fas fa-check-circle me-2"></i>
                    تم تفعيل الكود بنجاح! تم منحك الوصول للدورة: ${data.course_name}
                </div>
            `;
            
            setTimeout(() => {
                window.location.href = `course.php?id=${data.course_id}`;
            }, 2000);
        } else {
            resultDiv.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    ${data.message}
                </div>
            `;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        resultDiv.innerHTML = '<div class="alert alert-danger">حدث خطأ في الشبكة</div>';
    });
}

// Progress Tracking Functions
function showProgressModal() {
    loadUserProgress();
    const modal = new bootstrap.Modal(document.getElementById('progressModal'));
    modal.show();
}

function loadUserProgress() {
    fetch('api.php?action=get_user_progress')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('totalCourses').textContent = data.stats.total_courses;
                document.getElementById('completedLessons').textContent = data.stats.completed_lessons;
                document.getElementById('watchTime').textContent = data.stats.watch_hours + ' ساعة';
                
                const progressList = document.getElementById('coursesProgressList');
                progressList.innerHTML = data.courses.map(course => `
                    <div class="course-progress-item">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h6 class="mb-0">${course.name}</h6>
                            <span class="badge bg-primary">${course.progress}%</span>
                        </div>
                        <div class="progress-bar-custom">
                            <div class="progress-fill" style="width: ${course.progress}%"></div>
                        </div>
                        <small class="text-muted">${course.completed_lessons}/${course.total_lessons} دروس</small>
                    </div>
                `).join('');
            }
        })
        .catch(error => console.error('Error:', error));
}

// Share Functions
function showShareModal(courseId, courseTitle) {
    currentCourseId = courseId;
    const courseUrl = `${window.location.origin}/course.php?id=${courseId}`;
    document.getElementById('courseLink').value = courseUrl;
    
    const modal = new bootstrap.Modal(document.getElementById('shareModal'));
    modal.show();
}

function shareOnPlatform(platform) {
    const courseUrl = document.getElementById('courseLink').value;
    const courseTitle = 'تعلم معنا في منصة ترند التعليمية';
    
    const urls = {
        facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(courseUrl)}`,
        twitter: `https://twitter.com/intent/tweet?url=${encodeURIComponent(courseUrl)}&text=${encodeURIComponent(courseTitle)}`,
        whatsapp: `https://wa.me/?text=${encodeURIComponent(courseTitle + ' ' + courseUrl)}`,
        telegram: `https://t.me/share/url?url=${encodeURIComponent(courseUrl)}&text=${encodeURIComponent(courseTitle)}`
    };
    
    if (urls[platform]) {
        window.open(urls[platform], '_blank', 'width=600,height=400');
    }
}

function copyToClipboard() {
    const linkInput = document.getElementById('courseLink');
    linkInput.select();
    document.execCommand('copy');
    
    showAlert('success', 'تم نسخ الرابط إلى الحافظة!', { autoHide: true });
}

// Certificate Functions
function showCertificate(courseId) {
    fetch(`api.php?action=get_certificate&course_id=${courseId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('certificatePreview').innerHTML = data.certificate_html;
                const modal = new bootstrap.Modal(document.getElementById('certificateModal'));
                modal.show();
            }
        })
        .catch(error => console.error('Error:', error));
}

function downloadCertificate() {
    if (currentCourseId) {
        window.open(`api.php?action=download_certificate&course_id=${currentCourseId}`, '_blank');
    }
}

function shareCertificate() {
    if (currentCourseId) {
        const shareUrl = `${window.location.origin}/certificate.php?id=${currentCourseId}`;
        showShareModal(currentCourseId, 'شاهد شهادتي في الدورة');
        document.getElementById('courseLink').value = shareUrl;
    }
}

// Notes Functions
let currentLessonId = null;

function showNotesModal(lessonId) {
    currentLessonId = lessonId;
    loadNotes();
    const modal = new bootstrap.Modal(document.getElementById('notesModal'));
    modal.show();
}

function loadNotes() {
    if (!currentLessonId) return;
    
    fetch(`api.php?action=get_notes&lesson_id=${currentLessonId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const notesList = document.getElementById('notesList');
                notesList.innerHTML = data.notes.map(note => `
                    <div class="note-item">
                        <div class="note-meta">
                            <i class="fas fa-clock me-1"></i>
                            ${note.timestamp} - ${note.created_at}
                        </div>
                        <div class="note-text">${note.content}</div>
                        <div class="note-actions">
                            <button class="btn btn-sm btn-outline-danger" onclick="deleteNote(${note.id})">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                `).join('');
            }
        })
        .catch(error => console.error('Error:', error));
}

function addNote() {
    const noteText = document.getElementById('newNoteText').value.trim();
    if (!noteText || !currentLessonId) return;
    
    // الحصول على الوقت الحالي من مشغل الفيديو
    const currentTime = getCurrentVideoTime() || 0;
    
    fetch('api.php?action=add_note', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            lesson_id: currentLessonId,
            content: noteText,
            timestamp: currentTime
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            document.getElementById('newNoteText').value = '';
            loadNotes();
            showAlert('success', 'تم إضافة الملاحظة بنجاح');
        }
    })
    .catch(error => console.error('Error:', error));
}

function deleteNote(noteId) {
    if (!confirm('هل تريد حذف هذه الملاحظة؟')) return;
    
    fetch(`api.php?action=delete_note&note_id=${noteId}`, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            loadNotes();
            showAlert('success', 'تم حذف الملاحظة');
        }
    })
    .catch(error => console.error('Error:', error));
}

// Helper function to get current video time
function getCurrentVideoTime() {
    // يجب ربطها بمشغل الفيديو الحقيقي
    return 0;
}
</script>