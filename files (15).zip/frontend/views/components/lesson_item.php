<?php
/**
 * مكون عنصر الدرس
 */

if (!defined('LEARNING_PLATFORM') ) {
    die('Direct access not allowed');
}

function renderLessonItem($lesson, $userSubscribed = false, $completed = false) {
    $canPlay = $userSubscribed || $lesson['is_preview'];
    
    ob_start();
    ?>
    <div class="lesson-item <?php echo $completed ? 'completed' : ''; ?>" data-lesson-id="<?php echo $lesson['id']; ?>">
        <div class="lesson-content">
            <div class="lesson-info">
                <div class="lesson-title">
                    <div class="lesson-icon">
                        <?php if ($completed): ?>
                            <i class="fas fa-check-circle text-success"></i>
                        <?php elseif ($lesson['is_preview']): ?>
                            <i class="fas fa-unlock text-warning"></i>
                        <?php else: ?>
                            <i class="fas fa-play-circle text-primary"></i>
                        <?php endif; ?>
                    </div>
                    <h6 class="mb-1"><?php echo htmlspecialchars($lesson['title']); ?></h6>
                </div>
                
                <div class="lesson-meta">
                    <?php if (!empty($lesson['duration'])): ?>
                    <span class="duration">
                        <i class="fas fa-clock me-1"></i>
                        <?php echo formatDuration($lesson['duration']); ?>
                    </span>
                    <?php endif; ?>
                    
                    <?php if ($lesson['is_preview']): ?>
                    <span class="badge bg-warning">معاينة مجانية</span>
                    <?php endif; ?>
                    
                    <?php if ($completed): ?>
                    <span class="badge bg-success">مكتمل</span>
                    <?php endif; ?>
                </div>
                
                <?php if (!empty($lesson['description'])): ?>
                <p class="lesson-description">
                    <?php echo htmlspecialchars($lesson['description']); ?>
                </p>
                <?php endif; ?>
            </div>
            
            <div class="lesson-actions">
                <?php if ($canPlay): ?>
                    <button class="btn btn-sm btn-primary" 
                            onclick="playLesson(<?php echo $lesson['id']; ?>, '<?php echo $lesson['vdocipher_video_id']; ?>')">
                        <i class="fas fa-play me-1"></i>
                        <?php echo $completed ? 'إعادة مشاهدة' : 'تشغيل'; ?>
                    </button>
                <?php else: ?>
                    <button class="btn btn-sm btn-secondary" disabled title="يتطلب اشتراك">
                        <i class="fas fa-lock me-1"></i>مقفل
                    </button>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if ($userSubscribed && !empty($lesson['progress_percentage'])): ?>
        <div class="lesson-progress">
            <div class="progress" style="height: 4px;">
                <div class="progress-bar bg-primary" 
                     style="width: <?php echo $lesson['progress_percentage']; ?>%"></div>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
?>