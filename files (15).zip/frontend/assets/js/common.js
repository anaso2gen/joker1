            background: rgba(255, 255, 255, 0.6);
            border-radius: 50%;
            transform: scale(0);
            animation: ripple 0.6s linear;
            pointer-events: none;
        `;
        
        button.style.position = 'relative';
        button.style.overflow = 'hidden';
        button.appendChild(ripple);
        
        setTimeout(() => {
            ripple.remove();
        }, 600);
    },
    
    // منع النقر المتعدد
    preventDoubleClick(button) {
        let isClicked = false;
        
        button.addEventListener('click', () => {
            if (isClicked) return;
            
            isClicked = true;
            setTimeout(() => {
                isClicked = false;
            }, 1000);
        });
    },
    
    // تهيئة الصور
    initializeImages() {
        // Lazy loading للصور
        this.initializeLazyLoading();
        
        // معالجة أخطاء الصور
        this.handleImageErrors();
        
        // تحسين عرض الصور
        this.enhanceImageDisplay();
    },
    
    // Lazy loading للصور
    initializeLazyLoading() {
        const lazyImages = document.querySelectorAll('img[data-src]');
        
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.classList.remove('lazy');
                        imageObserver.unobserve(img);
                        
                        img.addEventListener('load', () => {
                            img.classList.add('loaded');
                        });
                    }
                });
            });
            
            lazyImages.forEach(img => imageObserver.observe(img));
        } else {
            // Fallback للمتصفحات القديمة
            lazyImages.forEach(img => {
                img.src = img.dataset.src;
                img.classList.remove('lazy');
            });
        }
    },
    
    // معالجة أخطاء الصور
    handleImageErrors() {
        const images = document.querySelectorAll('img');
        
        images.forEach(img => {
            img.addEventListener('error', () => {
                img.src = '/assets/images/placeholder.jpg';
                img.classList.add('error');
            });
        });
    },
    
    // تحسين عرض الصور
    enhanceImageDisplay() {
        const images = document.querySelectorAll('img[data-enhance="true"]');
        
        images.forEach(img => {
            img.addEventListener('click', () => {
                this.openImageModal(img.src, img.alt);
            });
        });
    },
    
    // فتح نموذج الصورة
    openImageModal(src, alt) {
        const modal = document.createElement('div');
        modal.className = 'image-modal';
        modal.innerHTML = `
            <div class="modal-backdrop" onclick="this.parentElement.remove()">
                <div class="modal-content" onclick="event.stopPropagation()">
                    <img src="${src}" alt="${alt}">
                    <button class="close-btn" onclick="this.closest('.image-modal').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // إضافة أنيميشن
        setTimeout(() => modal.classList.add('show'), 10);
    },
    
    // تهيئة التفاعلات
    initializeInteractions() {
        // تهيئة Tooltips
        this.initializeTooltips();
        
        // تهيئة القوائم المنسدلة
        this.initializeDropdowns();
        
        // تهيئة Tabs
        this.initializeTabs();
        
        // تهيئة Accordions
        this.initializeAccordions();
        
        // تهيئة المودال
        this.initializeModals();
    },
    
    // تهيئة Tooltips
    initializeTooltips() {
        const tooltipElements = document.querySelectorAll('[data-tooltip]');
        
        tooltipElements.forEach(element => {
            element.addEventListener('mouseenter', (e) => {
                this.showTooltip(e.target);
            });
            
            element.addEventListener('mouseleave', () => {
                this.hideTooltip();
            });
        });
    },
    
    // عرض Tooltip
    showTooltip(element) {
        const text = element.dataset.tooltip;
        const position = element.dataset.tooltipPosition || 'top';
        
        const tooltip = document.createElement('div');
        tooltip.className = `tooltip tooltip-${position}`;
        tooltip.textContent = text;
        tooltip.id = 'active-tooltip';
        
        document.body.appendChild(tooltip);
        
        const rect = element.getBoundingClientRect();
        const tooltipRect = tooltip.getBoundingClientRect();
        
        let top, left;
        
        switch (position) {
            case 'top':
                top = rect.top - tooltipRect.height - 8;
                left = rect.left + (rect.width / 2) - (tooltipRect.width / 2);
                break;
            case 'bottom':
                top = rect.bottom + 8;
                left = rect.left + (rect.width / 2) - (tooltipRect.width / 2);
                break;
            case 'left':
                top = rect.top + (rect.height / 2) - (tooltipRect.height / 2);
                left = rect.left - tooltipRect.width - 8;
                break;
            case 'right':
                top = rect.top + (rect.height / 2) - (tooltipRect.height / 2);
                left = rect.right + 8;
                break;
        }
        
        tooltip.style.top = `${top}px`;
        tooltip.style.left = `${left}px`;
        tooltip.classList.add('show');
    },
    
    // إخفاء Tooltip
    hideTooltip() {
        const tooltip = document.getElementById('active-tooltip');
        if (tooltip) {
            tooltip.remove();
        }
    },
    
    // تهيئة القوائم المنسدلة
    initializeDropdowns() {
        const dropdownToggles = document.querySelectorAll('[data-dropdown]');
        
        dropdownToggles.forEach(toggle => {
            toggle.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                const dropdownId = toggle.dataset.dropdown;
                const dropdown = document.getElementById(dropdownId);
                
                if (dropdown) {
                    // إغلاق القوائم الأخرى
                    document.querySelectorAll('.dropdown.show').forEach(dd => {
                        if (dd !== dropdown) dd.classList.remove('show');
                    });
                    
                    dropdown.classList.toggle('show');
                }
            });
        });
        
        // إغلاق عند النقر خارج القائمة
        document.addEventListener('click', () => {
            document.querySelectorAll('.dropdown.show').forEach(dropdown => {
                dropdown.classList.remove('show');
            });
        });
    },
    
    // تهيئة Tabs
    initializeTabs() {
        const tabButtons = document.querySelectorAll('[data-tab]');
        
        tabButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                
                const tabId = button.dataset.tab;
                const tabContainer = button.closest('.tabs-container');
                
                if (tabContainer) {
                    // إزالة الحالة النشطة من جميع الأزرار والمحتوى
                    tabContainer.querySelectorAll('[data-tab]').forEach(btn => {
                        btn.classList.remove('active');
                    });
                    
                    tabContainer.querySelectorAll('.tab-pane').forEach(pane => {
                        pane.classList.remove('active');
                    });
                    
                    // تفعيل الزر والمحتوى الحالي
                    button.classList.add('active');
                    const targetPane = document.getElementById(tabId);
                    if (targetPane) {
                        targetPane.classList.add('active');
                    }
                }
            });
        });
    },
    
    // تهيئة Accordions
    initializeAccordions() {
        const accordionHeaders = document.querySelectorAll('.accordion-header');
        
        accordionHeaders.forEach(header => {
            header.addEventListener('click', () => {
                const accordion = header.closest('.accordion');
                const content = header.nextElementSibling;
                const isActive = header.classList.contains('active');
                
                // إغلاق جميع العناصر الأخرى في نفس المجموعة
                if (accordion) {
                    accordion.querySelectorAll('.accordion-header').forEach(h => {
                        if (h !== header) {
                            h.classList.remove('active');
                            h.nextElementSibling.style.maxHeight = null;
                        }
                    });
                }
                
                // تبديل العنصر الحالي
                header.classList.toggle('active', !isActive);
                
                if (!isActive) {
                    content.style.maxHeight = content.scrollHeight + 'px';
                } else {
                    content.style.maxHeight = null;
                }
            });
        });
    },
    
    // تهيئة المودال
    initializeModals() {
        const modalTriggers = document.querySelectorAll('[data-modal-target]');
        
        modalTriggers.forEach(trigger => {
            trigger.addEventListener('click', (e) => {
                e.preventDefault();
                const modalId = trigger.dataset.modalTarget;
                this.openModal(modalId);
            });
        });
        
        // إغلاق المودال
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal-backdrop') || 
                e.target.classList.contains('modal-close')) {
                this.closeModal(e.target.closest('.modal'));
            }
        });
        
        // إغلاق بـ ESC
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const openModal = document.querySelector('.modal.show');
                if (openModal) {
                    this.closeModal(openModal);
                }
            }
        });
    },
    
    // فتح المودال
    openModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('show');
            document.body.classList.add('modal-open');
            
            // التركيز على أول عنصر قابل للتفاعل
            const focusable = modal.querySelector('input, textarea, select, button');
            if (focusable) {
                setTimeout(() => focusable.focus(), 100);
            }
        }
    },
    
    // إغلاق المودال
    closeModal(modal) {
        if (modal) {
            modal.classList.remove('show');
            document.body.classList.remove('modal-open');
        }
    }
};

// CSS للأنيميشن
const style = document.createElement('style');
style.textContent = `
    @keyframes ripple {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
    
    .image-modal {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 9999;
        opacity: 0;
        transition: opacity 0.3s ease;
    }
    
    .image-modal.show {
        opacity: 1;
    }
    
    .image-modal .modal-backdrop {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
    }
    
    .image-modal .modal-content {
        position: relative;
        max-width: 90%;
        max-height: 90%;
        cursor: default;
    }
    
    .image-modal img {
        max-width: 100%;
        max-height: 100%;
        border-radius: 8px;
    }
    
    .image-modal .close-btn {
        position: absolute;
        top: -40px;
        right: 0;
        background: rgba(255, 255, 255, 0.2);
        border: none;
        color: white;
        padding: 8px;
        border-radius: 50%;
        cursor: pointer;
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .tooltip {
        position: absolute;
        background: rgba(0, 0, 0, 0.9);
        color: white;
        padding: 8px 12px;
        border-radius: 4px;
        font-size: 12px;
        z-index: 9999;
        opacity: 0;
        transition: opacity 0.3s ease;
        pointer-events: none;
        white-space: nowrap;
    }
    
    .tooltip.show {
        opacity: 1;
    }
    
    .tooltip::after {
        content: '';
        position: absolute;
        width: 0;
        height: 0;
        border: 5px solid transparent;
    }
    
    .tooltip.tooltip-top::after {
        bottom: -10px;
        left: 50%;
        transform: translateX(-50%);
        border-top-color: rgba(0, 0, 0, 0.9);
    }
    
    .tooltip.tooltip-bottom::after {
        top: -10px;
        left: 50%;
        transform: translateX(-50%);
        border-bottom-color: rgba(0, 0, 0, 0.9);
    }
    
    .tooltip.tooltip-left::after {
        right: -10px;
        top: 50%;
        transform: translateY(-50%);
        border-left-color: rgba(0, 0, 0, 0.9);
    }
    
    .tooltip.tooltip-right::after {
        left: -10px;
        top: 50%;
        transform: translateY(-50%);
        border-right-color: rgba(0, 0, 0, 0.9);
    }
`;

document.head.appendChild(style);

// تهيئة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    FrontendJS.init();
});

// تصدير للاستخدام العام
window.FrontendJS = FrontendJS;