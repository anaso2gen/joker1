/**
 * ملف تهيئة التطبيق الرئيسي
 * يحتوي على إعدادات وتهيئة النظام العامة
 */

// إعدادات التطبيق العامة
const AppConfig = {
    name: 'منصة التعليم الإلكتروني',
    version: '1.0.0',
    debug: false, // تفعيل في بيئة التطوير فقط
    apiTimeout: 30000, // 30 ثانية
    retryAttempts: 3,
    retryDelay: 1000,
    
    // إعدادات الكاش
    cache: {
        enabled: true,
        expiry: 300000, // 5 دقائق
        maxSize: 50 // عدد العناصر
    },
    
    // إعدادات الأمان
    security: {
        csrfEnabled: true,
        xssProtection: true,
        contentSecurityPolicy: true
    },
    
    // إعدادات التحليلات
    analytics: {
        enabled: true,
        trackingId: null // يتم تعيينه من الإعدادات
    }
};

// مدير التطبيق الرئيسي
class App {
    constructor(config = {}) {
        this.config = { ...AppConfig, ...config };
        this.modules = new Map();
        this.events = new EventTarget();
        this.initialized = false;
        
        // ربط الأحداث
        this.bindEvents();
    }
    
    // تهيئة التطبيق
    async init() {
        if (this.initialized) return;
        
        try {
            // إظهار مؤشر التحميل
            this.showGlobalLoading();
            
            // تهيئة الوحدات الأساسية
            await this.initCoreModules();
            
            // تهيئة المكونات
            await this.initComponents();
            
            // تهيئة الخدمات
            await this.initServices();
            
            // تهيئة التحليلات
            this.initAnalytics();
            
            this.initialized = true;
            this.emit('app:initialized');
            
            if (this.config.debug) {
                console.log('App initialized successfully');
            }
            
        } catch (error) {
            console.error('App initialization failed:', error);
            this.emit('app:error', { error });
        } finally {
            // إخفاء مؤشر التحميل
            this.hideGlobalLoading();
        }
    }
    
    // تهيئة الوحدات الأساسية
    async initCoreModules() {
        // تهيئة مدير الكاش
        this.cache = new CacheManager(this.config.cache);
        
        // تهيئة مدير الشبكة
        this.network = new NetworkManager({
            timeout: this.config.apiTimeout,
            retryAttempts: this.config.retryAttempts,
            retryDelay: this.config.retryDelay
        });
        
        // تهيئة مدير الأمان
        this.security = new SecurityManager(this.config.security);
        
        // تهيئة مدير الإشعارات
        this.notifications = new NotificationManager();
        
        // تهيئة مدير الجلسة
        this.session = new SessionManager();
    }
    
    // تهيئة المكونات
    async initComponents() {
        // تهيئة مكونات Bootstrap
        this.initBootstrapComponents();
        
        // تهيئة مكونات AOS
        this.initAOSComponents();
        
        // تهيئة مكونات Lottie
        this.initLottieComponents();
    }
    
    // تهيئة الخدمات
    async initServices() {
        // تهيئة خدمة API
        this.api = new APIService(this.network, this.cache, this.security);
        
        // تهيئة خدمة المصادقة
        this.auth = new AuthService(this.api, this.session);
        
        // تهيئة خدمة التحليلات
        this.analytics = new AnalyticsService(this.config.analytics);
    }
    
    // تهيئة مكونات Bootstrap
    initBootstrapComponents() {
        // تهيئة أدوات التلميحات
        const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        tooltips.forEach(tooltip => {
            new bootstrap.Tooltip(tooltip);
        });
        
        // تهيئة النوافذ المنبثقة
        const popovers = document.querySelectorAll('[data-bs-toggle="popover"]');
        popovers.forEach(popover => {
            new bootstrap.Popover(popover);
        });
        
        // تهيئة النماذج المحسنة
        this.initEnhancedForms();
    }
    
    // تهيئة مكونات AOS
    initAOSComponents() {
        if (typeof AOS !== 'undefined') {
            AOS.init({
                duration: 800,
                easing: 'ease-in-out',
                once: true,
                mirror: false,
                offset: 100,
                delay: 0,
                anchorPlacement: 'top-bottom'
            });
        }
    }
    
    // تهيئة مكونات Lottie
    initLottieComponents() {
        // يتم تحميل Lottie بشكل تلقائي من CDN
        // يمكن إضافة تهيئة إضافية هنا إذا لزم الأمر
    }
    
    // تهيئة النماذج المحسنة
    initEnhancedForms() {
        const forms = document.querySelectorAll('form[data-enhanced]');
        forms.forEach(form => {
            new EnhancedForm(form, {
                validation: true,
                autoSave: false,
                submitProtection: true
            });
        });
    }
    
    // تهيئة التحليلات
    initAnalytics() {
        if (this.config.analytics.enabled) {
            // تتبع أحداث الصفحة
            this.analytics.trackPageView();
            
            // تتبع أحداث المستخدم
            this.bindAnalyticsEvents();
        }
    }
    
    // ربط أحداث التحليلات
    bindAnalyticsEvents() {
        // تتبع النقرات على الأزرار
        document.addEventListener('click', (e) => {
            const button = e.target.closest('button, .btn');
            if (button) {
                this.analytics.trackEvent('button_click', {
                    text: button.textContent.trim(),
                    class: button.className
                });
            }
        });
        
        // تتبع إرسال النماذج
        document.addEventListener('submit', (e) => {
            const form = e.target;
            this.analytics.trackEvent('form_submit', {
                id: form.id,
                class: form.className,
                action: form.action
            });
        });
        
        // تتبع أخطاء JavaScript
        window.addEventListener('error', (e) => {
            this.analytics.trackEvent('javascript_error', {
                message: e.message,
                filename: e.filename,
                lineno: e.lineno,
                colno: e.colno
            });
        });
    }
    
    // ربط الأحداث العامة
    bindEvents() {
        // عند تحميل الصفحة
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                this.init();
            });
        } else {
            this.init();
        }
        
        // عند إغلاق الصفحة
        window.addEventListener('beforeunload', () => {
            this.cleanup();
        });
        
        // مراقبة حالة الاتصال
        window.addEventListener('online', () => {
            this.emit('network:online');
            this.notifications.show('تم استعادة الاتصال بالإنترنت', 'success');
        });
        
        window.addEventListener('offline', () => {
            this.emit('network:offline');
            this.notifications.show('انقطع الاتصال بالإنترنت', 'warning');
        });
    }
    
    // تسجيل وحدة
    registerModule(name, module) {
        this.modules.set(name, module);
        if (this.initialized) {
            module.init();
        }
    }
    
    // الحصول على وحدة
    getModule(name) {
        return this.modules.get(name);
    }
    
    // إرسال حدث
    emit(eventName, data = null) {
        const event = new CustomEvent(eventName, { detail: data });
        this.events.dispatchEvent(event);
        
        if (this.config.debug) {
            console.log('Event emitted:', eventName, data);
        }
    }
    
    // الاستماع لحدث
    on(eventName, callback) {
        this.events.addEventListener(eventName, callback);
    }
    
    // إزالة مستمع الحدث
    off(eventName, callback) {
        this.events.removeEventListener(eventName, callback);
    }
    
    // إظهار مؤشر التحميل العالمي
    showGlobalLoading() {
        document.body.classList.add('loading');
    }
    
    // إخفاء مؤشر التحميل العالمي
    hideGlobalLoading() {
        document.body.classList.remove('loading');
    }
    
    // تنظيف الموارد
    cleanup() {
        // تنظيف الوحدات
        this.modules.forEach(module => {
            if (module.cleanup) {
                module.cleanup();
            }
        });
        
        // حفظ البيانات المهمة
        this.session.save();
        
        // إرسال إحصائيات الجلسة
        if (this.analytics) {
            this.analytics.trackSessionEnd();
        }
    }
}

// مدير الكاش
class CacheManager {
    constructor(config) {
        this.config = config;
        this.cache = new Map();
        this.enabled = config.enabled;
    }
    
    set(key, value, expiry = this.config.expiry) {
        if (!this.enabled) return false;
        
        // تنظيف الكاش إذا تجاوز الحد الأقصى
        if (this.cache.size >= this.config.maxSize) {
            this.cleanup();
        }
        
        this.cache.set(key, {
            value,
            expiry: Date.now() + expiry,
            created: Date.now()
        });
        
        return true;
    }
    
    get(key) {
        if (!this.enabled) return null;
        
        const item = this.cache.get(key);
        if (!item) return null;
        
        // فحص انتهاء الصلاحية
        if (Date.now() > item.expiry) {
            this.cache.delete(key);
            return null;
        }
        
        return item.value;
    }
    
    delete(key) {
        return this.cache.delete(key);
    }
    
    clear() {
        this.cache.clear();
    }
    
    cleanup() {
        const now = Date.now();
        for (const [key, item] of this.cache) {
            if (now > item.expiry) {
                this.cache.delete(key);
            }
        }
        
        // إذا كان الكاش لا يزال ممتلئاً، احذف الأقدم
        if (this.cache.size >= this.config.maxSize) {
            const oldest = Array.from(this.cache.entries())
                .sort((a, b) => a[1].created - b[1].created)
                .slice(0, Math.floor(this.config.maxSize / 2));
            
            oldest.forEach(([key]) => this.cache.delete(key));
        }
    }
}

// مدير الشبكة
class NetworkManager {
    constructor(config) {
        this.config = config;
        this.isOnline = navigator.onLine;
        this.queue = [];
        
        this.bindEvents();
    }
    
    async request(url, options = {}) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), this.config.timeout);
        
        const finalOptions = {
            ...options,
            signal: controller.signal
        };
        
        try {
            const response = await this.executeWithRetry(url, finalOptions);
            clearTimeout(timeoutId);
            return response;
        } catch (error) {
            clearTimeout(timeoutId);
            
            if (!this.isOnline) {
                // إضافة إلى طابور الطلبات عند عدم وجود اتصال
                this.queue.push({ url, options });
            }
            
            throw error;
        }
    }
    
    async executeWithRetry(url, options, attempt = 0) {
        try {
            return await fetch(url, options);
        } catch (error) {
            if (attempt < this.config.retryAttempts) {
                await this.delay(this.config.retryDelay * Math.pow(2, attempt));
                return this.executeWithRetry(url, options, attempt + 1);
            }
            throw error;
        }
    }
    
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    
    bindEvents() {
        window.addEventListener('online', () => {
            this.isOnline = true;
            this.processQueue();
        });
        
        window.addEventListener('offline', () => {
            this.isOnline = false;
        });
    }
    
    async processQueue() {
        while (this.queue.length > 0) {
            const { url, options } = this.queue.shift();
            try {
                await this.request(url, options);
            } catch (error) {
                console.error('Failed to process queued request:', error);
            }
        }
    }
}

// مدير الأمان
class SecurityManager {
    constructor(config) {
        this.config = config;
        this.csrfToken = this.getCSRFToken();
        
        if (config.xssProtection) {
            this.initXSSProtection();
        }
    }
    
    getCSRFToken() {
        const meta = document.querySelector('meta[name="csrf-token"]');
        return meta ? meta.getAttribute('content') : null;
    }
    
    initXSSProtection() {
        // تطهير المدخلات
        document.addEventListener('input', (e) => {
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                e.target.value = this.sanitizeInput(e.target.value);
            }
        });
    }
    
    sanitizeInput(input) {
        // إزالة العلامات الخطيرة
        return input.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
                   .replace(/javascript:/gi, '')
                   .replace(/on\w+\s*=/gi, '');
    }
    
    validateRequest(options) {
        if (this.config.csrfEnabled && this.csrfToken) {
            options.headers = options.headers || {};
            options.headers['X-CSRF-TOKEN'] = this.csrfToken;
        }
        
        return options;
    }
}

// مدير الإشعارات
class NotificationManager {
    constructor() {
        this.container = this.createContainer();
        this.notifications = new Map();
    }
    
    createContainer() {
        let container = document.getElementById('notification-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'notification-container';
            container.className = 'notification-container position-fixed top-0 end-0 p-3';
            container.style.zIndex = '9999';
            document.body.appendChild(container);
        }
        return container;
    }
    
    show(message, type = 'info', duration = 5000, options = {}) {
        const id = this.generateId();
        const notification = this.createNotification(id, message, type, options);
        
        this.container.appendChild(notification);
        this.notifications.set(id, notification);
        
        // إظهار الإشعار
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        // إخفاء الإشعار تلقائياً
        if (duration > 0) {
            setTimeout(() => {
                this.hide(id);
            }, duration);
        }
        
        return id;
    }
    
    createNotification(id, message, type, options) {
        const notification = document.createElement('div');
        notification.id = `notification-${id}`;
        notification.className = `notification alert alert-${type} alert-dismissible fade`;
        notification.setAttribute('role', 'alert');
        
        const icons = {
            success: 'fas fa-check-circle',
            error: 'fas fa-times-circle',
            warning: 'fas fa-exclamation-triangle',
            info: 'fas fa-info-circle'
        };
        
        notification.innerHTML = `
            <div class="d-flex align-items-center">
                <i class="${icons[type]} me-2"></i>
                <span class="flex-grow-1">${message}</span>
                <button type="button" class="btn-close" onclick="app.notifications.hide('${id}')"></button>
            </div>
        `;
        
        return notification;
    }
    
    hide(id) {
        const notification = this.notifications.get(id);
        if (notification) {
            notification.classList.remove('show');
            notification.classList.add('hide');
            
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
                this.notifications.delete(id);
            }, 300);
        }
    }
    
    clear() {
        this.notifications.forEach((notification, id) => {
            this.hide(id);
        });
    }
    
    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }
}

// إنشاء مثيل التطبيق العالمي
window.app = new App();

// تصدير للاستخدام في الوحدات الأخرى
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { App, AppConfig };
}