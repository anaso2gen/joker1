/**
 * مشغل الفيديو المتقدم
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 10:36:31
 */

'use strict';

const VideoPlayer = {
    // إعدادات المشغل
    config: {
        progressSaveInterval: 5000, // 5 ثوانٍ
        skipInterval: 10, // 10 ثوانٍ للتقديم/التراجع
        volumeStep: 0.1, // خطوة تغيير الصوت
        playbackRates: [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2],
        qualities: ['480p', '720p', '1080p'],
        autoHideControlsDelay: 3000, // 3 ثوانٍ
        keyboardShortcuts: true,
        autosave: true
    },
    
    // حالة المشغل
    state: {
        isPlaying: false,
        currentTime: 0,
        duration: 0,
        volume: 1,
        muted: false,
        playbackRate: 1,
        currentQuality: '720p',
        fullscreen: false,
        controlsVisible: true,
        seeking: false,
        lessonId: null,
        courseId: null,
        progress: 0
    },
    
    // عناصر DOM
    elements: {
        container: null,
        video: null,
        playBtn: null,
        progressBar: null,
        progressFilled: null,
        timeDisplay: null,
        volumeBtn: null,
        volumeSlider: null,
        speedBtn: null,
        qualityBtn: null,
        fullscreenBtn: null,
        controls: null
    },
    
    // المؤقتات
    timers: {
        progress: null,
        controlsHide: null,
        autosave: null
    },
    
    // تهيئة المشغل
    init(videoElement, options = {}) {
        try {
            // دمج الإعدادات
            this.config = { ...this.config, ...options };
            
            // تهيئة العناصر
            this.initializeElements(videoElement);
            
            // تهيئة الأحداث
            this.initializeEvents();
            
            // تهيئة الواجهة
            this.initializeUI();
            
            // تهيئة اختصارات لوحة المفاتيح
            if (this.config.keyboardShortcuts) {
                this.initializeKeyboardShortcuts();
            }
            
            // تحميل آخر موضع تشغيل
            this.loadProgress();
            
            // بدء الحفظ التلقائي
            if (this.config.autosave) {
                this.startAutosave();
            }
            
            console.log('Video Player initialized successfully');
        } catch (error) {
            console.error('Video Player initialization failed:', error);
        }
    },
    
    // تهيئة العناصر
    initializeElements(videoElement) {
        this.elements.video = videoElement;
        this.elements.container = videoElement.closest('.video-player');
        
        if (!this.elements.container) {
            throw new Error('Video container not found');
        }
        
        // الحصول على معرفات الدرس والدورة
        this.state.lessonId = this.elements.container.dataset.lessonId;
        this.state.courseId = this.elements.container.dataset.courseId;
        
        // تهيئة عناصر التحكم
        this.elements.controls = this.elements.container.querySelector('.video-controls');
        this.elements.playBtn = this.elements.container.querySelector('.play-btn');
        this.elements.progressBar = this.elements.container.querySelector('.progress-bar');
        this.elements.progressFilled = this.elements.container.querySelector('.progress-filled');
        this.elements.timeDisplay = this.elements.container.querySelector('.time-info');
        this.elements.volumeBtn = this.elements.container.querySelector('.volume-btn');
        this.elements.volumeSlider = this.elements.container.querySelector('.volume-slider');
        this.elements.speedBtn = this.elements.container.querySelector('.speed-btn');
        this.elements.qualityBtn = this.elements.container.querySelector('.quality-btn');
        this.elements.fullscreenBtn = this.elements.container.querySelector('.fullscreen-btn');
        
        // إنشاء عناصر مفقودة
        this.createMissingElements();
    },
    
    // إنشاء عناصر مفقودة
    createMissingElements() {
        if (!this.elements.controls) {
            this.elements.controls = this.createControlsBar();
            this.elements.container.appendChild(this.elements.controls);
        }
    },
    
    // إنشاء شريط التحكم
    createControlsBar() {
        const controls = document.createElement('div');
        controls.className = 'video-controls';
        controls.innerHTML = `
            <div class="progress-container">
                <div class="progress-bar">
                    <div class="progress-buffered"></div>
                    <div class="progress-filled"></div>
                    <div class="progress-handle"></div>
                </div>
            </div>
            <div class="controls-bar">
                <button class="control-btn play-btn large">
                    <i class="fas fa-play"></i>
                </button>
                <div class="time-info">
                    <span class="current-time">0:00</span>
                    <span class="time-separator">/</span>
                    <span class="duration">0:00</span>
                </div>
                <div class="volume-control">
                    <button class="control-btn volume-btn">
                        <i class="fas fa-volume-up"></i>
                    </button>
                    <div class="volume-slider">
                        <div class="volume-filled"></div>
                    </div>
                </div>
                <div class="speed-control">
                    <button class="control-btn speed-btn">1x</button>
                    <div class="speed-menu">
                        ${this.config.playbackRates.map(rate => 
                            `<button class="speed-option" data-rate="${rate}">${rate}x</button>`
                        ).join('')}
                    </div>
                </div>
                <div class="quality-control">
                    <button class="control-btn quality-btn">HD</button>
                    <div class="quality-menu">
                        ${this.config.qualities.map(quality => 
                            `<button class="quality-option" data-quality="${quality}">${quality}</button>`
                        ).join('')}
                    </div>
                </div>
                <div class="fullscreen-controls">
                    <button class="control-btn fullscreen-btn">
                        <i class="fas fa-expand"></i>
                    </button>
                </div>
            </div>
        `;
        
        // تحديث المراجع
        this.elements.playBtn = controls.querySelector('.play-btn');
        this.elements.progressBar = controls.querySelector('.progress-bar');
        this.elements.progressFilled = controls.querySelector('.progress-filled');
        this.elements.timeDisplay = controls.querySelector('.time-info');
        this.elements.volumeBtn = controls.querySelector('.volume-btn');
        this.elements.volumeSlider = controls.querySelector('.volume-slider');
        this.elements.speedBtn = controls.querySelector('.speed-btn');
        this.elements.qualityBtn = controls.querySelector('.quality-btn');
        this.elements.fullscreenBtn = controls.querySelector('.fullscreen-btn');
        
        return controls;
    },
    
    // تهيئة الأحداث
    initializeEvents() {
        // أحداث الفيديو
        this.elements.video.addEventListener('loadedmetadata', () => {
            this.state.duration = this.elements.video.duration;
            this.updateTimeDisplay();
        });
        
        this.elements.video.addEventListener('timeupdate', () => {
            if (!this.state.seeking) {
                this.state.currentTime = this.elements.video.currentTime;
                this.updateProgress();
                this.updateTimeDisplay();
            }
        });
        
        this.elements.video.addEventListener('play', () => {
            this.state.isPlaying = true;
            this.updatePlayButton();
        });
        
        this.elements.video.addEventListener('pause', () => {
            this.state.isPlaying = false;
            this.updatePlayButton();
        });
        
        this.elements.video.addEventListener('ended', () => {
            this.onVideoEnded();
        });
        
        this.elements.video.addEventListener('error', (e) => {
            this.handleVideoError(e);
        });
        
        // أحداث عناصر التحكم
        this.initializeControlEvents();
        
        // أحداث الماوس
        this.initializeMouseEvents();
        
        // أحداث اللمس
        this.initializeTouchEvents();
    },
    
    // تهيئة أحداث التحكم
    initializeControlEvents() {
        // زر التشغيل/الإيقاف
        this.elements.playBtn.addEventListener('click', () => {
            this.togglePlay();
        });
        
        // شريط التقدم
        this.elements.progressBar.addEventListener('click', (e) => {
            this.seek(e);
        });
        
        this.elements.progressBar.addEventListener('mousedown', (e) => {
            this.startSeeking(e);
        });
        
        // التحكم في الصوت
        this.elements.volumeBtn.addEventListener('click', () => {
            this.toggleMute();
        });
        
        this.elements.volumeSlider.addEventListener('click', (e) => {
            this.setVolume(e);
        });
        
        // السرعة
        this.elements.speedBtn.addEventListener('click', () => {
            this.toggleSpeedMenu();
        });
        
        document.querySelectorAll('.speed-option').forEach(option => {
            option.addEventListener('click', () => {
                this.setPlaybackRate(parseFloat(option.dataset.rate));
            });
        });
        
        // الجودة
        this.elements.qualityBtn.addEventListener('click', () => {
            this.toggleQualityMenu();
        });
        
        document.querySelectorAll('.quality-option').forEach(option => {
            option.addEventListener('click', () => {
                this.setQuality(option.dataset.quality);
            });
        });
        
        // ملء الشاشة
        this.elements.fullscreenBtn.addEventListener('click', () => {
            this.toggleFullscreen();
        });
    },
    
    // تهيئة أحداث الماوس
    initializeMouseEvents() {
        let mouseMoveTimer;
        
        this.elements.container.addEventListener('mousemove', () => {
            this.showControls();
            
            clearTimeout(mouseMoveTimer);
            mouseMoveTimer = setTimeout(() => {
                if (this.state.isPlaying) {
                    this.hideControls();
                }
            }, this.config.autoHideControlsDelay);
        });
        
        this.elements.container.addEventListener('mouseleave', () => {
            if (this.state.isPlaying) {
                this.hideControls();
            }
        });
        
        // النقر المزدوج للملء الشاشة
        this.elements.video.addEventListener('dblclick', () => {
            this.toggleFullscreen();
        });
    },
    
    // تهيئة أحداث اللمس
    initializeTouchEvents() {
        let touchStartTime = 0;
        let touchStartX = 0;
        let touchStartY = 0;
        
        this.elements.video.addEventListener('touchstart', (e) => {
            touchStartTime = Date.now();
            touchStartX = e.touches[0].clientX;
            touchStartY = e.touches[0].clientY;
        });
        
        this.elements.video.addEventListener('touchend', (e) => {
            const touchEndTime = Date.now();
            const touchDuration = touchEndTime - touchStartTime;
            const touchEndX = e.changedTouches[0].clientX;
            const touchEndY = e.changedTouches[0].clientY;
            
            const deltaX = Math.abs(touchEndX - touchStartX);
            const deltaY = Math.abs(touchEndY - touchStartY);
            
            // النقر (ليس سحب)
            if (touchDuration < 500 && deltaX < 10 && deltaY < 10) {
                this.togglePlay();
            }
        });
        
        // السحب الأفقي للتقديم/التراجع
        let isSwiping = false;
        
        this.elements.video.addEventListener('touchmove', (e) => {
            if (!isSwiping) return;
            
            const deltaX = e.touches[0].clientX - touchStartX;
            const skipAmount = (deltaX / this.elements.video.offsetWidth) * 60; // حتى 60 ثانية
            
            // عرض معاينة
            this.showSeekPreview(skipAmount);
        });
    },
    
    // تهيئة اختصارات لوحة المفاتيح
    initializeKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // تجاهل إذا كان التركيز على input
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                return;
            }
            
            switch (e.code) {
                case 'Space':
                    e.preventDefault();
                    this.togglePlay();
                    break;
                    
                case 'ArrowLeft':
                    e.preventDefault();
                    this.skipBackward();
                    break;
                    
                case 'ArrowRight':
                    e.preventDefault();
                    this.skipForward();
                    break;
                    
                case 'ArrowUp':
                    e.preventDefault();
                    this.increaseVolume();
                    break;
                    
                case 'ArrowDown':
                    e.preventDefault();
                    this.decreaseVolume();
                    break;
                    
                case 'KeyM':
                    this.toggleMute();
                    break;
                    
                case 'KeyF':
                    this.toggleFullscreen();
                    break;
                    
                case 'Escape':
                    if (this.state.fullscreen) {
                        this.exitFullscreen();
                    }
                    break;
                    
                // أرقام للسرعة
                case 'Digit1':
                    this.setPlaybackRate(1);
                    break;
                case 'Digit2':
                    this.setPlaybackRate(1.5);
                    break;
                case 'Digit3':
                    this.setPlaybackRate(2);
                    break;
            }
        });
    },
    
    // تهيئة الواجهة
    initializeUI() {
        this.updatePlayButton();
        this.updateVolumeButton();
        this.updateSpeedButton();
        this.updateQualityButton();
        this.updateFullscreenButton();
    },
    
    // التشغيل/الإيقاف
    togglePlay() {
        if (this.state.isPlaying) {
            this.pause();
        } else {
            this.play();
        }
    },
    
    // تشغيل
    async play() {
        try {
            await this.elements.video.play();
            this.startProgressTracking();
        } catch (error) {
            console.error('Play failed:', error);
            this.showError('فشل في تشغيل الفيديو');
        }
    },
    
    // إيقاف مؤقت
    pause() {
        this.elements.video.pause();
        this.stopProgressTracking();
    },
    
    // الانتقال لموضع معين
    seek(e) {
        const rect = this.elements.progressBar.getBoundingClientRect();
        const clickX = e.clientX - rect.left;
        const percentage = clickX / rect.width;
        const seekTime = percentage * this.state.duration;
        
        this.elements.video.currentTime = seekTime;
        this.state.currentTime = seekTime;
        this.updateProgress();
    },
    
    // بدء البحث
    startSeeking(e) {
        this.state.seeking = true;
        
        const mouseMoveHandler = (e) => {
            this.seek(e);
        };
        
        const mouseUpHandler = () => {
            this.state.seeking = false;
            document.removeEventListener('mousemove', mouseMoveHandler);
            document.removeEventListener('mouseup', mouseUpHandler);
        };
        
        document.addEventListener('mousemove', mouseMoveHandler);
        document.addEventListener('mouseup', mouseUpHandler);
    },
    
    // التقديم للأمام
    skipForward() {
        const newTime = Math.min(
            this.state.currentTime + this.config.skipInterval,
            this.state.duration
        );
        this.elements.video.currentTime = newTime;
        this.showSkipIndicator(`+${this.config.skipInterval}s`);
    },
    
    // التراجع للخلف
    skipBackward() {
        const newTime = Math.max(
            this.state.currentTime - this.config.skipInterval,
            0
        );
        this.elements.video.currentTime = newTime;
        this.showSkipIndicator(`-${this.config.skipInterval}s`);
    },
    
    // عرض مؤشر التقديم/التراجع
    showSkipIndicator(text) {
        const indicator = document.createElement('div');
        indicator.className = 'skip-indicator';
        indicator.textContent = text;
        
        this.elements.container.appendChild(indicator);
        
        setTimeout(() => {
            indicator.classList.add('show');
        }, 10);
        
        setTimeout(() => {
            indicator.remove();
        }, 1000);
    },
    
    // كتم/إلغاء كتم الصوت
    toggleMute() {
        if (this.state.muted) {
            this.unmute();
        } else {
            this.mute();
        }
    },
    
    // كتم الصوت
    mute() {
        this.elements.video.muted = true;
        this.state.muted = true;
        this.updateVolumeButton();
    },
    
    // إلغاء كتم الصوت
    unmute() {
        this.elements.video.muted = false;
        this.state.muted = false;
        this.updateVolumeButton();
    },
    
    // تعيين مستوى الصوت
    setVolume(e) {
        const rect = this.elements.volumeSlider.getBoundingClientRect();
        const clickX = e.clientX - rect.left;
        const volume = Math.max(0, Math.min(1, clickX / rect.width));
        
        this.elements.video.volume = volume;
        this.state.volume = volume;
        this.updateVolumeSlider();
        
        if (volume === 0) {
            this.mute();
        } else if (this.state.muted) {
            this.unmute();
        }
    },
    
    // زيادة الصوت
    increaseVolume() {
        const newVolume = Math.min(1, this.state.volume + this.config.volumeStep);
        this.elements.video.volume = newVolume;
        this.state.volume = newVolume;
        this.updateVolumeSlider();
        this.showVolumeIndicator(Math.round(newVolume * 100));
    },
    
    // تقليل الصوت
    decreaseVolume() {
        const newVolume = Math.max(0, this.state.volume - this.config.volumeStep);
        this.elements.video.volume = newVolume;
        this.state.volume = newVolume;
        this.updateVolumeSlider();
        this.showVolumeIndicator(Math.round(newVolume * 100));
    },
    
    // عرض مؤشر الصوت
    showVolumeIndicator(volume) {
        let indicator = this.elements.container.querySelector('.volume-indicator');
        
        if (!indicator) {
            indicator = document.createElement('div');
            indicator.className = 'volume-indicator';
            this.elements.container.appendChild(indicator);
        }
        
        indicator.innerHTML = `
            <i class="fas fa-volume-up"></i>
            <span>${volume}%</span>
        `;
        
        indicator.classList.add('show');
        
        clearTimeout(indicator.hideTimer);
        indicator.hideTimer = setTimeout(() => {
            indicator.classList.remove('show');
        }, 1000);
    },
    
    // تبديل قائمة السرعة
    toggleSpeedMenu() {
        const menu = this.elements.container.querySelector('.speed-menu');
        menu.classList.toggle('show');
        
        // إغلاق القوائم الأخرى
        this.elements.container.querySelector('.quality-menu').classList.remove('show');
    },
    
    // تعيين سرعة التشغيل
    setPlaybackRate(rate) {
        this.elements.video.playbackRate = rate;
        this.state.playbackRate = rate;
        this.updateSpeedButton();
        
        // إغلاق القائمة
        this.elements.container.querySelector('.speed-menu').classList.remove('show');
    },
    
    // تبديل قائمة الجودة
    toggleQualityMenu() {
        const menu = this.elements.container.querySelector('.quality-menu');
        menu.classList.toggle('show');
        
        // إغلاق القوائم الأخرى
        this.elements.container.querySelector('.speed-menu').classList.remove('show');
    },
    
    // تعيين الجودة
    setQuality(quality) {
        // حفظ الموضع الحالي
        const currentTime = this.elements.video.currentTime;
        const wasPlaying = !this.elements.video.paused;
        
        // تغيير مصدر الفيديو (يجب تنفيذه حسب نظام VdoCipher)
        this.changeVideoSource(quality).then(() => {
            // استعادة الموضع
            this.elements.video.currentTime = currentTime;
            
            if (wasPlaying) {
                this.elements.video.play();
            }
            
            this.state.currentQuality = quality;
            this.updateQualityButton();
        });
        
        // إغلاق القائمة
        this.elements.container.querySelector('.quality-menu').classList.remove('show');
    },
    
    // تغيير مصدر الفيديو
    async changeVideoSource(quality) {
        // هذه الدالة يجب أن تتكامل مع VdoCipher API
        try {
            const response = await fetch('/api.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'get_video_url',
                    lesson_id: this.state.lessonId,
                    quality: quality
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.elements.video.src = result.data.url;
                return Promise.resolve();
            } else {
                throw new Error(result.message);
            }
        } catch (error) {
            console.error('Failed to change video quality:', error);
            this.showError('فشل في تغيير جودة الفيديو');
            return Promise.reject(error);
        }
    },
    
    // ملء الشاشة
    toggleFullscreen() {
        if (this.state.fullscreen) {
            this.exitFullscreen();
        } else {
            this.enterFullscreen();
        }
    },
    
    // دخول ملء الشاشة
    enterFullscreen() {
        const element = this.elements.container;
        
        if (element.requestFullscreen) {
            element.requestFullscreen();
        } else if (element.webkitRequestFullscreen) {
            element.webkitRequestFullscreen();
        } else if (element.mozRequestFullScreen) {
            element.mozRequestFullScreen();
        } else if (element.msRequestFullscreen) {
            element.msRequestFullscreen();
        }
        
        this.state.fullscreen = true;
        this.updateFullscreenButton();
        this.elements.container.classList.add('fullscreen-mode');
    },
    
    // الخروج من ملء الشاشة
    exitFullscreen() {
        if (document.exitFullscreen) {
            document.exitFullscreen();
        } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        }
        
        this.state.fullscreen = false;
        this.updateFullscreenButton();
        this.elements.container.classList.remove('fullscreen-mode');
    },
    
    // إظهار عناصر التحكم
    showControls() {
        this.elements.controls.classList.add('show');
        this.state.controlsVisible = true;
        
        clearTimeout(this.timers.controlsHide);
    },
    
    // إخفاء عناصر التحكم
    hideControls() {
        if (!this.state.isPlaying) return;
        
        this.elements.controls.classList.remove('show');
        this.state.controlsVisible = false;
    },
    
    // تحديث زر التشغيل
    updatePlayButton() {
        const icon = this.elements.playBtn.querySelector('i');
        if (this.state.isPlaying) {
            icon.className = 'fas fa-pause';
            this.elements.playBtn.setAttribute('title', 'إيقاف مؤقت');
        } else {
            icon.className = 'fas fa-play';
            this.elements.playBtn.setAttribute('title', 'تشغيل');
        }
    },
    
    // تحديث شريط التقدم
    updateProgress() {
        if (this.state.duration === 0) return;
        
        const percentage = (this.state.currentTime / this.state.duration) * 100;
        this.elements.progressFilled.style.width = `${percentage}%`;
        
        // حساب التقدم للحفظ
        this.state.progress = Math.round(percentage);
    },
    
    // تحديث عرض الوقت
    updateTimeDisplay() {
        const currentTimeEl = this.elements.timeDisplay.querySelector('.current-time');
        const durationEl = this.elements.timeDisplay.querySelector('.duration');
        
        if (currentTimeEl) {
            currentTimeEl.textContent = this.formatTime(this.state.currentTime);
        }
        
        if (durationEl) {
            durationEl.textContent = this.formatTime(this.state.duration);
        }
    },
    
    // تحديث زر الصوت
    updateVolumeButton() {
        const icon = this.elements.volumeBtn.querySelector('i');
        
        if (this.state.muted || this.state.volume === 0) {
            icon.className = 'fas fa-volume-mute';
        } else if (this.state.volume < 0.5) {
            icon.className = 'fas fa-volume-down';
        } else {
            icon.className = 'fas fa-volume-up';
        }
    },
    
    // تحديث شريط الصوت
    updateVolumeSlider() {
        const volumeFilled = this.elements.volumeSlider.querySelector('.volume-filled');
        if (volumeFilled) {
            volumeFilled.style.width = `${this.state.volume * 100}%`;
        }
    },
    
    // تحديث زر السرعة
    updateSpeedButton() {
        this.elements.speedBtn.textContent = `${this.state.playbackRate}x`;
        
        // تحديث الخيارات النشطة
        document.querySelectorAll('.speed-option').forEach(option => {
            option.classList.toggle('active', 
                parseFloat(option.dataset.rate) === this.state.playbackRate);
        });
    },
    
    // تحديث زر الجودة
    updateQualityButton() {
        this.elements.qualityBtn.textContent = this.state.currentQuality;
        
        // تحديث الخيارات النشطة
        document.querySelectorAll('.quality-option').forEach(option => {
            option.classList.toggle('active', 
                option.dataset.quality === this.state.currentQuality);
        });
    },
    
    // تحديث زر ملء الشاشة
    updateFullscreenButton() {
        const icon = this.elements.fullscreenBtn.querySelector('i');
        
        if (this.state.fullscreen) {
            icon.className = 'fas fa-compress';
            this.elements.fullscreenBtn.setAttribute('title', 'الخروج من ملء الشاشة');
        } else {
            icon.className = 'fas fa-expand';
            this.elements.fullscreenBtn.setAttribute('title', 'ملء الشاشة');
        }
    },
    
    // بدء تتبع التقدم
    startProgressTracking() {
        this.timers.progress = setInterval(() => {
            this.trackProgress();
        }, this.config.progressSaveInterval);
    },
    
    // إيقاف تتبع التقدم
    stopProgressTracking() {
        if (this.timers.progress) {
            clearInterval(this.timers.progress);
        }
    },
    
    // تتبع التقدم
    async trackProgress() {
        if (!this.state.lessonId) return;
        
        try {
            const response = await fetch('/api.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'update_progress',
                    lesson_id: this.state.lessonId,
                    progress: this.state.progress,
                    watch_time: Math.round(this.state.currentTime)
                })
            });
            
            const result = await response.json();
            
            if (!result.success) {
                console.error('Failed to save progress:', result.message);
            }
        } catch (error) {
            console.error('Progress tracking error:', error);
        }
    },
    
    // تحميل آخر موضع
    async loadProgress() {
        if (!this.state.lessonId) return;
        
        try {
            const response = await fetch('/api.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'get_lesson_progress',
                    lesson_id: this.state.lessonId
                })
            });
            
            const result = await response.json();
            
            if (result.success && result.data.watch_time > 0) {
                // عرض خيار المتابعة من آخر موضع
                this.showResumeOption(result.data.watch_time);
            }
        } catch (error) {
            console.error('Failed to load progress:', error);
        }
    },
    
    // عرض خيار المتابعة
    showResumeOption(watchTime) {
        const resumeModal = document.createElement('div');
        resumeModal.className = 'resume-modal';
        resumeModal.innerHTML = `
            <div class="modal-content">
                <h3>متابعة المشاهدة</h3>
                <p>هل تريد المتابعة من حيث توقفت؟</p>
                <p class="resume-time">آخر موضع: ${this.formatTime(watchTime)}</p>
                <div class="modal-actions">
                    <button class="btn btn-secondary" data-action="start">البداية</button>
                    <button class="btn btn-primary" data-action="resume">متابعة</button>
                </div>
            </div>
        `;
        
        this.elements.container.appendChild(resumeModal);
        
        resumeModal.addEventListener('click', (e) => {
            const action = e.target.dataset.action;
            
            if (action === 'resume') {
                this.elements.video.currentTime = watchTime;
            }
            
            resumeModal.remove();
        });
    },
    
    // بدء الحفظ التلقائي
    startAutosave() {
        this.timers.autosave = setInterval(() => {
            this.trackProgress();
        }, this.config.progressSaveInterval);
    },
    
    // عند انتهاء الفيديو
    async onVideoEnded() {
        this.state.isPlaying = false;
        this.updatePlayButton();
        
        // تسجيل إكمال الدرس
        await this.markLessonComplete();
        
        // الانتقال للدرس التالي
        this.showNextLessonOption();
    },
    
    // تسجيل إكمال الدرس
    async markLessonComplete() {
        if (!this.state.lessonId) return;
        
        try {
            const response = await fetch('/api.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'complete_lesson',
                    lesson_id: this.state.lessonId
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.showSuccessMessage('تم إكمال الدرس!');
            }
        } catch (error) {
            console.error('Failed to mark lesson complete:', error);
        }
    },
    
    // عرض خيار الدرس التالي
    showNextLessonOption() {
        const nextModal = document.createElement('div');
        nextModal.className = 'next-lesson-modal';
        nextModal.innerHTML = `
            <div class="modal-content">
                <div class="success-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h3>أحسنت!</h3>
                <p>لقد أكملت هذا الدرس بنجاح</p>
                <div class="modal-actions">
                    <button class="btn btn-secondary" data-action="replay">إعادة التشغيل</button>
                    <button class="btn btn-primary" data-action="next">الدرس التالي</button>
                </div>
            </div>
        `;
        
        this.elements.container.appendChild(nextModal);
        
        nextModal.addEventListener('click', (e) => {
            const action = e.target.dataset.action;
            
            if (action === 'replay') {
                this.elements.video.currentTime = 0;
                this.play();
            } else if (action === 'next') {
                this.goToNextLesson();
            }
            
            nextModal.remove();
        });
    },
    
    // الانتقال للدرس التالي
    async goToNextLesson() {
        try {
            const response = await fetch('/api.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'get_next_lesson',
                    lesson_id: this.state.lessonId,
                    course_id: this.state.courseId
                })
            });
            
            const result = await response.json();
            
            if (result.success && result.data.next_lesson) {
                window.location.href = `/player.php?lesson=${result.data.next_lesson.id}`;
            } else {
                this.showSuccessMessage('تهانينا! لقد أكملت جميع دروس الدورة');
            }
        } catch (error) {
            console.error('Failed to get next lesson:', error);
        }
    },
    
    // معالجة أخطاء الفيديو
    handleVideoError(e) {
        const error = e.target.error;
        let message = 'حدث خطأ في تشغيل الفيديو';
        
        switch (error.code) {
            case MediaError.MEDIA_ERR_NETWORK:
                message = 'خطأ في الشبكة. تحقق من اتصال الإنترنت';
                break;
            case MediaError.MEDIA_ERR_DECODE:
                message = 'خطأ في فك تشفير الفيديو';
                break;
            case MediaError.MEDIA_ERR_SRC_NOT_SUPPORTED:
                message = 'تنسيق الفيديو غير مدعوم';
                break;
        }
        
        this.showError(message);
    },
    
    // عرض رسالة خطأ
    showError(message) {
        const errorOverlay = document.createElement('div');
        errorOverlay.className = 'player-overlay error-overlay show';
        errorOverlay.innerHTML = `
            <div class="overlay-content">
                <i class="overlay-icon error-icon fas fa-exclamation-circle"></i>
                <div class="overlay-text">${message}</div>
                <button class="retry-btn" onclick="location.reload()">إعادة المحاولة</button>
            </div>
        `;
        
        this.elements.container.appendChild(errorOverlay);
    },
    
    // عرض رسالة نجاح
    showSuccessMessage(message) {
        const notification = document.createElement('div');
        notification.className = 'player-notification success';
        notification.innerHTML = `
            <i class="fas fa-check-circle"></i>
            <span>${message}</span>
        `;
        
        this.elements.container.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    },
    
    // تنسيق الوقت
    formatTime(seconds) {
        if (isNaN(seconds) || seconds < 0) return '0:00';
        
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = Math.floor(seconds % 60);
        
        if (hours > 0) {
            return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        }
        
        return `${minutes}:${secs.toString().padStart(2, '0')}`;
    },
    
    // تدمير المشغل
    destroy() {
        // إيقاف جميع المؤقتات
        Object.values(this.timers).forEach(timer => {
            if (timer) clearInterval(timer);
        });
        
        // إزالة مستمعي الأحداث
        // (يجب إضافة removeEventListener لكل addEventListener)
        
        // إعادة تعيين الحالة
        this.state = {
            isPlaying: false,
            currentTime: 0,
            duration: 0,
            volume: 1,
            muted: false,
            playbackRate: 1,
            currentQuality: '720p',
            fullscreen: false,
            controlsVisible: true,
            seeking: false,
            lessonId: null,
            courseId: null,
            progress: 0
        };
    }
};

// CSS للمشغل
const playerStyle = document.createElement('style');
playerStyle.textContent = `
    .skip-indicator {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: rgba(0, 0, 0, 0.8);
        color: white;
        padding: 10px 20px;
        border-radius: 25px;
        font-weight: bold;
        opacity: 0;
        transition: opacity 0.3s ease;
        z-index: 10;
    }
    
    .skip-indicator.show {
        opacity: 1;
    }
    
    .volume-indicator {
        position: absolute;
        top: 50%;
        right: 20px;
        transform: translateY(-50%);
        background: rgba(0, 0, 0, 0.8);
        color: white;
        padding: 10px 15px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 8px;
        opacity: 0;
        transition: opacity 0.3s ease;
        z-index: 10;
    }
    
    .volume-indicator.show {
        opacity: 1;
    }
    
    .resume-modal,
    .next-lesson-modal {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 20;
    }
    
    .resume-modal .modal-content,
    .next-lesson-modal .modal-content {
        background: white;
        padding: 30px;
        border-radius: 12px;
        text-align: center;
        max-width: 400px;
        width: 90%;
    }
    
    .success-icon {
        color: #48bb78;
        font-size: 3rem;
        margin-bottom: 20px;
    }
    
    .resume-time {
        font-weight: bold;
        color: #667eea;
        margin: 15px 0;
    }
    
    .modal-actions {
        display: flex;
        gap: 10px;
        justify-content: center;
        margin-top: 20px;
    }
    
    .player-notification {
        position: absolute;
        top: 20px;
        right: 20px;
        background: rgba(72, 187, 120, 0.9);
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 8px;
        opacity: 0;
        transform: translateX(100%);
        transition: all 0.3s ease;
        z-index: 15;
    }
    
    .player-notification.show {
        opacity: 1;
        transform: translateX(0);
    }
`;

document.head.appendChild(playerStyle);

// تهيئة المشغل عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    const videoElement = document.querySelector('.video-element');
    if (videoElement) {
        VideoPlayer.init(videoElement);
    }
});

// تصدير للاستخدام العام
window.VideoPlayer = VideoPlayer;