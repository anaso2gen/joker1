-- إنشاء قاعدة البيانات
CREATE DATABASE IF NOT EXISTS learning_platform CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE learning_platform;

-- جدول المستخدمين
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    user_id VARCHAR(36) UNIQUE NOT NULL,
    full_name VARCHAR(255),
    avatar_url VARCHAR(500),
    is_admin TINYINT(1) DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول الجلسات
CREATE TABLE sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_session_token (session_token),
    INDEX idx_user_id (user_id)
);

-- جدول الكورسات
CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    image_url VARCHAR(500),
    thumbnail_url VARCHAR(500),
    price DECIMAL(10,2) DEFAULT 0.00,
    is_active TINYINT(1) DEFAULT 1,
    sort_order INT DEFAULT 0,
    total_duration INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_code (code),
    INDEX idx_active (is_active)
);

-- جدول الأقسام
CREATE TABLE sections (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    order_index INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    INDEX idx_course_order (course_id, order_index)
);

-- جدول الدروس
CREATE TABLE lessons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    section_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    vdocipher_video_id VARCHAR(255) NOT NULL,
    order_index INT DEFAULT 0,
    duration INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    is_preview TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (section_id) REFERENCES sections(id) ON DELETE CASCADE,
    INDEX idx_section_order (section_id, order_index),
    INDEX idx_vdocipher (vdocipher_video_id)
);

-- جدول الاشتراكات
CREATE TABLE subscriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    course_id INT NOT NULL,
    status ENUM('active', 'expired', 'cancelled') DEFAULT 'active',
    expires_at TIMESTAMP NULL,
    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    UNIQUE KEY unique_subscription (user_id, course_id),
    INDEX idx_user_course (user_id, course_id),
    INDEX idx_status (status)
);

-- جدول الأكواد
CREATE TABLE codes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    course_id INT NOT NULL,
    is_active TINYINT(1) DEFAULT 1,
    uses_count INT DEFAULT 0,
    max_uses INT DEFAULT 0,
    expires_at TIMESTAMP NULL,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_code_active (code, is_active),
    INDEX idx_course_id (course_id)
);

-- جدول تقدم الطلاب
CREATE TABLE lesson_progress (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    lesson_id INT NOT NULL,
    completed TINYINT(1) DEFAULT 0,
    watch_time INT DEFAULT 0,
    last_position INT DEFAULT 0,
    completed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE,
    UNIQUE KEY unique_progress (user_id, lesson_id),
    INDEX idx_user_lesson (user_id, lesson_id)
);

-- جدول الإعدادات العامة
CREATE TABLE settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    setting_type ENUM('string', 'number', 'boolean', 'json') DEFAULT 'string',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- إدراج مستخدم مسؤول افتراضي
INSERT INTO users (email, password, user_id, full_name, is_admin) VALUES 
('admin@learning.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', UUID(), 'مدير النظام', 1);

-- إدراج إعدادات افتراضية
INSERT INTO settings (setting_key, setting_value, setting_type, description) VALUES
('site_name', 'منصة التعلم الإلكتروني', 'string', 'اسم الموقع'),
('site_description', 'منصة تعليمية متكاملة للدورات الرقمية', 'string', 'وصف الموقع'),
('vdocipher_api_secret', '', 'string', 'مفتاح VdoCipher API'),
('session_timeout', '86400', 'number', 'مدة انتهاء الجلسة بالثواني'),
('max_login_attempts', '5', 'number', 'عدد محاولات الدخول المسموح'),
('maintenance_mode', '0', 'boolean', 'وضع الصيانة');

-- إدراج بيانات تجريبية للكورسات
INSERT INTO courses (name, code, description, is_active) VALUES 
('البرمجة الأساسية', 'PROG2024', 'تعلم أساسيات البرمجة من الصفر', 1),
('تطوير المواقع الحديثة', 'WEB2024', 'تعلم تطوير المواقع بأحدث التقنيات', 1),
('الذكاء الاصطناعي للمبتدئين', 'AI2024', 'مقدمة شاملة في الذكاء الاصطناعي', 1);

-- إدراج أقسام تجريبية
INSERT INTO sections (course_id, name, order_index) VALUES 
(1, 'مقدمة في البرمجة', 1),
(1, 'المتغيرات والدوال', 2),
(1, 'الهياكل الشرطية', 3),
(2, 'HTML الأساسي', 1),
(2, 'CSS والتصميم', 2),
(2, 'JavaScript التفاعلي', 3),
(3, 'مفاهيم الذكاء الاصطناعي', 1),
(3, 'التعلم الآلي', 2);

-- إدراج دروس تجريبية
INSERT INTO lessons (section_id, title, vdocipher_video_id, order_index, duration, is_preview) VALUES 
(1, 'ما هي البرمجة؟', 'sample_video_1', 1, 1200, 1),
(1, 'إعداد بيئة العمل', 'sample_video_2', 2, 1800, 0),
(1, 'كتابة أول برنامج', 'sample_video_3', 3, 2400, 0),
(2, 'تعريف المتغيرات', 'sample_video_4', 1, 1500, 0),
(2, 'الدوال والإجراءات', 'sample_video_5', 2, 2100, 0),
(4, 'بنية HTML الأساسية', 'sample_video_6', 1, 1800, 1),
(4, 'العناصر والخصائص', 'sample_video_7', 2, 2200, 0),
(5, 'مقدمة في CSS', 'sample_video_8', 1, 1600, 0),
(5, 'التخطيط والتصميم', 'sample_video_9', 2, 2800, 0);

-- إدراج أكواد اشتراك تجريبية
INSERT INTO codes (code, course_id, is_active, max_uses) VALUES 
('PROG2024FREE', 1, 1, 100),
('WEB2024STUDENT', 2, 1, 50),
('AI2024BETA', 3, 1, 25);