-- إضافة جداول نظام أكواد التفعيل
-- تاريخ الإنشاء: 2025-05-29

-- جدول أكواد التفعيل
CREATE TABLE `activation_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL UNIQUE,
  `code_type` enum('single_course','all_courses','course_bundle') DEFAULT 'single_course',
  `course_ids` text NULL COMMENT 'JSON array of course IDs',
  `max_uses` int(11) DEFAULT 1 COMMENT 'عدد مرات الاستخدام المسموح',
  `used_count` int(11) DEFAULT 0 COMMENT 'عدد مرات الاستخدام الفعلي',
  `expires_at` datetime NULL COMMENT 'تاريخ انتهاء الصلاحية',
  `duration_days` int(11) DEFAULT 365 COMMENT 'مدة الاشتراك بالأيام',
  `created_by` int(11) NOT NULL COMMENT 'المسؤول الذي أنشأ الكود',
  `notes` text NULL COMMENT 'ملاحظات حول الكود',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_code_active` (`code`, `is_active`),
  KEY `idx_expires_at` (`expires_at`),
  KEY `idx_created_by` (`created_by`),
  FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول سجل استخدام الأكواد
CREATE TABLE `code_usage_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `used_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `ip_address` varchar(45) NULL,
  `user_agent` text NULL,
  `status` enum('success','failed','expired','already_used','invalid') DEFAULT 'success',
  `notes` text NULL,
  PRIMARY KEY (`id`),
  KEY `idx_code_id` (`code_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_used_at` (`used_at`),
  KEY `idx_status` (`status`),
  FOREIGN KEY (`code_id`) REFERENCES `activation_codes` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول اشتراكات المستخدمين (تحديث)
CREATE TABLE IF NOT EXISTS `user_subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `course_id` int(11) NULL COMMENT 'NULL means all courses access',
  `activation_code_id` int(11) NULL COMMENT 'الكود المستخدم للتفعيل',
  `subscription_type` enum('free','code_activated','paid') DEFAULT 'code_activated',
  `starts_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `expires_at` datetime NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_course` (`user_id`, `course_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_course_id` (`course_id`),
  KEY `idx_expires_at` (`expires_at`),
  KEY `idx_is_active` (`is_active`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`activation_code_id`) REFERENCES `activation_codes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إضافة فهارس لتحسين الأداء
CREATE INDEX idx_activation_codes_search ON activation_codes(code, is_active, expires_at);
CREATE INDEX idx_user_subscriptions_active ON user_subscriptions(user_id, is_active, expires_at);
CREATE INDEX idx_code_usage_search ON code_usage_log(code_id, user_id, status);

-- إدراج بيانات تجريبية
INSERT INTO `activation_codes` (`code`, `code_type`, `course_ids`, `max_uses`, `expires_at`, `duration_days`, `created_by`, `notes`) VALUES
('WELCOME2025', 'all_courses', NULL, 100, '2025-12-31 23:59:59', 365, 1, 'كود ترحيبي للعام الجديد'),
('COURSE123', 'single_course', '[1]', 50, '2025-06-30 23:59:59', 180, 1, 'كود خاص بالدورة الأولى'),
('BUNDLE001', 'course_bundle', '[1,2,3]', 25, '2025-08-30 23:59:59', 270, 1, 'باقة الدورات الأساسية'),
('STUDENT50', 'all_courses', NULL, 1, '2025-07-15 23:59:59', 90, 1, 'كود طالب فردي'),
('PROMO2025', 'all_courses', NULL, 200, '2025-12-25 23:59:59', 365, 1, 'عرض ترويجي خاص');