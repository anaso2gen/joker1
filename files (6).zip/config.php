<?php
/**
 * ملف الإعدادات للاتصال بقاعدة البيانات
 */

// معلومات الاتصال بقاعدة البيانات
$host = 'localhost'; // اسم المضيف، عادةً localhost
$db   = 'u860905067_elearn'; // اسم قاعدة البيانات
$user = 'u860905067_elearn'; // اسم المستخدم لقاعدة البيانات
$pass = '@aqEb4q[2wD8';       // كلمة المرور لقاعدة البيانات

// إنشاء اتصال بقاعدة البيانات باستخدام mysqli
$mysqli = new mysqli($host, $user, $pass, $db);

// التحقق من الاتصال
if ($mysqli->connect_error) {
    die("خطأ في الاتصال بقاعدة البيانات: " . $mysqli->connect_error);
}

// تأكد من ضبط الترميز ليدعم العربية
$mysqli->set_charset("utf8mb4");
?>