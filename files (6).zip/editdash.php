<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <title>لوحة التحكم</title>
  <!-- روابط الموارد المشتركة -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css">
  <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
  <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>

  <style>
    body {
      margin: 0; padding: 0;
      font-family: sans-serif;
      background-color: #e0e0e0; /* خلفية رمادية */
    }
    header {
      background: #34495e; 
      color: #fff;
      padding: 15px;
      text-align: center;
    }
    .actions-container {
      margin: 20px auto;
      max-width: 800px;
      display: flex;
      gap: 20px;
      flex-wrap: wrap;
      justify-content: center;
    }
    .action-card {
      background: #fff;
      width: 200px;
      padding: 20px;
      border-radius: 8px;
      text-align: center;
      cursor: pointer;
      box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }
    .action-card:hover {
      background: #f0f0f0;
    }
    .action-card i {
      font-size: 30px;
      margin-bottom: 10px;
    }
    table {
      width: 90%;
      margin: 20px auto;
      border-collapse: collapse;
      background: #fff;
      box-shadow: 0 2px 5px rgba(0,0,0,0.15);
    }
    thead {
      background: #2ecc71;
      color: #fff;
    }
    th, td {
      padding: 10px;
      border: 1px solid #ccc;
      text-align: center;
    }
    /* مثال لأزرار الجدول */
    .btn-icon {
      border: none;
      background: none;
      cursor: pointer;
      font-size: 16px;
      margin: 0 5px;
    }
    .btn-icon.edit { color: #2980b9; }
    .btn-icon.delete { color: #e74c3c; }
  </style>
</head>
<body onload="AOS.init();">
<header>
  <h1>لوحة التحكم</h1>
</header>

<div class="actions-container" data-aos="fade-up">
  <div class="action-card" onclick="openModal('addCourse')">
    <i class="fa fa-puzzle-piece"></i>
    <h4>إضافة كورس</h4>
  </div>
  <div class="action-card" onclick="openModal('editCourse')">
    <i class="fa fa-folder-open"></i>
    <h4>تعديل كورس</h4>
  </div>
  <div class="action-card" onclick="openModal('deleteCourse')">
    <i class="fa fa-pencil"></i>
    <h4>حذف كورس</h4>
  </div>
</div>

<!-- جدول بيانات بسيط -->
<table data-aos="fade-in">
  <thead>
    <tr>
      <th>المعرف</th>
      <th>اسم الكورس</th>
      <th>الإجراءات</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>كورس PHP</td>
      <td>
        <button class="btn-icon edit"><i class="fa fa-edit"></i></button>
        <button class="btn-icon delete"><i class="fa fa-trash"></i></button>
      </td>
    </tr>
    <tr>
      <td>2</td>
      <td>كورس JS</td>
      <td>
        <button class="btn-icon edit"><i class="fa fa-edit"></i></button>
        <button class="btn-icon delete"><i class="fa fa-trash"></i></button>
      </td>
    </tr>
  </tbody>
</table>

<!-- مثال لمودال بسيط -->
<div id="modalBox" style="display:none;">
  <!-- محتوى المودال -->
</div>

<script>
  function openModal(actionType) {
    alert("فتح نافذة لعملية: " + actionType);
    // يمكن إضافة رسوم متحركة خفيفة
  }
</script>
</body>
</html>