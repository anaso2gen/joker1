// Start session
session_start([
  'cookie_lifetime' => 0,
  'cookie_httponly' => true,
  'use_strict_mode' => true
]);

// Regenerate session on login to avoid fixation
if (!isset($_SESSION['initiated'])) {
    session_regenerate_id();
    $_SESSION['initiated'] = true;
}