/**
 * مثال بسيط لإدارة الحالة وحماية طلبات AJAX مع منع الثغرات (XSS) قدر الإمكان.
 * 1. تخزين الحالة (الكورس، القسم، الدرس) في LocalStorage.
 * 2. استخدام Fetch API لإرسال طلبات آمنة.
 * 3. تأكد من تعقيم البيانات المدخلة من المستخدم على الجانب الخادم.
 */

// عند تحميل الصفحة، نجلب القائمة من الـ backend (مثال):
document.addEventListener('DOMContentLoaded', () => {
  const courseSelect = document.getElementById('courseSelect');
  const sectionSelect = document.getElementById('sectionSelect');
  const lessonSelect = document.getElementById('lessonSelect');
  const videoPlayer = document.getElementById('videoPlayer');

  // استعادة آخر حالة محفوظة
  const savedCourse = localStorage.getItem('selectedCourse');
  const savedSection = localStorage.getItem('selectedSection');
  const savedLesson = localStorage.getItem('selectedLesson');

  // جلب قائمة الكورسات (AJAX)
  fetch('get_courses.php', {
    method: 'GET',
    credentials: 'include'
  })
  .then(response => response.json())
  .then(courses => {
    courseSelect.innerHTML = `<option value="">اختر الكورس</option>`;
    courses.forEach(c => {
      courseSelect.innerHTML += `<option value="${escapeHtml(c.id)}">${escapeHtml(c.name)}</option>`;
    });

    if (savedCourse) {
      courseSelect.value = savedCourse;
      loadSections(savedCourse);
    }
  })
  .catch(console.error);

  // عند تغيير الكورس
  courseSelect.addEventListener('change', e => {
    const courseId = e.target.value;
    localStorage.setItem('selectedCourse', courseId);
    loadSections(courseId);
  });

  // عند تغيير القسم
  sectionSelect.addEventListener('change', e => {
    const sectionId = e.target.value;
    localStorage.setItem('selectedSection', sectionId);
    loadLessons(sectionId);
  });

  // عند تغيير الدرس
  lessonSelect.addEventListener('change', e => {
    const lessonId = e.target.value;
    localStorage.setItem('selectedLesson', lessonId);
    loadVideo(lessonId);
  });

  /**
   * جلب الأقسام لكورس محدد
   */
  function loadSections(courseId) {
    if (!courseId) return;
    fetch(`get_sections.php?course_id=${encodeURIComponent(courseId)}`, {
      method: 'GET',
      credentials: 'include'
    })
    .then(res => res.json())
    .then(sections => {
      sectionSelect.innerHTML = `<option value="">اختر القسم</option>`;
      sections.forEach(s => {
        sectionSelect.innerHTML += `<option value="${escapeHtml(s.id)}">${escapeHtml(s.name)}</option>`;
      });
      if (savedSection && courseId === savedCourse) {
        sectionSelect.value = savedSection;
        loadLessons(savedSection);
      }
    })
    .catch(console.error);
  }

  /**
   * جلب الدروس لقسم محدد
   */
  function loadLessons(sectionId) {
    if (!sectionId) return;
    fetch(`get_lessons.php?section_id=${encodeURIComponent(sectionId)}`, {
      method: 'GET',
      credentials: 'include'
    })
    .then(res => res.json())
    .then(lessons => {
      lessonSelect.innerHTML = `<option value="">اختر الدرس</option>`;
      lessons.forEach(l => {
        lessonSelect.innerHTML += `<option value="${escapeHtml(l.id)}" data-video-id="${escapeHtml(l.vdocipher_video_id)}">${escapeHtml(l.title)}</option>`;
      });
      if (savedLesson && sectionId === savedSection) {
        lessonSelect.value = savedLesson;
        loadVideo(savedLesson);
      }
    })
    .catch(console.error);
  }

  /**
   * جلب فيديو من خلال get_otp.php
   * يشمل وضع watermark بـ user_id من جهة الخادم.
   */
  function loadVideo(lessonId) {
    if (!lessonId) return;
    const selectedOption = lessonSelect.querySelector(`option[value="${lessonId}"]`);
    const videoId = selectedOption ? selectedOption.getAttribute('data-video-id') : '';
    if (!videoId) return;

    fetch(`get_otp.php?video_id=${encodeURIComponent(videoId)}`, {
      method: 'GET',
      credentials: 'include'
    })
    .then(res => res.json())
    .then(data => {
      if (data.error) {
        console.error(data.error);
        return;
      }
      // إعادة تهيئة رابط التشغيل
      const otp = encodeURIComponent(data.otp);
      const playbackInfo = encodeURIComponent(data.playbackInfo);
      // مثال إضافة رابط الفيديو في iframe
      // يمكن استخدام Player JS من VdoCipher إذا رغبت
      const src = `https://player.vdocipher.com/v2/?otp=${otp}&playbackInfo=${playbackInfo}`;
      videoPlayer.src = src;
    })
    .catch(console.error);
  }

  /**
   * دالة لتعقيم المدخلات البسيطة؛
   * للحماية من إدراج أكواد في عنصر HTML.
   * من المفضل تعقيم أكثر شمولاً في طبقة الخادم.
   */
  function escapeHtml(unsafe) {
    return String(unsafe)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }
});