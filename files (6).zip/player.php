<?php
// player.php
// ---------------------------------------------------------------------
// ملاحظات:
//  1) التحقق من الجلسة لضمان عدم وصول المستخدم غير المسجل
//  2) إمكانية فحص iOS < 15 وحجب الجهاز
//  3) يفضل نقل الجزء المتعلق بطلب OTP من السيرفر إلى كود فعلي بدلاً من المؤقت
// ---------------------------------------------------------------------

// استدعاء ملفات الإعداد والجلسة
require_once 'config.php';
require_once 'session.php';

// مثال: التحقق من تسجيل دخول المستخدم
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?err=unauthorized");
    exit;
}

// اختياري: التحقق من iOS < 15
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
if (preg_match('/OS (\d+)_(\d+)_?(\d+)? like Mac OS X/', $userAgent, $matches)) {
    $iosVersion = (int)$matches[1];
    if ($iosVersion < 15) {
        echo "<h2>جهازك غير مدعوم. يرجى استخدام جهاز أحدث.</h2>";
        exit;
    }
}

// يمكنك وضع أكواد أخرى للتحقق من صلاحية المستخدم أو ترخيص الفيديو
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>مشغل الفيديو</title>
  <!-- روابط الموارد المشتركة -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css">
  <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
  <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>

  <!-- مثال بسيط لدعم الوضع الليلي -->
  <style>
    :root {
      --main-bg-color: #fafafa;
      --main-text-color: #333;
      --card-bg-color: #fff;
    }
    body.dark-mode {
      --main-bg-color: #121212;
      --main-text-color: #fff;
      --card-bg-color: #1e1e1e;
    }
    body {
      margin: 0;
      padding: 0;
      font-family: sans-serif;
      background-color: var(--main-bg-color);
      color: var(--main-text-color);
      transition: background-color 0.3s, color 0.3s;
    }
    .video-card {
      max-width: 800px;
      margin: 30px auto;
      background: var(--card-bg-color);
      border-radius: 10px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.15);
      padding: 20px;
      position: relative;
      transition: background-color 0.3s, color 0.3s;
    }
    .video-header {
      margin-bottom: 10px;
      font-weight: bold;
    }
    /* لإظهار الـ Spinner عند التحميل المبدئي */
    .spinner-overlay {
      position: fixed; 
      top: 0; left: 0; 
      width: 100%; 
      height: 100%;
      background: rgba(0,0,0,0.6);
      display: flex; 
      align-items: center; 
      justify-content: center;
      z-index: 9999;
    }
    .spinner {
      width: 60px; 
      height: 60px;
      border: 6px solid #ccc; 
      border-top: 6px solid #3498db;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    .toggle-dark-mode {
      position: absolute;
      top: 10px;
      left: 10px;
      cursor: pointer;
      background: transparent;
      border: none;
      color: var(--main-text-color);
      font-size: 20px;
      z-index: 10000;
      transition: color 0.3s;
    }
  </style>
</head>
<body onload="initPage()">

<!-- زر تبديل الوضع (فاتح/ليلي) -->
<button class="toggle-dark-mode" onclick="toggleDarkMode()">
  <i class="fa-solid fa-moon"></i>
</button>

<div class="video-card" data-aos="zoom-in">
  <div class="video-header">مشغل الفيديو</div>

  <!-- لوتي رمز "Play" قبل بدء الفيديو -->
  <lottie-player
    src="https://assets5.lottiefiles.com/packages/lf20_dxynpbow.json"
    background="transparent"
    speed="1"
    style="width: 80px; height:80px; margin-bottom: 10px;"
    loop autoplay>
  </lottie-player>

  <!-- إطار الفيديو (نسبة 16:9) -->
  <div style="position: relative; padding-top: 56.25%;">
    <iframe
      id="videoIframe"
      width="100%"
      height="100%"
      style="border: none; position: absolute; top:0; left:0; right:0; bottom:0;"
      allowfullscreen="true"
      allow="encrypted-media">
    </iframe>
  </div>

  <!-- شريط الاسم -->
  <p id="userBar"></p>
</div>

<!-- سبينر قبل توليد OTP -->
<div class="spinner-overlay" id="loadingSpinner">
  <div class="spinner"></div>
</div>

<script>
// تهيئة الصفحة
function initPage() {
  AOS.init();
  // إظهار السبينر عند فتح الصفحة
  document.getElementById('loadingSpinner').style.display = 'flex';

  // طلب الـ OTP من السيرفر (تجريبي)
  // يُفترض استبداله باستدعاء Ajax أو Fetch حقيقي
  setTimeout(() => {
    // إخفاء السبينر
    document.getElementById('loadingSpinner').style.display = 'none';

    // استلام الـ OTP و الـ Playback Info (قيم مثال)
    const otp = 'dummy-otp';
    const playbackInfo = 'dummy-playbackinfo';

    // تعيين رابط الفيديو في الـ iframe
    const iframeSrc = `https://player.vdocipher.com/v2/?otp=${otp}&playbackInfo=${playbackInfo}`;
    document.getElementById('videoIframe').src = iframeSrc;

    // اظهار اسم المستخدم (يفترض من $_SESSION)
    const userId = '<?php echo $_SESSION["user_id"] ?? "Guest"; ?>';
    document.getElementById('userBar').innerText =
      "يتم عرض هذا الفيديو باسم المستخدم: " + userId;
  }, 2000);
}

// وظيفة تبديل الوضع الليلي
function toggleDarkMode() {
  document.body.classList.toggle('dark-mode');
}
</script>
</body>
</html>