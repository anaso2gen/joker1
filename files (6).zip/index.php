<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <title>الصفحة الرئيسية</title>
  <!-- روابط الموارد المشتركة -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css">
  <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
  <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>

  <style>
    body { margin: 0; padding: 0; font-family: sans-serif; background-color: #f5f5f5; }
    header {
      background-color: #1e272e; 
      color: #fff;
      padding: 15px;
      text-align: center;
    }
    .courses-container {
      max-width: 1200px;
      margin: 20px auto;
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: center;
    }
    .course-card {
      width: 250px;
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.15);
      padding: 20px;
      text-align: center;
      cursor: pointer;
      transition: transform 0.2s;
    }
    .course-card:hover {
      transform: translateY(-5px);
    }
    .course-icon {
      font-size: 40px;
      color: #27ae60;
      margin-bottom: 10px;
    }
    .sections-container, .lessons-container {
      max-width: 600px;
      margin: 20px auto;
      display: none;
    }
    .sections-container ul, .lessons-container ul {
      list-style-type: none;
      padding: 0;
    }
    .sections-container li, .lessons-container li {
      margin: 10px 0;
      padding: 10px 15px;
      background: #fff;
      border-radius: 5px;
      cursor: pointer;
      box-shadow: 0 1px 2px rgba(0,0,0,0.2);
    }
    .sections-container li:hover, .lessons-container li:hover {
      background: #eee;
    }
    /* زرار لسرد أيقونة الدرس */
    .lesson-icon {
      margin-right: 10px;
    }
  </style>
</head>
<body onload="AOS.init();">

<header>
  <h1>منصتك التعليمية</h1>
</header>

<!-- لوتي متحرك لطالب يقرأ كتاب -->
<lottie-player
  src="https://assets2.lottiefiles.com/packages/lf20_8pLWBn.json" 
  background="transparent"
  speed="1"
  style="width: 200px; height: 200px; margin: 0 auto; display:block;"
  loop
  autoplay>
</lottie-player>

<!-- قائمة الكورسات -->
<div class="courses-container" id="coursesContainer">
  <!-- سيتم تحميل الكورسات هنا ديناميكياً، مثلاً -->
  <div class="course-card" data-aos="fade-up" onclick="selectCourse('course1')">
    <i class="fa fa-book course-icon"></i>
    <h4>كورس 1</h4>
  </div>
  <div class="course-card" data-aos="fade-up" onclick="selectCourse('course2')">
    <i class="fa fa-book course-icon"></i>
    <h4>كورس 2</h4>
  </div>
</div>

<!-- الأقسام -->
<div class="sections-container" id="sectionsContainer">
  <ul id="sectionsList"></ul>
</div>

<!-- الدروس -->
<div class="lessons-container" id="lessonsContainer">
  <ul id="lessonsList"></ul>
</div>

<script>
  function selectCourse(courseId) {
    // إظهار الأقسام مع حركة SlideDown بدائية
    const sectionsContainer = document.getElementById('sectionsContainer');
    sectionsContainer.style.display = 'block';
    sectionsContainer.style.height = '0px';
    setTimeout(() => {
      sectionsContainer.style.transition = 'height 0.3s ease-out';
      sectionsContainer.style.height = '200px';
    }, 50);

    // تعبئة أقسام وهمية
    const sectionsList = document.getElementById('sectionsList');
    sectionsList.innerHTML = `
      <li onclick="selectSection('sec1')"><span class="lesson-icon">📂</span> القسم الأول</li>
      <li onclick="selectSection('sec2')"><span class="lesson-icon">📂</span> القسم الثاني</li>
    `;
  }

  function selectSection(secId) {
    const lessonsContainer = document.getElementById('lessonsContainer');
    lessonsContainer.style.display = 'block';
    lessonsContainer.style.height = '0px';
    setTimeout(() => {
      lessonsContainer.style.transition = 'height 0.3s ease-out';
      lessonsContainer.style.height = '200px';
    }, 50);

    // تعبئة دروس وهمية
    const lessonsList = document.getElementById('lessonsList');
    lessonsList.innerHTML = `
      <li onclick="openLesson('lesson1')"><span class="lesson-icon">🎓</span> درس مفتوح</li>
      <li><span class="lesson-icon">🔒</span> درس مغلق</li>
    `;
  }

  function openLesson(lessonId) {
    alert('فتح الدرس: ' + lessonId);
    // هنا يمكن الانتقال إلى صفحة الفيديو player.php
  }
</script>
</body>
</html>