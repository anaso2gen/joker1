-- إنشاء قاعدة البيانات
CREATE DATABASE IF NOT EXISTS `edu_platform`;

USE `edu_platform`;

-- Table: users
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(255) UNIQUE NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `user_id` VARCHAR(255) UNIQUE NOT NULL,
  `session_token` VARCHAR(255),
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Table: courses
CREATE TABLE IF NOT EXISTS `courses` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `code` VARCHAR(100) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Table: sections
CREATE TABLE IF NOT EXISTS `sections` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `course_id` INT NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON DELETE CASCADE
);

-- Table: lessons
CREATE TABLE IF NOT EXISTS `lessons` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `section_id` INT NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `vdocipher_video_id` VARCHAR(255) NOT NULL,
  FOREIGN KEY (`section_id`) REFERENCES `sections`(`id`) ON DELETE CASCADE
);

-- Table: subscriptions
CREATE TABLE IF NOT EXISTS `subscriptions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `course_id` INT NOT NULL,
  `expiry_date` DATETIME DEFAULT NULL, -- تاريخ انتهاء الاشتراك
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON DELETE CASCADE
);

-- Table: sessions
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `session_token` VARCHAR(255) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_activity` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, -- آخر نشاط للجلسة
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
);

-- بيانات ابتدائية (Seed Data)

-- إضافة مستخدمين تجريبيين
INSERT INTO `users` (`email`, `password`, `user_id`, `session_token`) VALUES 
('user1@example.com', 'hashed_password_1', 'uuid_user_1', NULL),
('user2@example.com', 'hashed_password_2', 'uuid_user_2', NULL);

-- إضافة كورسات تجريبية
INSERT INTO `courses` (`name`, `code`) VALUES 
('كورس HTML أساسيات', 'HTML101'),
('كورس جافاسكربت متقدم', 'JS201');

-- إضافة أقسام للكورسات
INSERT INTO `sections` (`course_id`, `name`) VALUES 
(1, 'أساسيات HTML'),
(1, 'وسوم HTML شائعة'),
(2, 'متغيرات ودوال في JS'),
(2, 'كائنات ومصفوفات في JS');

-- إضافة دروس للأقسام
INSERT INTO `lessons` (`section_id`, `title`, `vdocipher_video_id`) VALUES 
(1, 'مقدمة عن HTML', 'video-123'),
(2, 'وسوم HTML الأساسية', 'video-124'),
(3, 'مقدمة عن المتغيرات', 'video-125'),
(4, 'كائنات في جافاسكربت', 'video-126');

-- إضافة اشتراكات تجريبية
INSERT INTO `subscriptions` (`user_id`, `course_id`, `expiry_date`) VALUES 
(1, 1, '2025-12-31'),
(2, 2, '2025-12-31');

-- إضافة جلسات تجريبية
INSERT INTO `sessions` (`user_id`, `session_token`) VALUES 
(1, 'random_session_token_1'),
(2, 'random_session_token_2');