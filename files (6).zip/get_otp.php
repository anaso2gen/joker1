<?php
/**
 * مثال مبسط لسكربت PHP.
 * المتطلبات:
 * - يجب تعديل بيانات الاتصال وقاعدة البيانات حسب احتياجاتك (db_host, db_user, db_password, db_name).
 * - يجب أن يحتوي جدول users على حقول (user_id, session_token).
 * - إصدار PHP >= 7.
 * - بدون استخدام مكتبات خارجية.
 */

header('Content-Type: application/json; charset=utf-8');

// 1. التحقق من وجود session_token في الكوكيز
if (!isset($_COOKIE['session_token']) || empty($_COOKIE['session_token'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Missing or invalid session token']);
    exit;
}
$sessionToken = $_COOKIE['session_token'];

// 2. التحقق من وجود video_id في الطلب (GET أو POST)
$videoId = $_REQUEST['video_id'] ?? '';
if (empty($videoId)) {
    http_response_code(400);
    echo json_encode(['error' => 'missing video_id']);
    exit;
}

// 3. ربط مع قاعدة البيانات باستخدام mysqli
$db_host = 'localhost';    // استبدل بالقيم المناسبة
$db_user = 'root';
$db_pass = '';             // كلمة مرور
$db_name = 'my_database';  // اسم قاعدة البيانات
$mysqli  = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($mysqli->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

// 4. التحقق من صلاحية session_token (جلب user_id)
$stmt = $mysqli->prepare("SELECT user_id FROM users WHERE session_token = ? LIMIT 1");
if (!$stmt) {
    http_response_code(500);
    echo json_encode(['error' => 'Database statement error']);
    exit;
}
$stmt->bind_param('s', $sessionToken);
$stmt->execute();
$result = $stmt->get_result();
if (!$result || $result->num_rows === 0) {
    http_response_code(401);
    echo json_encode(['error' => 'Invalid session']);
    exit;
}
$userRow = $result->fetch_assoc();
$userId = $userRow['user_id'] ?? null;
$stmt->close();

// 5. التحقق من الجهاز iPhone أو iPad وإصدار iOS < 15
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
if (preg_match('/(iPhone|iPad)/i', $userAgent)) {
    // استخراج رقم إصدار iOS
    // عادةً يكون بالشكل iPhone; CPU iPhone OS 14_4 like Mac OS X
    // نبحث عن رقم بعد OS (\d+_\d+)
    if (preg_match('/OS (\d+)_(\d+)/', $userAgent, $matches)) {
        $majorVersion = (int)$matches[1];
        if ($majorVersion < 15) {
            http_response_code(403);
            echo json_encode(['error' => 'Unsupported device']);
            exit;
        }
    }
}

// 6. إرسال طلب cURL إلى VdoCipher API
$apiSecret = "API_SECRET_KEY"; // ضع المفتاح الخاص بك
$endpoint  = "https://dev.vdocipher.com/api/videos/{$videoId}/otp";

// إعداد بيانات الطلب
$requestBody = [
    "ttl" => 300,
    "annotate" => [
        "text" => "User ID: {$userId}",
        "opacity" => 0.3,
        "color" => "white",
        "size" => 14,
        "position" => "bottom-right",
        "interval" => 5
    ]
];
$jsonBody = json_encode($requestBody);

$ch = curl_init($endpoint);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonBody);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: Apisecret {$apiSecret}",
    "Content-Type: application/json",
    'Content-Length: ' . strlen($jsonBody)
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
$curlError = curl_error($ch);
$httpCode  = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);

// التحقق من وجود أخطاء في cURL
if ($response === false || $curlError) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Failed to connect to VdoCipher API',
        'details' => $curlError
    ]);
    exit;
}

// التحقق من كود HTTP
if ($httpCode !== 200) {
    http_response_code($httpCode);
    echo ($response); // قد تريد إظهار رسالة الخطأ القادمة من VdoCipher
    exit;
}

$data = json_decode($response, true);
if (!isset($data['otp']) || !isset($data['playbackInfo'])) {
    http_response_code(500);
    echo json_encode(['error' => 'Missing fields in VdoCipher response']);
    exit;
}

// 7. إعادة JSON يحتوي (otp, playbackInfo)
echo json_encode([
    'otp' => $data['otp'],
    'playbackInfo' => $data['playbackInfo']
], JSON_UNESCAPED_UNICODE);