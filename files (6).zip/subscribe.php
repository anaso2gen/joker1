<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <title>الاشتراك</title>
  <!-- روابط الموارد المشتركة -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css">
  <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
  <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>

  <style>
    body {
      margin: 0; padding: 0;
      font-family: sans-serif;
      background-color: #f5f5f5;
      text-align: center;
    }
    .subscribe-container {
      max-width: 400px;
      margin: 40px auto;
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.15);
      padding: 20px;
    }
    .subscribe-title {
      margin-bottom: 20px;
    }
    .form-group {
      position: relative;
      margin-bottom: 15px;
    }
    .form-group i {
      position: absolute;
      left: 10px;
      top: 10px;
      color: #666;
    }
    .form-group input {
      width: 100%;
      padding: 10px 10px 10px 35px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    .btn-subscribe {
      background: #27ae60;
      color: #fff;
      border: none;
      padding: 10px 15px;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
    }
    /* اهتزاز عند الفشل */
    .shake {
      animation: shakeAnim 0.3s;
    }
    @keyframes shakeAnim {
      0% { transform: translateX(0);}
      25% { transform: translateX(-5px);}
      50% { transform: translateX(5px);}
      75% { transform: translateX(-5px);}
      100% { transform: translateX(0);}
    }
    /* نجاح الاشتراك */
    .success-animation {
      width: 150px; height: 150px;
      margin: 0 auto;
      display: none;
    }
  </style>
</head>
<body onload="AOS.init();">

<div class="subscribe-container" data-aos="zoom-in">
  <h2 class="subscribe-title">تفعيل الاشتراك</h2>

  <!-- رسم مفتاح ذهبي -->
  <lottie-player
    src="https://assets9.lottiefiles.com/packages/lf20_nzpkqlzj.json"
    background="transparent"
    speed="1"
    style="width: 100px; height: 100px; margin: 0 auto;"
    loop
    autoplay>
  </lottie-player>

  <form>
    <div class="form-group">
      <i class="fa-solid fa-key"></i>
      <input type="text" id="subscribeCode" placeholder="أدخل كود الاشتراك">
    </div>
    <button type="button" class="btn-subscribe" onclick="activateSubscription()">تفعيل</button>
  </form>

  <div class="success-animation" id="successAnim">
    <lottie-player
      src="https://assets1.lottiefiles.com/packages/lf20_K7aT0v.json"
      background="transparent"
      speed="1"
      loop
      autoplay>
    </lottie-player>
  </div>
</div>

<script>
  function activateSubscription() {
    const codeInput = document.getElementById('subscribeCode');
    const successAnim = document.getElementById('successAnim');
    // محاكاة التحقق
    if (codeInput.value === 'ABC123') {
      // نجاح
      successAnim.style.display = 'block';
      alert("تم تفعيل الاشتراك بنجاح!");
    } else {
      // فشل واهتزاز
      codeInput.classList.remove('shake');
      void codeInput.offsetWidth; // force reflow
      codeInput.classList.add('shake');
      alert("الكود غير صحيح!");
    }
  }
</script>
</body>
</html>