// تحميل صفحتي الكورسات والأقسام بشكل تجريبي
// يمكن التعديل لاحقاً للتوافق مع backend حقيقي

// محاكاة بيانات الكورسات والأقسام والدروس
const mockCourses = [
  { id: 'course1', name: 'كورس HTML Basics' },
  { id: 'course2', name: 'كورس JavaScript Advanced' }
];

const mockSections = {
  'course1': [
    { id: 'sec1', name: 'أساسيات التصميم' },
    { id: 'sec2', name: 'العناصر والوسوم' }
  ],
  'course2': [
    { id: 'sec3', name: 'الأساسيات المتقدمة' },
    { id: 'sec4', name: 'المكتبات والإطارات' }
  ]
};

const mockLessons = {
  'sec1': [
    { id: 'lesson1', title: 'مقدمة التصميم', locked: false, videoId: 'video-1111' },
    { id: 'lesson2', title: 'أدوات التصميم', locked: true, videoId: 'video-2222' }
  ],
  'sec2': [
    { id: 'lesson3', title: 'وسوم HTML شائعة', locked: false, videoId: 'video-3333' }
  ],
  'sec3': [
    { id: 'lesson4', title: 'المتغيرات والدوال', locked: false, videoId: 'video-4444' },
    { id: 'lesson5', title: 'كائنات في جافاسكربت', locked: true, videoId: 'video-5555' }
  ],
  'sec4': [
    { id: 'lesson6', title: 'مقدمة React', locked: false, videoId: 'video-6666' }
  ]
};

document.addEventListener('DOMContentLoaded', () => {
  const courseSelect   = document.getElementById('courseSelect');
  const sectionSelect  = document.getElementById('sectionSelect');
  const lessonsCard    = document.getElementById('lessonsCard');
  const lessonList     = document.getElementById('lessonList');
  const videoCard      = document.getElementById('videoCard');
  const videoIframe    = document.getElementById('lessonVideo');
  const lessonTitleEl  = document.getElementById('selectedLessonTitle');
  const loader         = document.getElementById('loader');
  const toggleThemeBtn = document.getElementById('toggleThemeBtn');

  // تعبئة القيمر
  fillCourseSelect();
  restoreLastSelection();

  // تبديل الوضع الليلي
  toggleThemeBtn.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
  });

  // عند تغيير الكورس
  courseSelect.addEventListener('change', () => {
    const selected = courseSelect.value;
    if (!selected) return;
    showLoader(true);
    // حفظ الحالة في LocalStorage
    localStorage.setItem('selectedCourse', selected);
    // جلب الأقسام
    loadSections(selected);
  });

  // عند تغيير القسم
  sectionSelect.addEventListener('change', () => {
    const selected = sectionSelect.value;
    if (!selected) return;
    showLoader(true);
    // حفظ الحالة في LocalStorage
    localStorage.setItem('selectedSection', selected);
    loadLessons(selected);
  });

  // دالة لتعبئة قائمة الكورسات
  function fillCourseSelect() {
    courseSelect.innerHTML = `<option value="">---</option>`;
    mockCourses.forEach(course => {
      courseSelect.innerHTML += `<option value="${course.id}">${course.name}</option>`;
    });
  }

  // دالة لجلب الأقسام
  function loadSections(courseId) {
    sectionSelect.innerHTML = `<option value="">---</option>`;
    const sections = mockSections[courseId] || [];
    if (!sections.length) {
      showLoader(false);
      alert("لا توجد أقسام متاحة لهذا الكورس.");
      return;
    }
    sections.forEach(sec => {
      sectionSelect.innerHTML += `<option value="${sec.id}">${sec.name}</option>`;
    });
    showLoader(false);
    lessonsCard.style.display = 'none';
    videoCard.style.display = 'none';
  }

  // جلب الدروس
  function loadLessons(sectionId) {
    lessonList.innerHTML = '';
    const lessons = mockLessons[sectionId] || [];
    if (!lessons.length) {
      showLoader(false);
      alert("لا توجد دروس متاحة لهذا القسم.");
      return;
    }
    lessons.forEach(lsn => {
      // رمز مغلق أو مفتوح
      const statusIcon = lsn.locked 
        ? '<i class="fa fa-lock" style="color:#f44336;"></i>'
        : '<i class="fa fa-unlock" style="color:#4caf50;"></i>';

      const lessonItem = document.createElement('li');
      lessonItem.classList.add('list-group-item');
      lessonItem.innerHTML = `
        ${lsn.title}
        ${statusIcon}
      `;
      // عند النقر على الدرس
      lessonItem.addEventListener('click', () => lessonClickHandler(lsn));
      lessonList.appendChild(lessonItem);
    });
    lessonsCard.style.display = 'block';
    videoCard.style.display = 'none';
    showLoader(false);
  }

  // عند الضغط على الدرس
  function lessonClickHandler(lesson) {
    if (lesson.locked) {
      alert("اشترك أولًا");
      return;
    }
    videoCard.style.display = 'block';
    lessonTitleEl.textContent = lesson.title;
    // iframe VdoCipher (افتراضي)
    // يمكنك تحويله لاستدعاء get_otp.php لعرض OTP و playbackInfo
    // هنا سنعرضه بشكل ثابت لتوضيح
    const sampleOtp = 'sample-otp';
    const samplePlaybackInfo = 'sample-playback-info';
    const videoSrc = `https://player.vdocipher.com/v2/?otp=${sampleOtp}&playbackInfo=${samplePlaybackInfo}`;
    videoIframe.src = videoSrc;
    // يمكنك حفظ الدرس في LocalStorage إن أردت
  }

  // إظهار أو إخفاء اللودر
  function showLoader(show) {
    loader.style.display = show ? 'flex' : 'none';
  }

  // استعادة آخر اختيار
  function restoreLastSelection() {
    const lastCourse = localStorage.getItem('selectedCourse');
    const lastSection = localStorage.getItem('selectedSection');
    if (lastCourse) {
      courseSelect.value = lastCourse;
      loadSections(lastCourse);
    }
    if (lastSection) {
      sectionSelect.value = lastSection;
      loadLessons(lastSection);
    }
  }
});