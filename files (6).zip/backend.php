<?php
/**
 * مثال مبسط للمعالجة في الجانب الخادم للاستضافة المشتركة (Shared Hosting).
 * هذا الملف فقط لتوضيح الفكرة, هنا يمكنك كتابة عمليات جلب الكورسات والأقسام والدروس من قاعدة بيانات فعلية.
 * 
 * - تأكد من ضبط الاتصال بقواعد البيانات.
 * - تأكد من حماية إدخال المستخدم ومنع ثغرات SQL Injection
 */

// نموذج بسيط للاتصال بقاعدة البيانات (mysqli)
$dbHost = 'localhost';
$dbUser = 'username';
$dbPass = 'password';
$dbName = 'database_name';

$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
if ($conn->connect_error) {
    die("خطأ في الاتصال بقاعدة البيانات: " . $conn->connect_error);
}

// مثلاً: جلب الكورسات
if (isset($_GET['action']) && $_GET['action'] === 'getCourses') {
    header('Content-Type: application/json; charset=utf-8');

    $sql = "SELECT course_id, course_name FROM courses";
    $result = $conn->query($sql);
    $courses = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $courses[] = [
              'id' => $row['course_id'],
              'name' => $row['course_name']
            ];
        }
    }
    echo json_encode($courses);
    exit;
}

// يمكنك إضافة المزيد من العمليات لجلب الأقسام والدروس حسب ID الكورس
// ...

$conn->close();