<?php
require_once 'auth.php';
header('Content-Type: application/json');

$courseId = isset($_GET['course_id']) ? (int) $_GET['course_id'] : 0;
if ($courseId <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'معرّف الدورة غير صالح']);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT id, name FROM sections WHERE course_id = :course_id");
    $stmt->execute(['course_id' => $courseId]);
    $sections = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($sections, JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'حدث خطأ أثناء جلب الأقسام']);
}