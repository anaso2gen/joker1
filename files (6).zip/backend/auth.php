<?php
session_start();
require_once 'db.php';

$sessionToken = $_COOKIE['session_token'] ?? '';

if (empty($sessionToken)) {
    // لا توجد كوكي، المستخدم غير مسجل الدخول
    header("Location: login.php");
    exit;
}

// التأكد من التوكن في جدول sessions
$stmt = $pdo->prepare("SELECT user_id FROM sessions WHERE session_token = :session_token LIMIT 1");
$stmt->execute(['session_token' => $sessionToken]);
$session = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$session) {
    // التوكن غير صالح
    setcookie('session_token', '', time() - 3600, '/');
    header("Location: login.php");
    exit;
}

// إذا وصلت هنا، التوكن صالح، يمكن إكمال العمل
$userId = $session['user_id'];