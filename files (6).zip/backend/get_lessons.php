<?php
require_once 'auth.php';
header('Content-Type: application/json');

$sectionId = isset($_GET['section_id']) ? (int) $_GET['section_id'] : 0;
if ($sectionId <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'معرّف القسم غير صالح']);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT id, title, vdocipher_video_id FROM lessons WHERE section_id = :section_id");
    $stmt->execute(['section_id' => $sectionId]);
    $lessons = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($lessons, JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'حدث خطأ أثناء جلب الدروس']);
}