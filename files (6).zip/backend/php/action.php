<?php
// مثال مبسط للتعامل مع المدخلات وإجراء العمليات في قاعدة البيانات
require_once '../db.php';

$action = $_POST['action'] ?? '';

switch ($action) {
    case 'addCourse':
        $name = $_POST['name'] ?? '';
        if (!empty($name)) {
            $stmt = $pdo->prepare("INSERT INTO courses (name) VALUES (:name)");
            $stmt->execute(['name' => $name]);
        }
        break;
    case 'editCourse':
        $id = $_POST['id'] ?? '';
        $name = $_POST['name'] ?? '';
        if (!empty($id) && !empty($name)) {
            $stmt = $pdo->prepare("UPDATE courses SET name = :name WHERE id = :id");
            $stmt->execute(['name' => $name, 'id' => $id]);
        }
        break;
    case 'deleteCourse':
        $id = $_POST['id'] ?? '';
        if (!empty($id)) {
            $stmt = $pdo->prepare("DELETE FROM courses WHERE id = :id");
            $stmt->execute(['id' => $id]);
        }
        break;

    case 'addSection':
        $name = $_POST['name'] ?? '';
        $course_id = $_POST['course_id'] ?? '';
        if (!empty($name) && !empty($course_id)) {
            $stmt = $pdo->prepare("INSERT INTO sections (name, course_id) VALUES (:name, :course_id)");
            $stmt->execute(['name' => $name, 'course_id' => $course_id]);
        }
        break;
    case 'editSection':
        $id = $_POST['id'] ?? '';
        $name = $_POST['name'] ?? '';
        $course_id = $_POST['course_id'] ?? '';
        // من الممكن تعديل الكورس أيضاً لو أردت
        if (!empty($id) && !empty($name)) {
            $stmt = $pdo->prepare("UPDATE sections SET name = :name WHERE id = :id");
            $stmt->execute(['name' => $name, 'id' => $id]);
        }
        break;
    case 'deleteSection':
        $id = $_POST['id'] ?? '';
        if (!empty($id)) {
            $stmt = $pdo->prepare("DELETE FROM sections WHERE id = :id");
            $stmt->execute(['id' => $id]);
        }
        break;

    case 'addLesson':
        $title = $_POST['title'] ?? '';
        $section_id = $_POST['section_id'] ?? '';
        if (!empty($title) && !empty($section_id)) {
            $stmt = $pdo->prepare("INSERT INTO lessons (title, section_id) VALUES (:title, :section_id)");
            $stmt->execute(['title' => $title, 'section_id' => $section_id]);
        }
        break;
    case 'editLesson':
        $id = $_POST['id'] ?? '';
        $title = $_POST['title'] ?? '';
        $section_id = $_POST['section_id'] ?? '';
        // من الممكن تعديل القسم أيضاً لو أردت
        if (!empty($id) && !empty($title)) {
            $stmt = $pdo->prepare("UPDATE lessons SET title = :title WHERE id = :id");
            $stmt->execute(['title' => $title, 'id' => $id]);
        }
        break;
    case 'deleteLesson':
        $id = $_POST['id'] ?? '';
        if (!empty($id)) {
            $stmt = $pdo->prepare("DELETE FROM lessons WHERE id = :id");
            $stmt->execute(['id' => $id]);
        }
        break;
    default:
        // لا يوجد إجراء محدد
        break;
}

// بعد الإنتهاء، إعادة التوجيه للصفحة مرة أخرى
header("Location: ../admin.php");
exit;