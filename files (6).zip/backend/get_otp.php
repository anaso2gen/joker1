<?php
require_once 'auth.php';
header('Content-Type: application/json');

$videoId = $_GET['video_id'] ?? '';
if (empty($videoId)) {
    http_response_code(400);
    echo json_encode(['error' => 'معرف الفيديو مفقود']);
    exit;
}

// مثال مصغر لاستدعاء VdoCipher API (ستحتاج مفاتيحك الخاصة)
$apiKey = "YOUR_VDOCIPHER_API_KEY"; // ضع المفتاح الخاص بك
$apiUrl = "https://dev.vdocipher.com/api/videos/$videoId/otp";

try {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Accept: application/json",
        "Authorization: Apisecret $apiKey"
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    if ($response === false) {
        throw new Exception("فشل الاتصال بخادم VdoCipher.");
    }

    echo $response; // إعادة النتيجة من VdoCipher
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}