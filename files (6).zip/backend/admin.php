<?php
// ملاحظة: هذا مثال مبسط يعتمد على وجود db.php للاتصال بقاعدة البيانات
// ويعتمد على auth.php إذا كانت الصفحة محمية.
// تأكد من تعديل الاستعلامات والمسارات وفق احتياجاتك الحقيقية من حيث البنية والمسارات.

require_once 'db.php'; // ملف الاتصال بقاعدة البيانات
// require_once 'auth.php'; // إذا كانت الصفحة تتطلب التحقق من صلاحية المستخدم

// جلب البيانات من قاعدة البيانات
try {
    // الكورسات
    $stmtCourses = $pdo->query("SELECT id, name FROM courses");
    $courses = $stmtCourses->fetchAll(PDO::FETCH_ASSOC);

    // الأقسام
    $stmtSections = $pdo->query("SELECT s.id, s.name, c.name AS course_name
                                 FROM sections s
                                 JOIN courses c ON s.course_id = c.id");
    $sections = $stmtSections->fetchAll(PDO::FETCH_ASSOC);

    // الدروس
    $stmtLessons = $pdo->query("SELECT l.id, l.title, s.name AS section_name
                                FROM lessons l
                                JOIN sections s ON l.section_id = s.id");
    $lessons = $stmtLessons->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    die("خطأ أثناء جلب البيانات: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>لوحة التحكم</title>
    <!-- تضمين Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container py-5">
    <h1 class="mb-4">لوحة تحكم الإدارة</h1>

    <!-- قسم الكورسات -->
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h2 class="h5 mb-0">الكورسات</h2>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#courseModal" 
                    onclick="openModal('addCourse')">إضافة كورس</button>
        </div>
        <div class="card-body">
            <table class="table">
                <thead>
                <tr>
                    <th>المعرف</th>
                    <th>اسم الكورس</th>
                    <th>التحكم</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($courses as $course) : ?>
                    <tr>
                        <td><?php echo htmlspecialchars($course['id'], ENT_QUOTES, 'UTF-8'); ?></td>
                        <td><?php echo htmlspecialchars($course['name'], ENT_QUOTES, 'UTF-8'); ?></td>
                        <td>
                            <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#courseModal"
                                    onclick="openModal('editCourse', <?php echo $course['id']; ?>, '<?php echo addslashes($course['name']); ?>')">
                                تعديل
                            </button>
                            <form action="php/action.php" method="POST" class="d-inline">
                                <input type="hidden" name="action" value="deleteCourse">
                                <input type="hidden" name="id" value="<?php echo $course['id']; ?>">
                                <button class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد؟');">حذف</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- قسم الأقسام -->
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h2 class="h5 mb-0">الأقسام</h2>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#sectionModal"
                    onclick="openModal('addSection')">إضافة قسم</button>
        </div>
        <div class="card-body">
            <table class="table">
                <thead>
                <tr>
                    <th>المعرف</th>
                    <th>اسم القسم</th>
                    <th>الكورس</th>
                    <th>التحكم</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($sections as $section) : ?>
                    <tr>
                        <td><?php echo htmlspecialchars($section['id'], ENT_QUOTES, 'UTF-8'); ?></td>
                        <td><?php echo htmlspecialchars($section['name'], ENT_QUOTES, 'UTF-8'); ?></td>
                        <td><?php echo htmlspecialchars($section['course_name'], ENT_QUOTES, 'UTF-8'); ?></td>
                        <td>
                            <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#sectionModal"
                                    onclick="openModal('editSection', <?php echo $section['id']; ?>, '<?php echo addslashes($section['name']); ?>')">
                                تعديل
                            </button>
                            <form action="php/action.php" method="POST" class="d-inline">
                                <input type="hidden" name="action" value="deleteSection">
                                <input type="hidden" name="id" value="<?php echo $section['id']; ?>">
                                <button class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد؟');">حذف</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- قسم الدروس -->
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h2 class="h5 mb-0">الدروس</h2>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#lessonModal"
                    onclick="openModal('addLesson')">إضافة درس</button>
        </div>
        <div class="card-body">
            <table class="table">
                <thead>
                <tr>
                    <th>المعرف</th>
                    <th>عنوان الدرس</th>
                    <th>القسم</th>
                    <th>التحكم</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($lessons as $lesson) : ?>
                    <tr>
                        <td><?php echo htmlspecialchars($lesson['id'], ENT_QUOTES, 'UTF-8'); ?></td>
                        <td><?php echo htmlspecialchars($lesson['title'], ENT_QUOTES, 'UTF-8'); ?></td>
                        <td><?php echo htmlspecialchars($lesson['section_name'], ENT_QUOTES, 'UTF-8'); ?></td>
                        <td>
                            <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#lessonModal"
                                    onclick="openModal('editLesson', <?php echo $lesson['id']; ?>, '<?php echo addslashes($lesson['title']); ?>')">
                                تعديل
                            </button>
                            <form action="php/action.php" method="POST" class="d-inline">
                                <input type="hidden" name="action" value="deleteLesson">
                                <input type="hidden" name="id" value="<?php echo $lesson['id']; ?>">
                                <button class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد؟');">حذف</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- مودال لكورس -->
<div class="modal fade" id="courseModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="php/action.php" method="POST">
        <div class="modal-header">
          <h5 class="modal-title" id="courseModalLabel">إدارة الكورس</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
        </div>
        <div class="modal-body">
            <input type="hidden" name="action" id="courseAction" value="">
            <input type="hidden" name="id" id="courseId" value="">
            <div class="mb-3">
                <label for="courseName" class="form-label">اسم الكورس</label>
                <input type="text" class="form-control" name="name" id="courseName" required>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
          <button type="submit" class="btn btn-primary">حفظ التغييرات</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- مودال لقسم -->
<div class="modal fade" id="sectionModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="php/action.php" method="POST">
        <div class="modal-header">
          <h5 class="modal-title" id="sectionModalLabel">إدارة القسم</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
        </div>
        <div class="modal-body">
            <input type="hidden" name="action" id="sectionAction" value="">
            <input type="hidden" name="id" id="sectionId" value="">
            <div class="mb-3">
                <label for="sectionName" class="form-label">اسم القسم</label>
                <input type="text" class="form-control" name="name" id="sectionName" required>
            </div>
            <div class="mb-3">
                <label for="courseSelect" class="form-label">اختر الكورس</label>
                <select class="form-select" name="course_id" id="courseSelect" required>
                    <?php foreach ($courses as $cItem) : ?>
                      <option value="<?php echo $cItem['id']; ?>">
                          <?php echo htmlspecialchars($cItem['name'], ENT_QUOTES, 'UTF-8'); ?>
                      </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
          <button type="submit" class="btn btn-primary">حفظ التغييرات</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- مودال لدرس -->
<div class="modal fade" id="lessonModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="php/action.php" method="POST">
        <div class="modal-header">
          <h5 class="modal-title" id="lessonModalLabel">إدارة الدرس</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
        </div>
        <div class="modal-body">
            <input type="hidden" name="action" id="lessonAction" value="">
            <input type="hidden" name="id" id="lessonId" value="">
            <div class="mb-3">
                <label for="lessonTitle" class="form-label">عنوان الدرس</label>
                <input type="text" class="form-control" name="title" id="lessonTitle" required>
            </div>
            <div class="mb-3">
                <label for="sectionSelect" class="form-label">اختر القسم</label>
                <select class="form-select" name="section_id" id="sectionSelect" required>
                    <?php foreach ($sections as $sItem) : ?>
                      <option value="<?php echo $sItem['id']; ?>">
                          <?php echo htmlspecialchars($sItem['name'], ENT_QUOTES, 'UTF-8'); ?> (<?php echo htmlspecialchars($sItem['course_name'], ENT_QUOTES, 'UTF-8'); ?>)
                      </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
          <button type="submit" class="btn btn-primary">حفظ التغييرات</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- سكربت بسيط لملء بيانات المودال -->
<script>
function openModal(action, id = '', name = '') {
    if(action === 'addCourse') {
        document.getElementById('courseAction').value = 'addCourse';
        document.getElementById('courseId').value = '';
        document.getElementById('courseName').value = '';
    } else if(action === 'editCourse') {
        document.getElementById('courseAction').value = 'editCourse';
        document.getElementById('courseId').value = id;
        document.getElementById('courseName').value = name;
    }

    if(action === 'addSection') {
        document.getElementById('sectionAction').value = 'addSection';
        document.getElementById('sectionId').value = '';
        document.getElementById('sectionName').value = '';
    } else if(action === 'editSection') {
        document.getElementById('sectionAction').value = 'editSection';
        document.getElementById('sectionId').value = id;
        document.getElementById('sectionName').value = name;
    }

    if(action === 'addLesson') {
        document.getElementById('lessonAction').value = 'addLesson';
        document.getElementById('lessonId').value = '';
        document.getElementById('lessonTitle').value = '';
    } else if(action === 'editLesson') {
        document.getElementById('lessonAction').value = 'editLesson';
        document.getElementById('lessonId').value = id;
        document.getElementById('lessonTitle').value = name;
    }
}
</script>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>