<?php
require_once 'auth.php';
header('Content-Type: application/json');

$subscriptionCode = $_POST['code'] ?? '';
$userId = $userId ?? 0; // مستخدم حالياً

if (empty($subscriptionCode)) {
    http_response_code(400);
    echo json_encode(['error' => 'كود الدورة غير موجود']);
    exit;
}

try {
    // جلب الدورة بناءً على الكود
    $stmt = $pdo->prepare("SELECT id, code FROM courses WHERE code = :code LIMIT 1");
    $stmt->execute(['code' => $subscriptionCode]);
    $course = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$course) {
        http_response_code(404);
        echo json_encode(['error' => 'الكود غير صحيح']);
        exit;
    }

    // إضافة الاشتراك
    $insertSub = $pdo->prepare("INSERT INTO subscriptions (user_id, course_id) VALUES (:user_id, :course_id)");
    $insertSub->execute([
        'user_id'   => $userId,
        'course_id' => $course['id']
    ]);

    echo json_encode(['success' => 'تم الاشتراك بنجاح']);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'حدث خطأ أثناء الاشتراك']);
}