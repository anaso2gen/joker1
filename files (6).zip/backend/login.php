<?php
session_start();
// استبدل db.php بملف الاتصال بقاعدة البيانات لديك
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    // التحقق من وجود المستخدم
    $stmt = $pdo->prepare("SELECT id, password FROM users WHERE email = :email LIMIT 1");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        // توليد session_token
        $sessionToken = bin2hex(random_bytes(32));

        // إغلاق أي جلسة سابقة
        $stmt = $pdo->prepare("DELETE FROM sessions WHERE user_id = :user_id");
        $stmt->execute(['user_id' => $user['id']]);

        // تخزين الـ session_token في جدول sessions
        $insert = $pdo->prepare("INSERT INTO sessions (user_id, session_token) VALUES (:user_id, :session_token)");
        $insert->execute([
            'user_id' => $user['id'],
            'session_token' => $sessionToken
        ]);

        // (اختياري) تحديث session_token في جدول users
        $update = $pdo->prepare("UPDATE users SET session_token = :token WHERE id = :user_id");
        $update->execute([
            'token'   => $sessionToken,
            'user_id' => $user['id']
        ]);

        // حفظ التوكن في الكوكي
        setcookie('session_token', $sessionToken, time() + 3600, '/'); // ساعة مثلاً

        // أعادة التوجيه
        header("Location: protected_page.php");
        exit;
    } else {
        $error = "البريد الإلكتروني أو كلمة المرور غير صحيحة";
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8" />
    <title>تسجيل الدخول</title>
</head>
<body>
    <h1>تسجيل الدخول</h1>
    <?php if (!empty($error)) : ?>
        <p style="color: red;"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></p>
    <?php endif; ?>
    <form action="login.php" method="POST">
        <div>
            <label for="email">البريد الإلكتروني:</label>
            <input type="email" name="email" required />
        </div>
        <div>
            <label for="password">كلمة المرور:</label>
            <input type="password" name="password" required />
        </div>
        <button type="submit">تسجيل الدخول</button>
    </form>
</body>
</html>