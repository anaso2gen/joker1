<?php
session_start();
require_once 'db.php';

// جلب التوكن من الكوكي إن وجد
$sessionToken = $_COOKIE['session_token'] ?? '';

if (!empty($sessionToken)) {
    // حذف التوكن من جدول sessions
    $stmt = $pdo->prepare("DELETE FROM sessions WHERE session_token = :session_token");
    $stmt->execute(['session_token' => $sessionToken]);

    // (اختياري) مسح session_token من حساب المستخدم
    $update = $pdo->prepare("UPDATE users SET session_token = NULL WHERE session_token = :session_token");
    $update->execute(['session_token' => $sessionToken]);

    // حذف الكوكي
    setcookie('session_token', '', time() - 3600, '/');
}

// إعادة التوجيه
header("Location: login.php");
exit;