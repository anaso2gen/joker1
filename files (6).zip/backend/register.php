<?php
/**
 * مثال مبسط لتسجيل مستخدم جديد, مع توليد user_id فريد.
 * يجب تعديل أسماء الحقول والجداول حسب تصميم قاعدة البيانات لديك.
 */
session_start();
require_once 'db.php'; // ملف الاتصال بقاعدة البيانات

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (!empty($email) && !empty($password)) {
        // توليد معرف مستخدم فريد (UUID/Hash) باستخدام random_bytes()
        $userUniqueId = bin2hex(random_bytes(16));

        // تأمين كلمة المرور باستخدام password_hash()
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // إدخال بيانات المستخدم إلى قاعدة البيانات (user_id, email, password)
        $stmt = $pdo->prepare("INSERT INTO users (user_id, email, password) VALUES (:uid, :email, :pass)");
        $stmt->execute([
            'uid'   => $userUniqueId,
            'email' => $email,
            'pass'  => $hashedPassword
        ]);

        // إعادة توجيه عند النجاح
        header("Location: login.php");
        exit;
    } else {
        $error = "يجب ملء الحقول المطلوبة.";
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>تسجيل مستخدم جديد</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container py-5">
    <h1 class="mb-4">تسجيل مستخدم جديد</h1>
    <?php if (!empty($error)) : ?>
      <div class="alert alert-danger"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
    <?php endif; ?>
    <form action="register.php" method="POST" class="mb-3">
        <div class="mb-3">
          <label for="email" class="form-label">البريد الإلكتروني</label>
          <input type="email" class="form-control" name="email" required />
        </div>
        <div class="mb-3">
          <label for="password" class="form-label">كلمة المرور</label>
          <input type="password" class="form-control" name="password" required />
        </div>
        <button type="submit" class="btn btn-primary">تسجيل</button>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>