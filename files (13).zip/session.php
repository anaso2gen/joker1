<?php
/**
 * إدارة الجلسات والأمان المتقدم
 * منصة ترند التعليمية - Learning Management System
 * يدعم نظام الجلسة الواحدة وحماية متقدمة
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

require_once __DIR__ . '/functions.php';

class SessionManager {
    private $pdo;
    private $currentUser = null;
    private $sessionTimeout;
    private $maxLoginAttempts;
    private $lockoutTime;
    
    public function __construct() {
        $this->sessionTimeout = defined('SESSION_TIMEOUT') ? SESSION_TIMEOUT : 7200; // 2 hours
        $this->maxLoginAttempts = defined('MAX_LOGIN_ATTEMPTS') ? MAX_LOGIN_ATTEMPTS : 5;
        $this->lockoutTime = defined('LOGIN_LOCKOUT_TIME') ? LOGIN_LOCKOUT_TIME : 900; // 15 minutes
        
        $this->initDatabase();
        $this->startSecureSession();
        $this->checkSessionSecurity();
    }
    
    /**
     * تهيئة الاتصال بقاعدة البيانات
     */
    private function initDatabase() {
        try {
            $this->pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
        } catch (PDOException $e) {
            logSecurityEvent('Database connection failed', 'critical', ['error' => $e->getMessage()]);
            if (defined('DEBUG_MODE') && DEBUG_MODE) {
                die('Database connection failed: ' . $e->getMessage());
            } else {
                die('System temporarily unavailable');
            }
        }
    }
    
    /**
     * بدء جلسة آمنة
     */
    private function startSecureSession() {
        // فحص إذا كانت الجلسة مبدوءة بالفعل
        if (session_status() === PHP_SESSION_ACTIVE) {
            // الجلسة مبدوءة بالفعل، لا نحتاج لتغيير الإعدادات
        } else {
            // إعدادات الجلسة الآمنة قبل بدء الجلسة
            ini_set('session.cookie_httponly', 1);
            ini_set('session.cookie_secure', isset($_SERVER['HTTPS']) ? 1 : 0);
            ini_set('session.use_strict_mode', 1);
            ini_set('session.cookie_samesite', 'Strict');
            
            // بدء الجلسة
            session_start();
        }
        
        // تجديد معرف الجلسة للحماية من Session Fixation
        if (!isset($_SESSION['initiated'])) {
            session_regenerate_id(true);
            $_SESSION['initiated'] = true;
            $_SESSION['start_time'] = time();
        }
        
        // تحديث بيانات المستخدم إذا كان مسجل دخول
        if (isset($_SESSION['user_id'])) {
            $this->loadCurrentUser();
            $this->validateSingleSession();
        }
    }
    
    /**
     * فحص أمان الجلسة
     */
    private function checkSessionSecurity() {
        // فحص انتهاء صلاحية الجلسة
        if (isset($_SESSION['start_time']) && (time() - $_SESSION['start_time'] > $this->sessionTimeout)) {
            $this->logout('Session expired');
            return;
        }
        
        // فحص IP المرتبط بالجلسة
        if (isset($_SESSION['ip_address']) && $_SESSION['ip_address'] !== getRealIpAddress()) {
            logSecurityEvent('IP address change detected', 'high', [
                'old_ip' => $_SESSION['ip_address'],
                'new_ip' => getRealIpAddress(),
                'user_id' => $_SESSION['user_id'] ?? null
            ]);
            
            $this->logout('Security violation: IP changed');
            return;
        }
        
        // فحص User Agent
        if (isset($_SESSION['user_agent']) && $_SESSION['user_agent'] !== ($_SERVER['HTTP_USER_AGENT'] ?? '')) {
            logSecurityEvent('User agent change detected', 'medium', [
                'old_agent' => $_SESSION['user_agent'],
                'new_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                'user_id' => $_SESSION['user_id'] ?? null
            ]);
        }
        
        // تحديث آخر نشاط
        $_SESSION['last_activity'] = time();
        $_SESSION['ip_address'] = getRealIpAddress();
        $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'] ?? '';
    }
    
    /**
     * تحميل بيانات المستخدم الحالي
     */
    private function loadCurrentUser() {
        try {
            $stmt = $this->pdo->prepare("
                SELECT * FROM users 
                WHERE id = ? AND is_active = 1
            ");
            $stmt->execute([$_SESSION['user_id']]);
            $this->currentUser = $stmt->fetch();
            
            if (!$this->currentUser) {
                $this->logout('User account not found or deactivated');
                return;
            }
            
            // تحديث آخر نشاط في قاعدة البيانات
            $this->updateLastActivity();
            
        } catch (PDOException $e) {
            logSecurityEvent('Failed to load user data', 'high', ['error' => $e->getMessage()]);
            $this->logout('Database error');
        }
    }
    
    /**
     * التحقق من نظام الجلسة الواحدة
     */
    private function validateSingleSession() {
        if (!isset($_SESSION['session_token'])) {
            $this->logout('Invalid session token');
            return;
        }
        
        try {
            $stmt = $this->pdo->prepare("
                SELECT * FROM user_sessions 
                WHERE user_id = ? AND session_token = ? AND session_id = ?
            ");
            $stmt->execute([
                $_SESSION['user_id'],
                $_SESSION['session_token'],
                session_id()
            ]);
            
            $session = $stmt->fetch();
            
            if (!$session) {
                logSecurityEvent('Invalid session detected', 'high', [
                    'user_id' => $_SESSION['user_id'],
                    'session_id' => session_id(),
                    'token' => $_SESSION['session_token']
                ]);
                
                $this->logout('Session validation failed');
                return;
            }
            
            // فحص انتهاء صلاحية الجلسة في قاعدة البيانات
            $lastActivity = strtotime($session['last_activity']);
            if (time() - $lastActivity > $this->sessionTimeout) {
                $this->cleanupExpiredSession($_SESSION['user_id']);
                $this->logout('Session expired');
                return;
            }
            
        } catch (PDOException $e) {
            logSecurityEvent('Session validation error', 'critical', ['error' => $e->getMessage()]);
            $this->logout('System error');
        }
    }
    
    /**
     * تسجيل دخول المستخدم
     */
    public function login($email, $password, $rememberMe = false) {
        // فحص محاولات تسجيل الدخول الفاشلة
        if ($this->isAccountLocked($email)) {
            return [
                'success' => false,
                'message' => 'الحساب مؤقتاً لمدة ' . ($this->lockoutTime / 60) . ' دقيقة بسبب محاولات دخول متكررة'
            ];
        }
        
        try {
            $stmt = $this->pdo->prepare("
                SELECT * FROM users 
                WHERE email = ? AND is_active = 1
            ");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password_hash'])) {
                // نجح تسجيل الدخول
                $this->clearFailedAttempts($email);
                $this->createUserSession($user, $rememberMe);
                
                logActivity("User logged in successfully", 'auth', $user['id']);
                
                return [
                    'success' => true,
                    'message' => 'تم تسجيل الدخول بنجاح',
                    'user' => $user,
                    'redirect' => $user['is_admin'] ? 'editdash.php' : 'index.php'
                ];
            } else {
                // فشل تسجيل الدخول
                $this->recordFailedAttempt($email);
                
                logSecurityEvent('Failed login attempt', 'medium', [
                    'email' => $email,
                    'ip' => getRealIpAddress()
                ]);
                
                return [
                    'success' => false,
                    'message' => 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
                ];
            }
            
        } catch (PDOException $e) {
            logSecurityEvent('Login database error', 'critical', ['error' => $e->getMessage()]);
            
            return [
                'success' => false,
                'message' => 'حدث خطأ في النظام، يرجى المحاولة لاحقاً'
            ];
        }
    }
    
    /**
     * إنشاء جلسة جديدة للمستخدم
     */
    private function createUserSession($user, $rememberMe = false) {
        // إنهاء جميع الجلسات السابقة (نظام الجلسة الواحدة)
        $this->terminateAllUserSessions($user['id']);
        
        // إنشاء رمز جلسة جديد
        $sessionToken = bin2hex(random_bytes(32));
        
        // حفظ بيانات الجلسة
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
        $_SESSION['is_admin'] = $user['is_admin'];
        $_SESSION['session_token'] = $sessionToken;
        $_SESSION['login_time'] = time();
        
        // حفظ الجلسة في قاعدة البيانات
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO user_sessions (
                    user_id, session_id, session_token, ip_address, 
                    user_agent, created_at, last_activity
                ) VALUES (?, ?, ?, ?, ?, NOW(), NOW())
            ");
            
            $stmt->execute([
                $user['id'],
                session_id(),
                $sessionToken,
                getRealIpAddress(),
                $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'
            ]);
            
            // تحديث آخر تسجيل دخول
            $updateStmt = $this->pdo->prepare("
                UPDATE users SET last_login = NOW() WHERE id = ?
            ");
            $updateStmt->execute([$user['id']]);
            
        } catch (PDOException $e) {
            logSecurityEvent('Failed to create session record', 'high', ['error' => $e->getMessage()]);
        }
        
        // تحديث كائن المستخدم الحالي
        $this->currentUser = $user;
        
        // إعداد cookie "تذكرني" إذا كان مطلوباً
        if ($rememberMe) {
            $this->setRememberMeCookie($user['id']);
        }
    }
    
    /**
     * إنهاء جميع جلسات المستخدم السابقة
     */
    private function terminateAllUserSessions($userId) {
        try {
            $stmt = $this->pdo->prepare("
                DELETE FROM user_sessions WHERE user_id = ?
            ");
            $stmt->execute([$userId]);
        } catch (PDOException $e) {
            logSecurityEvent('Failed to terminate previous sessions', 'medium', ['error' => $e->getMessage()]);
        }
    }
    
    /**
     * تسجيل محاولة دخول فاشلة
     */
    private function recordFailedAttempt($email) {
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO security_logs (
                    event_type, description, ip_address, user_agent, 
                    additional_data, created_at
                ) VALUES (?, ?, ?, ?, ?, NOW())
            ");
            
            $stmt->execute([
                'failed_login',
                'Failed login attempt for email: ' . $email,
                getRealIpAddress(),
                $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
                json_encode(['email' => $email, 'timestamp' => time()])
            ]);
        } catch (PDOException $e) {
            logSecurityEvent('Failed to record login attempt', 'low', ['error' => $e->getMessage()]);
        }
    }
    
    /**
     * مسح محاولات الدخول الفاشلة
     */
    private function clearFailedAttempts($email) {
        try {
            $stmt = $this->pdo->prepare("
                DELETE FROM security_logs 
                WHERE event_type = 'failed_login' 
                AND additional_data LIKE ? 
                AND created_at > DATE_SUB(NOW(), INTERVAL ? SECOND)
            ");
            
            $stmt->execute(['%' . $email . '%', $this->lockoutTime]);
        } catch (PDOException $e) {
            logSecurityEvent('Failed to clear login attempts', 'low', ['error' => $e->getMessage()]);
        }
    }
    
    /**
     * فحص ما إذا كان الحساب مقفل
     */
    private function isAccountLocked($email) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT COUNT(*) as attempts 
                FROM security_logs 
                WHERE event_type = 'failed_login' 
                AND additional_data LIKE ? 
                AND created_at > DATE_SUB(NOW(), INTERVAL ? SECOND)
            ");
            
            $stmt->execute(['%' . $email . '%', $this->lockoutTime]);
            $result = $stmt->fetch();
            
            return $result['attempts'] >= $this->maxLoginAttempts;
            
        } catch (PDOException $e) {
            logSecurityEvent('Failed to check account lock status', 'medium', ['error' => $e->getMessage()]);
            return false;
        }
    }
    
    /**
     * تحديث آخر نشاط
     */
    private function updateLastActivity() {
        try {
            $stmt = $this->pdo->prepare("
                UPDATE user_sessions 
                SET last_activity = NOW() 
                WHERE user_id = ? AND session_id = ?
            ");
            
            $stmt->execute([$_SESSION['user_id'], session_id()]);
        } catch (PDOException $e) {
            logSecurityEvent('Failed to update last activity', 'low', ['error' => $e->getMessage()]);
        }
    }
    
    /**
     * تنظيف الجلسات المنتهية الصلاحية
     */
    private function cleanupExpiredSession($userId) {
        try {
            $stmt = $this->pdo->prepare("
                DELETE FROM user_sessions 
                WHERE user_id = ? 
                AND last_activity < DATE_SUB(NOW(), INTERVAL ? SECOND)
            ");
            
            $stmt->execute([$userId, $this->sessionTimeout]);
        } catch (PDOException $e) {
            logSecurityEvent('Failed to cleanup expired sessions', 'low', ['error' => $e->getMessage()]);
        }
    }
    
    /**
     * تسجيل خروج المستخدم
     */
    public function logout($reason = 'User initiated logout') {
        if (isset($_SESSION['user_id'])) {
            $userId = $_SESSION['user_id'];
            
            try {
                // حذف الجلسة من قاعدة البيانات
                $stmt = $this->pdo->prepare("
                    DELETE FROM user_sessions 
                    WHERE user_id = ? AND session_id = ?
                ");
                $stmt->execute([$userId, session_id()]);
                
                logActivity("User logged out: $reason", 'auth', $userId);
                
            } catch (PDOException $e) {
                logSecurityEvent('Failed to remove session from database', 'medium', ['error' => $e->getMessage()]);
            }
        }
        
        // تنظيف جميع بيانات الجلسة
        $this->currentUser = null;
        session_unset();
        session_destroy();
        
        // بدء جلسة جديدة
        session_start();
        session_regenerate_id(true);
        $_SESSION['initiated'] = true;
        $_SESSION['start_time'] = time();
    }
    
    /**
     * فحص تسجيل الدخول
     */
    public function isLoggedIn() {
        return isset($_SESSION['user_id']) && $this->currentUser !== null;
    }
    
    /**
     * الحصول على المستخدم الحالي
     */
    public function getCurrentUser() {
        return $this->currentUser;
    }
    
    /**
     * فحص صلاحيات المسؤول
     */
    public function isAdmin() {
        return $this->isLoggedIn() && $this->currentUser['is_admin'] == 1;
    }
    
    /**
     * طلب تسجيل دخول إجباري
     */
    public function requireLogin() {
        if (!$this->isLoggedIn()) {
            $_SESSION['intended_url'] = $_SERVER['REQUEST_URI'];
            header('Location: login.php');
            exit;
        }
    }
    
    /**
     * طلب صلاحيات إدارية
     */
    public function requireAdmin() {
        $this->requireLogin();
        if (!$this->isAdmin()) {
            logSecurityEvent('Unauthorized admin access attempt', 'high', [
                'user_id' => $this->currentUser['id'],
                'requested_url' => $_SERVER['REQUEST_URI']
            ]);
            
            header('Location: index.php');
            exit;
        }
    }
    
    /**
     * تنظيف دوري للجلسات المنتهية الصلاحية
     */
    public function cleanupExpiredSessions() {
        try {
            $stmt = $this->pdo->prepare("
                DELETE FROM user_sessions 
                WHERE last_activity < DATE_SUB(NOW(), INTERVAL ? SECOND)
            ");
            
            $stmt->execute([$this->sessionTimeout]);
            
            $deletedCount = $stmt->rowCount();
            if ($deletedCount > 0) {
                logActivity("Cleaned up $deletedCount expired sessions", 'system');
            }
            
        } catch (PDOException $e) {
            logSecurityEvent('Failed to cleanup expired sessions', 'medium', ['error' => $e->getMessage()]);
        }
    }
}

// إنشاء مدير الجلسات العام
$sessionManager = new SessionManager();

// تنظيف دوري للجلسات المنتهية الصلاحية (5% احتمال)
if (random_int(1, 100) <= 5) {
    $sessionManager->cleanupExpiredSessions();
}
?>