<?php
/**
 * صفحة تفعيل أكواد الاشتراك
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 08:27:50
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/session.php';

// طلب تسجيل الدخول
$sessionManager->requireLogin();

$user = $sessionManager->getCurrentUser();
$error = '';
$success = '';
$codeDetails = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // التحقق من رمز CSRF
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'رمز الأمان غير صحيح. يرجى إعادة المحاولة.';
        logSecurityEvent('CSRF token mismatch in subscription', 'medium', ['user_id' => $user['id']]);
    } else {
        $activationCode = sanitizeInput($_POST['activation_code'] ?? '');
        $action = $_POST['action'] ?? 'check';
        
        if (empty($activationCode)) {
            $error = 'يرجى إدخال كود التفعيل';
        } else {
            try {
                $pdo = new PDO(
                    "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
                    DB_USER, DB_PASS,
                    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
                );
                
                if ($action === 'check') {
                    // فحص صحة الكود
                    $codeDetails = validateActivationCode($pdo, $activationCode, $user['id']);
                    
                    if (!$codeDetails['valid']) {
                        $error = $codeDetails['message'];
                    }
                } elseif ($action === 'activate') {
                    // تفعيل الكود
                    $result = activateSubscriptionCode($pdo, $activationCode, $user['id']);
                    
                    if ($result['success']) {
                        $success = $result['message'];
                        logActivity("Subscription activated successfully with code: $activationCode", 'subscription', $user['id']);
                        
                        // إعادة تحميل الصفحة بعد ثانيتين
                        header("refresh:2;url=courses.php");
                    } else {
                        $error = $result['message'];
                    }
                }
                
            } catch (PDOException $e) {
                logSecurityEvent('Subscription database error', 'high', [
                    'error' => $e->getMessage(),
                    'user_id' => $user['id'],
                    'code' => $activationCode
                ]);
                $error = 'حدث خطأ في النظام. يرجى المحاولة لاحقاً.';
            }
        }
    }
}

// جلب الاشتراكات الحالية للمستخدم
$currentSubscriptions = [];
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    
    $stmt = $pdo->prepare("
        SELECT s.*, c.name as course_name, c.image_url as course_image,
               ac.code as activation_code, ac.expires_at
        FROM subscriptions s
        JOIN courses c ON s.course_id = c.id
        LEFT JOIN activation_codes ac ON s.activation_code_id = ac.id
        WHERE s.user_id = ? AND s.is_active = 1
        ORDER BY s.created_at DESC
    ");
    $stmt->execute([$user['id']]);
    $currentSubscriptions = $stmt->fetchAll();
    
} catch (PDOException $e) {
    logSecurityEvent('Failed to load user subscriptions', 'medium', ['error' => $e->getMessage()]);
}

/**
 * التحقق من صحة كود التفعيل
 */
function validateActivationCode($pdo, $code, $userId) {
    try {
        $stmt = $pdo->prepare("
            SELECT ac.*, c.name as course_name, c.description as course_description,
                   c.price, c.image_url, c.duration_hours,
                   (SELECT COUNT(*) FROM subscriptions s WHERE s.activation_code_id = ac.id) as usage_count
            FROM activation_codes ac
            LEFT JOIN courses c ON ac.course_id = c.id
            WHERE ac.code = ? AND ac.is_active = 1
        ");
        $stmt->execute([$code]);
        $codeData = $stmt->fetch();
        
        if (!$codeData) {
            return [
                'valid' => false,
                'message' => 'كود التفعيل غير صحيح أو منتهي الصلاحية'
            ];
        }
        
        // فحص انتهاء الصلاحية
        if ($codeData['expires_at'] && strtotime($codeData['expires_at']) < time()) {
            return [
                'valid' => false,
                'message' => 'كود التفعيل منتهي الصلاحية'
            ];
        }
        
        // فحص عدد مرات الاستخدام
        if ($codeData['max_uses'] > 0 && $codeData['usage_count'] >= $codeData['max_uses']) {
            return [
                'valid' => false,
                'message' => 'تم استخدام هذا الكود الحد الأقصى المسموح'
            ];
        }
        
        // فحص ما إذا كان المستخدم مشترك بالفعل
        if ($codeData['course_id']) {
            $stmt = $pdo->prepare("
                SELECT id FROM subscriptions 
                WHERE user_id = ? AND course_id = ? AND is_active = 1
            ");
            $stmt->execute([$userId, $codeData['course_id']]);
            
            if ($stmt->fetch()) {
                return [
                    'valid' => false,
                    'message' => 'أنت مشترك بالفعل في هذه الدورة'
                ];
            }
        }
        
        return [
            'valid' => true,
            'data' => $codeData,
            'message' => 'كود التفعيل صحيح ومتاح للاستخدام'
        ];
        
    } catch (PDOException $e) {
        logSecurityEvent('Code validation error', 'medium', ['error' => $e->getMessage()]);
        return [
            'valid' => false,
            'message' => 'خطأ في التحقق من الكود'
        ];
    }
}

/**
 * تفعيل كود الاشتراك
 */
function activateSubscriptionCode($pdo, $code, $userId) {
    try {
        // بدء transaction
        $pdo->beginTransaction();
        
        // إعادة التحقق من الكود
        $validation = validateActivationCode($pdo, $code, $userId);
        if (!$validation['valid']) {
            $pdo->rollBack();
            return [
                'success' => false,
                'message' => $validation['message']
            ];
        }
        
        $codeData = $validation['data'];
        
        // إنشاء الاشتراك
        if ($codeData['course_id']) {
            // اشتراك في دورة محددة
            $stmt = $pdo->prepare("
                INSERT INTO subscriptions (user_id, course_id, activation_code_id, 
                                         subscription_type, expires_at, is_active, created_at)
                VALUES (?, ?, ?, 'code', ?, 1, NOW())
            ");
            
            $expiresAt = $codeData['subscription_days'] > 0 
                       ? date('Y-m-d H:i:s', strtotime("+{$codeData['subscription_days']} days"))
                       : null;
            
            $stmt->execute([
                $userId,
                $codeData['course_id'],
                $codeData['id'],
                $expiresAt
            ]);
            
            $message = "تم تفعيل اشتراكك في دورة: " . $codeData['course_name'];
            
        } else {
            // اشتراك عام (جميع الدورات)
            $stmt = $pdo->prepare("
                SELECT id FROM courses WHERE is_active = 1
            ");
            $stmt->execute();
            $courses = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            foreach ($courses as $courseId) {
                $stmt = $pdo->prepare("
                    INSERT INTO subscriptions (user_id, course_id, activation_code_id, 
                                             subscription_type, expires_at, is_active, created_at)
                    VALUES (?, ?, ?, 'code', ?, 1, NOW())
                    ON DUPLICATE KEY UPDATE 
                    expires_at = VALUES(expires_at), is_active = 1
                ");
                
                $expiresAt = $codeData['subscription_days'] > 0 
                           ? date('Y-m-d H:i:s', strtotime("+{$codeData['subscription_days']} days"))
                           : null;
                
                $stmt->execute([$userId, $courseId, $codeData['id'], $expiresAt]);
            }
            
            $message = "تم تفعيل اشتراكك في جميع الدورات المتاحة";
        }
        
        // تحديث استخدام الكود
        $stmt = $pdo->prepare("
            UPDATE activation_codes 
            SET used_count = used_count + 1, last_used_at = NOW()
            WHERE id = ?
        ");
        $stmt->execute([$codeData['id']]);
        
        // تسجيل عملية التفعيل
        $stmt = $pdo->prepare("
            INSERT INTO code_usage_log (activation_code_id, user_id, ip_address, 
                                       user_agent, created_at)
            VALUES (?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $codeData['id'],
            $userId,
            getRealIpAddress(),
            $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'
        ]);
        
        $pdo->commit();
        
        return [
            'success' => true,
            'message' => $message
        ];
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        logSecurityEvent('Code activation error', 'high', [
            'error' => $e->getMessage(),
            'user_id' => $userId,
            'code' => $code
        ]);
        
        return [
            'success' => false,
            'message' => 'فشل في تفعيل الكود. يرجى المحاولة لاحقاً.'
        ];
    }
}

// تضمين ملف العرض
require_once __DIR__ . '/frontend/views/pages/subscribe.php';
?>