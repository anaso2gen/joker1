#!/usr/bin/env php
<?php
/**
 * سكريپت تحسين الأداء
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 10:45:07
 */

// تحديد المسار الجذر
define('APP_ROOT', dirname(__DIR__));
define('APP_INIT', true);

// تحميل الإعدادات
require_once APP_ROOT . '/config/constants.php';
require_once APP_ROOT . '/config/config.php';

class PerformanceOptimizer
{
    private $config;
    private $startTime;
    private $logFile;
    private $db;
    private $optimizationResults = [];

    public function __construct()
    {
        $this->config = include APP_ROOT . '/config/app.php';
        $this->startTime = microtime(true);
        $this->setupLogging();
        $this->initializeDatabase();
    }

    /**
     * إعداد نظام التسجيل
     */
    private function setupLogging()
    {
        $logDir = APP_ROOT . '/storage/logs';
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $this->logFile = $logDir . '/optimization.log';
    }

    /**
     * تهيئة قاعدة البيانات
     */
    private function initializeDatabase()
    {
        try {
            $this->db = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                ]
            );
        } catch (PDOException $e) {
            $this->log("فشل في الاتصال بقاعدة البيانات: " . $e->getMessage(), 'ERROR');
            exit(1);
        }
    }

    /**
     * تشغيل تحسين الأداء
     */
    public function run($options = [])
    {
        try {
            $this->log("بدء عملية تحسين الأداء");
            
            // تحليل الأداء الحالي
            $this->analyzeCurrentPerformance();
            
            // تحسين قاعدة البيانات
            if (!isset($options['skip_database']) || !$options['skip_database']) {
                $this->optimizeDatabase();
            }
            
            // تحسين الفهارس
            if (!isset($options['skip_indexes']) || !$options['skip_indexes']) {
                $this->optimizeIndexes();
            }
            
            // تحسين ملفات CSS و JS
            if (!isset($options['skip_assets']) || !$options['skip_assets']) {
                $this->optimizeAssets();
            }
            
            // تحسين الصور
            if (!isset($options['skip_images']) || !$options['skip_images']) {
                $this->optimizeImages();
            }
            
            // تحسين ملفات التخزين المؤقت
            if (!isset($options['skip_cache']) || !$options['skip_cache']) {
                $this->optimizeCache();
            }
            
            // تحسين إعدادات PHP
            if (!isset($options['skip_php']) || !$options['skip_php']) {
                $this->optimizePHPSettings();
            }
            
            // تحسين إعدادات الخادم
            if (isset($options['server_config']) && $options['server_config']) {
                $this->generateServerConfig();
            }
            
            // إنشاء تقرير التحسين
            $this->generateOptimizationReport();
            
            $duration = round(microtime(true) - $this->startTime, 2);
            $this->log("اكتملت عملية التحسين بنجاح - المدة: {$duration}s");
            
            return [
                'success' => true,
                'duration' => $duration,
                'results' => $this->optimizationResults
            ];
            
        } catch (Exception $e) {
            $this->log("خطأ في عملية التحسين: " . $e->getMessage(), 'ERROR');
            
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * تحليل الأداء الحالي
     */
    private function analyzeCurrentPerformance()
    {
        $this->log("تحليل الأداء الحالي");
        
        $analysis = [];
        
        // تحليل قاعدة البيانات
        $analysis['database'] = $this->analyzeDatabasePerformance();
        
        // تحليل استخدام الذاكرة
        $analysis['memory'] = $this->analyzeMemoryUsage();
        
        // تحليل مساحة القرص
        $analysis['disk'] = $this->analyzeDiskUsage();
        
        // تحليل حجم الملفات
        $analysis['files'] = $this->analyzeFileSize();
        
        $this->optimizationResults['initial_analysis'] = $analysis;
        
        $this->log("اكتمل تحليل الأداء الحالي");
    }

    /**
     * تحليل أداء قاعدة البيانات
     */
    private function analyzeDatabasePerformance()
    {
        $analysis = [];
        
        try {
            // حجم قاعدة البيانات
            $stmt = $this->db->query("
                SELECT 
                    ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS 'database_size_mb',
                    ROUND(SUM(data_length) / 1024 / 1024, 2) AS 'data_size_mb',
                    ROUND(SUM(index_length) / 1024 / 1024, 2) AS 'index_size_mb'
                FROM information_schema.tables 
                WHERE table_schema = '" . DB_NAME . "'
            ");
            $dbSize = $stmt->fetch();
            $analysis['size'] = $dbSize;
            
            // الاستعلامات البطيئة
            $stmt = $this->db->query("SHOW VARIABLES LIKE 'slow_query_log'");
            $slowLog = $stmt->fetch();
            $analysis['slow_query_log'] = $slowLog['Value'] ?? 'OFF';
            
            // إحصائيات الجداول
            $stmt = $this->db->query("
                SELECT 
                    table_name,
                    table_rows,
                    ROUND((data_length + index_length) / 1024 / 1024, 2) AS 'size_mb'
                FROM information_schema.tables 
                WHERE table_schema = '" . DB_NAME . "'
                ORDER BY (data_length + index_length) DESC
                LIMIT 10
            ");
            $analysis['largest_tables'] = $stmt->fetchAll();
            
            // الفهارس غير المستخدمة
            $analysis['unused_indexes'] = $this->findUnusedIndexes();
            
        } catch (PDOException $e) {
            $this->log("خطأ في تحليل قاعدة البيانات: " . $e->getMessage(), 'ERROR');
        }
        
        return $analysis;
    }

    /**
     * البحث عن الفهارس غير المستخدمة
     */
    private function findUnusedIndexes()
    {
        try {
            $stmt = $this->db->query("
                SELECT 
                    t.table_schema,
                    t.table_name,
                    t.index_name
                FROM information_schema.statistics t
                LEFT JOIN performance_schema.table_io_waits_summary_by_index_usage p 
                    ON t.table_schema = p.object_schema 
                    AND t.table_name = p.object_name 
                    AND t.index_name = p.index_name
                WHERE t.table_schema = '" . DB_NAME . "'
                    AND t.index_name != 'PRIMARY'
                    AND p.index_name IS NULL
                GROUP BY t.table_schema, t.table_name, t.index_name
            ");
            
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            return [];
        }
    }

    /**
     * تحليل استخدام الذاكرة
     */
    private function analyzeMemoryUsage()
    {
        return [
            'memory_limit' => ini_get('memory_limit'),
            'memory_usage' => memory_get_usage(true),
            'peak_memory' => memory_get_peak_usage(true),
            'available_memory' => $this->getAvailableMemory()
        ];
    }

    /**
     * الحصول على الذاكرة المتاحة
     */
    private function getAvailableMemory()
    {
        $memLimit = ini_get('memory_limit');
        
        if ($memLimit == -1) {
            return 'unlimited';
        }
        
        $memLimit = $this->parseBytes($memLimit);
        $memUsage = memory_get_usage(true);
        
        return $memLimit - $memUsage;
    }

    /**
     * تحويل وحدات الذاكرة إلى بايت
     */
    private function parseBytes($val)
    {
        $val = trim($val);
        $last = strtolower($val[strlen($val)-1]);
        $val = (int) $val;
        
        switch($last) {
            case 'g':
                $val *= 1024;
            case 'm':
                $val *= 1024;
            case 'k':
                $val *= 1024;
        }
        
        return $val;
    }

    /**
     * تحليل استخدام القرص
     */
    private function analyzeDiskUsage()
    {
        return [
            'total_space' => disk_total_space(APP_ROOT),
            'free_space' => disk_free_space(APP_ROOT),
            'used_space' => disk_total_space(APP_ROOT) - disk_free_space(APP_ROOT)
        ];
    }

    /**
     * تحليل حجم الملفات
     */
    private function analyzeFileSize()
    {
        $sizes = [];
        
        $directories = [
            'storage' => APP_ROOT . '/storage',
            'public/uploads' => APP_ROOT . '/public/uploads',
            'assets' => APP_ROOT . '/assets'
        ];
        
        foreach ($directories as $name => $path) {
            if (is_dir($path)) {
                $sizes[$name] = $this->getDirectorySize($path);
            }
        }
        
        return $sizes;
    }

    /**
     * تحسين قاعدة البيانات
     */
    private function optimizeDatabase()
    {
        $this->log("بدء تحسين قاعدة البيانات");
        
        $results = [];
        
        try {
            // الحصول على قائمة الجداول
            $stmt = $this->db->query("SHOW TABLES");
            $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            foreach ($tables as $table) {
                // تحليل الجدول
                $this->db->exec("ANALYZE TABLE `{$table}`");
                
                // إصلاح الجدول إذا لزم الأمر
                $stmt = $this->db->query("CHECK TABLE `{$table}`");
                $checkResult = $stmt->fetch();
                
                if ($checkResult['Msg_text'] !== 'OK') {
                    $this->db->exec("REPAIR TABLE `{$table}`");
                    $results['repaired'][] = $table;
                }
                
                // تحسين الجدول
                $this->db->exec("OPTIMIZE TABLE `{$table}`");
                $results['optimized'][] = $table;
            }
            
            // تحديث إحصائيات MySQL
            $this->db->exec("FLUSH TABLES");
            $this->db->exec("RESET QUERY CACHE");
            
            $this->optimizationResults['database'] = $results;
            $this->log("اكتمل تحسين قاعدة البيانات - تم تحسين " . count($tables) . " جدول");
            
        } catch (PDOException $e) {
            $this->log("خطأ في تحسين قاعدة البيانات: " . $e->getMessage(), 'ERROR');
        }
    }

    /**
     * تحسين الفهارس
     */
    private function optimizeIndexes()
    {
        $this->log("بدء تحسين الفهارس");
        
        $results = [];
        
        try {
            // إنشاء فهارس مفقودة مهمة
            $indexesToCreate = [
                'users' => [
                    'idx_email_status' => ['email', 'status'],
                    'idx_created_at' => ['created_at'],
                    'idx_last_login' => ['last_login_at']
                ],
                'courses' => [
                    'idx_status_featured' => ['status', 'is_featured'],
                    'idx_category_status' => ['category_id', 'status'],
                    'idx_created_at' => ['created_at']
                ],
                'enrollments' => [
                    'idx_user_course' => ['user_id', 'course_id'],
                    'idx_status_enrolled' => ['status', 'enrolled_at'],
                    'idx_progress' => ['progress_percentage']
                ],
                'lessons' => [
                    'idx_course_order' => ['course_id', 'sort_order'],
                    'idx_status' => ['status']
                ],
                'lesson_progress' => [
                    'idx_user_lesson' => ['user_id', 'lesson_id'],
                    'idx_completed' => ['is_completed', 'completed_at']
                ]
            ];
            
            foreach ($indexesToCreate as $table => $indexes) {
                foreach ($indexes as $indexName => $columns) {
                    if (!$this->indexExists($table, $indexName)) {
                        $columnList = implode(', ', array_map(function($col) {
                            return "`{$col}`";
                        }, $columns));
                        
                        $sql = "CREATE INDEX `{$indexName}` ON `{$table}` ({$columnList})";
                        
                        try {
                            $this->db->exec($sql);
                            $results['created'][] = "{$table}.{$indexName}";
                            $this->log("تم إنشاء فهرس {$indexName} على جدول {$table}");
                        } catch (PDOException $e) {
                            $this->log("فشل في إنشاء فهرس {$indexName}: " . $e->getMessage(), 'WARNING');
                        }
                    }
                }
            }
            
            // حذف الفهارس غير المستخدمة (اختياري - يتطلب حذر)
            $unusedIndexes = $this->findUnusedIndexes();
            foreach ($unusedIndexes as $index) {
                if (isset($options['remove_unused_indexes']) && $options['remove_unused_indexes']) {
                    $sql = "DROP INDEX `{$index['index_name']}` ON `{$index['table_name']}`";
                    try {
                        $this->db->exec($sql);
                        $results['removed'][] = "{$index['table_name']}.{$index['index_name']}";
                    } catch (PDOException $e) {
                        $this->log("فشل في حذف فهرس {$index['index_name']}: " . $e->getMessage(), 'WARNING');
                    }
                }
            }
            
            $this->optimizationResults['indexes'] = $results;
            $this->log("اكتمل تحسين الفهارس");
            
        } catch (Exception $e) {
            $this->log("خطأ في تحسين الفهارس: " . $e->getMessage(), 'ERROR');
        }
    }

    /**
     * فحص وجود فهرس
     */
    private function indexExists($table, $indexName)
    {
        try {
            $stmt = $this->db->prepare("
                SELECT COUNT(*) 
                FROM information_schema.statistics 
                WHERE table_schema = ? 
                AND table_name = ? 
                AND index_name = ?
            ");
            $stmt->execute([DB_NAME, $table, $indexName]);
            
            return $stmt->fetchColumn() > 0;
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * تحسين ملفات CSS و JS
     */
    private function optimizeAssets()
    {
        $this->log("بدء تحسين ملفات CSS و JS");
        
        $results = [
            'css' => ['original_size' => 0, 'compressed_size' => 0, 'files' => []],
            'js' => ['original_size' => 0, 'compressed_size' => 0, 'files' => []]
        ];
        
        // تحسين ملفات CSS
        $cssFiles = glob(APP_ROOT . '/assets/css/*.css');
        foreach ($cssFiles as $file) {
            if (strpos($file, '.min.') === false) {
                $originalSize = filesize($file);
                $compressedContent = $this->compressCSS(file_get_contents($file));
                $compressedFile = str_replace('.css', '.min.css', $file);
                
                file_put_contents($compressedFile, $compressedContent);
                $compressedSize = filesize($compressedFile);
                
                $results['css']['original_size'] += $originalSize;
                $results['css']['compressed_size'] += $compressedSize;
                $results['css']['files'][] = basename($file);
            }
        }
        
        // تحسين ملفات JS
        $jsFiles = glob(APP_ROOT . '/assets/js/*.js');
        foreach ($jsFiles as $file) {
            if (strpos($file, '.min.') === false) {
                $originalSize = filesize($file);
                $compressedContent = $this->compressJS(file_get_contents($file));
                $compressedFile = str_replace('.js', '.min.js', $file);
                
                file_put_contents($compressedFile, $compressedContent);
                $compressedSize = filesize($compressedFile);
                
                $results['js']['original_size'] += $originalSize;
                $results['js']['compressed_size'] += $compressedSize;
                $results['js']['files'][] = basename($file);
            }
        }
        
        $this->optimizationResults['assets'] = $results;
        
        $cssCompressionRatio = $results['css']['original_size'] > 0 ? 
            round((1 - $results['css']['compressed_size'] / $results['css']['original_size']) * 100, 2) : 0;
        $jsCompressionRatio = $results['js']['original_size'] > 0 ? 
            round((1 - $results['js']['compressed_size'] / $results['js']['original_size']) * 100, 2) : 0;
        
        $this->log("اكتمل تحسين الملفات - CSS: {$cssCompressionRatio}% ضغط، JS: {$jsCompressionRatio}% ضغط");
    }

    /**
     * ضغط CSS
     */
    private function compressCSS($css)
    {
        // إزالة التعليقات
        $css = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $css);
        
        // إزالة المسافات الزائدة
        $css = str_replace(["\r\n", "\r", "\n", "\t"], '', $css);
        $css = preg_replace('/\s+/', ' ', $css);
        
        // إزالة المسافات حول الرموز
        $css = str_replace(['; ', ' ;', ' {', '{ ', '} ', ' }', ': ', ' :', ', ', ' ,'], 
                          [';', ';', '{', '{', '}', '}', ':', ':', ',', ','], $css);
        
        return trim($css);
    }

    /**
     * ضغط JavaScript
     */
    private function compressJS($js)
    {
        // إزالة التعليقات
        $js = preg_replace('/(?:(?:\/\*(?:[^*]|(?:\*+[^*\/]))*\*+\/)|(?:(?<!http:)(?<!https:)\/\/.*))/', '', $js);
        
        // إزالة المسافات الزائدة
        $js = preg_replace('/\s+/', ' ', $js);
        
        // إزالة المسافات حول الرموز
        $js = str_replace([' = ', ' == ', ' != ', ' <= ', ' >= ', ' && ', ' || ', ' + ', ' - ', ' * ', ' / '], 
                         ['=', '==', '!=', '<=', '>=', '&&', '||', '+', '-', '*', '/'], $js);
        
        return trim($js);
    }

    /**
     * تحسين الصور
     */
    private function optimizeImages()
    {
        $this->log("بدء تحسين الصور");
        
        $results = ['original_size' => 0, 'compressed_size' => 0, 'files' => []];
        
        $imageDirectories = [
            APP_ROOT . '/public/uploads',
            APP_ROOT . '/assets/images'
        ];
        
        foreach ($imageDirectories as $directory) {
            if (is_dir($directory)) {
                $images = $this->findImages($directory);
                
                foreach ($images as $image) {
                    $originalSize = filesize($image);
                    
                    if ($this->compressImage($image)) {
                        $compressedSize = filesize($image);
                        $results['original_size'] += $originalSize;
                        $results['compressed_size'] += $compressedSize;
                        $results['files'][] = str_replace(APP_ROOT, '', $image);
                    }
                }
            }
        }
        
        $this->optimizationResults['images'] = $results;
        
        $compressionRatio = $results['original_size'] > 0 ? 
            round((1 - $results['compressed_size'] / $results['original_size']) * 100, 2) : 0;
        
        $this->log("اكتمل تحسين الصور - تم ضغط " . count($results['files']) . " صورة بنسبة {$compressionRatio}%");
    }

    /**
     * البحث عن الصور
     */
    private function findImages($directory)
    {
        $images = [];
        $extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $ext = strtolower($file->getExtension());
                if (in_array($ext, $extensions)) {
                    $images[] = $file->getPathname();
                }
            }
        }
        
        return $images;
    }

    /**
     * ضغط صورة
     */
    private function compressImage($imagePath)
    {
        $imageInfo = getimagesize($imagePath);
        
        if (!$imageInfo) {
            return false;
        }
        
        $mimeType = $imageInfo['mime'];
        
        switch ($mimeType) {
            case 'image/jpeg':
                return $this->compressJPEG($imagePath);
            case 'image/png':
                return $this->compressPNG($imagePath);
            case 'image/gif':
                return $this->compressGIF($imagePath);
            default:
                return false;
        }
    }

    /**
     * ضغط صورة JPEG
     */
    private function compressJPEG($imagePath)
    {
        $image = imagecreatefromjpeg($imagePath);
        
        if (!$image) {
            return false;
        }
        
        $result = imagejpeg($image, $imagePath, 85); // جودة 85%
        imagedestroy($image);
        
        return $result;
    }

    /**
     * ضغط صورة PNG
     */
    private function compressPNG($imagePath)
    {
        $image = imagecreatefrompng($imagePath);
        
        if (!$image) {
            return false;
        }
        
        imagesavealpha($image, true);
        $result = imagepng($image, $imagePath, 6); // مستوى ضغط 6
        imagedestroy($image);
        
        return $result;
    }

    /**
     * ضغط صورة GIF
     */
    private function compressGIF($imagePath)
    {
        // GIF لا يحتاج ضغط إضافي عادة
        return true;
    }

    /**
     * تحسين ملفات التخزين المؤقت
     */
    private function optimizeCache()
    {
        $this->log("بدء تحسين ملفات التخزين المؤقت");
        
        $results = [];
        
        // إنشاء ملفات cache مجمعة
        $this->generateCombinedAssets();
        
        // تحسين OpCache
        if (function_exists('opcache_compile_file')) {
            $results['opcache'] = $this->precompileScripts();
        }
        
        // تحسين APCu
        if (extension_loaded('apcu')) {
            $results['apcu'] = $this->optimizeAPCu();
        }
        
        $this->optimizationResults['cache'] = $results;
        $this->log("اكتمل تحسين ملفات التخزين المؤقت");
    }

    /**
     * إنشاء ملفات مجمعة للأصول
     */
    private function generateCombinedAssets()
    {
        // دمج ملفات CSS
        $cssFiles = [
            APP_ROOT . '/assets/css/main.css',
            APP_ROOT . '/assets/css/auth.css',
            APP_ROOT . '/assets/css/dashboard.css'
        ];
        
        $combinedCSS = '';
        foreach ($cssFiles as $file) {
            if (file_exists($file)) {
                $combinedCSS .= file_get_contents($file) . "\n";
            }
        }
        
        if ($combinedCSS) {
            $compressedCSS = $this->compressCSS($combinedCSS);
            file_put_contents(APP_ROOT . '/assets/css/combined.min.css', $compressedCSS);
        }
        
        // دمج ملفات JS
        $jsFiles = [
            APP_ROOT . '/assets/js/main.js',
            APP_ROOT . '/assets/js/api.js',
            APP_ROOT . '/assets/js/auth.js'
        ];
        
        $combinedJS = '';
        foreach ($jsFiles as $file) {
            if (file_exists($file)) {
                $combinedJS .= file_get_contents($file) . ";\n";
            }
        }
        
        if ($combinedJS) {
            $compresse