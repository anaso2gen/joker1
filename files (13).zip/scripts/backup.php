#!/usr/bin/env php
<?php
/**
 * سكريپت النسخ الاحتياطي
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 10:42:09
 */

// تحديد المسار الجذر
define('APP_ROOT', dirname(__DIR__));
define('APP_INIT', true);

// تحميل الإعدادات
require_once APP_ROOT . '/config/constants.php';
require_once APP_ROOT . '/config/config.php';

class BackupManager
{
    private $config;
    private $startTime;
    private $logFile;
    private $backupPath;
    private $tempPath;

    public function __construct()
    {
        $this->config = include APP_ROOT . '/config/app.php';
        $this->startTime = microtime(true);
        $this->setupPaths();
        $this->setupLogging();
    }

    /**
     * إعداد المسارات
     */
    private function setupPaths()
    {
        $this->backupPath = APP_ROOT . '/storage/backups';
        $this->tempPath = APP_ROOT . '/storage/temp/backup';

        if (!is_dir($this->backupPath)) {
            mkdir($this->backupPath, 0755, true);
        }

        if (!is_dir($this->tempPath)) {
            mkdir($this->tempPath, 0755, true);
        }
    }

    /**
     * إعداد نظام التسجيل
     */
    private function setupLogging()
    {
        $this->logFile = APP_ROOT . '/storage/logs/backup.log';
        
        if (!is_dir(dirname($this->logFile))) {
            mkdir(dirname($this->logFile), 0755, true);
        }
    }

    /**
     * تشغيل النسخ الاحتياطي
     */
    public function run($type = 'full')
    {
        try {
            $this->log("بدء النسخ الاحتياطي - النوع: {$type}");
            
            // التحقق من الشروط المسبقة
            $this->checkPrerequisites();
            
            // إنشاء مجلد النسخة الاحتياطية
            $backupName = $this->generateBackupName($type);
            $backupDir = $this->tempPath . '/' . $backupName;
            
            if (!mkdir($backupDir, 0755, true)) {
                throw new Exception("فشل في إنشاء مجلد النسخة الاحتياطية: {$backupDir}");
            }
            
            // نسخ احتياطي لقاعدة البيانات
            $this->backupDatabase($backupDir);
            
            // نسخ احتياطي للملفات
            if ($type === 'full' || $type === 'files') {
                $this->backupFiles($backupDir);
            }
            
            // إنشاء ملف المعلومات
            $this->createInfoFile($backupDir, $type);
            
            // ضغط النسخة الاحتياطية
            $archivePath = $this->compressBackup($backupDir, $backupName);
            
            // تشفير النسخة الاحتياطية
            if ($this->config['backup']['encryption']['enabled']) {
                $archivePath = $this->encryptBackup($archivePath);
            }
            
            // رفع النسخة الاحتياطية للتخزين السحابي
            $this->uploadToCloud($archivePath);
            
            // تنظيف النسخ القديمة
            $this->cleanupOldBackups();
            
            // تنظيف الملفات المؤقتة
            $this->cleanupTempFiles($backupDir);
            
            $duration = round(microtime(true) - $this->startTime, 2);
            $size = $this->formatBytes(filesize($archivePath));
            
            $this->log("اكتمل النسخ الاحتياطي بنجاح - المدة: {$duration}s - الحجم: {$size}");
            
            return [
                'success' => true,
                'backup_name' => $backupName,
                'file_path' => $archivePath,
                'size' => filesize($archivePath),
                'duration' => $duration
            ];
            
        } catch (Exception $e) {
            $this->log("خطأ في النسخ الاحتياطي: " . $e->getMessage(), 'ERROR');
            
            // تنظيف الملفات المؤقتة في حالة الخطأ
            if (isset($backupDir) && is_dir($backupDir)) {
                $this->recursiveRemoveDirectory($backupDir);
            }
            
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * التحقق من الشروط المسبقة
     */
    private function checkPrerequisites()
    {
        // التحقق من مساحة القرص المتاحة
        $freeSpace = disk_free_space($this->backupPath);
        $requiredSpace = $this->estimateBackupSize();
        
        if ($freeSpace < $requiredSpace * 1.5) { // 50% مساحة إضافية للأمان
            throw new Exception("مساحة القرص غير كافية للنسخ الاحتياطي");
        }
        
        // التحقق من وجود قاعدة البيانات
        try {
            $pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
        } catch (PDOException $e) {
            throw new Exception("فشل في الاتصال بقاعدة البيانات: " . $e->getMessage());
        }
        
        // التحقق من أدوات الضغط
        if (!class_exists('ZipArchive')) {
            throw new Exception("مكتبة ZipArchive غير متوفرة");
        }
        
        $this->log("تم التحقق من الشروط المسبقة بنجاح");
    }

    /**
     * تقدير حجم النسخة الاحتياطية
     */
    private function estimateBackupSize()
    {
        $dbSize = $this->getDatabaseSize();
        $filesSize = $this->getFilesSize();
        
        return $dbSize + $filesSize;
    }

    /**
     * الحصول على حجم قاعدة البيانات
     */
    private function getDatabaseSize()
    {
        try {
            $pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
            
            $stmt = $pdo->query("
                SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 1) AS 'DB Size in MB' 
                FROM information_schema.tables 
                WHERE table_schema='" . DB_NAME . "'
            ");
            
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return ($result['DB Size in MB'] ?? 0) * 1024 * 1024; // تحويل إلى بايت
            
        } catch (Exception $e) {
            $this->log("فشل في حساب حجم قاعدة البيانات: " . $e->getMessage(), 'WARNING');
            return 100 * 1024 * 1024; // افتراض 100MB
        }
    }

    /**
     * الحصول على حجم الملفات
     */
    private function getFilesSize()
    {
        $totalSize = 0;
        $includePaths = $this->config['backup']['files']['include'];
        
        foreach ($includePaths as $path) {
            $fullPath = APP_ROOT . '/' . $path;
            if (is_dir($fullPath)) {
                $totalSize += $this->getDirectorySize($fullPath);
            } elseif (is_file($fullPath)) {
                $totalSize += filesize($fullPath);
            }
        }
        
        return $totalSize;
    }

    /**
     * الحصول على حجم المجلد
     */
    private function getDirectorySize($directory)
    {
        $size = 0;
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $size += $file->getSize();
            }
        }
        
        return $size;
    }

    /**
     * إنشاء اسم النسخة الاحتياطية
     */
    private function generateBackupName($type)
    {
        $timestamp = date('Y-m-d_H-i-s');
        $hostname = gethostname() ?: 'server';
        
        return "trend_academy_{$type}_{$timestamp}_{$hostname}";
    }

    /**
     * نسخ احتياطي لقاعدة البيانات
     */
    private function backupDatabase($backupDir)
    {
        $this->log("بدء نسخ قاعدة البيانات الاحتياطي");
        
        $sqlFile = $backupDir . '/database.sql';
        $command = sprintf(
            'mysqldump --host=%s --user=%s --password=%s --single-transaction --routines --triggers --add-drop-table %s > %s 2>&1',
            escapeshellarg(DB_HOST),
            escapeshellarg(DB_USER),
            escapeshellarg(DB_PASS),
            escapeshellarg(DB_NAME),
            escapeshellarg($sqlFile)
        );
        
        exec($command, $output, $returnCode);
        
        if ($returnCode !== 0) {
            // محاولة النسخ الاحتياطي عبر PHP إذا فشل mysqldump
            $this->log("فشل mysqldump، محاولة النسخ عبر PHP", 'WARNING');
            $this->backupDatabaseViaPHP($sqlFile);
        }
        
        if (!file_exists($sqlFile) || filesize($sqlFile) === 0) {
            throw new Exception("فشل في إنشاء نسخة احتياطية من قاعدة البيانات");
        }
        
        $this->log("اكتمل نسخ قاعدة البيانات الاحتياطي - الحجم: " . $this->formatBytes(filesize($sqlFile)));
    }

    /**
     * نسخ احتياطي لقاعدة البيانات عبر PHP
     */
    private function backupDatabaseViaPHP($sqlFile)
    {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        
        $fp = fopen($sqlFile, 'w');
        
        if (!$fp) {
            throw new Exception("فشل في فتح ملف SQL للكتابة");
        }
        
        // كتابة رأس الملف
        fwrite($fp, "-- نسخة احتياطية من قاعدة البيانات\n");
        fwrite($fp, "-- تاريخ الإنشاء: " . date('Y-m-d H:i:s') . "\n");
        fwrite($fp, "-- قاعدة البيانات: " . DB_NAME . "\n\n");
        
        fwrite($fp, "SET FOREIGN_KEY_CHECKS=0;\n");
        fwrite($fp, "SET SQL_MODE=\"NO_AUTO_VALUE_ON_ZERO\";\n\n");
        
        // الحصول على قائمة الجداول
        $stmt = $pdo->query("SHOW TABLES");
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        foreach ($tables as $table) {
            $this->dumpTable($pdo, $fp, $table);
        }
        
        fwrite($fp, "SET FOREIGN_KEY_CHECKS=1;\n");
        fclose($fp);
    }

    /**
     * نسخ جدول واحد
     */
    private function dumpTable($pdo, $fp, $table)
    {
        // هيكل الجدول
        fwrite($fp, "\n-- هيكل الجدول `{$table}`\n");
        fwrite($fp, "DROP TABLE IF EXISTS `{$table}`;\n");
        
        $stmt = $pdo->query("SHOW CREATE TABLE `{$table}`");
        $createTable = $stmt->fetch(PDO::FETCH_ASSOC);
        fwrite($fp, $createTable['Create Table'] . ";\n\n");
        
        // بيانات الجدول
        $stmt = $pdo->query("SELECT * FROM `{$table}`");
        $rowCount = 0;
        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            if ($rowCount === 0) {
                fwrite($fp, "-- بيانات الجدول `{$table}`\n");
                fwrite($fp, "INSERT INTO `{$table}` VALUES\n");
            }
            
            $values = array_map(function($value) use ($pdo) {
                return $value === null ? 'NULL' : $pdo->quote($value);
            }, array_values($row));
            
            $comma = $rowCount > 0 ? ',' : '';
            fwrite($fp, $comma . '(' . implode(',', $values) . ")\n");
            $rowCount++;
        }
        
        if ($rowCount > 0) {
            fwrite($fp, ";\n\n");
        }
    }

    /**
     * نسخ احتياطي للملفات
     */
    private function backupFiles($backupDir)
    {
        $this->log("بدء نسخ الملفات الاحتياطي");
        
        $filesDir = $backupDir . '/files';
        mkdir($filesDir, 0755, true);
        
        $includePaths = $this->config['backup']['files']['include'];
        $excludePaths = $this->config['backup']['files']['exclude'];
        
        foreach ($includePaths as $path) {
            $sourcePath = APP_ROOT . '/' . $path;
            $destPath = $filesDir . '/' . $path;
            
            if (is_dir($sourcePath)) {
                $this->copyDirectory($sourcePath, $destPath, $excludePaths);
            } elseif (is_file($sourcePath)) {
                $destDir = dirname($destPath);
                if (!is_dir($destDir)) {
                    mkdir($destDir, 0755, true);
                }
                copy($sourcePath, $destPath);
            }
        }
        
        $this->log("اكتمل نسخ الملفات الاحتياطي");
    }

    /**
     * نسخ مجلد مع استثناءات
     */
    private function copyDirectory($source, $dest, $exclude = [])
    {
        if (!is_dir($dest)) {
            mkdir($dest, 0755, true);
        }
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($source, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($iterator as $item) {
            $relativePath = substr($item->getPathname(), strlen($source) + 1);
            
            // التحقق من الاستثناءات
            $shouldExclude = false;
            foreach ($exclude as $excludePath) {
                if (strpos($relativePath, $excludePath) === 0) {
                    $shouldExclude = true;
                    break;
                }
            }
            
            if ($shouldExclude) {
                continue;
            }
            
            $destPath = $dest . '/' . $relativePath;
            
            if ($item->isDir()) {
                if (!is_dir($destPath)) {
                    mkdir($destPath, 0755, true);
                }
            } else {
                $destDir = dirname($destPath);
                if (!is_dir($destDir)) {
                    mkdir($destDir, 0755, true);
                }
                copy($item->getPathname(), $destPath);
            }
        }
    }

    /**
     * إنشاء ملف المعلومات
     */
    private function createInfoFile($backupDir, $type)
    {
        $info = [
            'backup_type' => $type,
            'created_at' => date('Y-m-d H:i:s'),
            'created_by' => 'Trend Academy Backup System',
            'php_version' => PHP_VERSION,
            'mysql_version' => $this->getMySQLVersion(),
            'server_info' => [
                'hostname' => gethostname(),
                'os' => PHP_OS,
                'memory_limit' => ini_get('memory_limit'),
                'max_execution_time' => ini_get('max_execution_time')
            ],
            'config' => [
                'app_version' => $this->config['app']['version'],
                'environment' => $this->config['app']['environment']
            ]
        ];
        
        file_put_contents(
            $backupDir . '/backup_info.json',
            json_encode($info, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
        );
    }

    /**
     * الحصول على إصدار MySQL
     */
    private function getMySQLVersion()
    {
        try {
            $pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
            
            $stmt = $pdo->query("SELECT VERSION() as version");
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['version'] ?? 'Unknown';
            
        } catch (Exception $e) {
            return 'Unknown';
        }
    }

    /**
     * ضغط النسخة الاحتياطية
     */
    private function compressBackup($backupDir, $backupName)
    {
        $this->log("بدء ضغط النسخة الاحتياطية");
        
        $archivePath = $this->backupPath . '/' . $backupName . '.zip';
        $zip = new ZipArchive();
        
        if ($zip->open($archivePath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
            throw new Exception("فشل في إنشاء ملف الأرشيف: {$archivePath}");
        }
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($backupDir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $relativePath = substr($file->getPathname(), strlen($backupDir) + 1);
                $zip->addFile($file->getPathname(), $relativePath);
            }
        }
        
        $zip->close();
        
        $this->log("اكتمل ضغط النسخة الاحتياطية - الحجم: " . $this->formatBytes(filesize($archivePath)));
        
        return $archivePath;
    }

    /**
     * تشفير النسخة الاحتياطية
     */
    private function encryptBackup($archivePath)
    {
        $this->log("بدء تشفير النسخة الاحتياطية");
        
        $encryptedPath = $archivePath . '.enc';
        $key = $this->config['backup']['encryption']['key'];
        
        if (empty($key)) {
            throw new Exception("مفتاح التشفير غير محدد");
        }
        
        $iv = random_bytes(16);
        $encryptedData = openssl_encrypt(
            file_get_contents($archivePath),
            'AES-256-CBC',
            $key,
            OPENSSL_RAW_DATA,
            $iv
        );
        
        if ($encryptedData === false) {
            throw new Exception("فشل في تشفير النسخة الاحتياطية");
        }
        
        file_put_contents($encryptedPath, $iv . $encryptedData);
        
        // حذف الملف غير المشفر
        unlink($archivePath);
        
        $this->log("اكتمل تشفير النسخة الاحتياطية");
        
        return $encryptedPath;
    }

    /**
     * رفع النسخة الاحتياطية للتخزين السحابي
     */
    private function uploadToCloud($archivePath)
    {
        $s3Config = $this->config['backup']['destinations']['s3'];
        
        if (!$s3Config['enabled']) {
            return;
        }
        
        $this->log("بدء رفع النسخة الاحتياطية إلى S3");
        
        // هنا يمكن إضافة كود رفع S3
        // يتطلب مكتبة AWS SDK
        
        $this->log("اكتمل رفع النسخة الاحتياطية إلى S3");
    }

    /**
     * تنظيف النسخ القديمة
     */
    private function cleanupOldBackups()
    {
        $this->log("بدء تنظيف النسخ القديمة");
        
        $retention = $this->config['backup']['retention'];
        $files = glob($this->backupPath . '/*.{zip,enc}', GLOB_BRACE);
        
        // ترتيب الملفات حسب التاريخ
        usort($files, function($a, $b) {
            return filemtime($b) - filemtime($a);
        });
        
        $dailyCount = 0;
        $weeklyCount = 0;
        $monthlyCount = 0;
        
        foreach ($files as $file) {
            $age = time() - filemtime($file);
            $days = floor($age / 86400);
            
            $shouldKeep = false;
            
            // النسخ اليومية
            if ($days < 7 && $dailyCount < $retention['daily']) {
                $shouldKeep = true;
                $dailyCount++;
            }
            // النسخ الأسبوعية
            elseif ($days < 30 && $days % 7 === 0 && $weeklyCount < $retention['weekly']) {
                $shouldKeep = true;
                $weeklyCount++;
            }
            // النسخ الشهرية
            elseif ($days % 30 === 0 && $monthlyCount < $retention['monthly']) {
                $shouldKeep = true;
                $monthlyCount++;
            }
            
            if (!$shouldKeep) {
                unlink($file);
                $this->log("حذف النسخة القديمة: " . basename($file));
            }
        }
        
        $this->log("اكتمل تنظيف النسخ القديمة");
    }

    /**
     * تنظيف الملفات المؤقتة
     */
    private function cleanupTempFiles($backupDir)
    {
        if (is_dir($backupDir)) {
            $this->recursiveRemoveDirectory($backupDir);
        }
    }

    /**
     * حذف مجلد بشكل تكراري
     */
    private function recursiveRemoveDirectory($dir)
    {
        if (!is_dir($dir)) {
            return;
        }
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        
        foreach ($iterator as $file) {
            if ($file->isDir()) {
                rmdir($file->getPathname());
            } else {
                unlink($file->getPathname());
            }
        }
        
        rmdir($dir);
    }

    /**
     * تنسيق الحجم بالبايت
     */
    private function formatBytes($bytes, $precision = 2)
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        
        for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
            $bytes /= 1024;
        }
        
        return round($bytes, $precision) . ' ' . $units[$i];
    }

    /**
     * تسجيل رسالة
     */
    private function log($message, $level = 'INFO')
    {
        $timestamp = date('Y-m-d H:i:s');
        $logEntry = "[{$timestamp}] [{$level}] {$message}" . PHP_EOL;
        
        file_put_contents($this->logFile, $logEntry, FILE_APPEND | LOCK_EX);
        
        // طباعة في سطر الأوامر أيضاً
        if (php_sapi_name() === 'cli') {
            echo $logEntry;
        }
    }
}

// تشغيل النسخ الاحتياطي إذا تم استدعاؤه من سطر الأوامر
if (php_sapi_name() === 'cli') {
    $type = $argv[1] ?? 'full';
    $validTypes = ['full', 'database', 'files'];
    
    if (!in_array($type, $validTypes)) {
        echo "الاستخدام: php backup.php [full|database|files]" . PHP_EOL;
        exit(1);
    }
    
    $backup = new BackupManager();
    $result = $backup->run($type);
    
    if ($result['success']) {
        echo "اكتمل النسخ الاحتياطي بنجاح!" . PHP_EOL;
        exit(0);
    } else {
        echo "فشل النسخ الاحتياطي: " . $result['error'] . PHP_EOL;
        exit(1);
    }
}