#!/usr/bin/env php
<?php
/**
 * سكريپت تنظيف النظام
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 10:45:07
 */

// تحديد المسار الجذر
define('APP_ROOT', dirname(__DIR__));
define('APP_INIT', true);

// تحميل الإعدادات
require_once APP_ROOT . '/config/constants.php';
require_once APP_ROOT . '/config/config.php';

class SystemCleanup
{
    private $config;
    private $startTime;
    private $logFile;
    private $db;
    private $cleanupSummary = [];

    public function __construct()
    {
        $this->config = include APP_ROOT . '/config/app.php';
        $this->startTime = microtime(true);
        $this->setupLogging();
        $this->initializeDatabase();
    }

    /**
     * إعداد نظام التسجيل
     */
    private function setupLogging()
    {
        $logDir = APP_ROOT . '/storage/logs';
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $this->logFile = $logDir . '/cleanup.log';
    }

    /**
     * تهيئة قاعدة البيانات
     */
    private function initializeDatabase()
    {
        try {
            $this->db = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                ]
            );
        } catch (PDOException $e) {
            $this->log("فشل في الاتصال بقاعدة البيانات: " . $e->getMessage(), 'ERROR');
            exit(1);
        }
    }

    /**
     * تشغيل عملية التنظيف
     */
    public function run($options = [])
    {
        try {
            $this->log("بدء عملية تنظيف النظام");
            
            // تنظيف الملفات المؤقتة
            if (!isset($options['skip_temp']) || !$options['skip_temp']) {
                $this->cleanupTempFiles();
            }
            
            // تنظيف ملفات السجلات القديمة
            if (!isset($options['skip_logs']) || !$options['skip_logs']) {
                $this->cleanupOldLogs();
            }
            
            // تنظيف الجلسات المنتهية الصلاحية
            if (!isset($options['skip_sessions']) || !$options['skip_sessions']) {
                $this->cleanupExpiredSessions();
            }
            
            // تنظيف رموز التفعيل المنتهية
            if (!isset($options['skip_tokens']) || !$options['skip_tokens']) {
                $this->cleanupExpiredTokens();
            }
            
            // تنظيف الإشعارات القديمة
            if (!isset($options['skip_notifications']) || !$options['skip_notifications']) {
                $this->cleanupOldNotifications();
            }
            
            // تنظيف ملفات التخزين المؤقت
            if (!isset($options['skip_cache']) || !$options['skip_cache']) {
                $this->cleanupCache();
            }
            
            // تنظيف الملفات المرفوعة المؤقتة
            if (!isset($options['skip_uploads']) || !$options['skip_uploads']) {
                $this->cleanupTempUploads();
            }
            
            // تنظيف بيانات المسار المنتهية
            if (!isset($options['skip_analytics']) || !$options['skip_analytics']) {
                $this->cleanupOldAnalytics();
            }
            
            // تنظيف النسخ الاحتياطية القديمة
            if (!isset($options['skip_backups']) || !$options['skip_backups']) {
                $this->cleanupOldBackups();
            }
            
            // تحسين قاعدة البيانات
            if (isset($options['optimize_db']) && $options['optimize_db']) {
                $this->optimizeDatabase();
            }
            
            // إنشاء تقرير التنظيف
            $this->generateCleanupReport();
            
            $duration = round(microtime(true) - $this->startTime, 2);
            $this->log("اكتملت عملية التنظيف بنجاح - المدة: {$duration}s");
            
            return [
                'success' => true,
                'duration' => $duration,
                'summary' => $this->cleanupSummary
            ];
            
        } catch (Exception $e) {
            $this->log("خطأ في عملية التنظيف: " . $e->getMessage(), 'ERROR');
            
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * تنظيف الملفات المؤقتة
     */
    private function cleanupTempFiles()
    {
        $this->log("بدء تنظيف الملفات المؤقتة");
        
        $tempPaths = [
            APP_ROOT . '/storage/temp',
            APP_ROOT . '/storage/framework/cache',
            APP_ROOT . '/storage/framework/sessions',
            sys_get_temp_dir() . '/trend_academy_*'
        ];
        
        $deletedFiles = 0;
        $freedSpace = 0;
        
        foreach ($tempPaths as $path) {
            if (strpos($path, '*') !== false) {
                // مسار يحتوي على wildcard
                $files = glob($path);
                foreach ($files as $file) {
                    if ($this->shouldDeleteTempFile($file)) {
                        $size = is_file($file) ? filesize($file) : $this->getDirectorySize($file);
                        
                        if (is_file($file)) {
                            unlink($file);
                        } else {
                            $this->recursiveRemoveDirectory($file);
                        }
                        
                        $deletedFiles++;
                        $freedSpace += $size;
                    }
                }
            } elseif (is_dir($path)) {
                $result = $this->cleanupDirectory($path, 86400); // 24 hours
                $deletedFiles += $result['files'];
                $freedSpace += $result['size'];
            }
        }
        
        $this->cleanupSummary['temp_files'] = [
            'deleted_files' => $deletedFiles,
            'freed_space' => $this->formatBytes($freedSpace)
        ];
        
        $this->log("تم تنظيف {$deletedFiles} ملف مؤقت - مساحة محررة: " . $this->formatBytes($freedSpace));
    }

    /**
     * فحص ما إذا كان يجب حذف الملف المؤقت
     */
    private function shouldDeleteTempFile($file)
    {
        // حذف الملفات الأقدم من 24 ساعة
        return (time() - filemtime($file)) > 86400;
    }

    /**
     * تنظيف ملفات السجلات القديمة
     */
    private function cleanupOldLogs()
    {
        $this->log("بدء تنظيف ملفات السجلات القديمة");
        
        $logsPath = APP_ROOT . '/storage/logs';
        $maxAge = 30 * 86400; // 30 يوم
        
        $result = $this->cleanupDirectory($logsPath, $maxAge);
        
        $this->cleanupSummary['log_files'] = [
            'deleted_files' => $result['files'],
            'freed_space' => $this->formatBytes($result['size'])
        ];
        
        $this->log("تم تنظيف {$result['files']} ملف سجل - مساحة محررة: " . $this->formatBytes($result['size']));
    }

    /**
     * تنظيف الجلسات المنتهية الصلاحية
     */
    private function cleanupExpiredSessions()
    {
        $this->log("بدء تنظيف الجلسات المنتهية الصلاحية");
        
        try {
            // تنظيف جلسات قاعدة البيانات
            $stmt = $this->db->prepare("
                DELETE FROM user_sessions 
                WHERE last_activity < DATE_SUB(NOW(), INTERVAL ? SECOND)
            ");
            $stmt->execute([$this->config['security']['session']['lifetime']]);
            $dbSessions = $stmt->rowCount();
            
            // تنظيف ملفات الجلسات
            $sessionsPath = APP_ROOT . '/storage/framework/sessions';
            $fileSessions = 0;
            
            if (is_dir($sessionsPath)) {
                $files = glob($sessionsPath . '/sess_*');
                foreach ($files as $file) {
                    if ((time() - filemtime($file)) > $this->config['security']['session']['lifetime']) {
                        unlink($file);
                        $fileSessions++;
                    }
                }
            }
            
            $totalSessions = $dbSessions + $fileSessions;
            
            $this->cleanupSummary['expired_sessions'] = [
                'database_sessions' => $dbSessions,
                'file_sessions' => $fileSessions,
                'total_sessions' => $totalSessions
            ];
            
            $this->log("تم تنظيف {$totalSessions} جلسة منتهية الصلاحية ({$dbSessions} من قاعدة البيانات، {$fileSessions} ملف)");
            
        } catch (PDOException $e) {
            $this->log("خطأ في تنظيف الجلسات: " . $e->getMessage(), 'ERROR');
        }
    }

    /**
     * تنظيف رموز التفعيل المنتهية
     */
    private function cleanupExpiredTokens()
    {
        $this->log("بدء تنظيف رموز التفعيل المنتهية");
        
        try {
            $tables = [
                'password_reset_tokens' => 'expires_at',
                'email_verification_tokens' => 'expires_at',
                'two_factor_tokens' => 'expires_at'
            ];
            
            $totalTokens = 0;
            
            foreach ($tables as $table => $expiryColumn) {
                $stmt = $this->db->prepare("DELETE FROM {$table} WHERE {$expiryColumn} < NOW()");
                $stmt->execute();
                $deletedCount = $stmt->rowCount();
                $totalTokens += $deletedCount;
                
                $this->log("تم حذف {$deletedCount} رمز من جدول {$table}");
            }
            
            $this->cleanupSummary['expired_tokens'] = [
                'total_tokens' => $totalTokens
            ];
            
            $this->log("تم تنظيف {$totalTokens} رمز تفعيل منتهي الصلاحية");
            
        } catch (PDOException $e) {
            $this->log("خطأ في تنظيف الرموز: " . $e->getMessage(), 'ERROR');
        }
    }

    /**
     * تنظيف الإشعارات القديمة
     */
    private function cleanupOldNotifications()
    {
        $this->log("بدء تنظيف الإشعارات القديمة");
        
        try {
            // حذف الإشعارات المقروءة الأقدم من 30 يوم
            $stmt = $this->db->prepare("
                DELETE FROM notifications 
                WHERE is_read = 1 
                AND created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)
            ");
            $stmt->execute();
            $readNotifications = $stmt->rowCount();
            
            // حذف الإشعارات غير المقروءة الأقدم من 90 يوم
            $stmt = $this->db->prepare("
                DELETE FROM notifications 
                WHERE is_read = 0 
                AND created_at < DATE_SUB(NOW(), INTERVAL 90 DAY)
            ");
            $stmt->execute();
            $unreadNotifications = $stmt->rowCount();
            
            $totalNotifications = $readNotifications + $unreadNotifications;
            
            $this->cleanupSummary['old_notifications'] = [
                'read_notifications' => $readNotifications,
                'unread_notifications' => $unreadNotifications,
                'total_notifications' => $totalNotifications
            ];
            
            $this->log("تم تنظيف {$totalNotifications} إشعار قديم ({$readNotifications} مقروء، {$unreadNotifications} غير مقروء)");
            
        } catch (PDOException $e) {
            $this->log("خطأ في تنظيف الإشعارات: " . $e->getMessage(), 'ERROR');
        }
    }

    /**
     * تنظيف ملفات التخزين المؤقت
     */
    private function cleanupCache()
    {
        $this->log("بدء تنظيف ملفات التخزين المؤقت");
        
        $cachePaths = [
            APP_ROOT . '/storage/framework/cache/data',
            APP_ROOT . '/storage/framework/views'
        ];
        
        $deletedFiles = 0;
        $freedSpace = 0;
        
        foreach ($cachePaths as $path) {
            if (is_dir($path)) {
                $result = $this->cleanupDirectory($path, 3600); // 1 hour for cache
                $deletedFiles += $result['files'];
                $freedSpace += $result['size'];
            }
        }
        
        // تنظيف Redis cache إذا كان متاحاً
        if (extension_loaded('redis')) {
            $this->cleanupRedisCache();
        }
        
        $this->cleanupSummary['cache_files'] = [
            'deleted_files' => $deletedFiles,
            'freed_space' => $this->formatBytes($freedSpace)
        ];
        
        $this->log("تم تنظيف {$deletedFiles} ملف تخزين مؤقت - مساحة محررة: " . $this->formatBytes($freedSpace));
    }

    /**
     * تنظيف Redis cache
     */
    private function cleanupRedisCache()
    {
        try {
            $redis = new Redis();
            $redis->connect(
                $this->config['database']['redis']['host'],
                $this->config['database']['redis']['port']
            );
            
            if (!empty($this->config['database']['redis']['password'])) {
                $redis->auth($this->config['database']['redis']['password']);
            }
            
            $redis->select($this->config['database']['redis']['database']);
            
            // حذف المفاتيح المنتهية الصلاحية
            $deletedKeys = 0;
            $keys = $redis->keys('trend_cache:*');
            
            foreach ($keys as $key) {
                $ttl = $redis->ttl($key);
                if ($ttl === -1) { // مفتاح بدون انتهاء صلاحية
                    $redis->expire($key, 3600); // تعيين انتهاء صلاحية ساعة واحدة
                } elseif ($ttl === -2) { // مفتاح منتهي الصلاحية
                    $redis->del($key);
                    $deletedKeys++;
                }
            }
            
            $redis->close();
            
            $this->log("تم تنظيف {$deletedKeys} مفتاح Redis منتهي الصلاحية");
            
        } catch (Exception $e) {
            $this->log("خطأ في تنظيف Redis: " . $e->getMessage(), 'WARNING');
        }
    }

    /**
     * تنظيف الملفات المرفوعة المؤقتة
     */
    private function cleanupTempUploads()
    {
        $this->log("بدء تنظيف الملفات المرفوعة المؤقتة");
        
        $tempUploadsPath = APP_ROOT . '/storage/uploads/temp';
        $maxAge = 86400; // 24 hours
        
        $result = $this->cleanupDirectory($tempUploadsPath, $maxAge);
        
        $this->cleanupSummary['temp_uploads'] = [
            'deleted_files' => $result['files'],
            'freed_space' => $this->formatBytes($result['size'])
        ];
        
        $this->log("تم تنظيف {$result['files']} ملف مرفوع مؤقت - مساحة محررة: " . $this->formatBytes($result['size']));
    }

    /**
     * تنظيف بيانات التحليلات القديمة
     */
    private function cleanupOldAnalytics()
    {
        $this->log("بدء تنظيف بيانات التحليلات القديمة");
        
        try {
            $tables = [
                'page_views' => 90,        // 90 يوم
                'user_activities' => 180,  // 180 يوم
                'search_queries' => 30,    // 30 يوم
                'error_logs' => 30        // 30 يوم
            ];
            
            $totalRecords = 0;
            
            foreach ($tables as $table => $retentionDays) {
                $stmt = $this->db->prepare("
                    DELETE FROM {$table} 
                    WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)
                ");
                $stmt->execute([$retentionDays]);
                $deletedCount = $stmt->rowCount();
                $totalRecords += $deletedCount;
                
                $this->log("تم حذف {$deletedCount} سجل من جدول {$table} (أقدم من {$retentionDays} يوم)");
            }
            
            $this->cleanupSummary['old_analytics'] = [
                'total_records' => $totalRecords
            ];
            
            $this->log("تم تنظيف {$totalRecords} سجل تحليلات قديم");
            
        } catch (PDOException $e) {
            $this->log("خطأ في تنظيف التحليلات: " . $e->getMessage(), 'ERROR');
        }
    }

    /**
     * تنظيف النسخ الاحتياطية القديمة
     */
    private function cleanupOldBackups()
    {
        $this->log("بدء تنظيف النسخ الاحتياطية القديمة");
        
        $backupsPath = APP_ROOT . '/storage/backups';
        $retention = $this->config['backup']['retention'] ?? ['daily' => 7, 'weekly' => 4, 'monthly' => 12];
        
        if (!is_dir($backupsPath)) {
            return;
        }
        
        $files = glob($backupsPath . '/*.{zip,enc}', GLOB_BRACE);
        usort($files, function($a, $b) {
            return filemtime($b) - filemtime($a);
        });
        
        $deletedFiles = 0;
        $freedSpace = 0;
        $dailyCount = 0;
        $weeklyCount = 0;
        $monthlyCount = 0;
        
        foreach ($files as $file) {
            $age = time() - filemtime($file);
            $days = floor($age / 86400);
            
            $shouldKeep = false;
            
            if ($days < 7 && $dailyCount < $retention['daily']) {
                $shouldKeep = true;
                $dailyCount++;
            } elseif ($days < 30 && $days % 7 === 0 && $weeklyCount < $retention['weekly']) {
                $shouldKeep = true;
                $weeklyCount++;
            } elseif ($days % 30 === 0 && $monthlyCount < $retention['monthly']) {
                $shouldKeep = true;
                $monthlyCount++;
            }
            
            if (!$shouldKeep) {
                $size = filesize($file);
                unlink($file);
                $deletedFiles++;
                $freedSpace += $size;
            }
        }
        
        $this->cleanupSummary['old_backups'] = [
            'deleted_files' => $deletedFiles,
            'freed_space' => $this->formatBytes($freedSpace)
        ];
        
        $this->log("تم تنظيف {$deletedFiles} نسخة احتياطية قديمة - مساحة محررة: " . $this->formatBytes($freedSpace));
    }

    /**
     * تحسين قاعدة البيانات
     */
    private function optimizeDatabase()
    {
        $this->log("بدء تحسين قاعدة البيانات");
        
        try {
            // الحصول على قائمة الجداول
            $stmt = $this->db->query("SHOW TABLES");
            $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            $optimizedTables = 0;
            $totalSpaceSaved = 0;
            
            foreach ($tables as $table) {
                // الحصول على حجم الجدول قبل التحسين
                $stmt = $this->db->query("
                    SELECT (data_length + index_length) as size 
                    FROM information_schema.tables 
                    WHERE table_schema = '" . DB_NAME . "' 
                    AND table_name = '{$table}'
                ");
                $sizeBefore = $stmt->fetchColumn();
                
                // تحسين الجدول
                $this->db->exec("OPTIMIZE TABLE `{$table}`");
                
                // الحصول على حجم الجدول بعد التحسين
                $stmt = $this->db->query("
                    SELECT (data_length + index_length) as size 
                    FROM information_schema.tables 
                    WHERE table_schema = '" . DB_NAME . "' 
                    AND table_name = '{$table}'
                ");
                $sizeAfter = $stmt->fetchColumn();
                
                $spaceSaved = $sizeBefore - $sizeAfter;
                $totalSpaceSaved += $spaceSaved;
                $optimizedTables++;
                
                $this->log("تم تحسين جدول {$table} - مساحة محررة: " . $this->formatBytes($spaceSaved));
            }
            
            $this->cleanupSummary['database_optimization'] = [
                'optimized_tables' => $optimizedTables,
                'space_saved' => $this->formatBytes($totalSpaceSaved)
            ];
            
            $this->log("تم تحسين {$optimizedTables} جدول - إجمالي المساحة المحررة: " . $this->formatBytes($totalSpaceSaved));
            
        } catch (PDOException $e) {
            $this->log("خطأ في تحسين قاعدة البيانات: " . $e->getMessage(), 'ERROR');
        }
    }

    /**
     * تنظيف مجلد
     */
    private function cleanupDirectory($directory, $maxAge)
    {
        if (!is_dir($directory)) {
            return ['files' => 0, 'size' => 0];
        }
        
        $deletedFiles = 0;
        $freedSpace = 0;
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $age = time() - $file->getMTime();
                
                if ($age > $maxAge) {
                    $size = $file->getSize();
                    unlink($file->getPathname());
                    $deletedFiles++;
                    $freedSpace += $size;
                }
            } elseif ($file->isDir()) {
                // حذف المجلدات الفارغة
                if ($this->isDirectoryEmpty($file->getPathname())) {
                    rmdir($file->getPathname());
                }
            }
        }
        
        return ['files' => $deletedFiles, 'size' => $freedSpace];
    }

    /**
     * فحص ما إذا كان المجلد فارغ
     */
    private function isDirectoryEmpty($directory)
    {
        $handle = opendir($directory);
        while (false !== ($entry = readdir($handle))) {
            if ($entry !== '.' && $entry !== '..') {
                closedir($handle);
                return false;
            }
        }
        closedir($handle);
        return true;
    }

    /**
     * الحصول على حجم المجلد
     */
    private function getDirectorySize($directory)
    {
        $size = 0;
        
        if (!is_dir($directory)) {
            return 0;
        }
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $size += $file->getSize();
            }
        }
        
        return $size;
    }

    /**
     * حذف مجلد بشكل تكراري
     */
    private function recursiveRemoveDirectory($dir)
    {
        if (!is_dir($dir)) {
            return;
        }
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        
        foreach ($iterator as $file) {
            if ($file->isDir()) {
                rmdir($file->getPathname());
            } else {
                unlink($file->getPathname());
            }
        }
        
        rmdir($dir);
    }

    /**
     * إنشاء تقرير التنظيف
     */
    private function generateCleanupReport()
    {
        $reportPath = APP_ROOT . '/storage/logs/cleanup_report_' . date('Y-m-d_H-i-s') . '.json';
        
        $report = [
            'cleanup_date' => date('Y-m-d H:i:s'),
            'duration' => round(microtime(true) - $this->startTime, 2),
            'summary' => $this->cleanupSummary,
            'system_info' => [
                'php_version' => PHP_VERSION,
                'memory_usage' => memory_get_peak_usage(true),
                'disk_free_space' => disk_free_space(APP_ROOT)
            ]
        ];
        
        file_put_contents($reportPath, json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        
        $this->log("تم إنشاء تقرير التنظيف: " . basename($reportPath));
    }

    /**
     * تنسيق الحجم بالبايت
     */
    private function formatBytes($bytes, $precision = 2)
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        
        for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
            $bytes /= 1024;
        }
        
        return round($bytes, $precision) . ' ' . $units[$i];
    }

    /**
     * تسجيل رسالة
     */
    private function log($message, $level = 'INFO')
    {
        $timestamp = date('Y-m-d H:i:s');
        $logEntry = "[{$timestamp}] [{$level}] {$message}" . PHP_EOL;
        
        file_put_contents($this->logFile, $logEntry, FILE_APPEND | LOCK_EX);
        
        // طباعة في سطر الأوامر أيضاً
        if (php_sapi_name() === 'cli') {
            echo $logEntry;
        }
    }
}

// تشغيل التنظيف إذا تم استدعاؤه من سطر الأوامر
if (php_sapi_name() === 'cli') {
    $options = [];
    
    // تحليل المعاملات
    for ($i = 1; $i < $argc; $i++) {
        switch ($argv[$i]) {
            case '--skip-temp':
                $options['skip_temp'] = true;
                break;
            case '--skip-logs':
                $options['skip_logs'] = true;
                break;
            case '--skip-sessions':
                $options['skip_sessions'] = true;
                break;
            case '--skip-cache':
                $options['skip_cache'] = true;
                break;
            case '--optimize-db':
                $options['optimize_db'] = true;
                break;
            case '--help':
                echo "استخدام: php cleanup.php [options]" . PHP_EOL;
                echo "الخيارات:" . PHP_EOL;
                echo "  --skip-temp     تخطي تنظيف الملفات المؤقتة" . PHP_EOL;
                echo "  --skip-logs     تخطي تنظيف ملفات السجلات" . PHP_EOL;
                echo "  --skip-sessions تخطي تنظيف الجلسات" . PHP_EOL;
                echo "  --skip-cache    تخطي تنظيف ملفات التخزين المؤقت" . PHP_EOL;
                echo "  --optimize-db   تحسين قاعدة البيانات" . PHP_EOL;
                echo "  --help          عرض هذه الرسالة" . PHP_EOL;
                exit(0);
        }
    }
    
    $cleanup = new SystemCleanup();
    $result = $cleanup->run($options);
    
    if ($result['success']) {
        echo "اكتملت عملية التنظيف بنجاح!" . PHP_EOL;
        echo "المدة: {$result['duration']} ثانية" . PHP_EOL;
        exit(0);
    } else {
        echo "فشلت عملية التنظيف: " . $result['error'] . PHP_EOL;
        exit(1);
    }
}