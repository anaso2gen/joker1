<?php
/**
 * الدوال المساعدة العامة
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 08:52:12
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

/**
 * تنظيف المدخلات من النصوص الضارة
 */
function sanitizeInput($input) {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
    
    return $input;
}

/**
 * التحقق من صحة البريد الإلكتروني
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * التحقق من قوة كلمة المرور
 */
function isStrongPassword($password) {
    // على الأقل 8 أحرف، حرف كبير، حرف صغير، رقم
    return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{8,}$/', $password);
}

/**
 * إنشاء رمز CSRF
 */
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * التحقق من رمز CSRF
 */
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * إنشاء كود تفعيل عشوائي
 */
function generateActivationCode($length = 12, $type = 'alphanumeric') {
    switch ($type) {
        case 'numeric':
            $characters = '0123456789';
            break;
        case 'alphabetic':
            $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
            break;
        case 'mixed':
            $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
            break;
        default:
            $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    }
    
    $code = '';
    $charactersLength = strlen($characters);
    
    for ($i = 0; $i < $length; $i++) {
        $code .= $characters[random_int(0, $charactersLength - 1)];
    }
    
    return $code;
}

/**
 * الحصول على عنوان IP الحقيقي
 */
function getRealIpAddress() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ips[0]);
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED'])) {
        return $_SERVER['HTTP_X_FORWARDED'];
    } elseif (!empty($_SERVER['HTTP_X_CLUSTER_CLIENT_IP'])) {
        return $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_FORWARDED_FOR'];
    } elseif (!empty($_SERVER['HTTP_FORWARDED'])) {
        return $_SERVER['HTTP_FORWARDED'];
    } else {
        return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    }
}

/**
 * تسجيل حدث أمني
 */
function logSecurityEvent($description, $severity = 'medium', $additionalData = []) {
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        
        $stmt = $pdo->prepare("
            INSERT INTO security_logs (event_type, description, ip_address, user_agent, additional_data, created_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([
            $severity,
            $description,
            getRealIpAddress(),
            $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
            json_encode($additionalData)
        ]);
        
    } catch (Exception $e) {
        error_log("Failed to log security event: " . $e->getMessage());
    }
}

/**
 * تسجيل نشاط المستخدم
 */
function logActivity($description, $category = 'general', $userId = null) {
    try {
        $logFile = __DIR__ . '/logs/activity.log';
        $timestamp = date('Y-m-d H:i:s');
        $ip = getRealIpAddress();
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
        $userIdStr = $userId ? "User:$userId" : 'Guest';
        
        $logEntry = "[$timestamp] [$category] [$userIdStr] [$ip] $description - $userAgent" . PHP_EOL;
        
        // إنشاء مجلد اللوجز إذا لم يكن موجود
        $logDir = dirname($logFile);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
        
    } catch (Exception $e) {
        error_log("Failed to log activity: " . $e->getMessage());
    }
}

/**
 * تحويل الثواني إلى تنسيق قابل للقراءة
 */
function formatDuration($seconds) {
    if ($seconds < 60) {
        return $seconds . ' ثانية';
    } elseif ($seconds < 3600) {
        $minutes = floor($seconds / 60);
        return $minutes . ' دقيقة';
    } else {
        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        
        if ($minutes > 0) {
            return $hours . ' ساعة و ' . $minutes . ' دقيقة';
        } else {
            return $hours . ' ساعة';
        }
    }
}

/**
 * تحويل التاريخ إلى التنسيق العربي
 */
function formatArabicDate($date, $includeTime = false) {
    $timestamp = is_string($date) ? strtotime($date) : $date;
    
    if ($includeTime) {
        return date('Y/m/d - H:i', $timestamp);
    } else {
        return date('Y/m/d', $timestamp);
    }
}

/**
 * حساب الوقت المنقضي منذ تاريخ معين
 */
function timeAgo($date) {
    $timestamp = is_string($date) ? strtotime($date) : $date;
    $diff = time() - $timestamp;
    
    if ($diff < 60) {
        return 'منذ لحظات';
    } elseif ($diff < 3600) {
        $minutes = floor($diff / 60);
        return "منذ $minutes دقيقة";
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return "منذ $hours ساعة";
    } elseif ($diff < 2592000) {
        $days = floor($diff / 86400);
        return "منذ $days يوم";
    } elseif ($diff < 31536000) {
        $months = floor($diff / 2592000);
        return "منذ $months شهر";
    } else {
        $years = floor($diff / 31536000);
        return "منذ $years سنة";
    }
}

/**
 * تشفير البيانات الحساسة
 */
function encryptData($data, $key = null) {
    $key = $key ?: ENCRYPTION_SALT;
    $method = 'AES-256-CBC';
    $iv = openssl_random_pseudo_bytes(16);
    $encrypted = openssl_encrypt($data, $method, $key, 0, $iv);
    
    return base64_encode($iv . $encrypted);
}

/**
 * فك تشفير البيانات
 */
function decryptData($encryptedData, $key = null) {
    $key = $key ?: ENCRYPTION_SALT;
    $method = 'AES-256-CBC';
    $data = base64_decode($encryptedData);
    $iv = substr($data, 0, 16);
    $encrypted = substr($data, 16);
    
    return openssl_decrypt($encrypted, $method, $key, 0, $iv);
}

/**
 * إرسال بريد إلكتروني
 */
function sendEmail($to, $subject, $message, $isHTML = true) {
    // هذه دالة بسيطة، يفضل استخدام PHPMailer في الإنتاج
    $headers = [
        'From: ' . ADMIN_EMAIL,
        'Reply-To: ' . ADMIN_EMAIL,
        'X-Mailer: PHP/' . phpversion()
    ];
    
    if ($isHTML) {
        $headers[] = 'MIME-Version: 1.0';
        $headers[] = 'Content-type: text/html; charset=UTF-8';
    }
    
    return mail($to, $subject, $message, implode("\r\n", $headers));
}

/**
 * ضغط وتحسين الصور
 */
function compressImage($source, $destination, $quality = 80) {
    $info = getimagesize($source);
    
    if (!$info) {
        return false;
    }
    
    switch ($info['mime']) {
        case 'image/jpeg':
            $image = imagecreatefromjpeg($source);
            break;
        case 'image/png':
            $image = imagecreatefrompng($source);
            break;
        case 'image/gif':
            $image = imagecreatefromgif($source);
            break;
        default:
            return false;
    }
    
    // حفظ الصورة بجودة محددة
    return imagejpeg($image, $destination, $quality);
}

/**
 * إنشاء صورة مصغرة
 */
function createThumbnail($source, $destination, $maxWidth = 300, $maxHeight = 200) {
    $info = getimagesize($source);
    
    if (!$info) {
        return false;
    }
    
    list($width, $height) = $info;
    
    // حساب الأبعاد الجديدة
    $ratio = min($maxWidth / $width, $maxHeight / $height);
    $newWidth = intval($width * $ratio);
    $newHeight = intval($height * $ratio);
    
    // إنشاء الصورة المصغرة
    $thumbnail = imagecreatetruecolor($newWidth, $newHeight);
    
    switch ($info['mime']) {
        case 'image/jpeg':
            $source_image = imagecreatefromjpeg($source);
            break;
        case 'image/png':
            $source_image = imagecreatefrompng($source);
            // الحفاظ على الشفافية
            imagealphablending($thumbnail, false);
            imagesavealpha($thumbnail, true);
            break;
        case 'image/gif':
            $source_image = imagecreatefromgif($source);
            break;
        default:
            return false;
    }
    
    imagecopyresampled($thumbnail, $source_image, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
    
    return imagejpeg($thumbnail, $destination, 85);
}

/**
 * التحقق من صحة رفع الملف
 */
function validateFileUpload($file, $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'], $maxSize = 5242880) {
    $errors = [];
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors[] = 'حدث خطأ في رفع الملف';
        return $errors;
    }
    
    if ($file['size'] > $maxSize) {
        $errors[] = 'حجم الملف كبير جداً. الحد الأقصى ' . formatBytes($maxSize);
    }
    
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($extension, $allowedTypes)) {
        $errors[] = 'نوع الملف غير مدعوم. الأنواع المدعومة: ' . implode(', ', $allowedTypes);
    }
    
    // فحص إضافي للتأكد من نوع الملف
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    $allowedMimes = [
        'image/jpeg',
        'image/png', 
        'image/gif'
    ];
    
    if (!in_array($mimeType, $allowedMimes)) {
        $errors[] = 'نوع الملف غير آمن';
    }
    
    return $errors;
}

/**
 * تحويل البايتات إلى تنسيق قابل للقراءة
 */
function formatBytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    
    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    
    return round($bytes, $precision) . ' ' . $units[$i];
}

/**
 * إنشاء URL آمن للملفات
 */
function secureFileUrl($filePath, $expiry = 3600) {
    $timestamp = time() + $expiry;
    $hash = hash_hmac('sha256', $filePath . $timestamp, SECURITY_KEY);
    
    return "file.php?path=" . urlencode($filePath) . "&expires=$timestamp&hash=$hash";
}

/**
 * التحقق من صحة URL الملف الآمن
 */
function validateSecureFileUrl($filePath, $expires, $hash) {
    if (time() > $expires) {
        return false;
    }
    
    $expectedHash = hash_hmac('sha256', $filePath . $expires, SECURITY_KEY);
    
    return hash_equals($expectedHash, $hash);
}

/**
 * إنشاء رمز تحقق لإعادة تعيين كلمة المرور
 */
function generatePasswordResetToken($userId) {
    $token = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
    
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        
        // حذف الرموز السابقة
        $stmt = $pdo->prepare("DELETE FROM password_resets WHERE user_id = ?");
        $stmt->execute([$userId]);
        
        // إدراج رمز جديد
        $stmt = $pdo->prepare("
            INSERT INTO password_resets (user_id, token, expires_at, created_at)
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->execute([$userId, $token, $expires]);
        
        return $token;
        
    } catch (Exception $e) {
        logSecurityEvent('Failed to generate password reset token', 'high', ['error' => $e->getMessage()]);
        return false;
    }
}

/**
 * صفحة خطأ مخصصة
 */
function showErrorPage($code = 404, $message = null) {
    http_response_code($code);
    
    $defaultMessages = [
        404 => 'الصفحة غير موجودة',
        403 => 'ليس لديك صلاحية للوصول',
        500 => 'خطأ في الخادم الداخلي',
        503 => 'الخدمة غير متاحة حالياً'
    ];
    
    $message = $message ?: $defaultMessages[$code] ?? 'حدث خطأ غير متوقع';
    
    include __DIR__ . '/frontend/views/pages/error.php';
    exit;
}

/**
 * التحقق من وجود إذن في المجلد
 */
function checkDirectoryPermissions($directory) {
    if (!is_dir($directory)) {
        return false;
    }
    
    return is_writable($directory);
}

/**
 * إنشاء مجلدات مع صلاحيات آمنة
 */
function createSecureDirectory($path, $permissions = 0755) {
    if (!is_dir($path)) {
        if (!mkdir($path, $permissions, true)) {
            return false;
        }
        
        // إنشاء ملف .htaccess لحماية المجلد
        $htaccess = $path . '/.htaccess';
        if (!file_exists($htaccess)) {
            file_put_contents($htaccess, "Order deny,allow\nDeny from all");
        }
    }
    
    return true;
}

/**
 * تنظيف الملفات المؤقتة
 */
function cleanupTempFiles($directory, $maxAge = 3600) {
    if (!is_dir($directory)) {
        return;
    }
    
    $files = scandir($directory);
    $deleted = 0;
    
    foreach ($files as $file) {
        if ($file === '.' || $file === '..') {
            continue;
        }
        
        $filePath = $directory . '/' . $file;
        
        if (is_file($filePath) && (time() - filemtime($filePath)) > $maxAge) {
            if (unlink($filePath)) {
                $deleted++;
            }
        }
    }
    
    logActivity("Cleaned up $deleted temporary files", 'system');
}
?>