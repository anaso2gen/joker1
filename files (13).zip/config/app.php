<?php
/**
 * إعدادات التطبيق المتقدمة
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 10:42:09
 */

// منع الوصول المباشر
if (!defined('APP_INIT')) {
    die('الوصول المباشر غير مسموح');
}

return [
    /*
    |--------------------------------------------------------------------------
    | معلومات التطبيق الأساسية
    |--------------------------------------------------------------------------
    */
    'app' => [
        'name' => 'منصة ترند التعليمية',
        'name_en' => 'Trend Academy',
        'version' => '1.0.0',
        'environment' => $_ENV['APP_ENV'] ?? 'production', // development, testing, production
        'debug' => $_ENV['APP_DEBUG'] ?? false,
        'timezone' => 'Asia/Riyadh',
        'locale' => 'ar',
        'fallback_locale' => 'en',
        'key' => $_ENV['APP_KEY'] ?? 'trend-academy-2025-secure-key',
        'url' => $_ENV['APP_URL'] ?? 'https://trendacademy.sa',
    ],

    /*
    |--------------------------------------------------------------------------
    | إعدادات قاعدة البيانات المتقدمة
    |--------------------------------------------------------------------------
    */
    'database' => [
        'default' => 'mysql',
        'connections' => [
            'mysql' => [
                'driver' => 'mysql',
                'host' => $_ENV['DB_HOST'] ?? 'localhost',
                'port' => $_ENV['DB_PORT'] ?? '3306',
                'database' => $_ENV['DB_DATABASE'] ?? 'trend_academy',
                'username' => $_ENV['DB_USERNAME'] ?? 'root',
                'password' => $_ENV['DB_PASSWORD'] ?? '',
                'charset' => 'utf8mb4',
                'collation' => 'utf8mb4_unicode_ci',
                'options' => [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
                ],
                'pool' => [
                    'min_connections' => 2,
                    'max_connections' => 20,
                    'wait_timeout' => 30,
                    'idle_timeout' => 300
                ]
            ],
            'backup' => [
                'driver' => 'mysql',
                'host' => $_ENV['BACKUP_DB_HOST'] ?? 'localhost',
                'port' => $_ENV['BACKUP_DB_PORT'] ?? '3306',
                'database' => $_ENV['BACKUP_DB_DATABASE'] ?? 'trend_academy_backup',
                'username' => $_ENV['BACKUP_DB_USERNAME'] ?? 'root',
                'password' => $_ENV['BACKUP_DB_PASSWORD'] ?? '',
                'charset' => 'utf8mb4',
                'collation' => 'utf8mb4_unicode_ci',
            ]
        ],
        'migration_table' => 'migrations',
        'redis' => [
            'host' => $_ENV['REDIS_HOST'] ?? '127.0.0.1',
            'port' => $_ENV['REDIS_PORT'] ?? 6379,
            'password' => $_ENV['REDIS_PASSWORD'] ?? null,
            'database' => $_ENV['REDIS_DB'] ?? 0,
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | إعدادات الأمان المتقدمة
    |--------------------------------------------------------------------------
    */
    'security' => [
        'encryption' => [
            'method' => 'AES-256-CBC',
            'key' => $_ENV['ENCRYPTION_KEY'] ?? 'your-32-character-secret-key-here',
            'iv_length' => 16
        ],
        'password' => [
            'algorithm' => PASSWORD_ARGON2ID,
            'options' => [
                'memory_cost' => 65536, // 64 MB
                'time_cost' => 4,       // 4 iterations
                'threads' => 3          // 3 threads
            ],
            'min_length' => 8,
            'require_special_chars' => true,
            'require_numbers' => true,
            'require_uppercase' => true,
            'require_lowercase' => true
        ],
        'session' => [
            'lifetime' => 7200, // 2 hours
            'secure' => true,
            'httponly' => true,
            'samesite' => 'Strict',
            'regenerate_interval' => 1800, // 30 minutes
            'gc_probability' => 1,
            'gc_divisor' => 100
        ],
        'csrf' => [
            'enabled' => true,
            'token_lifetime' => 3600, // 1 hour
            'token_name' => 'csrf_token',
            'header_name' => 'X-CSRF-Token'
        ],
        'rate_limiting' => [
            'enabled' => true,
            'max_attempts' => 5,
            'decay_minutes' => 15,
            'lockout_duration' => 900 // 15 minutes
        ],
        'two_factor' => [
            'enabled' => true,
            'issuer' => 'Trend Academy',
            'window' => 1, // Allow 1 time window drift
            'secret_length' => 32
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | إعدادات التخزين والملفات
    |--------------------------------------------------------------------------
    */
    'storage' => [
        'default' => 'local',
        'disks' => [
            'local' => [
                'driver' => 'local',
                'root' => APP_ROOT . '/storage/app',
                'url' => '/storage',
                'visibility' => 'private'
            ],
            'public' => [
                'driver' => 'local',
                'root' => APP_ROOT . '/storage/app/public',
                'url' => '/storage',
                'visibility' => 'public'
            ],
            's3' => [
                'driver' => 's3',
                'key' => $_ENV['AWS_ACCESS_KEY_ID'] ?? '',
                'secret' => $_ENV['AWS_SECRET_ACCESS_KEY'] ?? '',
                'region' => $_ENV['AWS_DEFAULT_REGION'] ?? 'us-east-1',
                'bucket' => $_ENV['AWS_BUCKET'] ?? '',
                'url' => $_ENV['AWS_URL'] ?? '',
                'endpoint' => $_ENV['AWS_ENDPOINT'] ?? ''
            ]
        ],
        'uploads' => [
            'max_size' => 50 * 1024 * 1024, // 50MB
            'allowed_types' => [
                'images' => ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'],
                'videos' => ['mp4', 'webm', 'ogg', 'avi', 'mov'],
                'documents' => ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt'],
                'archives' => ['zip', 'rar', '7z', 'tar', 'gz']
            ],
            'paths' => [
                'avatars' => 'uploads/avatars',
                'courses' => 'uploads/courses',
                'lessons' => 'uploads/lessons',
                'certificates' => 'uploads/certificates',
                'temp' => 'uploads/temp'
            ]
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | إعدادات الإشعارات والبريد الإلكتروني
    |--------------------------------------------------------------------------
    */
    'mail' => [
        'default' => 'smtp',
        'mailers' => [
            'smtp' => [
                'transport' => 'smtp',
                'host' => $_ENV['MAIL_HOST'] ?? 'smtp.gmail.com',
                'port' => $_ENV['MAIL_PORT'] ?? 587,
                'encryption' => $_ENV['MAIL_ENCRYPTION'] ?? 'tls',
                'username' => $_ENV['MAIL_USERNAME'] ?? '',
                'password' => $_ENV['MAIL_PASSWORD'] ?? '',
                'timeout' => 60
            ],
            'ses' => [
                'transport' => 'ses',
                'key' => $_ENV['AWS_ACCESS_KEY_ID'] ?? '',
                'secret' => $_ENV['AWS_SECRET_ACCESS_KEY'] ?? '',
                'region' => $_ENV['AWS_DEFAULT_REGION'] ?? 'us-east-1'
            ]
        ],
        'from' => [
            'address' => $_ENV['MAIL_FROM_ADDRESS'] ?? 'noreply@trendacademy.sa',
            'name' => $_ENV['MAIL_FROM_NAME'] ?? 'منصة ترند التعليمية'
        ],
        'templates' => [
            'welcome' => 'emails/welcome',
            'verification' => 'emails/verification',
            'password_reset' => 'emails/password_reset',
            'course_enrollment' => 'emails/course_enrollment',
            'certificate' => 'emails/certificate'
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | إعدادات التخزين المؤقت والأداء
    |--------------------------------------------------------------------------
    */
    'cache' => [
        'default' => 'redis',
        'stores' => [
            'file' => [
                'driver' => 'file',
                'path' => APP_ROOT . '/storage/framework/cache'
            ],
            'redis' => [
                'driver' => 'redis',
                'connection' => 'cache',
                'prefix' => 'trend_cache'
            ],
            'memcached' => [
                'driver' => 'memcached',
                'servers' => [
                    [
                        'host' => $_ENV['MEMCACHED_HOST'] ?? '127.0.0.1',
                        'port' => $_ENV['MEMCACHED_PORT'] ?? 11211,
                        'weight' => 100
                    ]
                ]
            ]
        ],
        'ttl' => [
            'default' => 3600,     // 1 hour
            'short' => 300,        // 5 minutes
            'medium' => 1800,      // 30 minutes
            'long' => 86400,       // 24 hours
            'permanent' => 604800  // 1 week
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | إعدادات الدفع والمدفوعات
    |--------------------------------------------------------------------------
    */
    'payment' => [
        'default_currency' => 'SAR',
        'currencies' => ['SAR', 'USD', 'EUR'],
        'gateways' => [
            'paypal' => [
                'enabled' => $_ENV['PAYPAL_ENABLED'] ?? true,
                'mode' => $_ENV['PAYPAL_MODE'] ?? 'sandbox', // sandbox or live
                'client_id' => $_ENV['PAYPAL_CLIENT_ID'] ?? '',
                'client_secret' => $_ENV['PAYPAL_CLIENT_SECRET'] ?? '',
                'webhook_id' => $_ENV['PAYPAL_WEBHOOK_ID'] ?? ''
            ],
            'stripe' => [
                'enabled' => $_ENV['STRIPE_ENABLED'] ?? true,
                'public_key' => $_ENV['STRIPE_PUBLIC_KEY'] ?? '',
                'secret_key' => $_ENV['STRIPE_SECRET_KEY'] ?? '',
                'webhook_secret' => $_ENV['STRIPE_WEBHOOK_SECRET'] ?? ''
            ],
            'tap' => [
                'enabled' => $_ENV['TAP_ENABLED'] ?? true,
                'secret_key' => $_ENV['TAP_SECRET_KEY'] ?? '',
                'public_key' => $_ENV['TAP_PUBLIC_KEY'] ?? '',
                'mode' => $_ENV['TAP_MODE'] ?? 'sandbox'
            ]
        ],
        'commission' => [
            'platform_fee' => 0.05, // 5%
            'instructor_share' => 0.70, // 70%
            'admin_share' => 0.25 // 25%
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | إعدادات خدمات الطرف الثالث
    |--------------------------------------------------------------------------
    */
    'services' => [
        'vdocipher' => [
            'api_key' => $_ENV['VDOCIPHER_API_KEY'] ?? '',
            'secret_key' => $_ENV['VDOCIPHER_SECRET_KEY'] ?? '',
            'base_url' => 'https://dev.vdocipher.com/api'
        ],
        'google' => [
            'client_id' => $_ENV['GOOGLE_CLIENT_ID'] ?? '',
            'client_secret' => $_ENV['GOOGLE_CLIENT_SECRET'] ?? '',
            'redirect_url' => $_ENV['GOOGLE_REDIRECT_URL'] ?? ''
        ],
        'facebook' => [
            'app_id' => $_ENV['FACEBOOK_APP_ID'] ?? '',
            'app_secret' => $_ENV['FACEBOOK_APP_SECRET'] ?? '',
            'redirect_url' => $_ENV['FACEBOOK_REDIRECT_URL'] ?? ''
        ],
        'analytics' => [
            'google_analytics_id' => $_ENV['GOOGLE_ANALYTICS_ID'] ?? '',
            'facebook_pixel_id' => $_ENV['FACEBOOK_PIXEL_ID'] ?? '',
            'hotjar_id' => $_ENV['HOTJAR_ID'] ?? ''
        ],
        'sms' => [
            'provider' => 'taqnyat', // taqnyat, twilio, nexmo
            'taqnyat' => [
                'bearer' => $_ENV['TAQNYAT_BEARER'] ?? '',
                'sender' => $_ENV['TAQNYAT_SENDER'] ?? 'TrendAcademy'
            ],
            'twilio' => [
                'sid' => $_ENV['TWILIO_SID'] ?? '',
                'token' => $_ENV['TWILIO_TOKEN'] ?? '',
                'from' => $_ENV['TWILIO_FROM'] ?? ''
            ]
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | إعدادات النظام والأداء
    |--------------------------------------------------------------------------
    */
    'system' => [
        'maintenance_mode' => $_ENV['MAINTENANCE_MODE'] ?? false,
        'allowed_ips' => explode(',', $_ENV['MAINTENANCE_ALLOWED_IPS'] ?? ''),
        'max_execution_time' => 300, // 5 minutes
        'memory_limit' => '512M',
        'upload_max_filesize' => '50M',
        'post_max_size' => '52M',
        'max_input_vars' => 3000,
        'compression' => [
            'enabled' => true,
            'level' => 6,
            'types' => ['text/html', 'text/css', 'text/javascript', 'application/json']
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | إعدادات التسجيل والمراقبة
    |--------------------------------------------------------------------------
    */
    'logging' => [
        'default' => 'stack',
        'channels' => [
            'stack' => [
                'driver' => 'stack',
                'channels' => ['single', 'slack']
            ],
            'single' => [
                'driver' => 'single',
                'path' => APP_ROOT . '/storage/logs/trend.log',
                'level' => $_ENV['LOG_LEVEL'] ?? 'info'
            ],
            'daily' => [
                'driver' => 'daily',
                'path' => APP_ROOT . '/storage/logs/trend.log',
                'level' => $_ENV['LOG_LEVEL'] ?? 'info',
                'days' => 14
            ],
            'slack' => [
                'driver' => 'slack',
                'url' => $_ENV['LOG_SLACK_WEBHOOK_URL'] ?? '',
                'username' => 'Trend Academy',
                'emoji' => ':boom:',
                'level' => 'critical'
            ]
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | إعدادات المحتوى والوسائط
    |--------------------------------------------------------------------------
    */
    'content' => [
        'text_editor' => 'tinymce', // tinymce, ckeditor, quill
        'image_optimization' => [
            'enabled' => true,
            'quality' => 85,
            'max_width' => 1920,
            'max_height' => 1080,
            'formats' => ['webp', 'jpg', 'png']
        ],
        'video_processing' => [
            'enabled' => true,
            'ffmpeg_path' => $_ENV['FFMPEG_PATH'] ?? '/usr/bin/ffmpeg',
            'qualities' => ['480p', '720p', '1080p'],
            'formats' => ['mp4', 'webm']
        ],
        'cdn' => [
            'enabled' => $_ENV['CDN_ENABLED'] ?? false,
            'url' => $_ENV['CDN_URL'] ?? '',
            'key' => $_ENV['CDN_KEY'] ?? '',
            'secret' => $_ENV['CDN_SECRET'] ?? ''
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | إعدادات الشهادات والدرجات
    |--------------------------------------------------------------------------
    */
    'certificates' => [
        'enabled' => true,
        'template_path' => APP_ROOT . '/resources/templates/certificate.html',
        'fonts_path' => APP_ROOT . '/resources/fonts',
        'watermark' => [
            'enabled' => true,
            'image' => APP_ROOT . '/assets/images/watermark.png',
            'opacity' => 0.3
        ],
        'verification' => [
            'enabled' => true,
            'url_prefix' => '/verify/',
            'expiry_days' => 0 // 0 = never expires
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | إعدادات API والتكامل
    |--------------------------------------------------------------------------
    */
    'api' => [
        'version' => 'v1',
        'prefix' => 'api',
        'rate_limit' => 60, // requests per minute
        'throttle' => [
            'login' => '5,1', // 5 attempts per minute
            'api' => '60,1'   // 60 requests per minute
        ],
        'cors' => [
            'enabled' => true,
            'allowed_origins' => explode(',', $_ENV['CORS_ALLOWED_ORIGINS'] ?? '*'),
            'allowed_methods' => ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
            'allowed_headers' => ['Content-Type', 'Authorization', 'X-Requested-With', 'X-CSRF-Token'],
            'expose_headers' => [],
            'max_age' => 3600,
            'supports_credentials' => true
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | إعدادات الصحة والمراقبة
    |--------------------------------------------------------------------------
    */
    'health' => [
        'checks' => [
            'database' => true,
            'cache' => true,
            'storage' => true,
            'queue' => true,
            'external_services' => true
        ],
        'endpoints' => [
            'health' => '/health',
            'ready' => '/ready',
            'metrics' => '/metrics'
        ],
        'monitoring' => [
            'enabled' => $_ENV['MONITORING_ENABLED'] ?? false,
            'endpoint' => $_ENV['MONITORING_ENDPOINT'] ?? '',
            'key' => $_ENV['MONITORING_KEY'] ?? ''
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | إعدادات النسخ الاحتياطي
    |--------------------------------------------------------------------------
    */
    'backup' => [
        'enabled' => true,
        'schedule' => '0 2 * * *', // Daily at 2 AM
        'destinations' => [
            'local' => [
                'enabled' => true,
                'path' => APP_ROOT . '/storage/backups'
            ],
            's3' => [
                'enabled' => $_ENV['BACKUP_S3_ENABLED'] ?? false,
                'bucket' => $_ENV['BACKUP_S3_BUCKET'] ?? '',
                'path' => 'backups/trend-academy'
            ]
        ],
        'retention' => [
            'daily' => 7,    // Keep 7 daily backups
            'weekly' => 4,   // Keep 4 weekly backups
            'monthly' => 12  // Keep 12 monthly backups
        ],
        'databases' => ['mysql'],
        'files' => [
            'include' => [
                'storage/app',
                'public/uploads'
            ],
            'exclude' => [
                'storage/logs',
                'storage/framework/cache',
                'storage/framework/sessions',
                'node_modules',
                '.git'
            ]
        ],
        'compression' => true,
        'encryption' => [
            'enabled' => true,
            'key' => $_ENV['BACKUP_ENCRYPTION_KEY'] ?? ''
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | إعدادات التطوير والاختبار
    |--------------------------------------------------------------------------
    */
    'development' => [
        'debug_bar' => $_ENV['DEBUG_BAR_ENABLED'] ?? false,
        'query_log' => $_ENV['QUERY_LOG_ENABLED'] ?? false,
        'fake_mail' => $_ENV['FAKE_MAIL_ENABLED'] ?? false,
        'telescope' => $_ENV['TELESCOPE_ENABLED'] ?? false,
        'profiler' => [
            'enabled' => $_ENV['PROFILER_ENABLED'] ?? false,
            'storage' => 'file', // file, redis, database
            'max_profiles' => 100
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | إعدادات الذكاء الاصطناعي والتعلم الآلي
    |--------------------------------------------------------------------------
    */
    'ai' => [
        'recommendation_engine' => [
            'enabled' => $_ENV['AI_RECOMMENDATIONS'] ?? false,
            'provider' => 'openai', // openai, custom
            'api_key' => $_ENV['OPENAI_API_KEY'] ?? '',
            'model' => 'gpt-3.5-turbo'
        ],
        'content_analysis' => [
            'enabled' => $_ENV['AI_CONTENT_ANALYSIS'] ?? false,
            'auto_tagging' => true,
            'sentiment_analysis' => true,
            'quality_scoring' => true
        ],
        'chatbot' => [
            'enabled' => $_ENV['AI_CHATBOT'] ?? false,
            'provider' => 'openai',
            'knowledge_base' => 'courses_and_faqs'
        ]
    ]
];