<?php
/**
 * سكريبت تثبيت منصة التعليم الإلكتروني - مُحسن للاستضافة المشتركة
 * Learning Platform Installation Script - Enhanced for Shared Hosting
 */

// تفعيل عرض الأخطاء
error_reporting(E_ALL);
ini_set('display_errors', 1);

// منع الوصول المباشر إذا كان النظام مثبت مسبقاً
if (file_exists('config.php')) {
    $config = file_get_contents('config.php');
    if (strpos($config, 'INSTALLATION_COMPLETE') !== false) {
        die('⚠️ النظام مثبت مسبقاً. احذف ملف install.php لأسباب أمنية.');
    }
}

// بدء الجلسة
session_start();

// متغيرات الأخطاء والنجاح
$errors = [];
$success = [];
$debug = [];
$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;

// دالة عرض الأخطاء
function displayErrors($errors) {
    if (!empty($errors)) {
        echo '<div class="alert alert-danger"><ul class="mb-0">';
        foreach ($errors as $error) {
            echo '<li>' . htmlspecialchars($error) . '</li>';
        }
        echo '</ul></div>';
    }
}

// دالة عرض النجاح
function displaySuccess($success) {
    if (!empty($success)) {
        echo '<div class="alert alert-success"><ul class="mb-0">';
        foreach ($success as $msg) {
            echo '<li>' . htmlspecialchars($msg) . '</li>';
        }
        echo '</ul></div>';
    }
}

// دالة عرض معلومات التشخيص
function displayDebug($debug) {
    if (!empty($debug)) {
        echo '<div class="alert alert-info"><strong>معلومات التشخيص:</strong><ul class="mb-0">';
        foreach ($debug as $msg) {
            echo '<li>' . htmlspecialchars($msg) . '</li>';
        }
        echo '</ul></div>';
    }
}

// دالة فحص متطلبات PHP
function checkPHPRequirements() {
    $requirements = [
        'PHP Version >= 7.4' => version_compare(PHP_VERSION, '7.4.0', '>='),
        'MySQLi Extension' => extension_loaded('mysqli'),
        'PDO Extension' => extension_loaded('pdo'),
        'PDO MySQL Driver' => extension_loaded('pdo_mysql'),
        'cURL Extension' => extension_loaded('curl'),
        'JSON Extension' => extension_loaded('json'),
        'OpenSSL Extension' => extension_loaded('openssl'),
        'MBString Extension' => extension_loaded('mbstring'),
    ];
    
    return $requirements;
}

// دالة فحص أذونات المجلدات
function checkDirectoryPermissions() {
    $directories = [
        'uploads' => 'uploads/',
        'logs' => 'logs/',
    ];
    
    $permissions = [];
    
    foreach ($directories as $name => $path) {
        if (!file_exists($path)) {
            @mkdir($path, 0755, true);
        }
        $permissions[$name] = is_writable($path);
    }
    
    return $permissions;
}

// دالة اختبار الاتصال بقاعدة البيانات
function testDatabaseConnection($host, $dbname, $username, $password) {
    try {
        $dsn = "mysql:host=$host;charset=utf8mb4";
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // التحقق من وجود قاعدة البيانات
        $stmt = $pdo->prepare("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = ?");
        $stmt->execute([$dbname]);
        $dbExists = $stmt->fetch() !== false;
        
        return ['success' => true, 'db_exists' => $dbExists, 'connection' => $pdo];
    } catch (PDOException $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

// دالة إنشاء قاعدة البيانات
function createDatabase($pdo, $dbname) {
    try {
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        return ['success' => true];
    } catch (PDOException $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

// دالة التحقق من وجود الجداول
function checkTablesExist($pdo, $dbname) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) as table_count FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = ?");
        $stmt->execute([$dbname]);
        $result = $stmt->fetch();
        return (int)$result['table_count'];
    } catch (PDOException $e) {
        return 0;
    }
}

// دالة إنشاء الجداول - مُحسنة للاستضافة المشتركة
function createTables($pdo, $dbname) {
    global $debug;
    
    try {
        // التبديل لقاعدة البيانات المطلوبة
        $pdo->exec("USE `$dbname`");
        $debug[] = "تم التبديل لقاعدة البيانات: $dbname";
        
        $tables = [
            'users' => "
                CREATE TABLE users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    first_name VARCHAR(50) NOT NULL,
                    last_name VARCHAR(50) NOT NULL,
                    email VARCHAR(100) NOT NULL UNIQUE,
                    password_hash VARCHAR(255) NOT NULL,
                    avatar_url VARCHAR(255) DEFAULT NULL,
                    is_admin TINYINT(1) DEFAULT 0,
                    is_active TINYINT(1) DEFAULT 1,
                    email_verified TINYINT(1) DEFAULT 0,
                    last_login TIMESTAMP NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ",
            
            'courses' => "
                CREATE TABLE courses (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(200) NOT NULL,
                    description TEXT,
                    short_description VARCHAR(500),
                    image_url VARCHAR(255),
                    category VARCHAR(100),
                    difficulty_level ENUM('beginner', 'intermediate', 'advanced') DEFAULT 'beginner',
                    is_active TINYINT(1) DEFAULT 1,
                    is_featured TINYINT(1) DEFAULT 0,
                    price DECIMAL(10,2) DEFAULT 0.00,
                    created_by INT DEFAULT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ",
            
            'sections' => "
                CREATE TABLE sections (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    course_id INT NOT NULL,
                    name VARCHAR(200) NOT NULL,
                    description TEXT,
                    sort_order INT DEFAULT 0,
                    is_active TINYINT(1) DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ",
            
            'lessons' => "
                CREATE TABLE lessons (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    section_id INT NOT NULL,
                    title VARCHAR(200) NOT NULL,
                    description TEXT,
                    content TEXT,
                    vdocipher_video_id VARCHAR(100),
                    duration INT DEFAULT 0,
                    sort_order INT DEFAULT 0,
                    is_active TINYINT(1) DEFAULT 1,
                    is_preview TINYINT(1) DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ",
            
            'activation_codes' => "
                CREATE TABLE activation_codes (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    code VARCHAR(50) NOT NULL UNIQUE,
                    course_id INT DEFAULT NULL,
                    max_uses INT DEFAULT 1,
                    used_count INT DEFAULT 0,
                    expires_at TIMESTAMP NULL,
                    is_active TINYINT(1) DEFAULT 1,
                    created_by INT DEFAULT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ",
            
            'subscriptions' => "
                CREATE TABLE subscriptions (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT NOT NULL,
                    course_id INT NOT NULL,
                    activation_code_id INT DEFAULT NULL,
                    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP NULL,
                    is_active TINYINT(1) DEFAULT 1
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ",
            
            'lesson_progress' => "
                CREATE TABLE lesson_progress (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT NOT NULL,
                    lesson_id INT NOT NULL,
                    last_position INT DEFAULT 0,
                    watch_time INT DEFAULT 0,
                    is_completed TINYINT(1) DEFAULT 0,
                    completed_at TIMESTAMP NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ",
            
            'user_sessions' => "
                CREATE TABLE user_sessions (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT NOT NULL,
                    session_id VARCHAR(128) NOT NULL,
                    session_token VARCHAR(255) NOT NULL,
                    ip_address VARCHAR(45),
                    user_agent TEXT,
                    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ",
            
            'security_logs' => "
                CREATE TABLE security_logs (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT DEFAULT NULL,
                    event_type VARCHAR(50) NOT NULL,
                    description TEXT,
                    ip_address VARCHAR(45),
                    user_agent TEXT,
                    additional_data TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ",
            
            'settings' => "
                CREATE TABLE settings (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    category VARCHAR(50) NOT NULL,
                    setting_key VARCHAR(100) NOT NULL,
                    setting_value TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            "
        ];

        $createdTables = [];
        $failedTables = [];
        
        foreach ($tables as $tableName => $sql) {
            try {
                // إزالة الجدول إذا كان موجوداً (للتأكد من بداية نظيفة)
                $pdo->exec("DROP TABLE IF EXISTS `$tableName`");
                
                // إنشاء الجدول
                $pdo->exec($sql);
                $createdTables[] = $tableName;
                $debug[] = "تم إنشاء جدول: $tableName";
            } catch (PDOException $e) {
                $failedTables[] = "$tableName: " . $e->getMessage();
                $debug[] = "فشل إنشاء جدول $tableName: " . $e->getMessage();
            }
        }
        
        if (empty($failedTables)) {
            return [
                'success' => true, 
                'message' => 'تم إنشاء جميع الجداول بنجاح (' . count($createdTables) . ' جدول)',
                'created' => $createdTables
            ];
        } else {
            return [
                'success' => false, 
                'error' => 'فشل في إنشاء بعض الجداول',
                'failed' => $failedTables,
                'created' => $createdTables
            ];
        }
        
    } catch (PDOException $e) {
        return ['success' => false, 'error' => 'خطأ عام في إنشاء الجداول: ' . $e->getMessage()];
    }
}

// معالجة الخطوات
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    switch ($step) {
        case 2: // فحص قاعدة البيانات
            $host = trim($_POST['db_host'] ?? '');
            $dbname = trim($_POST['db_name'] ?? '');
            $username = trim($_POST['db_user'] ?? '');
            $password = $_POST['db_pass'] ?? '';
            
            if (empty($host)) {
                $errors[] = 'عنوان خادم قاعدة البيانات مطلوب';
            }
            if (empty($dbname)) {
                $errors[] = 'اسم قاعدة البيانات مطلوب';
            }
            if (empty($username)) {
                $errors[] = 'اسم مستخدم قاعدة البيانات مطلوب';
            }
            
            if (empty($errors)) {
                $dbTest = testDatabaseConnection($host, $dbname, $username, $password);
                
                if ($dbTest['success']) {
                    if (!$dbTest['db_exists']) {
                        $createResult = createDatabase($dbTest['connection'], $dbname);
                        if ($createResult['success']) {
                            $success[] = 'تم إنشاء قاعدة البيانات بنجاح';
                        } else {
                            $errors[] = 'فشل في إنشاء قاعدة البيانات: ' . ($createResult['error'] ?? 'خطأ غير معروف');
                        }
                    } else {
                        $success[] = 'قاعدة البيانات موجودة مسبقاً';
                    }
                    
                    if (empty($errors)) {
                        $_SESSION['db_config'] = [
                            'host' => $host,
                            'name' => $dbname,
                            'user' => $username,
                            'pass' => $password
                        ];
                        
                        header("Location: ?step=3");
                        exit;
                    }
                } else {
                    $errors[] = 'فشل الاتصال بقاعدة البيانات: ' . $dbTest['error'];
                }
            }
            break;
            
        case 3: // إنشاء الجداول
            if (!isset($_SESSION['db_config'])) {
                $errors[] = 'بيانات قاعدة البيانات مفقودة. يرجى العودة للخطوة السابقة';
                $step = 2;
                break;
            }
            
            $config = $_SESSION['db_config'];
            
            try {
                $dsn = "mysql:host={$config['host']};charset=utf8mb4";
                $pdo = new PDO($dsn, $config['user'], $config['pass']);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                $result = createTables($pdo, $config['name']);
                
                if ($result['success']) {
                    $success[] = $result['message'];
                    
                    // التحقق من وجود الجداول فعلياً
                    $tableCount = checkTablesExist($pdo, $config['name']);
                    if ($tableCount >= 5) { // على الأقل 5 جداول أساسية
                        $success[] = "تم التحقق من إنشاء $tableCount جدول في قاعدة البيانات";
                        header("Location: ?step=4");
                        exit;
                    } else {
                        $errors[] = "تم الإبلاغ عن نجاح الإنشاء لكن تم العثور على $tableCount جدول فقط";
                    }
                } else {
                    $errors[] = $result['error'];
                    if (isset($result['failed'])) {
                        foreach ($result['failed'] as $failure) {
                            $errors[] = $failure;
                        }
                    }
                }
            } catch (Exception $e) {
                $errors[] = 'خطأ في الاتصال بقاعدة البيانات: ' . $e->getMessage();
            }
            break;
            
        case 4: // إنشاء حساب المسؤول
            $firstName = trim($_POST['first_name'] ?? '');
            $lastName = trim($_POST['last_name'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';
            
            if (empty($firstName)) {
                $errors[] = 'الاسم الأول مطلوب';
            }
            if (empty($lastName)) {
                $errors[] = 'اللقب مطلوب';
            }
            if (empty($email)) {
                $errors[] = 'البريد الإلكتروني مطلوب';
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = 'عنوان البريد الإلكتروني غير صحيح';
            }
            if (empty($password)) {
                $errors[] = 'كلمة المرور مطلوبة';
            } elseif (strlen($password) < 8) {
                $errors[] = 'كلمة المرور يجب أن تكون 8 أحرف على الأقل';
            }
            if ($password !== $confirmPassword) {
                $errors[] = 'كلمة المرور وتأكيدها غير متطابقتين';
            }
            
            if (empty($errors)) {
                if (isset($_SESSION['db_config'])) {
                    $config = $_SESSION['db_config'];
                    
                    try {
                        $dsn = "mysql:host={$config['host']};dbname={$config['name']};charset=utf8mb4";
                        $pdo = new PDO($dsn, $config['user'], $config['pass']);
                        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                        
                        // التحقق من وجود جدول users
                        $stmt = $pdo->prepare("SHOW TABLES LIKE 'users'");
                        $stmt->execute();
                        if (!$stmt->fetch()) {
                            $errors[] = 'جدول المستخدمين غير موجود. يرجى العودة لخطوة إنشاء الجداول';
                            $debug[] = 'جدول users غير موجود في قاعدة البيانات';
                            break;
                        }
                        
                        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                        
                        $stmt = $pdo->prepare("
                            INSERT INTO users (first_name, last_name, email, password_hash, is_admin, is_active, email_verified) 
                            VALUES (?, ?, ?, ?, 1, 1, 1)
                        ");
                        
                        $stmt->execute([$firstName, $lastName, $email, $hashedPassword]);
                        
                        $_SESSION['admin_created'] = true;
                        $success[] = 'تم إنشاء حساب المسؤول بنجاح';
                        
                        header("Location: ?step=5");
                        exit;
                    } catch (PDOException $e) {
                        if ($e->getCode() == 23000) {
                            $errors[] = 'البريد الإلكتروني مستخدم مسبقاً';
                        } else {
                            $errors[] = 'خطأ في إنشاء حساب المسؤول: ' . $e->getMessage();
                        }
                    }
                } else {
                    $errors[] = 'بيانات قاعدة البيانات مفقودة';
                    $step = 2;
                }
            }
            break;
            
        case 5: // إنشاء ملف config.php
            $siteUrl = trim($_POST['site_url'] ?? '');
            $siteName = trim($_POST['site_name'] ?? '');
            $vdocipherSecret = trim($_POST['vdocipher_secret'] ?? '');
            
            if (empty($siteUrl)) {
                $errors[] = 'رابط الموقع مطلوب';
            }
            if (empty($siteName)) {
                $errors[] = 'اسم الموقع مطلوب';
            }
            
            if (empty($errors)) {
                if (isset($_SESSION['db_config'])) {
                    $config = $_SESSION['db_config'];
                    
                    // إنشاء مفاتيح أمنية عشوائية
                    $securityKey = bin2hex(random_bytes(32));
                    $encryptionSalt = bin2hex(random_bytes(16));
                    
                    $configContent = "<?php\n";
                    $configContent .= "/**\n * ملف إعدادات منصة التعليم الإلكتروني\n * تم إنشاؤه تلقائياً في " . date('Y-m-d H:i:s') . "\n */\n\n";
                    $configContent .= "// منع الوصول المباشر\n";
                    $configContent .= "if (!defined('LEARNING_PLATFORM')) {\n    die('Direct access not allowed');\n}\n\n";
                    
                    $configContent .= "// إعدادات قاعدة البيانات\n";
                    $configContent .= "define('DB_HOST', '" . addslashes($config['host']) . "');\n";
                    $configContent .= "define('DB_NAME', '" . addslashes($config['name']) . "');\n";
                    $configContent .= "define('DB_USER', '" . addslashes($config['user']) . "');\n";
                    $configContent .= "define('DB_PASS', '" . addslashes($config['pass']) . "');\n";
                    $configContent .= "define('DB_CHARSET', 'utf8mb4');\n\n";
                    
                    $configContent .= "// إعدادات الموقع\n";
                    $configContent .= "define('SITE_NAME', '" . addslashes($siteName) . "');\n";
                    $configContent .= "define('SITE_URL', '" . addslashes($siteUrl) . "');\n";
                    $configContent .= "define('ADMIN_EMAIL', 'admin@example.com');\n\n";
                    
                    $configContent .= "// إعدادات الأمان\n";
                    $configContent .= "define('SECURITY_KEY', '$securityKey');\n";
                    $configContent .= "define('ENCRYPTION_SALT', '$encryptionSalt');\n\n";
                    
                    if (!empty($vdocipherSecret)) {
                        $configContent .= "// إعدادات VdoCipher\n";
                        $configContent .= "define('VDOCIPHER_API_SECRET', '" . addslashes($vdocipherSecret) . "');\n";
                        $configContent .= "define('VDOCIPHER_API_URL', 'https://dev.vdocipher.com/api');\n\n";
                    }
                    
                    $configContent .= "// إعدادات البيئة\n";
                    $configContent .= "define('ENVIRONMENT', 'production');\n";
                    $configContent .= "define('DEBUG_MODE', false);\n\n";
                    
                    $configContent .= "// تأكيد اكتمال التثبيت\n";
                    $configContent .= "define('INSTALLATION_COMPLETE', true);\n\n";
                    
                    $configContent .= "// إعدادات إضافية\n";
                    $configContent .= "define('MAX_UPLOAD_SIZE', 10485760); // 10MB\n";
                    $configContent .= "define('SESSION_TIMEOUT', 7200); // 2 hours\n";
                    $configContent .= "define('MAX_LOGIN_ATTEMPTS', 5);\n";
                    $configContent .= "define('LOGIN_LOCKOUT_TIME', 900); // 15 minutes\n\n";
                    
                    $configContent .= "?>";
                    
                    if (file_put_contents('config.php', $configContent)) {
                        $success[] = 'تم إنشاء ملف الإعدادات بنجاح';
                        
                        // تنظيف الجلسة
                        unset($_SESSION['db_config']);
                        
                        header("Location: ?step=6");
                        exit;
                    } else {
                        $errors[] = 'فشل في إنشاء ملف الإعدادات. تحقق من أذونات الكتابة في المجلد الجذر';
                    }
                } else {
                    $errors[] = 'بيانات قاعدة البيانات مفقودة';
                    $step = 2;
                }
            }
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تثبيت منصة التعليم الإلكتروني</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .install-container {
            max-width: 900px;
            margin: 2rem auto;
            padding: 2rem;
        }
        .install-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .install-header {
            background: linear-gradient(135deg, #007bff, #0056b3);
            color: white;
            padding: 2rem;
            text-align: center;
        }
        .step-indicator {
            display: flex;
            justify-content: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }
        .step {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 10px 10px 10px;
            font-weight: bold;
            position: relative;
        }
        .step.completed {
            background: #28a745;
            color: white;
        }
        .step.active {
            background: #007bff;
            color: white;
        }
        .step.pending {
            background: #e9ecef;
            color: #6c757d;
        }
        .requirement-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.75rem;
            border-bottom: 1px solid #f8f9fa;
        }
        .requirement-item:last-child {
            border-bottom: none;
        }
        .status-ok {
            color: #28a745;
        }
        .status-error {
            color: #dc3545;
        }
        .form-label {
            font-weight: 600;
            color: #495057;
        }
        .btn-lg {
            padding: 0.75rem 2rem;
            font-size: 1.1rem;
        }
        
        @media (max-width: 768px) {
            .install-container {
                padding: 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="install-container">
        <div class="install-card">
            <div class="install-header">
                <h1><i class="fas fa-graduation-cap me-3"></i>تثبيت منصة التعليم الإلكتروني</h1>
                <p class="mb-0">إعداد سريع وآمن لمنصتك التعليمية</p>
            </div>
            
            <div class="p-4">
                <!-- مؤشر الخطوات -->
                <div class="step-indicator">
                    <?php for ($i = 1; $i <= 6; $i++): ?>
                        <div class="step <?= $i < $step ? 'completed' : ($i == $step ? 'active' : 'pending') ?>">
                            <?= $i < $step ? '<i class="fas fa-check"></i>' : $i ?>
                        </div>
                    <?php endfor; ?>
                </div>
                
                <?php displayDebug($debug); ?>
                <?php displayErrors($errors); ?>
                <?php displaySuccess($success); ?>
                
                <?php if ($step == 1): ?>
                    <!-- الخطوة 1: فحص المتطلبات -->
                    <h3><i class="fas fa-list-check me-2"></i>فحص متطلبات النظام</h3>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <h5>متطلبات PHP</h5>
                            <div class="border rounded p-3 mb-3">
                                <?php foreach (checkPHPRequirements() as $req => $status): ?>
                                    <div class="requirement-item">
                                        <span><?= $req ?></span>
                                        <span class="<?= $status ? 'status-ok' : 'status-error' ?>">
                                            <i class="fas fa-<?= $status ? 'check' : 'times' ?>"></i>
                                            <?= $status ? 'متوفر' : 'غير متوفر' ?>
                                        </span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <h5>أذونات المجلدات</h5>
                            <div class="border rounded p-3 mb-3">
                                <?php foreach (checkDirectoryPermissions() as $dir => $status): ?>
                                    <div class="requirement-item">
                                        <span><?= $dir ?>/</span>
                                        <span class="<?= $status ? 'status-ok' : 'status-error' ?>">
                                            <i class="fas fa-<?= $status ? 'check' : 'times' ?>"></i>
                                            <?= $status ? 'قابل للكتابة' : 'غير قابل للكتابة' ?>
                                        </span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    
                    <?php 
                    $allRequirementsMet = array_reduce(array_merge(
                        checkPHPRequirements(), 
                        checkDirectoryPermissions()
                    ), function($carry, $item) {
                        return $carry && $item;
                    }, true);
                    ?>
                    
                    <?php if ($allRequirementsMet): ?>
                        <div class="text-center">
                            <a href="?step=2" class="btn btn-success btn-lg">
                                <i class="fas fa-arrow-left me-2"></i>متابعة لإعداد قاعدة البيانات
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-warning">
                            <strong>تحذير:</strong> بعض المتطلبات غير متوفرة. يرجى إصلاحها قبل المتابعة.
                            <br><button class="btn btn-warning btn-sm mt-2" onclick="location.reload()">
                                <i class="fas fa-redo me-1"></i>إعادة الفحص
                            </button>
                        </div>
                    <?php endif; ?>
                
                <?php elseif ($step == 2): ?>
                    <!-- الخطوة 2: إعداد قاعدة البيانات -->
                    <h3><i class="fas fa-database me-2"></i>إعداد قاعدة البيانات</h3>
                    
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>ملاحظة:</strong> تأكد من إنشاء قاعدة البيانات مسبقاً من cPanel أو أداة الإدارة.
                    </div>
                    
                    <form method="post">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">
                                    <i class="fas fa-server me-1"></i>عنوان الخادم *
                                </label>
                                <input type="text" class="form-control" name="db_host" 
                                       value="<?= htmlspecialchars($_POST['db_host'] ?? 'localhost') ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">
                                    <i class="fas fa-database me-1"></i>اسم قاعدة البيانات *
                                </label>
                                <input type="text" class="form-control" name="db_name" 
                                       value="<?= htmlspecialchars($_POST['db_name'] ?? '') ?>" 
                                       placeholder="u860905067_elearn" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">
                                    <i class="fas fa-user me-1"></i>اسم المستخدم *
                                </label>
                                <input type="text" class="form-control" name="db_user" 
                                       value="<?= htmlspecialchars($_POST['db_user'] ?? '') ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">
                                    <i class="fas fa-lock me-1"></i>كلمة المرور
                                </label>
                                <input type="password" class="form-control" name="db_pass">
                            </div>
                        </div>
                        
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-check me-2"></i>اختبار الاتصال ومتابعة
                            </button>
                        </div>
                    </form>
                
                <?php elseif ($step == 3): ?>
                    <!-- الخطوة 3: إنشاء الجداول -->
                    <h3><i class="fas fa-table me-2"></i>إنشاء جداول قاعدة البيانات</h3>
                    
                    <?php if (isset($_SESSION['db_config'])): ?>
                        <div class="alert alert-info">
                            <h5><i class="fas fa-info-circle me-2"></i>جاري إنشاء الجداول</h5>
                            <p>سيتم إنشاء 10 جداول أساسية للمنصة:</p>
                            <div class="row">
                                <div class="col-md-6">
                                    <ul class="list-unstyled">
                                        <li>✓ users (المستخدمين)</li>
                                        <li>✓ courses (الدورات)</li>
                                        <li>✓ sections (الأقسام)</li>
                                        <li>✓ lessons (الدروس)</li>
                                        <li>✓ activation_codes (أكواد التفعيل)</li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <ul class="list-unstyled">
                                        <li>✓ subscriptions (الاشتراكات)</li>
                                        <li>✓ lesson_progress (تقدم الدروس)</li>
                                        <li>✓ user_sessions (الجلسات)</li>
                                        <li>✓ security_logs (سجل الأمان)</li>
                                        <li>✓ settings (الإعدادات)</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                        <form method="post">
                            <div class="text-center">
                                <button type="submit" class="btn btn-success btn-lg">
                                    <i class="fas fa-plus me-2"></i>إنشاء الجداول الآن
                                </button>
                            </div>
                        </form>
                    <?php else: ?>
                        <div class="alert alert-danger">
                            <h5>بيانات قاعدة البيانات مفقودة</h5>
                            <a href="?step=2" class="btn btn-primary">العودة لإعداد قاعدة البيانات</a>
                        </div>
                    <?php endif; ?>
                
                <?php elseif ($step == 4): ?>
                    <!-- الخطوة 4: إنشاء حساب المسؤول -->
                    <h3><i class="fas fa-user-shield me-2"></i>إنشاء حساب المسؤول</h3>
                    
                    <form method="post">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">الاسم الأول *</label>
                                <input type="text" class="form-control" name="first_name" 
                                       value="<?= htmlspecialchars($_POST['first_name'] ?? '') ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">اللقب *</label>
                                <input type="text" class="form-control" name="last_name" 
                                       value="<?= htmlspecialchars($_POST['last_name'] ?? '') ?>" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">البريد الإلكتروني *</label>
                            <input type="email" class="form-control" name="email" 
                                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">كلمة المرور *</label>
                                <input type="password" class="form-control" name="password" required minlength="8">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">تأكيد كلمة المرور *</label>
                                <input type="password" class="form-control" name="confirm_password" required>
                            </div>
                        </div>
                        
                        <div class="text-center">
                            <button type="submit" class="btn btn-success btn-lg">
                                <i class="fas fa-user-plus me-2"></i>إنشاء حساب المسؤول
                            </button>
                        </div>
                    </form>
                
                <?php elseif ($step == 5): ?>
                    <!-- الخطوة 5: الإعدادات العامة -->
                    <h3><i class="fas fa-cog me-2"></i>الإعدادات العامة</h3>
                    
                    <form method="post">
                        <div class="mb-3">
                            <label class="form-label">رابط الموقع *</label>
                            <input type="url" class="form-control" name="site_url" 
                                   value="<?= htmlspecialchars($_POST['site_url'] ?? ((isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['REQUEST_URI']), '/'))) ?>" 
                                   required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">اسم الموقع *</label>
                            <input type="text" class="form-control" name="site_name" 
                                   value="<?= htmlspecialchars($_POST['site_name'] ?? 'منصة التعليم الإلكتروني') ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">VdoCipher API Secret (اختياري)</label>
                            <input type="text" class="form-control" name="vdocipher_secret" 
                                   value="<?= htmlspecialchars($_POST['vdocipher_secret'] ?? '') ?>">
                        </div>
                        
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save me-2"></i>حفظ الإعدادات وإنهاء التثبيت
                            </button>
                        </div>
                    </form>
                
                <?php elseif ($step == 6): ?>
                    <!-- الخطوة 6: اكتمال التثبيت -->
                    <div class="text-center">
                        <div class="mb-4">
                            <i class="fas fa-check-circle text-success" style="font-size: 4rem;"></i>
                        </div>
                        
                        <h3 class="text-success mb-4">🎉 تم اكتمال التثبيت بنجاح!</h3>
                        
                        <div class="alert alert-success">
                            <h5><strong>التثبيت مكتمل!</strong></h5>
                            <p>تم إعداد منصة التعليم الإلكتروني بنجاح.</p>
                        </div>
                        
                        <div class="alert alert-warning">
                            <h6><i class="fas fa-exclamation-triangle me-2"></i>تنبيه أمني مهم</h6>
                            <p><strong>احذف ملف install.php فوراً</strong> لأسباب أمنية!</p>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-block">
                            <a href="index.php" class="btn btn-outline-primary">الصفحة الرئيسية</a>
                            <a href="login.php" class="btn btn-success">تسجيل الدخول</a>
                            <a href="editdash.php" class="btn btn-outline-info">لوحة التحكم</a>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>