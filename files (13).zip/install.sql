-- منصة ترند التعليمية - هيكل قاعدة البيانات
-- المطور: anaso2gen
-- التاريخ: 2025-05-29 08:33:09

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

-- قاعدة البيانات: learning_platform
CREATE DATABASE IF NOT EXISTS `learning_platform` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `learning_platform`;

-- جدول المستخدمين
CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `avatar_url` varchar(500) DEFAULT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `newsletter_subscribed` tinyint(1) NOT NULL DEFAULT 0,
  `activation_code` varchar(100) DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `is_active` (`is_active`),
  KEY `is_admin` (`is_admin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول الدورات
CREATE TABLE `courses` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `short_description` varchar(500) DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `level` enum('beginner','intermediate','advanced') DEFAULT 'beginner',
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `duration_hours` int(11) DEFAULT NULL,
  `instructor_id` bigint(20) UNSIGNED DEFAULT NULL,
  `instructor_name` varchar(255) DEFAULT NULL,
  `instructor_avatar` varchar(500) DEFAULT NULL,
  `is_featured` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `category` (`category`),
  KEY `level` (`level`),
  KEY `is_featured` (`is_featured`),
  KEY `is_active` (`is_active`),
  KEY `instructor_id` (`instructor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول أقسام الدورات
CREATE TABLE `sections` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `course_id` (`course_id`),
  KEY `sort_order` (`sort_order`),
  CONSTRAINT `sections_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول الدروس
CREATE TABLE `lessons` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `section_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `vdocipher_id` varchar(100) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL COMMENT 'Duration in seconds',
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_preview` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `section_id` (`section_id`),
  KEY `sort_order` (`sort_order`),
  KEY `vdocipher_id` (`vdocipher_id`),
  CONSTRAINT `lessons_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول أكواد التفعيل
CREATE TABLE `activation_codes` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `course_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'NULL for all courses',
  `max_uses` int(11) NOT NULL DEFAULT 1,
  `used_count` int(11) NOT NULL DEFAULT 0,
  `subscription_days` int(11) NOT NULL DEFAULT 365,
  `expires_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `course_id` (`course_id`),
  KEY `expires_at` (`expires_at`),
  CONSTRAINT `activation_codes_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول الاشتراكات
CREATE TABLE `subscriptions` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `course_id` bigint(20) UNSIGNED NOT NULL,
  `activation_code_id` bigint(20) UNSIGNED DEFAULT NULL,
  `subscription_type` enum('free','code','paid') NOT NULL DEFAULT 'code',
  `expires_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_course_unique` (`user_id`,`course_id`),
  KEY `course_id` (`course_id`),
  KEY `activation_code_id` (`activation_code_id`),
  KEY `expires_at` (`expires_at`),
  CONSTRAINT `subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subscriptions_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subscriptions_activation_code_id_foreign` FOREIGN KEY (`activation_code_id`) REFERENCES `activation_codes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول تقدم الدروس
CREATE TABLE `lesson_progress` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `lesson_id` bigint(20) UNSIGNED NOT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `last_position` int(11) NOT NULL DEFAULT 0 COMMENT 'Last watched position in seconds',
  `completed` tinyint(1) NOT NULL DEFAULT 0,
  `ip_address` varchar(45) DEFAULT NULL,
  `last_accessed` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_lesson_unique` (`user_id`,`lesson_id`),
  KEY `lesson_id` (`lesson_id`),
  KEY `completed` (`completed`),
  CONSTRAINT `lesson_progress_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lesson_progress_lesson_id_foreign` FOREIGN KEY (`lesson_id`) REFERENCES `lessons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول جلسات المستخدمين
CREATE TABLE `user_sessions` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `session_id` varchar(128) NOT NULL,
  `session_token` varchar(128) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`),
  UNIQUE KEY `session_token` (`session_token`),
  KEY `user_id` (`user_id`),
  KEY `last_activity` (`last_activity`),
  CONSTRAINT `user_sessions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول سجل الأمان
CREATE TABLE `security_logs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `event_type` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `additional_data` json DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `event_type` (`event_type`),
  KEY `ip_address` (`ip_address`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول سجل استخدام الأكواد
CREATE TABLE `code_usage_log` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `activation_code_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `activation_code_id` (`activation_code_id`),
  KEY `user_id` (`user_id`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `code_usage_log_activation_code_id_foreign` FOREIGN KEY (`activation_code_id`) REFERENCES `activation_codes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `code_usage_log_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول تقييمات الدورات
CREATE TABLE `course_reviews` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `course_id` bigint(20) UNSIGNED NOT NULL,
  `rating` tinyint(4) NOT NULL CHECK (`rating` >= 1 AND `rating` <= 5),
  `review_text` text DEFAULT NULL,
  `is_approved` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_course_review_unique` (`user_id`,`course_id`),
  KEY `course_id` (`course_id`),
  KEY `rating` (`rating`),
  KEY `is_approved` (`is_approved`),
  CONSTRAINT `course_reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `course_reviews_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج مستخدم مسؤول افتراضي
INSERT INTO `users` (`first_name`, `last_name`, `email`, `password_hash`, `is_admin`, `is_active`, `created_at`) 
VALUES ('مسؤول', 'النظام', 'admin@trendeducation.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1, 1, NOW());

-- إدراج بيانات تجريبية للدورات
INSERT INTO `courses` (`name`, `description`, `short_description`, `category`, `level`, `price`, `duration_hours`, `instructor_name`, `is_featured`, `is_active`) VALUES
('مقدمة في البرمجة', 'دورة شاملة لتعلم أساسيات البرمجة باستخدام Python', 'تعلم البرمجة من الصفر', 'البرمجة', 'beginner', 0.00, 20, 'أحمد محمد', 1, 1),
('تطوير المواقع بـ PHP', 'دورة متقدمة لتطوير المواقع الديناميكية', 'احترف تطوير المواقع', 'تطوير الويب', 'intermediate', 299.00, 35, 'سارة أحمد', 1, 1),
('أساسيات التصميم الجرافيكي', 'تعلم مبادئ التصميم واستخدام أدوات Adobe', 'ابدأ رحلتك في التصميم', 'التصميم', 'beginner', 199.00, 25, 'محمد علي', 0, 1),
('إدارة المشاريع الرقمية', 'دورة شاملة في إدارة المشاريع التقنية', 'قد المشاريع بفعالية', 'إدارة الأعمال', 'intermediate', 399.00, 30, 'فاطمة خالد', 1, 1);

-- إدراج أقسام ودروس تجريبية
INSERT INTO `sections` (`course_id`, `name`, `description`, `sort_order`) VALUES
(1, 'المقدمة والأساسيات', 'التعرف على مفاهيم البرمجة الأساسية', 1),
(1, 'المتغيرات والدوال', 'تعلم كيفية استخدام المتغيرات وإنشاء الدوال', 2),
(2, 'إعداد البيئة التطويرية', 'تثبيت وإعداد PHP والخادم المحلي', 1),
(2, 'أساسيات PHP', 'تعلم بنية اللغة والمتغيرات', 2);

INSERT INTO `lessons` (`section_id`, `name`, `description`, `duration`, `sort_order`, `is_preview`) VALUES
(1, 'ما هي البرمجة؟', 'مقدمة عن البرمجة ولماذا نحتاجها', 900, 1, 1),
(1, 'اختيار لغة البرمجة', 'كيفية اختيار اللغة المناسبة لك', 1200, 2, 1),
(2, 'المتغيرات في Python', 'تعلم كيفية إنشاء واستخدام المتغيرات', 1500, 1, 0),
(3, 'تثبيت XAMPP', 'دليل خطوة بخطوة لتثبيت XAMPP', 1800, 1, 1),
(4, 'بنية ملف PHP', 'تعلم الهيكل الأساسي لملف PHP', 1000, 1, 0);

-- إدراج أكواد تفعيل تجريبية
INSERT INTO `activation_codes` (`code`, `course_id`, `max_uses`, `subscription_days`, `is_active`) VALUES
('WELCOME2024', NULL, 100, 365, 1),
('PHP2024', 2, 50, 180, 1),
('DESIGN2024', 3, 30, 90, 1),
('PREMIUM2024', NULL, 10, 730, 1);

COMMIT;