<?php
/**
 * API إنشاء كود اشتراك جديد (للمسؤولين فقط)
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(['success' => false, 'message' => 'طريقة طلب غير صالحة'], 405);
}

try {
    $user = $sessionManager->requireAdmin();
    $db = Database::getInstance()->getConnection();
    
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    
    $code = sanitizeInput($input['code'] ?? '');
    $courseId = intval($input['course_id'] ?? 0);
    $maxUses = intval($input['max_uses'] ?? 0);
    $expiresAt = $input['expires_at'] ?? null;
    $isActive = isset($input['is_active']) ? 1 : 0;
    
    $errors = [];
    
    // التحقق من صحة البيانات
    if (empty($code)) {
        $errors['code'] = 'الكود مطلوب';
    } else {
        // التحقق من عدم تكرار الكود
        $stmt = $db->prepare("SELECT COUNT(*) FROM codes WHERE code = ?");
        $stmt->execute([$code]);
        if ($stmt->fetchColumn() > 0) {
            $errors['code'] = 'الكود موجود مسبقاً';
        }
    }
    
    if ($courseId <= 0) {
        $errors['course_id'] = 'الدورة مطلوبة';
    } else {
        // التحقق من وجود الدورة
        $stmt = $db->prepare("SELECT id FROM courses WHERE id = ? AND is_active = 1");
        $stmt->execute([$courseId]);
        if (!$stmt->fetch()) {
            $errors['course_id'] = 'الدورة غير موجودة';
        }
    }
    
    if ($maxUses < 0) {
        $errors['max_uses'] = 'عدد الاستخدامات لا يمكن أن يكون سالباً';
    }
    
    if ($expiresAt && !strtotime($expiresAt)) {
        $errors['expires_at'] = 'تاريخ انتهاء الصلاحية غير صالح';
    }
    
    if (!empty($errors)) {
        sendJsonResponse([
            'success' => false,
            'message' => 'بيانات غير صالحة',
            'errors' => $errors
        ]);
    }
    
    // إنشاء الكود
    $stmt = $db->prepare("
        INSERT INTO codes (code, course_id, max_uses, expires_at, is_active, created_by) 
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $code, 
        $courseId, 
        $maxUses, 
        $expiresAt ?: null, 
        $isActive,
        $user['id']
    ]);
    
    $codeId = $db->lastInsertId();
    
    // جلب الكود المنشأ مع بيانات الكورس
    $stmt = $db->prepare("
        SELECT c.*, co.name as course_name, co.code as course_code,
               u.email as created_by_email
        FROM codes c
        JOIN courses co ON co.id = c.course_id
        LEFT JOIN users u ON u.id = c.created_by
        WHERE c.id = ?
    ");
    
    $stmt->execute([$codeId]);
    $createdCode = $stmt->fetch();
    
    sendJsonResponse([
        'success' => true,
        'message' => 'تم إنشاء الكود بنجاح',
        'code' => $createdCode
    ]);
    
} catch (Exception $e) {
    logError("Create code error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في إنشاء الكود'
    ], 500);
}
?>