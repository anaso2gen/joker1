<?php
/**
 * API حذف الكورس (للمسؤولين فقط)
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    sendJsonResponse(['success' => false, 'message' => 'طريقة طلب غير صالحة'], 405);
}

try {
    $user = $sessionManager->requireAdmin();
    $db = Database::getInstance()->getConnection();
    
    $courseId = intval($_GET['id'] ?? 0);
    
    if ($courseId <= 0) {
        sendJsonResponse([
            'success' => false,
            'message' => 'معرف الدورة غير صالح'
        ]);
    }
    
    // التحقق من وجود الكورس
    $stmt = $db->prepare("SELECT * FROM courses WHERE id = ?");
    $stmt->execute([$courseId]);
    $course = $stmt->fetch();
    
    if (!$course) {
        sendJsonResponse([
            'success' => false,
            'message' => 'الدورة غير موجودة'
        ], 404);
    }
    
    // التحقق من وجود اشتراكات فعالة
    $stmt = $db->prepare("SELECT COUNT(*) FROM subscriptions WHERE course_id = ? AND status = 'active'");
    $stmt->execute([$courseId]);
    $activeSubscriptions = $stmt->fetchColumn();
    
    if ($activeSubscriptions > 0) {
        sendJsonResponse([
            'success' => false,
            'message' => 'لا يمكن حذف الدورة لوجود اشتراكات فعالة'
        ]);
    }
    
    $db->beginTransaction();
    
    try {
        // حذف تقدم الدروس
        $stmt = $db->prepare("
            DELETE lp FROM lesson_progress lp
            JOIN lessons l ON l.id = lp.lesson_id
            JOIN sections s ON s.id = l.section_id
            WHERE s.course_id = ?
        ");
        $stmt->execute([$courseId]);
        
        // حذف الدروس
        $stmt = $db->prepare("
            DELETE l FROM lessons l
            JOIN sections s ON s.id = l.section_id
            WHERE s.course_id = ?
        ");
        $stmt->execute([$courseId]);
        
        // حذف الأقسام
        $stmt = $db->prepare("DELETE FROM sections WHERE course_id = ?");
        $stmt->execute([$courseId]);
        
        // حذف الاشتراكات
        $stmt = $db->prepare("DELETE FROM subscriptions WHERE course_id = ?");
        $stmt->execute([$courseId]);
        
        // حذف الأكواد
        $stmt = $db->prepare("DELETE FROM codes WHERE course_id = ?");
        $stmt->execute([$courseId]);
        
        // حذف الكورس
        $stmt = $db->prepare("DELETE FROM courses WHERE id = ?");
        $stmt->execute([$courseId]);
        
        $db->commit();
        
        // حذف صورة الكورس
        if ($course['image_url'] && file_exists(str_replace(SITE_URL, BASE_PATH, $course['image_url']))) {
            unlink(str_replace(SITE_URL, BASE_PATH, $course['image_url']));
        }
        
        sendJsonResponse([
            'success' => true,
            'message' => 'تم حذف الدورة بنجاح'
        ]);
        
    } catch (Exception $e) {
        $db->rollback();
        throw $e;
    }
    
} catch (Exception $e) {
    logError("Delete course error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في حذف الدورة'
    ], 500);
}
?>