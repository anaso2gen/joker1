<?php
/**
 * API جلب الكورسات
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

try {
    $db = Database::getInstance()->getConnection();
    $user = $sessionManager->validateSession();
    
    // إذا كان طلب لكورس محدد
    if (isset($_GET['id'])) {
        $courseId = intval($_GET['id']);
        
        $stmt = $db->prepare("
            SELECT c.*, 
                   COUNT(DISTINCT s.id) as sections_count,
                   COUNT(DISTINCT l.id) as lessons_count,
                   SUM(l.duration) as total_duration
            FROM courses c
            LEFT JOIN sections s ON s.course_id = c.id AND s.is_active = 1
            LEFT JOIN lessons l ON l.section_id = s.id AND l.is_active = 1
            WHERE c.id = ? AND c.is_active = 1
            GROUP BY c.id
        ");
        
        $stmt->execute([$courseId]);
        $course = $stmt->fetch();
        
        if (!$course) {
            sendJsonResponse([
                'success' => false,
                'message' => 'الدورة غير موجودة'
            ], 404);
        }
        
        // التحقق من الاشتراك إذا كان المستخدم مسجل دخول
        $subscribed = false;
        if ($user) {
            $subscribed = $sessionManager->hasSubscription($courseId, $user['user_id']);
        }
        
        $course['subscribed'] = $subscribed;
        $course['total_duration'] = formatDuration($course['total_duration'] ?: 0);
        
        sendJsonResponse([
            'success' => true,
            'course' => $course
        ]);
        return;
    }
    
    // جلب جميع الكورسات
    $page = max(1, intval($_GET['page'] ?? 1));
    $limit = max(1, min(50, intval($_GET['limit'] ?? 12)));
    $offset = ($page - 1) * $limit;
    
    $search = sanitizeInput($_GET['search'] ?? '');
    $category = sanitizeInput($_GET['category'] ?? '');
    $level = sanitizeInput($_GET['level'] ?? '');
    $sort = sanitizeInput($_GET['sort'] ?? 'created_at');
    
    // بناء شروط البحث
    $whereConditions = ['c.is_active = 1'];
    $params = [];
    
    if (!empty($search)) {
        $whereConditions[] = "(c.name LIKE ? OR c.description LIKE ? OR c.code LIKE ?)";
        $searchTerm = "%{$search}%";
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }
    
    // ترتيب النتائج
    $orderBy = 'c.created_at DESC';
    switch ($sort) {
        case 'name':
            $orderBy = 'c.name ASC';
            break;
        case 'popular':
            $orderBy = 'subscribers_count DESC, c.created_at DESC';
            break;
        case 'updated':
            $orderBy = 'c.updated_at DESC';
            break;
    }
    
    $whereClause = implode(' AND ', $whereConditions);
    
    // جلب الكورسات مع الإحصائيات
    $stmt = $db->prepare("
        SELECT c.*, 
               COUNT(DISTINCT s.id) as sections_count,
               COUNT(DISTINCT l.id) as lessons_count,
               SUM(l.duration) as total_duration,
               COUNT(DISTINCT sub.user_id) as subscribers_count
        FROM courses c
        LEFT JOIN sections s ON s.course_id = c.id AND s.is_active = 1
        LEFT JOIN lessons l ON l.section_id = s.id AND l.is_active = 1
        LEFT JOIN subscriptions sub ON sub.course_id = c.id AND sub.status = 'active'
        WHERE {$whereClause}
        GROUP BY c.id
        ORDER BY {$orderBy}
        LIMIT {$limit} OFFSET {$offset}
    ");
    
    $stmt->execute($params);
    $courses = $stmt->fetchAll();
    
    // التحقق من الاشتراكات للمستخدم المسجل دخول
    if ($user) {
        $userSubscriptions = $sessionManager->getUserSubscriptions($user['user_id']);
        $subscribedCourseIds = array_column($userSubscriptions, 'course_id');
        
        foreach ($courses as &$course) {
            $course['subscribed'] = in_array($course['id'], $subscribedCourseIds);
            $course['total_duration'] = formatDuration($course['total_duration'] ?: 0);
        }
    } else {
        foreach ($courses as &$course) {
            $course['subscribed'] = false;
            $course['total_duration'] = formatDuration($course['total_duration'] ?: 0);
        }
    }
    
    // عدد الكورسات الإجمالي
    $countStmt = $db->prepare("SELECT COUNT(*) as total FROM courses c WHERE {$whereClause}");
    $countStmt->execute($params);
    $total = $countStmt->fetch()['total'];
    
    sendJsonResponse([
        'success' => true,
        'courses' => $courses,
        'pagination' => [
            'current_page' => $page,
            'total_pages' => ceil($total / $limit),
            'total_items' => (int)$total,
            'items_per_page' => $limit,
            'has_more' => $page < ceil($total / $limit)
        ]
    ]);
    
} catch (Exception $e) {
    logError("Get courses error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في جلب الكورسات'
    ], 500);
}
?>