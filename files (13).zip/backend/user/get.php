<?php
/**
 * API جلب بيانات المستخدمين
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

try {
    $user = $sessionManager->requireLogin();
    $db = Database::getInstance()->getConnection();
    
    // إذا كان الطلب لجلب ملف المستخدم الشخصي
    if (!isset($_GET['list']) && !isset($_GET['id'])) {
        // جلب إحصائيات المستخدم
        $stmt = $db->prepare("
            SELECT 
                COUNT(DISTINCT s.course_id) as subscribed_courses,
                COUNT(DISTINCT lp.lesson_id) as completed_lessons,
                COALESCE(SUM(l.duration), 0) as total_watch_time
            FROM subscriptions s
            LEFT JOIN lesson_progress lp ON lp.user_id = s.user_id AND lp.completed = 1
            LEFT JOIN lessons l ON l.id = lp.lesson_id
            WHERE s.user_id = ? AND s.status = 'active'
        ");
        
        $stmt->execute([$user['user_id']]);
        $stats = $stmt->fetch();
        
        // جلب آخر الدروس المشاهدة
        $stmt = $db->prepare("
            SELECT l.*, c.name as course_name, s.name as section_name,
                   lp.last_position, lp.watch_time
            FROM lesson_progress lp
            JOIN lessons l ON l.id = lp.lesson_id
            JOIN sections s ON s.id = l.section_id
            JOIN courses c ON c.id = s.course_id
            JOIN subscriptions sub ON sub.course_id = c.id AND sub.user_id = lp.user_id
            WHERE lp.user_id = ? AND lp.watch_time > 0
            ORDER BY lp.updated_at DESC
            LIMIT 5
        ");
        
        $stmt->execute([$user['user_id']]);
        $recentLessons = $stmt->fetchAll();
        
        sendJsonResponse([
            'success' => true,
            'user' => [
                'user_id' => $user['user_id'],
                'email' => $user['email'],
                'full_name' => $user['full_name'],
                'avatar_url' => $user['avatar_url'],
                'last_login' => $user['last_login'],
                'created_at' => $user['created_at']
            ],
            'stats' => [
                'subscribed_courses' => (int)$stats['subscribed_courses'],
                'completed_lessons' => (int)$stats['completed_lessons'],
                'total_watch_time' => formatDuration($stats['total_watch_time'])
            ],
            'recent_lessons' => $recentLessons
        ]);
    }
    
    // إذا كان المستخدم مسؤول ويطلب قائمة المستخدمين
    if (isset($_GET['list']) && $user['is_admin']) {
        $page = max(1, intval($_GET['page'] ?? 1));
        $limit = max(1, min(100, intval($_GET['limit'] ?? 20)));
        $offset = ($page - 1) * $limit;
        
        $search = sanitizeInput($_GET['search'] ?? '');
        $status = sanitizeInput($_GET['status'] ?? '');
        
        $whereConditions = [];
        $params = [];
        
        if (!empty($search)) {
            $whereConditions[] = "(email LIKE ? OR full_name LIKE ?)";
            $params[] = "%{$search}%";
            $params[] = "%{$search}%";
        }
        
        if ($status === 'active') {
            $whereConditions[] = "is_active = 1";
        } elseif ($status === 'inactive') {
            $whereConditions[] = "is_active = 0";
        }
        
        $whereClause = empty($whereConditions) ? '' : 'WHERE ' . implode(' AND ', $whereConditions);
        
        // جلب المستخدمين
        $stmt = $db->prepare("
            SELECT u.*, 
                   COUNT(DISTINCT s.course_id) as subscribed_courses,
                   MAX(sess.created_at) as last_session
            FROM users u
            LEFT JOIN subscriptions s ON s.user_id = u.user_id AND s.status = 'active'
            LEFT JOIN sessions sess ON sess.user_id = u.user_id
            {$whereClause}
            GROUP BY u.id
            ORDER BY u.created_at DESC
            LIMIT {$limit} OFFSET {$offset}
        ");
        
        $stmt->execute($params);
        $users = $stmt->fetchAll();
        
        // عدد المستخدمين الإجمالي
        $countStmt = $db->prepare("SELECT COUNT(*) as total FROM users u {$whereClause}");
        $countStmt->execute($params);
        $total = $countStmt->fetch()['total'];
        
        sendJsonResponse([
            'success' => true,
            'users' => $users,
            'pagination' => [
                'current_page' => $page,
                'total_pages' => ceil($total / $limit),
                'total_items' => (int)$total,
                'items_per_page' => $limit
            ]
        ]);
    }
    
    // جلب مستخدم محدد (للمسؤولين)
    if (isset($_GET['id']) && $user['is_admin']) {
        $userId = sanitizeInput($_GET['id']);
        
        $stmt = $db->prepare("
            SELECT u.*, 
                   COUNT(DISTINCT s.course_id) as subscribed_courses,
                   COUNT(DISTINCT lp.lesson_id) as completed_lessons
            FROM users u
            LEFT JOIN subscriptions s ON s.user_id = u.user_id AND s.status = 'active'
            LEFT JOIN lesson_progress lp ON lp.user_id = u.user_id AND lp.completed = 1
            WHERE u.user_id = ?
            GROUP BY u.id
        ");
        
        $stmt->execute([$userId]);
        $targetUser = $stmt->fetch();
        
        if (!$targetUser) {
            sendJsonResponse([
                'success' => false,
                'message' => 'المستخدم غير موجود'
            ], 404);
        }
        
        // جلب اشتراكات المستخدم
        $stmt = $db->prepare("
            SELECT s.*, c.name as course_name, c.code as course_code
            FROM subscriptions s
            JOIN courses c ON c.id = s.course_id
            WHERE s.user_id = ?
            ORDER BY s.subscribed_at DESC
        ");
        
        $stmt->execute([$userId]);
        $subscriptions = $stmt->fetchAll();
        
        sendJsonResponse([
            'success' => true,
            'user' => $targetUser,
            'subscriptions' => $subscriptions
        ]);
    }
    
} catch (Exception $e) {
    logError("Get user error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في جلب بيانات المستخدم'
    ], 500);
}
?>