<?php
/**
 * API تحديث بيانات المستخدم
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

// التأكد من أن الطلب PUT أو POST
if (!in_array($_SERVER['REQUEST_METHOD'], ['PUT', 'POST'])) {
    sendJsonResponse(['success' => false, 'message' => 'طريقة طلب غير صالحة'], 405);
}

try {
    $user = $sessionManager->requireLogin();
    $db = Database::getInstance()->getConnection();
    
    // جلب البيانات المرسلة
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    
    $fullName = sanitizeInput($input['full_name'] ?? '');
    $currentPassword = $input['current_password'] ?? '';
    $newPassword = $input['new_password'] ?? '';
    $confirmPassword = $input['confirm_password'] ?? '';
    
    $errors = [];
    $updateFields = [];
    $updateParams = [];
    
    // تحديث الاسم الكامل
    if (!empty($fullName)) {
        $updateFields[] = "full_name = ?";
        $updateParams[] = $fullName;
    }
    
    // تحديث كلمة المرور
    if (!empty($newPassword)) {
        if (empty($currentPassword)) {
            $errors['current_password'] = 'كلمة المرور الحالية مطلوبة';
        } else {
            // التحقق من كلمة المرور الحالية
            $stmt = $db->prepare("SELECT password FROM users WHERE user_id = ?");
            $stmt->execute([$user['user_id']]);
            $currentHash = $stmt->fetchColumn();
            
            if (!verifyPassword($currentPassword, $currentHash)) {
                $errors['current_password'] = 'كلمة المرور الحالية غير صحيحة';
            }
        }
        
        if (!validatePassword($newPassword)) {
            $errors['new_password'] = 'كلمة المرور يجب أن تكون ' . PASSWORD_MIN_LENGTH . ' أحرف على الأقل';
        }
        
        if ($newPassword !== $confirmPassword) {
            $errors['confirm_password'] = 'كلمة المرور غير متطابقة';
        }
        
        if (empty($errors)) {
            $updateFields[] = "password = ?";
            $updateParams[] = hashPassword($newPassword);
        }
    }
    
    // معالجة رفع الصورة الشخصية
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $uploadResult = handleAvatarUpload($_FILES['avatar'], $user['user_id']);
        
        if ($uploadResult['success']) {
            $updateFields[] = "avatar_url = ?";
            $updateParams[] = $uploadResult['url'];
        } else {
            $errors['avatar'] = $uploadResult['message'];
        }
    }
    
    if (!empty($errors)) {
        sendJsonResponse([
            'success' => false,
            'message' => 'بيانات غير صالحة',
            'errors' => $errors
        ]);
    }
    
    if (empty($updateFields)) {
        sendJsonResponse([
            'success' => false,
            'message' => 'لا توجد بيانات للتحديث'
        ]);
    }
    
    // تحديث البيانات
    $updateFields[] = "updated_at = NOW()";
    $updateParams[] = $user['user_id'];
    
    $sql = "UPDATE users SET " . implode(', ', $updateFields) . " WHERE user_id = ?";
    $stmt = $db->prepare($sql);
    $stmt->execute($updateParams);
    
    // جلب البيانات المحدثة
    $stmt = $db->prepare("SELECT user_id, email, full_name, avatar_url FROM users WHERE user_id = ?");
    $stmt->execute([$user['user_id']]);
    $updatedUser = $stmt->fetch();
    
    sendJsonResponse([
        'success' => true,
        'message' => 'تم تحديث البيانات بنجاح',
        'user' => $updatedUser
    ]);
    
} catch (Exception $e) {
    logError("Update user error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في تحديث البيانات'
    ], 500);
}

/**
 * معالجة رفع الصورة الشخصية
 */
function handleAvatarUpload($file, $userId) {
    try {
        // التحقق من نوع الملف
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (!in_array($file['type'], $allowedTypes)) {
            return ['success' => false, 'message' => 'نوع الملف غير مدعوم'];
        }
        
        // التحقق من حجم الملف (5MB كحد أقصى)
        if ($file['size'] > 5 * 1024 * 1024) {
            return ['success' => false, 'message' => 'حجم الملف كبير جداً'];
        }
        
        // إنشاء مجلد الرفع
        $uploadDir = UPLOAD_PATH . 'avatars/';
        ensureDirectoryExists($uploadDir);
        
        // تحديد اسم الملف
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = $userId . '_' . time() . '.' . $extension;
        $filepath = $uploadDir . $filename;
        
        // رفع الملف
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            // تغيير حجم الصورة إذا كانت كبيرة
            resizeImage($filepath, 200, 200);
            
            $url = SITE_URL . '/uploads/avatars/' . $filename;
            
            return ['success' => true, 'url' => $url];
        } else {
            return ['success' => false, 'message' => 'خطأ في رفع الملف'];
        }
        
    } catch (Exception $e) {
        logError("Avatar upload error: " . $e->getMessage());
        return ['success' => false, 'message' => 'خطأ في معالجة الصورة'];
    }
}

/**
 * تغيير حجم الصورة
 */
function resizeImage($filepath, $maxWidth, $maxHeight) {
    try {
        $imageInfo = getimagesize($filepath);
        if (!$imageInfo) return false;
        
        $width = $imageInfo[0];
        $height = $imageInfo[1];
        $type = $imageInfo[2];
        
        // إذا كانت الصورة أصغر من المطلوب، لا نحتاج لتغيير الحجم
        if ($width <= $maxWidth && $height <= $maxHeight) {
            return true;
        }
        
        // حساب النسبة الجديدة
        $ratio = min($maxWidth / $width, $maxHeight / $height);
        $newWidth = (int)($width * $ratio);
        $newHeight = (int)($height * $ratio);
        
        // إنشاء الصورة الجديدة
        $newImage = imagecreatetruecolor($newWidth, $newHeight);
        
        switch ($type) {
            case IMAGETYPE_JPEG:
                $source = imagecreatefromjpeg($filepath);
                break;
            case IMAGETYPE_PNG:
                $source = imagecreatefrompng($filepath);
                imagealphablending($newImage, false);
                imagesavealpha($newImage, true);
                break;
            case IMAGETYPE_GIF:
                $source = imagecreatefromgif($filepath);
                break;
            default:
                return false;
        }
        
        // تغيير الحجم
        imagecopyresampled($newImage, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
        
        // حفظ الصورة الجديدة
        switch ($type) {
            case IMAGETYPE_JPEG:
                imagejpeg($newImage, $filepath, 85);
                break;
            case IMAGETYPE_PNG:
                imagepng($newImage, $filepath);
                break;
            case IMAGETYPE_GIF:
                imagegif($newImage, $filepath);
                break;
        }
        
        // تنظيف الذاكرة
        imagedestroy($source);
        imagedestroy($newImage);
        
        return true;
        
    } catch (Exception $e) {
        logError("Image resize error: " . $e->getMessage());
        return false;
    }
}
?>