<?php
/**
 * API جلب دروس القسم
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

try {
    $db = Database::getInstance()->getConnection();
    $user = $sessionManager->validateSession();
    
    $sectionId = intval($_GET['section_id'] ?? 0);
    
    if ($sectionId <= 0) {
        sendJsonResponse([
            'success' => false,
            'message' => 'معرف القسم غير صالح'
        ]);
    }
    
    // التحقق من وجود القسم
    $stmt = $db->prepare("
        SELECT s.*, c.name as course_name, c.id as course_id
        FROM sections s
        JOIN courses c ON c.id = s.course_id
        WHERE s.id = ? AND s.is_active = 1 AND c.is_active = 1
    ");
    
    $stmt->execute([$sectionId]);
    $section = $stmt->fetch();
    
    if (!$section) {
        sendJsonResponse([
            'success' => false,
            'message' => 'القسم غير موجود'
        ], 404);
    }
    
    // التحقق من الاشتراك في الكورس
    $userSubscribed = false;
    if ($user) {
        $userSubscribed = $sessionManager->hasSubscription($section['course_id'], $user['user_id']);
    }
    
    // جلب دروس القسم
    $stmt = $db->prepare("
        SELECT l.*
        FROM lessons l
        WHERE l.section_id = ? AND l.is_active = 1
        ORDER BY l.order_index ASC, l.created_at ASC
    ");
    
    $stmt->execute([$sectionId]);
    $lessons = $stmt->fetchAll();
    
    // إضافة معلومات التقدم للمستخدم المشترك
    if ($user && $userSubscribed) {
        $stmt = $db->prepare("
            SELECT lesson_id, completed, watch_time, last_position,
                   (watch_time * 100.0 / GREATEST(l.duration, 1)) as progress_percentage
            FROM lesson_progress lp
            JOIN lessons l ON l.id = lp.lesson_id
            WHERE lp.user_id = ? AND l.section_id = ?
        ");
        
        $stmt->execute([$user['user_id'], $sectionId]);
        $progressData = [];
        
        while ($progress = $stmt->fetch()) {
            $progressData[$progress['lesson_id']] = $progress;
        }
        
        // إضافة بيانات التقدم للدروس
        foreach ($lessons as &$lesson) {
            $lessonProgress = $progressData[$lesson['id']] ?? null;
            $lesson['completed'] = $lessonProgress ? (bool)$lessonProgress['completed'] : false;
            $lesson['watch_time'] = $lessonProgress ? (int)$lessonProgress['watch_time'] : 0;
            $lesson['progress_percentage'] = $lessonProgress ? round($lessonProgress['progress_percentage'], 1) : 0;
        }
    } else {
        // للمستخدمين غير المشتركين
        foreach ($lessons as &$lesson) {
            $lesson['completed'] = false;
            $lesson['watch_time'] = 0;
            $lesson['progress_percentage'] = 0;
        }
    }
    
    sendJsonResponse([
        'success' => true,
        'section' => $section,
        'lessons' => $lessons,
        'user_subscribed' => $userSubscribed
    ]);
    
} catch (Exception $e) {
    logError("Get lessons error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في جلب الدروس'
    ], 500);
}
?>