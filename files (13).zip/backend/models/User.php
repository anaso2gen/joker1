<?php
/**
 * نموذج المستخدم
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:52:06
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

require_once __DIR__ . '/BaseModel.php';

class User extends BaseModel {
    protected $table = 'users';
    protected $fillable = [
        'first_name', 'last_name', 'email', 'password_hash', 'phone',
        'avatar_url', 'is_admin', 'is_active', 'email_verified',
        'email_verification_token', 'newsletter_subscribed', 'last_login_ip'
    ];
    protected $hidden = ['password_hash', 'email_verification_token'];
    
    /**
     * الحقول القابلة للبحث
     */
    protected function getSearchableFields() {
        return ['first_name', 'last_name', 'email'];
    }
    
    /**
     * إنشاء مستخدم جديد مع تشفير كلمة المرور
     */
    public function createUser($data) {
        if (isset($data['password'])) {
            $data['password_hash'] = password_hash($data['password'], PASSWORD_DEFAULT);
            unset($data['password']);
        }
        
        if (!isset($data['email_verification_token'])) {
            $data['email_verification_token'] = bin2hex(random_bytes(32));
        }
        
        return $this->create($data);
    }
    
    /**
     * البحث عن مستخدم بالبريد الإلكتروني
     */
    public function findByEmail($email) {
        return $this->findWhere(['email' => strtolower(trim($email))]);
    }
    
    /**
     * البحث عن مستخدم برمز التفعيل
     */
    public function findByVerificationToken($token) {
        return $this->findWhere(['email_verification_token' => $token]);
    }
    
    /**
     * تفعيل البريد الإلكتروني
     */
    public function verifyEmail($userId) {
        return $this->update($userId, [
            'email_verified' => 1,
            'email_verified_at' => date('Y-m-d H:i:s'),
            'email_verification_token' => null
        ]);
    }
    
    /**
     * تحديث كلمة المرور
     */
    public function updatePassword($userId, $newPassword) {
        return $this->update($userId, [
            'password_hash' => password_hash($newPassword, PASSWORD_DEFAULT)
        ]);
    }
    
    /**
     * تحديث آخر تسجيل دخول
     */
    public function updateLastLogin($userId, $ipAddress = null) {
        return $this->update($userId, [
            'last_login' => date('Y-m-d H:i:s'),
            'last_login_ip' => $ipAddress ?: getRealIpAddress()
        ]);
    }
    
    /**
     * الحصول على دورات المستخدم
     */
    public function getUserCourses($userId, $onlyActive = true) {
        $activeCondition = $onlyActive ? 'AND s.is_active = 1' : '';
        
        return $this->query("
            SELECT c.*, s.created_at as enrolled_at, s.price_paid,
                   COUNT(DISTINCT l.id) as total_lessons,
                   COUNT(DISTINCT CASE WHEN lp.completed = 1 THEN lp.lesson_id END) as completed_lessons,
                   ROUND((COUNT(DISTINCT CASE WHEN lp.completed = 1 THEN lp.lesson_id END) / COUNT(DISTINCT l.id)) * 100, 2) as progress_percentage
            FROM subscriptions s
            JOIN courses c ON s.course_id = c.id
            LEFT JOIN sections sec ON c.id = sec.course_id
            LEFT JOIN lessons l ON sec.id = l.section_id AND l.is_active = 1
            LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = s.user_id
            WHERE s.user_id = ? $activeCondition
            GROUP BY c.id, s.id
            ORDER BY s.created_at DESC
        ", [$userId]);
    }
    
    /**
     * إحصائيات المستخدم
     */
    public function getUserStats($userId) {
        // الدورات المسجل بها
        $coursesCount = $this->query("
            SELECT COUNT(*) as count FROM subscriptions 
            WHERE user_id = ? AND is_active = 1
        ", [$userId])[0]['count'] ?? 0;
        
        // الدروس المكتملة
        $completedLessons = $this->query("
            SELECT COUNT(*) as count FROM lesson_progress 
            WHERE user_id = ? AND completed = 1
        ", [$userId])[0]['count'] ?? 0;
        
        // ساعات المشاهدة
        $watchHours = $this->query("
            SELECT COALESCE(SUM(FLOOR(last_position / 3600)), 0) as hours 
            FROM lesson_progress 
            WHERE user_id = ?
        ", [$userId])[0]['hours'] ?? 0;
        
        // الشهادات
        $certificates = $this->query("
            SELECT COUNT(*) as count FROM course_completions 
            WHERE user_id = ?
        ", [$userId])[0]['count'] ?? 0;
        
        return [
            'enrolled_courses' => $coursesCount,
            'completed_lessons' => $completedLessons,
            'watch_hours' => $watchHours,
            'certificates_earned' => $certificates
        ];
    }
    
    /**
     * النشاط الأخير للمستخدم
     */
    public function getRecentActivity($userId, $limit = 20) {
        return $this->query("
            SELECT 'lesson' as type, l.name as title, c.name as course_name, 
                   lp.last_accessed as activity_time, c.id as course_id, l.id as lesson_id
            FROM lesson_progress lp
            JOIN lessons l ON lp.lesson_id = l.id
            JOIN sections s ON l.section_id = s.id
            JOIN courses c ON s.course_id = c.id
            WHERE lp.user_id = ?
            ORDER BY lp.last_accessed DESC
            LIMIT ?
        ", [$userId, $limit]);
    }
    
    /**
     * شهادات المستخدم
     */
    public function getUserCertificates($userId) {
        return $this->query("
            SELECT c.id, c.name, c.image_url, cc.completed_at, cc.certificate_code
            FROM course_completions cc
            JOIN courses c ON cc.course_id = c.id
            WHERE cc.user_id = ?
            ORDER BY cc.completed_at DESC
        ", [$userId]);
    }
    
    /**
     * قائمة المفضلة
     */
    public function getUserWishlist($userId) {
        return $this->query("
            SELECT c.*, w.created_at as added_at,
                   COUNT(DISTINCT s.id) as students_count,
                   AVG(cr.rating) as avg_rating
            FROM wishlist w
            JOIN courses c ON w.course_id = c.id
            LEFT JOIN subscriptions s ON c.id = s.course_id AND s.is_active = 1
            LEFT JOIN course_reviews cr ON c.id = cr.course_id AND cr.is_approved = 1
            WHERE w.user_id = ? AND c.is_active = 1
            GROUP BY c.id
            ORDER BY w.created_at DESC
        ", [$userId]);
    }
    
    /**
     * فحص الاشتراك في دورة
     */
    public function isEnrolledInCourse($userId, $courseId) {
        $result = $this->query("
            SELECT COUNT(*) as count FROM subscriptions 
            WHERE user_id = ? AND course_id = ? AND is_active = 1
        ", [$userId, $courseId]);
        
        return $result[0]['count'] > 0;
    }
    
    /**
     * فحص إكمال دورة
     */
    public function hasCompletedCourse($userId, $courseId) {
        $result = $this->query("
            SELECT COUNT(*) as count FROM course_completions 
            WHERE user_id = ? AND course_id = ?
        ", [$userId, $courseId]);
        
        return $result[0]['count'] > 0;
    }
    
    /**
     * فحص تقييم دورة
     */
    public function hasReviewedCourse($userId, $courseId) {
        $result = $this->query("
            SELECT COUNT(*) as count FROM course_reviews 
            WHERE user_id = ? AND course_id = ?
        ", [$userId, $courseId]);
        
        return $result[0]['count'] > 0;
    }
    
    /**
     * إضافة/إزالة من المفضلة
     */
    public function toggleWishlist($userId, $courseId) {
        // فحص الوجود
        $exists = $this->query("
            SELECT id FROM wishlist WHERE user_id = ? AND course_id = ?
        ", [$userId, $courseId]);
        
        if ($exists) {
            // إزالة
            $this->query("DELETE FROM wishlist WHERE user_id = ? AND course_id = ?", [$userId, $courseId]);
            return false;
        } else {
            // إضافة
            $this->query("
                INSERT INTO wishlist (user_id, course_id, created_at) 
                VALUES (?, ?, NOW())
            ", [$userId, $courseId]);
            return true;
        }
    }
    
    /**
     * الحصول على الإشعارات
     */
    public function getNotifications($userId, $limit = 20, $onlyUnread = false) {
        $unreadCondition = $onlyUnread ? 'AND is_read = 0' : '';
        
        return $this->query("
            SELECT * FROM notifications 
            WHERE user_id = ? $unreadCondition
            ORDER BY created_at DESC
            LIMIT ?
        ", [$userId, $limit]);
    }
    
    /**
     * عد الإشعارات غير المقروءة
     */
    public function getUnreadNotificationsCount($userId) {
        $result = $this->query("
            SELECT COUNT(*) as count FROM notifications 
            WHERE user_id = ? AND is_read = 0
        ", [$userId]);
        
        return $result[0]['count'] ?? 0;
    }
    
    /**
     * تحديد إشعار كمقروء
     */
    public function markNotificationAsRead($notificationId, $userId) {
        return $this->query("
            UPDATE notifications 
            SET is_read = 1, read_at = NOW() 
            WHERE id = ? AND user_id = ?
        ", [$notificationId, $userId]);
    }
    
    /**
     * إنشاء إشعار
     */
    public function createNotification($userId, $title, $message, $type = 'info', $data = []) {
        return $this->query("
            INSERT INTO notifications (user_id, title, message, type, data, created_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ", [$userId, $title, $message, $type, json_encode($data)]);
    }
    
    /**
     * تنشيط/إلغاء تنشيط المستخدم
     */
    public function setActiveStatus($userId, $isActive) {
        return $this->update($userId, ['is_active' => $isActive ? 1 : 0]);
    }
    
    /**
     * ترقية المستخدم لمدير
     */
    public function setAdminStatus($userId, $isAdmin) {
        return $this->update($userId, ['is_admin' => $isAdmin ? 1 : 0]);
    }
    
    /**
     * حذف المستخدم وجميع بياناته
     */
    public function deleteUserData($userId) {
        return $this->transaction(function() use ($userId) {
            // حذف البيانات المرتبطة
            $this->query("DELETE FROM lesson_notes WHERE user_id = ?", [$userId]);
            $this->query("DELETE FROM lesson_progress WHERE user_id = ?", [$userId]);
            $this->query("DELETE FROM course_reviews WHERE user_id = ?", [$userId]);
            $this->query("DELETE FROM course_completions WHERE user_id = ?", [$userId]);
            $this->query("DELETE FROM subscriptions WHERE user_id = ?", [$userId]);
            $this->query("DELETE FROM wishlist WHERE user_id = ?", [$userId]);
            $this->query("DELETE FROM notifications WHERE user_id = ?", [$userId]);
            $this->query("DELETE FROM user_sessions WHERE user_id = ?", [$userId]);
            $this->query("DELETE FROM password_resets WHERE user_id = ?", [$userId]);
            $this->query("DELETE FROM activity_logs WHERE user_id = ?", [$userId]);
            
            // حذف المستخدم
            return $this->delete($userId);
        });
    }
}
?>