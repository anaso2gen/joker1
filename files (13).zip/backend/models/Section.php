<?php
/**
 * نموذج القسم
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:56:22
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

require_once __DIR__ . '/BaseModel.php';

class Section extends BaseModel {
    protected $table = 'sections';
    protected $fillable = [
        'name', 'description', 'course_id', 'sort_order'
    ];
    
    /**
     * الحقول القابلة للبحث
     */
    protected function getSearchableFields() {
        return ['name', 'description'];
    }
    
    /**
     * الحصول على أقسام الدورة مع الإحصائيات
     */
    public function getCourseSections($courseId) {
        return $this->query("
            SELECT s.*, 
                   COUNT(l.id) as lessons_count,
                   SUM(l.duration) as total_duration
            FROM sections s 
            LEFT JOIN lessons l ON s.id = l.section_id AND l.is_active = 1
            WHERE s.course_id = ? 
            GROUP BY s.id 
            ORDER BY s.sort_order
        ", [$courseId]);
    }
    
    /**
     * الحصول على قسم مع دروسه
     */
    public function getSectionWithLessons($sectionId, $userId = null) {
        $section = $this->find($sectionId);
        if (!$section) {
            return null;
        }
        
        // إضافة الدروس
        $lessonModel = new Lesson();
        $section['lessons'] = $lessonModel->getSectionLessons($sectionId, $userId);
        
        return $section;
    }
    
    /**
     * نقل قسم لدورة أخرى
     */
    public function moveToCoures($sectionId, $newCourseId) {
        return $this->update($sectionId, ['course_id' => $newCourseId]);
    }
    
    /**
     * ترقيم الأقسام تلقائياً
     */
    public function reorderSections($courseId) {
        $sections = $this->query("
            SELECT id FROM sections 
            WHERE course_id = ? 
            ORDER BY sort_order, created_at
        ", [$courseId]);
        
        foreach ($sections as $index => $section) {
            $this->update($section['id'], ['sort_order' => $index + 1]);
        }
        
        return true;
    }
    
    /**
     * نسخ قسم مع دروسه
     */
    public function duplicateSection($sectionId, $newCourseId = null) {
        return $this->transaction(function() use ($sectionId, $newCourseId) {
            $section = $this->find($sectionId);
            if (!$section) {
                return false;
            }
            
            unset($section['id']);
            $section['name'] = $section['name'] . ' - نسخة';
            
            if ($newCourseId) {
                $section['course_id'] = $newCourseId;
            }
            
            // تحديد الترتيب
            $maxOrder = $this->query("
                SELECT COALESCE(MAX(sort_order), 0) + 1 as next_order
                FROM sections WHERE course_id = ?
            ", [$section['course_id']]);
            
            $section['sort_order'] = $maxOrder[0]['next_order'];
            
            // إنشاء القسم الجديد
            $newSectionId = $this->create($section);
            
            // نسخ الدروس
            $lessonModel = new Lesson();
            $lessons = $lessonModel->findAll(['section_id' => $sectionId]);
            
            foreach ($lessons as $lesson) {
                $lessonModel->duplicateLesson($lesson['id'], $newSectionId);
            }
            
            return $newSectionId;
        });
    }
    
    /**
     * حذف قسم مع جميع دروسه
     */
    public function deleteSectionWithLessons($sectionId) {
        return $this->transaction(function() use ($sectionId) {
            $lessonModel = new Lesson();
            $lessonModel->deleteSectionLessons($sectionId);
            
            return $this->delete($sectionId);
        });
    }
    
    /**
     * إحصائيات القسم
     */
    public function getSectionStats($sectionId) {
        return $this->query("
            SELECT 
                COUNT(DISTINCT l.id) as total_lessons,
                SUM(l.duration) as total_duration,
                COUNT(DISTINCT lp.user_id) as unique_viewers,
                COUNT(CASE WHEN lp.completed = 1 THEN 1 END) as completed_lessons
            FROM sections s
            LEFT JOIN lessons l ON s.id = l.section_id AND l.is_active = 1
            LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id
            WHERE s.id = ?
        ", [$sectionId]);
    }
}
?>