<?php
/**
 * النموذج الأساسي
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:52:06
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

abstract class BaseModel {
    protected $pdo;
    protected $table;
    protected $primaryKey = 'id';
    protected $fillable = [];
    protected $hidden = [];
    protected $timestamps = true;
    
    public function __construct() {
        try {
            $this->pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
                DB_USER, DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
        } catch (PDOException $e) {
            throw new Exception('Database connection failed: ' . $e->getMessage());
        }
    }
    
    /**
     * البحث عن سجل بالمعرف
     */
    public function find($id) {
        $stmt = $this->pdo->prepare("SELECT * FROM {$this->table} WHERE {$this->primaryKey} = ?");
        $stmt->execute([$id]);
        $result = $stmt->fetch();
        
        return $result ? $this->hideFields($result) : null;
    }
    
    /**
     * البحث عن أول سجل يطابق الشروط
     */
    public function findWhere($conditions = []) {
        $query = "SELECT * FROM {$this->table}";
        $params = [];
        
        if (!empty($conditions)) {
            $whereClauses = [];
            foreach ($conditions as $key => $value) {
                $whereClauses[] = "$key = ?";
                $params[] = $value;
            }
            $query .= " WHERE " . implode(' AND ', $whereClauses);
        }
        
        $stmt = $this->pdo->prepare($query);
        $stmt->execute($params);
        $result = $stmt->fetch();
        
        return $result ? $this->hideFields($result) : null;
    }
    
    /**
     * البحث عن جميع السجلات
     */
    public function findAll($conditions = [], $orderBy = null, $limit = null) {
        $query = "SELECT * FROM {$this->table}";
        $params = [];
        
        if (!empty($conditions)) {
            $whereClauses = [];
            foreach ($conditions as $key => $value) {
                $whereClauses[] = "$key = ?";
                $params[] = $value;
            }
            $query .= " WHERE " . implode(' AND ', $whereClauses);
        }
        
        if ($orderBy) {
            $query .= " ORDER BY $orderBy";
        }
        
        if ($limit) {
            $query .= " LIMIT $limit";
        }
        
        $stmt = $this->pdo->prepare($query);
        $stmt->execute($params);
        $results = $stmt->fetchAll();
        
        return array_map([$this, 'hideFields'], $results);
    }
    
    /**
     * إنشاء سجل جديد
     */
    public function create($data) {
        $data = $this->filterFillable($data);
        
        if ($this->timestamps) {
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['updated_at'] = date('Y-m-d H:i:s');
        }
        
        $columns = array_keys($data);
        $placeholders = array_fill(0, count($columns), '?');
        
        $query = "INSERT INTO {$this->table} (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $placeholders) . ")";
        
        $stmt = $this->pdo->prepare($query);
        $stmt->execute(array_values($data));
        
        return $this->pdo->lastInsertId();
    }
    
    /**
     * تحديث سجل
     */
    public function update($id, $data) {
        $data = $this->filterFillable($data);
        
        if ($this->timestamps) {
            $data['updated_at'] = date('Y-m-d H:i:s');
        }
        
        $setParts = [];
        $params = [];
        
        foreach ($data as $key => $value) {
            $setParts[] = "$key = ?";
            $params[] = $value;
        }
        
        $params[] = $id;
        
        $query = "UPDATE {$this->table} SET " . implode(', ', $setParts) . " WHERE {$this->primaryKey} = ?";
        
        $stmt = $this->pdo->prepare($query);
        return $stmt->execute($params);
    }
    
    /**
     * حذف سجل
     */
    public function delete($id) {
        $stmt = $this->pdo->prepare("DELETE FROM {$this->table} WHERE {$this->primaryKey} = ?");
        return $stmt->execute([$id]);
    }
    
    /**
     * عد السجلات
     */
    public function count($conditions = []) {
        $query = "SELECT COUNT(*) FROM {$this->table}";
        $params = [];
        
        if (!empty($conditions)) {
            $whereClauses = [];
            foreach ($conditions as $key => $value) {
                $whereClauses[] = "$key = ?";
                $params[] = $value;
            }
            $query .= " WHERE " . implode(' AND ', $whereClauses);
        }
        
        $stmt = $this->pdo->prepare($query);
        $stmt->execute($params);
        
        return $stmt->fetchColumn();
    }
    
    /**
     * فحص وجود سجل
     */
    public function exists($id) {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM {$this->table} WHERE {$this->primaryKey} = ?");
        $stmt->execute([$id]);
        
        return $stmt->fetchColumn() > 0;
    }
    
    /**
     * تصفية البيانات المسموح بها
     */
    protected function filterFillable($data) {
        if (empty($this->fillable)) {
            return $data;
        }
        
        return array_intersect_key($data, array_flip($this->fillable));
    }
    
    /**
     * إخفاء الحقول الحساسة
     */
    protected function hideFields($data) {
        if (empty($this->hidden)) {
            return $data;
        }
        
        foreach ($this->hidden as $field) {
            unset($data[$field]);
        }
        
        return $data;
    }
    
    /**
     * تنفيذ استعلام خام
     */
    public function query($sql, $params = []) {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetchAll();
    }
    
    /**
     * بدء transaction
     */
    public function beginTransaction() {
        return $this->pdo->beginTransaction();
    }
    
    /**
     * تأكيد transaction
     */
    public function commit() {
        return $this->pdo->commit();
    }
    
    /**
     * إلغاء transaction
     */
    public function rollback() {
        return $this->pdo->rollback();
    }
    
    /**
     * تنفيذ عملية في transaction
     */
    public function transaction($callback) {
        $this->beginTransaction();
        
        try {
            $result = $callback($this);
            $this->commit();
            return $result;
        } catch (Exception $e) {
            $this->rollback();
            throw $e;
        }
    }
    
    /**
     * البحث بشروط متقدمة
     */
    public function search($filters = [], $pagination = []) {
        $query = "SELECT * FROM {$this->table}";
        $params = [];
        $conditions = [];
        
        // تطبيق الفلاتر
        if (isset($filters['search']) && !empty($filters['search'])) {
            $searchTerm = '%' . $filters['search'] . '%';
            $searchConditions = [];
            
            // البحث في الحقول النصية (يمكن تخصيصها في كل نموذج)
            $searchFields = $this->getSearchableFields();
            foreach ($searchFields as $field) {
                $searchConditions[] = "$field LIKE ?";
                $params[] = $searchTerm;
            }
            
            if (!empty($searchConditions)) {
                $conditions[] = '(' . implode(' OR ', $searchConditions) . ')';
            }
        }
        
        // فلاتر أخرى
        foreach ($filters as $key => $value) {
            if ($key !== 'search' && !empty($value)) {
                $conditions[] = "$key = ?";
                $params[] = $value;
            }
        }
        
        if (!empty($conditions)) {
            $query .= ' WHERE ' . implode(' AND ', $conditions);
        }
        
        // حساب العدد الإجمالي
        $countQuery = str_replace('SELECT *', 'SELECT COUNT(*)', $query);
        $countStmt = $this->pdo->prepare($countQuery);
        $countStmt->execute($params);
        $total = $countStmt->fetchColumn();
        
        // تطبيق الترتيب
        if (isset($pagination['order_by'])) {
            $orderDir = $pagination['order_dir'] ?? 'ASC';
            $query .= " ORDER BY {$pagination['order_by']} $orderDir";
        }
        
        // تطبيق التصفح
        if (isset($pagination['page']) && isset($pagination['per_page'])) {
            $page = max(1, intval($pagination['page']));
            $perPage = max(1, intval($pagination['per_page']));
            $offset = ($page - 1) * $perPage;
            
            $query .= " LIMIT $perPage OFFSET $offset";
        }
        
        $stmt = $this->pdo->prepare($query);
        $stmt->execute($params);
        $results = $stmt->fetchAll();
        
        return [
            'data' => array_map([$this, 'hideFields'], $results),
            'pagination' => [
                'total' => $total,
                'page' => $pagination['page'] ?? 1,
                'per_page' => $pagination['per_page'] ?? 10,
                'total_pages' => isset($pagination['per_page']) ? ceil($total / $pagination['per_page']) : 1
            ]
        ];
    }
    
    /**
     * الحقول القابلة للبحث (يجب تعريفها في كل نموذج)
     */
    protected function getSearchableFields() {
        return ['name', 'title', 'description'];
    }
    
    /**
     * العلاقات (للاستخدام المستقبلي)
     */
    public function hasOne($model, $foreignKey = null, $localKey = null) {
        // منطق العلاقة one-to-one
    }
    
    public function hasMany($model, $foreignKey = null, $localKey = null) {
        // منطق العلاقة one-to-many
    }
    
    public function belongsTo($model, $foreignKey = null, $localKey = null) {
        // منطق العلاقة many-to-one
    }
    
    public function belongsToMany($model, $pivotTable, $foreignKey = null, $relatedKey = null) {
        // منطق العلاقة many-to-many
    }
}
?>