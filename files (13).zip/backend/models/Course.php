<?php
/**
 * نموذج الدورة التدريبية
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:52:06
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

require_once __DIR__ . '/BaseModel.php';

class Course extends BaseModel {
    protected $table = 'courses';
    protected $fillable = [
        'name', 'description', 'short_description', 'category', 'level',
        'price', 'instructor_id', 'image_url', 'preview_video', 'is_active',
        'learning_objectives', 'requirements', 'certificate_template'
    ];
    
    /**
     * الحقول القابلة للبحث
     */
    protected function getSearchableFields() {
        return ['name', 'description', 'short_description', 'category'];
    }
    
    /**
     * الحصول على جميع الدورات مع الإحصائيات
     */
    public function getAllWithStats($filters = [], $pagination = []) {
        $query = "
            SELECT c.*, 
                   COUNT(DISTINCT s.id) as students_count,
                   COUNT(DISTINCT sec.id) as sections_count,
                   COUNT(DISTINCT l.id) as lessons_count,
                   SUM(l.duration) as total_duration,
                   AVG(cr.rating) as avg_rating,
                   COUNT(DISTINCT cr.id) as reviews_count,
                   u.first_name as instructor_first_name,
                   u.last_name as instructor_last_name
            FROM {$this->table} c 
            LEFT JOIN subscriptions s ON c.id = s.course_id AND s.is_active = 1
            LEFT JOIN sections sec ON c.id = sec.course_id
            LEFT JOIN lessons l ON sec.id = l.section_id AND l.is_active = 1
            LEFT JOIN course_reviews cr ON c.id = cr.course_id AND cr.is_approved = 1
            LEFT JOIN users u ON c.instructor_id = u.id
            WHERE c.is_active = 1
        ";
        
        $params = [];
        $conditions = [];
        
        // تطبيق الفلاتر
        if (isset($filters['search']) && !empty($filters['search'])) {
            $searchTerm = '%' . $filters['search'] . '%';
            $conditions[] = "(c.name LIKE ? OR c.description LIKE ? OR c.category LIKE ?)";
            $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm]);
        }
        
        if (isset($filters['category']) && !empty($filters['category'])) {
            $conditions[] = "c.category = ?";
            $params[] = $filters['category'];
        }
        
        if (isset($filters['level']) && !empty($filters['level'])) {
            $conditions[] = "c.level = ?";
            $params[] = $filters['level'];
        }
        
        if (isset($filters['instructor']) && !empty($filters['instructor'])) {
            $conditions[] = "c.instructor_id = ?";
            $params[] = $filters['instructor'];
        }
        
        if (isset($filters['price_range']) && !empty($filters['price_range'])) {
            switch ($filters['price_range']) {
                case 'free':
                    $conditions[] = "c.price = 0";
                    break;
                case 'paid':
                    $conditions[] = "c.price > 0";
                    break;
                case 'under_100':
                    $conditions[] = "c.price BETWEEN 0 AND 100";
                    break;
                case 'under_500':
                    $conditions[] = "c.price BETWEEN 0 AND 500";
                    break;
            }
        }
        
        if (!empty($conditions)) {
            $query .= ' AND ' . implode(' AND ', $conditions);
        }
        
        $query .= " GROUP BY c.id";
        
        // حساب العدد الإجمالي
        $countQuery = "SELECT COUNT(DISTINCT c.id) FROM courses c WHERE c.is_active = 1";
        if (!empty($conditions)) {
            $countQuery .= ' AND ' . implode(' AND ', str_replace('c.', 'c.', $conditions));
        }
        
        $countStmt = $this->pdo->prepare($countQuery);
        $countStmt->execute($params);
        $total = $countStmt->fetchColumn();
        
        // تطبيق الترتيب
        $orderBy = 'c.created_at DESC';
        if (isset($pagination['sort'])) {
            switch ($pagination['sort']) {
                case 'popular':
                    $orderBy = 'students_count DESC, c.created_at DESC';
                    break;
                case 'price_low':
                    $orderBy = 'c.price ASC';
                    break;
                case 'price_high':
                    $orderBy = 'c.price DESC';
                    break;
                case 'rating':
                    $orderBy = 'avg_rating DESC, reviews_count DESC';
                    break;
                case 'alphabetical':
                    $orderBy = 'c.name ASC';
                    break;
                case 'latest':
                default:
                    $orderBy = 'c.created_at DESC';
                    break;
            }
        }
        
        $query .= " ORDER BY $orderBy";
        
        // تطبيق التصفح
        if (isset($pagination['page']) && isset($pagination['per_page'])) {
            $page = max(1, intval($pagination['page']));
            $perPage = max(1, intval($pagination['per_page']));
            $offset = ($page - 1) * $perPage;
            
            $query .= " LIMIT $perPage OFFSET $offset";
        }
        
        $stmt = $this->pdo->prepare($query);
        $stmt->execute($params);
        $results = $stmt->fetchAll();
        
        return [
            'data' => $results,
            'pagination' => [
                'total' => $total,
                'page' => $pagination['page'] ?? 1,
                'per_page' => $pagination['per_page'] ?? 10,
                'total_pages' => isset($pagination['per_page']) ? ceil($total / $pagination['per_page']) : 1
            ]
        ];
    }
    
    /**
     * الحصول على تفاصيل دورة مع العلاقات
     */
    public function getWithDetails($courseId, $userId = null) {
        // معلومات الدورة الأساسية
        $course = $this->query("
            SELECT c.*, 
                   COUNT(DISTINCT s.id) as students_count,
                   AVG(cr.rating) as avg_rating,
                   COUNT(DISTINCT cr.id) as reviews_count,
                   u.first_name as instructor_first_name,
                   u.last_name as instructor_last_name,
                   u.avatar_url as instructor_avatar,
                   u.email as instructor_email
            FROM courses c 
            LEFT JOIN subscriptions s ON c.id = s.course_id AND s.is_active = 1
            LEFT JOIN course_reviews cr ON c.id = cr.course_id AND cr.is_approved = 1
            LEFT JOIN users u ON c.instructor_id = u.id
            WHERE c.id = ? AND c.is_active = 1
            GROUP BY c.id
        ", [$courseId]);
        
        if (empty($course)) {
            return null;
        }
        
        $course = $course[0];
        
        // الأقسام والدروس
        $course['sections'] = $this->getCourseSections($courseId, $userId);
        
        // التقييمات
        $course['reviews'] = $this->getCourseReviews($courseId, 10);
        
        // دورات مشابهة
        $course['related_courses'] = $this->getRelatedCourses($courseId, $course['category'], 4);
        
        // معلومات المستخدم (إذا كان مسجل الدخول)
        if ($userId) {
            $course['user_data'] = [
                'is_enrolled' => $this->isUserEnrolled($userId, $courseId),
                'progress' => $this->getUserProgress($userId, $courseId),
                'can_review' => $this->canUserReview($userId, $courseId)
            ];
        }
        
        return $course;
    }
    
    /**
     * الحصول على أقسام الدورة
     */
    public function getCourseSections($courseId, $userId = null) {
        $sections = $this->query("
            SELECT s.*, 
                   COUNT(l.id) as lessons_count,
                   SUM(l.duration) as total_duration
            FROM sections s 
            LEFT JOIN lessons l ON s.id = l.section_id AND l.is_active = 1
            WHERE s.course_id = ? 
            GROUP BY s.id 
            ORDER BY s.sort_order
        ", [$courseId]);
        
        // إضافة الدروس لكل قسم
        foreach ($sections as &$section) {
            $section['lessons'] = $this->getSectionLessons($section['id'], $userId);
        }
        
        return $sections;
    }
    
    /**
     * الحصول على دروس القسم
     */
    public function getSectionLessons($sectionId, $userId = null) {
        $query = "
            SELECT l.*";
        
        if ($userId) {
            $query .= ",
                   lp.completed,
                   lp.last_position,
                   lp.last_accessed";
        }
        
        $query .= "
            FROM lessons l";
        
        if ($userId) {
            $query .= " 
            LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = ?";
        }
        
        $query .= "
            WHERE l.section_id = ? AND l.is_active = 1 
            ORDER BY l.sort_order";
        
        $params = $userId ? [$userId, $sectionId] : [$sectionId];
        
        return $this->query($query, $params);
    }
    
    /**
     * الحصول على تقييمات الدورة
     */
    public function getCourseReviews($courseId, $limit = 10) {
        return $this->query("
            SELECT cr.*, 
                   u.first_name, 
                   u.last_name, 
                   u.avatar_url
            FROM course_reviews cr
            JOIN users u ON cr.user_id = u.id
            WHERE cr.course_id = ? AND cr.is_approved = 1
            ORDER BY cr.created_at DESC
            LIMIT ?
        ", [$courseId, $limit]);
    }
    
    /**
     * الحصول على دورات مشابهة
     */
    public function getRelatedCourses($courseId, $category, $limit = 4) {
        return $this->query("
            SELECT c.*, 
                   COUNT(DISTINCT s.id) as students_count,
                   COUNT(DISTINCT l.id) as lessons_count,
                   AVG(cr.rating) as avg_rating
            FROM courses c 
            LEFT JOIN subscriptions s ON c.id = s.course_id AND s.is_active = 1
            LEFT JOIN sections sec ON c.id = sec.course_id
            LEFT JOIN lessons l ON sec.id = l.section_id AND l.is_active = 1
            LEFT JOIN course_reviews cr ON c.id = cr.course_id AND cr.is_approved = 1
            WHERE c.category = ? AND c.id != ? AND c.is_active = 1
            GROUP BY c.id
            ORDER BY students_count DESC, c.created_at DESC 
            LIMIT ?
        ", [$category, $courseId, $limit]);
    }
    
    /**
     * فحص اشتراك المستخدم
     */
    public function isUserEnrolled($userId, $courseId) {
        $result = $this->query("
            SELECT COUNT(*) as count FROM subscriptions 
            WHERE user_id = ? AND course_id = ? AND is_active = 1
        ", [$userId, $courseId]);
        
        return $result[0]['count'] > 0;
    }
    
    /**
     * الحصول على تقدم المستخدم
     */
    public function getUserProgress($userId, $courseId) {
        $result = $this->query("
            SELECT 
                COUNT(DISTINCT l.id) as total_lessons,
                COUNT(DISTINCT CASE WHEN lp.completed = 1 THEN lp.lesson_id END) as completed_lessons
            FROM lessons l
            JOIN sections s ON l.section_id = s.id
            LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = ?
            WHERE s.course_id = ? AND l.is_active = 1
        ", [$userId, $courseId]);
        
        if (empty($result) || $result[0]['total_lessons'] == 0) {
            return 0;
        }
        
        return round(($result[0]['completed_lessons'] / $result[0]['total_lessons']) * 100);
    }
    
    /**
     * فحص إمكانية التقييم
     */
    public function canUserReview($userId, $courseId) {
        // يجب أن يكون مشترك ولم يقيم من قبل
        $enrolled = $this->isUserEnrolled($userId, $courseId);
        
        if (!$enrolled) {
            return false;
        }
        
        $result = $this->query("
            SELECT COUNT(*) as count FROM course_reviews 
            WHERE user_id = ? AND course_id = ?
        ", [$userId, $courseId]);
        
        return $result[0]['count'] == 0;
    }
    
    /**
     * إضافة تقييم
     */
    public function addReview($userId, $courseId, $rating, $reviewText) {
        return $this->query("
            INSERT INTO course_reviews (user_id, course_id, rating, review_text, created_at)
            VALUES (?, ?, ?, ?, NOW())
        ", [$userId, $courseId, $rating, $reviewText]);
    }
    
    /**
     * الحصول على الفئات
     */
    public function getCategories() {
        return $this->query("
            SELECT category, COUNT(*) as count 
            FROM courses 
            WHERE is_active = 1 
            GROUP BY category 
            ORDER BY count DESC, category ASC
        ");
    }
    
    /**
     * الحصول على المستويات
     */
    public function getLevels() {
        return $this->query("
            SELECT level, COUNT(*) as count 
            FROM courses 
            WHERE is_active = 1 
            GROUP BY level 
            ORDER BY 
                CASE level 
                    WHEN 'beginner' THEN 1 
                    WHEN 'intermediate' THEN 2 
                    WHEN 'advanced' THEN 3 
                    ELSE 4 
                END
        ");
    }
    
    /**
     * الحصول على أفضل الدورات
     */
    public function getTopCourses($limit = 10) {
        return $this->query("
            SELECT c.*, 
                   COUNT(DISTINCT s.id) as students_count,
                   AVG(cr.rating) as avg_rating,
                   COUNT(DISTINCT cr.id) as reviews_count
            FROM courses c 
            LEFT JOIN subscriptions s ON c.id = s.course_id AND s.is_active = 1
            LEFT JOIN course_reviews cr ON c.id = cr.course_id AND cr.is_approved = 1
            WHERE c.is_active = 1
            GROUP BY c.id
            ORDER BY students_count DESC, avg_rating DESC
            LIMIT ?
        ", [$limit]);
    }
    
    /**
     * الحصول على أحدث الدورات
     */
    public function getLatestCourses($limit = 10) {
        return $this->query("
            SELECT c.*, 
                   COUNT(DISTINCT s.id) as students_count,
                   COUNT(DISTINCT l.id) as lessons_count
            FROM courses c 
            LEFT JOIN subscriptions s ON c.id = s.course_id AND s.is_active = 1
            LEFT JOIN sections sec ON c.id = sec.course_id
            LEFT JOIN lessons l ON sec.id = l.section_id AND l.is_active = 1
            WHERE c.is_active = 1
            GROUP BY c.id
            ORDER BY c.created_at DESC
            LIMIT ?
        ", [$limit]);
    }
    
    /**
     * البحث في الدورات
     */
    public function searchCourses($searchTerm, $filters = [], $pagination = []) {
        $searchTerm = '%' . $searchTerm . '%';
        
        $query = "
            SELECT c.*, 
                   COUNT(DISTINCT s.id) as students_count,
                   AVG(cr.rating) as avg_rating,
                   COUNT(DISTINCT cr.id) as reviews_count,
                   MATCH(c.name, c.description) AGAINST(? IN NATURAL LANGUAGE MODE) as relevance_score
            FROM courses c 
            LEFT JOIN subscriptions s ON c.id = s.course_id AND s.is_active = 1
            LEFT JOIN course_reviews cr ON c.id = cr.course_id AND cr.is_approved = 1
            WHERE c.is_active = 1 
            AND (c.name LIKE ? OR c.description LIKE ? OR c.category LIKE ?)
        ";
        
        $params = [$searchTerm, $searchTerm, $searchTerm, $searchTerm];
        
        // إضافة فلاتر إضافية
        if (isset($filters['category']) && !empty($filters['category'])) {
            $query .= " AND c.category = ?";
            $params[] = $filters['category'];
        }
        
        if (isset($filters['level']) && !empty($filters['level'])) {
            $query .= " AND c.level = ?";
            $params[] = $filters['level'];
        }
        
        $query .= " GROUP BY c.id ORDER BY relevance_score DESC, students_count DESC";
        
        // تطبيق التصفح
        if (isset($pagination['page']) && isset($pagination['per_page'])) {
            $page = max(1, intval($pagination['page']));
            $perPage = max(1, intval($pagination['per_page']));
            $offset = ($page - 1) * $perPage;
            
            $query .= " LIMIT $perPage OFFSET $offset";
        }
        
        return $this->query($query, $params);
    }
    
    /**
     * حذف دورة مع جميع بياناتها
     */
    public function deleteCourseData($courseId) {
        return $this->transaction(function() use ($courseId) {
            // حذف البيانات المرتبطة
            $this->query("DELETE FROM lesson_notes WHERE lesson_id IN (SELECT l.id FROM lessons l JOIN sections s ON l.section_id = s.id WHERE s.course_id = ?)", [$courseId]);
            $this->query("DELETE FROM lesson_progress WHERE lesson_id IN (SELECT l.id FROM lessons l JOIN sections s ON l.section_id = s.id WHERE s.course_id = ?)", [$courseId]);
            $this->query("DELETE FROM lessons WHERE section_id IN (SELECT id FROM sections WHERE course_id = ?)", [$courseId]);
            $this->query("DELETE FROM sections WHERE course_id = ?", [$courseId]);
            $this->query("DELETE FROM course_reviews WHERE course_id = ?", [$courseId]);
            $this->query("DELETE FROM course_completions WHERE course_id = ?", [$courseId]);
            $this->query("DELETE FROM subscriptions WHERE course_id = ?", [$courseId]);
            $this->query("DELETE FROM wishlist WHERE course_id = ?", [$courseId]);
            
            // حذف الدورة
            return $this->delete($courseId);
        });
    }
}
?>