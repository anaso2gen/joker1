<?php
/**
 * API فحص صحة الجلسة
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

try {
    $user = $sessionManager->validateSession();
    
    if ($user) {
        sendJsonResponse([
            'success' => true,
            'authenticated' => true,
            'user' => [
                'user_id' => $user['user_id'],
                'email' => $user['email'],
                'full_name' => $user['full_name'],
                'is_admin' => (bool)$user['is_admin'],
                'avatar_url' => $user['avatar_url']
            ]
        ]);
    } else {
        sendJsonResponse([
            'success' => true,
            'authenticated' => false
        ]);
    }
    
} catch (Exception $e) {
    logError("Session check error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في فحص الجلسة'
    ], 500);
}
?>