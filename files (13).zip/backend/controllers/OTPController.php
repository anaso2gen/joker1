<?php
/**
 * معالج VdoCipher OTP - إنشاء والتحقق من رموز التشغيل
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

require_once __DIR__ . '/../../api.php';

class OTPController extends BaseController {
    
    /**
     * إنشاء OTP لتشغيل الفيديو
     */
    public function generate() {
        $userId = $_SESSION['user_id'];
        $data = $this->getJsonInput() ?: $_POST;
        
        // التحقق من صحة البيانات
        $errors = $this->validate($data, [
            'lesson_id' => 'required',
            'video_id' => 'required'
        ]);
        
        if (!empty($errors)) {
            return $this->errorResponse('بيانات غير صالحة', 422, $errors);
        }
        
        $lessonId = intval($data['lesson_id']);
        $videoId = sanitizeInput($data['video_id']);
        $sessionId = $data['session_id'] ?? session_id();
        
        try {
            // التحقق من صحة الدرس
            $stmt = $this->db->prepare("
                SELECT l.*, s.course_id, c.name as course_name
                FROM lessons l
                JOIN sections s ON l.section_id = s.id
                JOIN courses c ON s.course_id = c.id
                WHERE l.id = ? AND l.is_active = 1 AND s.is_active = 1 AND c.is_active = 1
            ");
            $stmt->execute([$lessonId]);
            $lesson = $stmt->fetch();
            
            if (!$lesson) {
                return $this->errorResponse('الدرس غير موجود أو غير متاح', 404);
            }
            
            // التحقق من الاشتراك أو كون الدرس مجاني
            if (!$lesson['is_preview']) {
                if (!$this->sessionManager->hasSubscription($lesson['course_id'], $userId)) {
                    return $this->errorResponse('ليس لديك اشتراك في هذه الدورة', 403);
                }
            }
            
            // التحقق من صحة معرف الفيديو
            if ($lesson['vdocipher_video_id'] !== $videoId) {
                return $this->errorResponse('معرف الفيديو غير صحيح', 400);
            }
            
            // إنشاء OTP من VdoCipher
            $otpData = $this->generateVdoCipherOTP($videoId, $userId, $sessionId);
            
            if (!$otpData) {
                return $this->errorResponse('خطأ في إنشاء رمز التشغيل', 500);
            }
            
            // تسجيل الوصول للدرس
            $this->logLessonAccess($userId, $lessonId, $sessionId);
            
            return $this->successResponse([
                'otp' => $otpData['otp'],
                'playback_info' => $otpData['playbackInfo'],
                'expires_at' => $otpData['expiresAt'],
                'lesson_info' => [
                    'id' => $lesson['id'],
                    'title' => $lesson['title'],
                    'duration' => $lesson['duration'],
                    'course_name' => $lesson['course_name']
                ]
            ], 'تم إنشاء رمز التشغيل بنجاح');
            
        } catch (Exception $e) {
            error_log("OTP generation error: " . $e->getMessage());
            return $this->errorResponse('خطأ في إنشاء رمز التشغيل', 500);
        }
    }
    
    /**
     * التحقق من صحة OTP
     */
    public function verify() {
        $userId = $_SESSION['user_id'];
        $data = $this->getJsonInput() ?: $_POST;
        
        $errors = $this->validate($data, [
            'otp' => 'required',
            'lesson_id' => 'required'
        ]);
        
        if (!empty($errors)) {
            return $this->errorResponse('بيانات غير صالحة', 422, $errors);
        }
        
        $otp = sanitizeInput($data['otp']);
        $lessonId = intval($data['lesson_id']);
        
        try {
            // التحقق من صحة OTP مع VdoCipher
            $isValid = $this->verifyVdoCipherOTP($otp);
            
            if ($isValid) {
                // تسجيل بداية المشاهدة
                $this->recordWatchStart($userId, $lessonId);
                
                return $this->successResponse([
                    'valid' => true
                ], 'رمز التشغيل صالح');
            } else {
                return $this->errorResponse('رمز التشغيل غير صالح أو منتهي الصلاحية', 401);
            }
            
        } catch (Exception $e) {
            error_log("OTP verification error: " . $e->getMessage());
            return $this->errorResponse('خطأ في التحقق من رمز التشغيل', 500);
        }
    }
    
    /**
     * إنشاء OTP من VdoCipher API
     */
    private function generateVdoCipherOTP($videoId, $userId, $sessionId) {
        try {
            $url = VDOCIPHER_API_URL . '/videos/' . $videoId . '/otp';
            
            $headers = [
                'Accept: application/json',
                'Content-Type: application/json',
                'Authorization: Apisecret ' . VDOCIPHER_API_SECRET
            ];
            
            $requestData = [
                'ttl' => 3600, // انتهاء الصلاحية بعد ساعة
                'player' => $userId,
                'session' => $sessionId,
                'annotate' => json_encode([
                    'user_id' => $userId,
                    'session_id' => $sessionId,
                    'timestamp' => time()
                ])
            ];
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);
            
            if ($error) {
                error_log("VdoCipher cURL error: " . $error);
                return false;
            }
            
            if ($httpCode !== 200) {
                error_log("VdoCipher API error: HTTP {$httpCode} - {$response}");
                return false;
            }
            
            $data = json_decode($response, true);
            
            if (!$data || !isset($data['otp']) || !isset($data['playbackInfo'])) {
                error_log("VdoCipher invalid response: " . $response);
                return false;
            }
            
            return [
                'otp' => $data['otp'],
                'playbackInfo' => $data['playbackInfo'],
                'expiresAt' => time() + 3600
            ];
            
        } catch (Exception $e) {
            error_log("VdoCipher OTP generation error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * التحقق من صحة OTP مع VdoCipher
     */
    private function verifyVdoCipherOTP($otp) {
        try {
            // في الحقيقة، VdoCipher لا يوفر API للتحقق من OTP
            // لكن يمكننا التحقق من تنسيق OTP والوقت
            
            // فحص تنسيق OTP (يجب أن يكون base64)
            if (!preg_match('/^[A-Za-z0-9+\/]+=*$/', $otp)) {
                return false;
            }
            
            // يمكن إضافة فحوصات إضافية هنا
            // مثل فحص قاعدة البيانات للـ OTPs المستخدمة مسبقاً
            
            return true;
            
        } catch (Exception $e) {
            error_log("OTP verification error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * تسجيل الوصول للدرس
     */
    private function logLessonAccess($userId, $lessonId, $sessionId) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO lesson_progress (user_id, lesson_id, created_at) 
                VALUES (?, ?, NOW())
                ON DUPLICATE KEY UPDATE updated_at = NOW()
            ");
            $stmt->execute([$userId, $lessonId]);
            
            // تسجيل في سجل الأنشطة
            logActivity($userId, 'lesson_accessed', "Lesson ID: {$lessonId}, Session: {$sessionId}");
            
        } catch (Exception $e) {
            error_log("Lesson access logging error: " . $e->getMessage());
        }
    }
    
    /**
     * تسجيل بداية المشاهدة
     */
    private function recordWatchStart($userId, $lessonId) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO lesson_progress (user_id, lesson_id, created_at, updated_at) 
                VALUES (?, ?, NOW(), NOW())
                ON DUPLICATE KEY UPDATE updated_at = NOW()
            ");
            $stmt->execute([$userId, $lessonId]);
            
            logActivity($userId, 'video_watch_started', "Lesson ID: {$lessonId}");
            
        } catch (Exception $e) {
            error_log("Watch start recording error: " . $e->getMessage());
        }
    }
}
?>