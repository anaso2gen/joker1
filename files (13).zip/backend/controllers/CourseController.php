<?php
/**
 * تحكم الدورات التدريبية
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:40:51
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

require_once __DIR__ . '/BaseController.php';

class CourseController extends BaseController {
    
    /**
     * الحصول على جميع الدورات مع الفلترة
     */
    public function getAllCourses() {
        try {
            $filters = $this->getInputData();
            $page = max(1, intval($filters['page'] ?? 1));
            $perPage = min(50, max(1, intval($filters['per_page'] ?? 12)));
            $sortBy = $filters['sort'] ?? 'latest';
            
            // تحديد الترتيب
            $orderBy = match($sortBy) {
                'popular' => 'students_count DESC',
                'price_low' => 'c.price ASC',
                'price_high' => 'c.price DESC',
                'rating' => 'avg_rating DESC',
                'alphabetical' => 'c.name ASC',
                default => 'c.created_at DESC'
            };
            
            // الاستعلام الأساسي
            $baseQuery = "
                SELECT c.*, 
                       COUNT(DISTINCT s.id) as students_count,
                       COUNT(DISTINCT sec.id) as sections_count,
                       COUNT(DISTINCT l.id) as lessons_count,
                       SUM(l.duration) as total_duration,
                       AVG(cr.rating) as avg_rating,
                       COUNT(DISTINCT cr.id) as reviews_count
                FROM courses c 
                LEFT JOIN subscriptions s ON c.id = s.course_id AND s.is_active = 1
                LEFT JOIN sections sec ON c.id = sec.course_id
                LEFT JOIN lessons l ON sec.id = l.section_id AND l.is_active = 1
                LEFT JOIN course_reviews cr ON c.id = cr.course_id AND cr.is_approved = 1
                WHERE c.is_active = 1
            ";
            
            // تطبيق الفلاتر
            $allowedFilters = ['search', 'category', 'level', 'price_range', 'instructor'];
            list($query, $params) = $this->applyFilters($baseQuery, $filters, $allowedFilters);
            
            $query .= " GROUP BY c.id";
            
            // حساب العدد الإجمالي
            $totalCourses = $this->getTotalCount(str_replace("SELECT c.*, COUNT(DISTINCT s.id) as students_count, COUNT(DISTINCT sec.id) as sections_count, COUNT(DISTINCT l.id) as lessons_count, SUM(l.duration) as total_duration, AVG(cr.rating) as avg_rating, COUNT(DISTINCT cr.id) as reviews_count", "SELECT COUNT(DISTINCT c.id)", $query), $params);
            
            // تطبيق الترتيب والتصفح
            $query = $this->applyPagination($query, $page, $perPage, $orderBy);
            
            $stmt = $this->pdo->prepare($query);
            $stmt->execute($params);
            $courses = $stmt->fetchAll();
            
            // إضافة معلومات إضافية لكل دورة
            foreach ($courses as &$course) {
                $course['image_url'] = $course['image_url'] ?: null;
                $course['progress'] = $this->getCourseProgress($course['id']);
                $course['is_enrolled'] = $this->isUserEnrolled($course['id']);
                $course['preview_available'] = !empty($course['preview_video']);
            }
            
            $this->sendSuccess([
                'courses' => $courses,
                'pagination' => [
                    'current_page' => $page,
                    'per_page' => $perPage,
                    'total' => $totalCourses,
                    'total_pages' => ceil($totalCourses / $perPage)
                ],
                'filters' => $filters
            ]);
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to get courses', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحميل الدورات');
        }
    }
    
    /**
     * الحصول على تفاصيل دورة واحدة
     */
    public function getCourse() {
        try {
            $courseId = intval($_GET['id'] ?? 0);
            
            if (!$courseId) {
                $this->sendError('معرف الدورة مطلوب');
            }
            
            // الحصول على تفاصيل الدورة
            $stmt = $this->pdo->prepare("
                SELECT c.*, 
                       COUNT(DISTINCT s.id) as students_count,
                       AVG(cr.rating) as avg_rating,
                       COUNT(DISTINCT cr.id) as reviews_count,
                       u.first_name as instructor_first_name,
                       u.last_name as instructor_last_name,
                       u.avatar_url as instructor_avatar
                FROM courses c 
                LEFT JOIN subscriptions s ON c.id = s.course_id AND s.is_active = 1
                LEFT JOIN course_reviews cr ON c.id = cr.course_id AND cr.is_approved = 1
                LEFT JOIN users u ON c.instructor_id = u.id
                WHERE c.id = ? AND c.is_active = 1
                GROUP BY c.id
            ");
            
            $stmt->execute([$courseId]);
            $course = $stmt->fetch();
            
            if (!$course) {
                $this->sendError('الدورة غير موجودة', 404);
            }
            
            // الحصول على الأقسام والدروس
            $sectionsStmt = $this->pdo->prepare("
                SELECT s.*, 
                       COUNT(l.id) as lessons_count,
                       SUM(l.duration) as total_duration
                FROM sections s 
                LEFT JOIN lessons l ON s.id = l.section_id AND l.is_active = 1
                WHERE s.course_id = ? 
                GROUP BY s.id 
                ORDER BY s.sort_order
            ");
            
            $sectionsStmt->execute([$courseId]);
            $sections = $sectionsStmt->fetchAll();
            
            // إضافة الدروس لكل قسم
            foreach ($sections as &$section) {
                $lessonsStmt = $this->pdo->prepare("
                    SELECT l.*,
                           lp.completed,
                           lp.last_position,
                           lp.last_accessed
                    FROM lessons l 
                    LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = ?
                    WHERE l.section_id = ? AND l.is_active = 1 
                    ORDER BY l.sort_order
                ");
                
                $lessonsStmt->execute([$this->user['id'] ?? 0, $section['id']]);
                $section['lessons'] = $lessonsStmt->fetchAll();
            }
            
            // الحصول على التقييمات
            $reviewsStmt = $this->pdo->prepare("
                SELECT cr.*, 
                       u.first_name, 
                       u.last_name, 
                       u.avatar_url
                FROM course_reviews cr
                JOIN users u ON cr.user_id = u.id
                WHERE cr.course_id = ? AND cr.is_approved = 1
                ORDER BY cr.created_at DESC
                LIMIT 10
            ");
            
            $reviewsStmt->execute([$courseId]);
            $reviews = $reviewsStmt->fetchAll();
            
            // فحص حالة الاشتراك
            $isEnrolled = $this->isUserEnrolled($courseId);
            $progress = $isEnrolled ? $this->getCourseProgress($courseId) : 0;
            
            // الحصول على دورات مشابهة
            $relatedStmt = $this->pdo->prepare("
                SELECT c.*, 
                       COUNT(DISTINCT s.id) as students_count,
                       COUNT(DISTINCT l.id) as lessons_count
                FROM courses c 
                LEFT JOIN subscriptions s ON c.id = s.course_id AND s.is_active = 1
                LEFT JOIN sections sec ON c.id = sec.course_id
                LEFT JOIN lessons l ON sec.id = l.section_id AND l.is_active = 1
                WHERE c.category = ? AND c.id != ? AND c.is_active = 1
                GROUP BY c.id
                ORDER BY c.created_at DESC 
                LIMIT 4
            ");
            
            $relatedStmt->execute([$course['category'], $courseId]);
            $relatedCourses = $relatedStmt->fetchAll();
            
            // تسجيل المشاهدة
            $this->logActivity("Viewed course: {$course['name']}", 'course_view', ['course_id' => $courseId]);
            
            $this->sendSuccess([
                'course' => $course,
                'sections' => $sections,
                'reviews' => $reviews,
                'related_courses' => $relatedCourses,
                'user_data' => [
                    'is_enrolled' => $isEnrolled,
                    'progress' => $progress,
                    'can_review' => $isEnrolled && !$this->hasUserReviewed($courseId)
                ]
            ]);
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to get course details', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحميل تفاصيل الدورة');
        }
    }
    
    /**
     * إنشاء دورة جديدة
     */
    public function createCourse() {
        $this->requireAdmin();
        
        try {
            $this->validateCSRF();
            
            $data = $this->getInputData();
            
            // التحقق من صحة البيانات
            $errors = $this->validate($data, [
                'name' => 'required|min:3|max:255',
                'description' => 'required|min:10',
                'short_description' => 'max:255',
                'category' => 'required|max:100',
                'level' => 'required',
                'price' => 'numeric'
            ]);
            
            if (!empty($errors)) {
                $this->sendError('البيانات المدخلة غير صحيحة', 400, $errors);
            }
            
            $courseData = [
                'name' => $this->sanitizeInput($data['name']),
                'description' => $this->sanitizeInput($data['description']),
                'short_description' => $this->sanitizeInput($data['short_description'] ?? ''),
                'category' => $this->sanitizeInput($data['category']),
                'level' => $this->sanitizeInput($data['level']),
                'price' => floatval($data['price'] ?? 0),
                'instructor_id' => $this->user['id'],
                'is_active' => intval($data['is_active'] ?? 1),
                'learning_objectives' => json_encode($data['learning_objectives'] ?? []),
                'requirements' => json_encode($data['requirements'] ?? [])
            ];
            
            // معالجة رفع الصورة
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $uploadDir = __DIR__ . '/../../uploads/courses';
                $imageName = $this->handleFileUpload($_FILES['image'], $uploadDir, ['jpg', 'jpeg', 'png']);
                $courseData['image_url'] = 'uploads/courses/' . $imageName;
                
                // تحسين الصورة
                $this->optimizeImage(
                    $uploadDir . '/' . $imageName,
                    $uploadDir . '/optimized_' . $imageName,
                    800, 85
                );
            }
            
            $result = $this->transaction(function($pdo) use ($courseData) {
                $stmt = $pdo->prepare("
                    INSERT INTO courses (name, description, short_description, category, level, price, 
                                       instructor_id, image_url, is_active, learning_objectives, requirements, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                ");
                
                $stmt->execute([
                    $courseData['name'],
                    $courseData['description'],
                    $courseData['short_description'],
                    $courseData['category'],
                    $courseData['level'],
                    $courseData['price'],
                    $courseData['instructor_id'],
                    $courseData['image_url'] ?? null,
                    $courseData['is_active'],
                    $courseData['learning_objectives'],
                    $courseData['requirements']
                ]);
                
                return $pdo->lastInsertId();
            });
            
            $this->logActivity("Created course: {$courseData['name']}", 'course_create', ['course_id' => $result]);
            
            $this->sendSuccess(['course_id' => $result], 'تم إنشاء الدورة بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to create course', 'high', ['error' => $e->getMessage()]);
            $this->sendError('فشل في إنشاء الدورة: ' . $e->getMessage());
        }
    }
    
    /**
     * تحديث دورة
     */
    public function updateCourse() {
        $this->requireAdmin();
        
        try {
            $this->validateCSRF();
            
            $courseId = intval($_POST['course_id'] ?? $_GET['id'] ?? 0);
            $data = $this->getInputData();
            
            if (!$courseId) {
                $this->sendError('معرف الدورة مطلوب');
            }
            
            // التحقق من وجود الدورة
            $stmt = $this->pdo->prepare("SELECT * FROM courses WHERE id = ?");
            $stmt->execute([$courseId]);
            $course = $stmt->fetch();
            
            if (!$course) {
                $this->sendError('الدورة غير موجودة', 404);
            }
            
            // التحقق من صحة البيانات
            $errors = $this->validate($data, [
                'name' => 'required|min:3|max:255',
                'description' => 'required|min:10',
                'category' => 'required|max:100',
                'level' => 'required',
                'price' => 'numeric'
            ]);
            
            if (!empty($errors)) {
                $this->sendError('البيانات المدخلة غير صحيحة', 400, $errors);
            }
            
            $updateData = [
                'name' => $this->sanitizeInput($data['name']),
                'description' => $this->sanitizeInput($data['description']),
                'short_description' => $this->sanitizeInput($data['short_description'] ?? ''),
                'category' => $this->sanitizeInput($data['category']),
                'level' => $this->sanitizeInput($data['level']),
                'price' => floatval($data['price'] ?? 0),
                'is_active' => intval($data['is_active'] ?? $course['is_active']),
                'learning_objectives' => json_encode($data['learning_objectives'] ?? []),
                'requirements' => json_encode($data['requirements'] ?? [])
            ];
            
            // معالجة رفع صورة جديدة
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $uploadDir = __DIR__ . '/../../uploads/courses';
                $imageName = $this->handleFileUpload($_FILES['image'], $uploadDir, ['jpg', 'jpeg', 'png']);
                $updateData['image_url'] = 'uploads/courses/' . $imageName;
                
                // حذف الصورة القديمة
                if ($course['image_url'] && file_exists(__DIR__ . '/../../' . $course['image_url'])) {
                    unlink(__DIR__ . '/../../' . $course['image_url']);
                }
                
                // تحسين الصورة الجديدة
                $this->optimizeImage(
                    $uploadDir . '/' . $imageName,
                    $uploadDir . '/optimized_' . $imageName,
                    800, 85
                );
            }
            
            $this->transaction(function($pdo) use ($courseId, $updateData) {
                $setParts = [];
                $params = [];
                
                foreach ($updateData as $key => $value) {
                    $setParts[] = "$key = ?";
                    $params[] = $value;
                }
                
                $params[] = $courseId;
                
                $sql = "UPDATE courses SET " . implode(', ', $setParts) . ", updated_at = NOW() WHERE id = ?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
            });
            
            $this->logActivity("Updated course: {$updateData['name']}", 'course_update', ['course_id' => $courseId]);
            
            $this->sendSuccess(null, 'تم تحديث الدورة بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to update course', 'high', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحديث الدورة: ' . $e->getMessage());
        }
    }
    
    /**
     * حذف دورة
     */
    public function deleteCourse() {
        $this->requireAdmin();
        
        try {
            $this->validateCSRF();
            
            $courseId = intval($_POST['course_id'] ?? $_GET['id'] ?? 0);
            
            if (!$courseId) {
                $this->sendError('معرف الدورة مطلوب');
            }
            
            // التحقق من وجود الدورة
            $stmt = $this->pdo->prepare("SELECT name, image_url FROM courses WHERE id = ?");
            $stmt->execute([$courseId]);
            $course = $stmt->fetch();
            
            if (!$course) {
                $this->sendError('الدورة غير موجودة', 404);
            }
            
            // التحقق من وجود اشتراكات نشطة
            $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM subscriptions WHERE course_id = ? AND is_active = 1");
            $stmt->execute([$courseId]);
            $activeSubscriptions = $stmt->fetchColumn();
            
            if ($activeSubscriptions > 0) {
                $this->sendError('لا يمكن حذف الدورة لوجود اشتراكات نشطة بها');
            }
            
            $this->transaction(function($pdo) use ($courseId, $course) {
                // حذف البيانات المرتبطة
                $pdo->prepare("DELETE FROM lesson_progress WHERE lesson_id IN (SELECT l.id FROM lessons l JOIN sections s ON l.section_id = s.id WHERE s.course_id = ?)")->execute([$courseId]);
                $pdo->prepare("DELETE FROM lessons WHERE section_id IN (SELECT id FROM sections WHERE course_id = ?)")->execute([$courseId]);
                $pdo->prepare("DELETE FROM sections WHERE course_id = ?")->execute([$courseId]);
                $pdo->prepare("DELETE FROM course_reviews WHERE course_id = ?")->execute([$courseId]);
                $pdo->prepare("DELETE FROM subscriptions WHERE course_id = ?")->execute([$courseId]);
                $pdo->prepare("DELETE FROM courses WHERE id = ?")->execute([$courseId]);
                
                // حذف صورة الدورة
                if ($course['image_url'] && file_exists(__DIR__ . '/../../' . $course['image_url'])) {
                    unlink(__DIR__ . '/../../' . $course['image_url']);
                }
            });
            
            $this->logActivity("Deleted course: {$course['name']}", 'course_delete', ['course_id' => $courseId]);
            
            $this->sendSuccess(null, 'تم حذف الدورة بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to delete course', 'high', ['error' => $e->getMessage()]);
            $this->sendError('فشل في حذف الدورة: ' . $e->getMessage());
        }
    }
    
    /**
     * الاشتراك في دورة
     */
    public function subscribeToCourse() {
        $this->requireAuth();
        
        try {
            $data = $this->getInputData();
            $courseId = intval($data['course_id'] ?? 0);
            
            if (!$courseId) {
                $this->sendError('معرف الدورة مطلوب');
            }
            
            // التحقق من وجود الدورة
            $stmt = $this->pdo->prepare("SELECT * FROM courses WHERE id = ? AND is_active = 1");
            $stmt->execute([$courseId]);
            $course = $stmt->fetch();
            
            if (!$course) {
                $this->sendError('الدورة غير موجودة أو غير متاحة', 404);
            }
            
            // التحقق من الاشتراك المسبق
            if ($this->isUserEnrolled($courseId)) {
                $this->sendError('أنت مشترك بالفعل في هذه الدورة');
            }
            
            // التحقق من السعر والدفع (يمكن إضافة منطق الدفع هنا)
            if ($course['price'] > 0) {
                // منطق التحقق من الدفع
                $paymentVerified = $this->verifyPayment($data);
                if (!$paymentVerified) {
                    $this->sendError('فشل في التحقق من الدفع');
                }
            }
            
            $subscriptionId = $this->transaction(function($pdo) use ($courseId, $course) {
                $stmt = $pdo->prepare("
                    INSERT INTO subscriptions (user_id, course_id, price_paid, is_active, created_at)
                    VALUES (?, ?, ?, 1, NOW())
                ");
                
                $stmt->execute([
                    $this->user['id'],
                    $courseId,
                    $course['price']
                ]);
                
                return $pdo->lastInsertId();
            });
            
            $this->logActivity("Subscribed to course: {$course['name']}", 'course_subscribe', [
                'course_id' => $courseId,
                'subscription_id' => $subscriptionId
            ]);
            
            $this->sendSuccess([
                'subscription_id' => $subscriptionId,
                'course_name' => $course['name']
            ], 'تم الاشتراك في الدورة بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to subscribe to course', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في الاشتراك: ' . $e->getMessage());
        }
    }
    
    /**
     * إضافة تقييم للدورة
     */
    public function addReview() {
        $this->requireAuth();
        
        try {
            $this->validateCSRF();
            
            $data = $this->getInputData();
            
            $errors = $this->validate($data, [
                'course_id' => 'required|numeric',
                'rating' => 'required|numeric',
                'review_text' => 'required|min:10|max:1000'
            ]);
            
            if (!empty($errors)) {
                $this->sendError('البيانات المدخلة غير صحيحة', 400, $errors);
            }
            
            $courseId = intval($data['course_id']);
            $rating = max(1, min(5, intval($data['rating'])));
            $reviewText = $this->sanitizeInput($data['review_text']);
            
            // التحقق من الاشتراك
            if (!$this->isUserEnrolled($courseId)) {
                $this->sendError('يجب أن تكون مشتركاً في الدورة لتقييمها');
            }
            
            // التحقق من التقييم المسبق
            if ($this->hasUserReviewed($courseId)) {
                $this->sendError('لقد قمت بتقييم هذه الدورة مسبقاً');
            }
            
            $reviewId = $this->transaction(function($pdo) use ($courseId, $rating, $reviewText) {
                $stmt = $pdo->prepare("
                    INSERT INTO course_reviews (user_id, course_id, rating, review_text, created_at)
                    VALUES (?, ?, ?, ?, NOW())
                ");
                
                $stmt->execute([
                    $this->user['id'],
                    $courseId,
                    $rating,
                    $reviewText
                ]);
                
                return $pdo->lastInsertId();
            });
            
            $this->logActivity("Added review for course", 'course_review', [
                'course_id' => $courseId,
                'review_id' => $reviewId,
                'rating' => $rating
            ]);
            
            $this->sendSuccess(['review_id' => $reviewId], 'تم إضافة التقييم بنجاح');
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to add review', 'medium', ['error' => $e->getMessage()]);
            $this->sendError('فشل في إضافة التقييم: ' . $e->getMessage());
        }
    }
    
    /**
     * الحصول على معاينة الدورة
     */
    public function getCoursePreview() {
        try {
            $courseId = intval($_GET['course_id'] ?? 0);
            
            if (!$courseId) {
                $this->sendError('معرف الدورة مطلوب');
            }
            
            $stmt = $this->pdo->prepare("
                SELECT c.id, c.name, c.description, c.preview_video, c.image_url,
                       COUNT(DISTINCT s.id) as students_count,
                       COUNT(DISTINCT l.id) as lessons_count,
                       SUM(l.duration) as total_duration
                FROM courses c 
                LEFT JOIN subscriptions s ON c.id = s.course_id AND s.is_active = 1
                LEFT JOIN sections sec ON c.id = sec.course_id
                LEFT JOIN lessons l ON sec.id = l.section_id AND l.is_active = 1
                WHERE c.id = ? AND c.is_active = 1
                GROUP BY c.id
            ");
            
            $stmt->execute([$courseId]);
            $course = $stmt->fetch();
            
            if (!$course) {
                $this->sendError('الدورة غير موجودة', 404);
            }
            
            // الحصول على درس معاينة مجاني
            $previewLessonStmt = $this->pdo->prepare("
                SELECT l.name, l.video_url, l.duration
                FROM lessons l
                JOIN sections s ON l.section_id = s.id
                WHERE s.course_id = ? AND l.is_preview = 1 AND l.is_active = 1
                ORDER BY s.sort_order, l.sort_order
                LIMIT 1
            ");
            
            $previewLessonStmt->execute([$courseId]);
            $previewLesson = $previewLessonStmt->fetch();
            
            if ($previewLesson) {
                $course['preview_video'] = $previewLesson['video_url'];
                $course['preview_lesson_name'] = $previewLesson['name'];
            }
            
            $this->sendSuccess(['course' => $course]);
            
        } catch (Exception $e) {
            $this->logSecurityEvent('Failed to get course preview', 'low', ['error' => $e->getMessage()]);
            $this->sendError('فشل في تحميل معاينة الدورة');
        }
    }
    
    // Helper Methods
    
    private function isUserEnrolled($courseId) {
        if (!$this->user) return false;
        
        $stmt = $this->pdo->prepare("
            SELECT COUNT(*) FROM subscriptions 
            WHERE user_id = ? AND course_id = ? AND is_active = 1
        ");
        $stmt->execute([$this->user['id'], $courseId]);
        
        return $stmt->fetchColumn() > 0;
    }
    
    private function hasUserReviewed($courseId) {
        if (!$this->user) return false;
        
        $stmt = $this->pdo->prepare("
            SELECT COUNT(*) FROM course_reviews 
            WHERE user_id = ? AND course_id = ?
        ");
        $stmt->execute([$this->user['id'], $courseId]);
        
        return $stmt->fetchColumn() > 0;
    }
    
    private function getCourseProgress($courseId) {
        if (!$this->user) return 0;
        
        $stmt = $this->pdo->prepare("
            SELECT 
                COUNT(DISTINCT l.id) as total_lessons,
                COUNT(DISTINCT CASE WHEN lp.completed = 1 THEN lp.lesson_id END) as completed_lessons
            FROM lessons l
            JOIN sections s ON l.section_id = s.id
            LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = ?
            WHERE s.course_id = ? AND l.is_active = 1
        ");
        
        $stmt->execute([$this->user['id'], $courseId]);
        $progress = $stmt->fetch();
        
        if ($progress['total_lessons'] == 0) return 0;
        
        return round(($progress['completed_lessons'] / $progress['total_lessons']) * 100);
    }
    
    private function verifyPayment($data) {
        // منطق التحقق من الدفع
        // يمكن ربطه مع بوابات الدفع مثل PayPal, Stripe, تابي، إلخ
        return true; // مؤقت
    }
}
?>