<?php
/**
 * API تحديث القسم (للمسؤولين فقط)
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

if (!in_array($_SERVER['REQUEST_METHOD'], ['PUT', 'POST'])) {
    sendJsonResponse(['success' => false, 'message' => 'طريقة طلب غير صالحة'], 405);
}

try {
    $user = $sessionManager->requireAdmin();
    $db = Database::getInstance()->getConnection();
    
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    
    $sectionId = intval($input['id'] ?? $_GET['id'] ?? 0);
    $name = sanitizeInput($input['name'] ?? '');
    $description = sanitizeInput($input['description'] ?? '');
    $orderIndex = intval($input['order_index'] ?? 0);
    $isActive = isset($input['is_active']) ? 1 : 0;
    
    $errors = [];
    
    if ($sectionId <= 0) {
        sendJsonResponse([
            'success' => false,
            'message' => 'معرف القسم غير صالح'
        ]);
    }
    
    // التحقق من وجود القسم
    $stmt = $db->prepare("SELECT * FROM sections WHERE id = ?");
    $stmt->execute([$sectionId]);
    $section = $stmt->fetch();
    
    if (!$section) {
        sendJsonResponse([
            'success' => false,
            'message' => 'القسم غير موجود'
        ], 404);
    }
    
    // التحقق من صحة البيانات
    if (empty($name)) {
        $errors['name'] = 'اسم القسم مطلوب';
    }
    
    if (!empty($errors)) {
        sendJsonResponse([
            'success' => false,
            'message' => 'بيانات غير صالحة',
            'errors' => $errors
        ]);
    }
    
    // تحديث القسم
    $stmt = $db->prepare("
        UPDATE sections 
        SET name = ?, description = ?, order_index = ?, is_active = ?, updated_at = NOW()
        WHERE id = ?
    ");
    
    $stmt->execute([$name, $description, $orderIndex, $isActive, $sectionId]);
    
    // جلب القسم المحدث
    $stmt = $db->prepare("SELECT * FROM sections WHERE id = ?");
    $stmt->execute([$sectionId]);
    $updatedSection = $stmt->fetch();
    
    sendJsonResponse([
        'success' => true,
        'message' => 'تم تحديث القسم بنجاح',
        'section' => $updatedSection
    ]);
    
} catch (Exception $e) {
    logError("Update section error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في تحديث القسم'
    ], 500);
}
?>