<?php
/**
 * API حذف القسم (للمسؤولين فقط)
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    sendJsonResponse(['success' => false, 'message' => 'طريقة طلب غير صالحة'], 405);
}

try {
    $user = $sessionManager->requireAdmin();
    $db = Database::getInstance()->getConnection();
    
    $sectionId = intval($_GET['id'] ?? 0);
    
    if ($sectionId <= 0) {
        sendJsonResponse([
            'success' => false,
            'message' => 'معرف القسم غير صالح'
        ]);
    }
    
    // التحقق من وجود القسم
    $stmt = $db->prepare("SELECT * FROM sections WHERE id = ?");
    $stmt->execute([$sectionId]);
    $section = $stmt->fetch();
    
    if (!$section) {
        sendJsonResponse([
            'success' => false,
            'message' => 'القسم غير موجود'
        ], 404);
    }
    
    $db->beginTransaction();
    
    try {
        // حذف تقدم الدروس للقسم
        $stmt = $db->prepare("
            DELETE lp FROM lesson_progress lp
            JOIN lessons l ON l.id = lp.lesson_id
            WHERE l.section_id = ?
        ");
        $stmt->execute([$sectionId]);
        
        // حذف دروس القسم
        $stmt = $db->prepare("DELETE FROM lessons WHERE section_id = ?");
        $stmt->execute([$sectionId]);
        
        // حذف القسم
        $stmt = $db->prepare("DELETE FROM sections WHERE id = ?");
        $stmt->execute([$sectionId]);
        
        $db->commit();
        
        sendJsonResponse([
            'success' => true,
            'message' => 'تم حذف القسم بنجاح'
        ]);
        
    } catch (Exception $e) {
        $db->rollback();
        throw $e;
    }
    
} catch (Exception $e) {
    logError("Delete section error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في حذف القسم'
    ], 500);
}
?>