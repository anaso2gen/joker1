<?php
/**
 * API جلب أقسام الكورس
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

try {
    $db = Database::getInstance()->getConnection();
    $user = $sessionManager->validateSession();
    
    $courseId = intval($_GET['course_id'] ?? 0);
    
    if ($courseId <= 0) {
        sendJsonResponse([
            'success' => false,
            'message' => 'معرف الدورة غير صالح'
        ]);
    }
    
    // التحقق من وجود الكورس
    $stmt = $db->prepare("SELECT id, name FROM courses WHERE id = ? AND is_active = 1");
    $stmt->execute([$courseId]);
    $course = $stmt->fetch();
    
    if (!$course) {
        sendJsonResponse([
            'success' => false,
            'message' => 'الدورة غير موجودة'
        ], 404);
    }
    
    // جلب أقسام الكورس
    $stmt = $db->prepare("
        SELECT s.*, 
               COUNT(l.id) as lessons_count,
               SUM(l.duration) as total_duration
        FROM sections s
        LEFT JOIN lessons l ON l.section_id = s.id AND l.is_active = 1
        WHERE s.course_id = ? AND s.is_active = 1
        GROUP BY s.id
        ORDER BY s.order_index ASC, s.created_at ASC
    ");
    
    $stmt->execute([$courseId]);
    $sections = $stmt->fetchAll();
    
    // تنسيق البيانات
    foreach ($sections as &$section) {
        $section['lessons_count'] = (int)$section['lessons_count'];
        $section['total_duration'] = (int)$section['total_duration'];
    }
    
    sendJsonResponse([
        'success' => true,
        'course' => $course,
        'sections' => $sections
    ]);
    
} catch (Exception $e) {
    logError("Get sections error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في جلب الأقسام'
    ], 500);
}
?>