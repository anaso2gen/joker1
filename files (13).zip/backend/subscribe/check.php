<?php
/**
 * API فحص الاشتراكات
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../session.php';

try {
    $user = $sessionManager->requireLogin();
    $db = Database::getInstance()->getConnection();
    
    // فحص اشتراك في دورة محددة
    if (isset($_GET['course_id'])) {
        $courseId = intval($_GET['course_id']);
        
        $stmt = $db->prepare("
            SELECT s.*, c.name as course_name, c.code as course_code,
                   c.description, c.image_url
            FROM subscriptions s
            JOIN courses c ON c.id = s.course_id
            WHERE s.user_id = ? AND s.course_id = ? AND s.status = 'active'
            AND (s.expires_at IS NULL OR s.expires_at > NOW())
        ");
        
        $stmt->execute([$user['user_id'], $courseId]);
        $subscription = $stmt->fetch();
        
        sendJsonResponse([
            'success' => true,
            'subscribed' => $subscription !== false,
            'subscription' => $subscription
        ]);
        return;
    }
    
    // جلب جميع اشتراكات المستخدم
    $stmt = $db->prepare("
        SELECT s.*, c.name as course_name, c.code as course_code,
               c.description, c.image_url,
               COUNT(DISTINCT sec.id) as sections_count,
               COUNT(DISTINCT l.id) as lessons_count,
               COUNT(DISTINCT lp.lesson_id) as completed_lessons,
               SUM(l.duration) as total_duration,
               COALESCE(AVG(CASE WHEN lp.completed = 1 THEN 100 ELSE 0 END), 0) as progress_percentage
        FROM subscriptions s
        JOIN courses c ON c.id = s.course_id
        LEFT JOIN sections sec ON sec.course_id = c.id AND sec.is_active = 1
        LEFT JOIN lessons l ON l.section_id = sec.id AND l.is_active = 1
        LEFT JOIN lesson_progress lp ON lp.lesson_id = l.id AND lp.user_id = s.user_id
        WHERE s.user_id = ? AND s.status = 'active'
        AND (s.expires_at IS NULL OR s.expires_at > NOW())
        AND c.is_active = 1
        GROUP BY s.course_id
        ORDER BY s.subscribed_at DESC
    ");
    
    $stmt->execute([$user['user_id']]);
    $subscriptions = $stmt->fetchAll();
    
    // تنسيق البيانات
    foreach ($subscriptions as &$subscription) {
        $subscription['sections_count'] = (int)$subscription['sections_count'];
        $subscription['lessons_count'] = (int)$subscription['lessons_count'];
        $subscription['completed_lessons'] = (int)$subscription['completed_lessons'];
        $subscription['total_duration'] = formatDuration($subscription['total_duration'] ?: 0);
        $subscription['progress_percentage'] = round($subscription['progress_percentage'], 1);
        $subscription['subscribed'] = true; // لتوافق مع كروت الكورسات
    }
    
    sendJsonResponse([
        'success' => true,
        'subscriptions' => $subscriptions
    ]);
    
} catch (Exception $e) {
    logError("Check subscriptions error: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'message' => 'خطأ في جلب الاشتراكات'
    ], 500);
}
?>