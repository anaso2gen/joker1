<?php
// ملف تشخيص شامل - احذفه بعد الانتهاء
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "<h2>🔍 تشخيص شامل للموقع</h2>";

// 1. فحص ملفات المشروع
echo "<h3>1. فحص الملفات الأساسية:</h3>";
$requiredFiles = [
    'config.php' => 'ملف الإعدادات',
    'index.php' => 'الصفحة الرئيسية',
    'login.php' => 'صفحة تسجيل الدخول',
    'logout.php' => 'تسجيل الخروج',
    'courses.php' => 'صفحة الدورات',
    'register.php' => 'صفحة التسجيل',
    'editdash.php' => 'لوحة التحكم'
];

foreach ($requiredFiles as $file => $description) {
    $status = file_exists($file) ? "✅ موجود" : "❌ مفقود";
    echo "$description ($file): $status<br>";
}

// 2. فحص أذونات المجلدات
echo "<h3>2. فحص أذونات المجلدات:</h3>";
$directories = ['uploads/', 'logs/', 'assets/'];
foreach ($directories as $dir) {
    if (!file_exists($dir)) {
        @mkdir($dir, 0755, true);
    }
    $writable = is_writable($dir) ? "✅ قابل للكتابة" : "❌ غير قابل للكتابة";
    echo "$dir: $writable<br>";
}

// 3. فحص إعدادات PHP
echo "<h3>3. إعدادات PHP:</h3>";
echo "إصدار PHP: " . PHP_VERSION . "<br>";
echo "الحد الأقصى لرفع الملفات: " . ini_get('upload_max_filesize') . "<br>";
echo "الحد الأقصى لحجم POST: " . ini_get('post_max_size') . "<br>";
echo "عرض الأخطاء: " . (ini_get('display_errors') ? 'مفعل' : 'معطل') . "<br>";

// 4. فحص الإضافات المطلوبة
echo "<h3>4. إضافات PHP المطلوبة:</h3>";
$extensions = ['pdo', 'pdo_mysql', 'mysqli', 'curl', 'json', 'mbstring'];
foreach ($extensions as $ext) {
    $status = extension_loaded($ext) ? "✅ مفعل" : "❌ معطل";
    echo "$ext: $status<br>";
}

// 5. اختبار قاعدة البيانات
echo "<h3>5. اختبار قاعدة البيانات:</h3>";
if (file_exists('config.php')) {
    try {
        define('LEARNING_PLATFORM', true);
        require_once 'config.php';
        
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", 
                       DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        echo "✅ الاتصال بقاعدة البيانات ناجح<br>";
        
        // فحص الجداول
        $stmt = $pdo->query("SHOW TABLES");
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
        echo "عدد الجداول: " . count($tables) . "<br>";
        
        $expectedTables = ['users', 'courses', 'sections', 'lessons', 'activation_codes', 
                          'subscriptions', 'lesson_progress', 'user_sessions', 'security_logs', 'settings'];
        
        foreach ($expectedTables as $table) {
            $status = in_array($table, $tables) ? "✅ موجود" : "❌ مفقود";
            echo "جدول $table: $status<br>";
        }
        
        // عدد المستخدمين
        if (in_array('users', $tables)) {
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
            $userCount = $stmt->fetch()['count'];
            echo "عدد المستخدمين: $userCount<br>";
        }
        
    } catch (Exception $e) {
        echo "❌ خطأ في قاعدة البيانات: " . $e->getMessage() . "<br>";
    }
} else {
    echo "❌ ملف config.php غير موجود<br>";
}

// 6. فحص متغيرات الخادم
echo "<h3>6. معلومات الخادم:</h3>";
echo "خادم الويب: " . ($_SERVER['SERVER_SOFTWARE'] ?? 'غير معروف') . "<br>";
echo "المجلد الجذر: " . ($_SERVER['DOCUMENT_ROOT'] ?? 'غير معروف') . "<br>";
echo "المجلد الحالي: " . getcwd() . "<br>";
echo "اسم النطاق: " . ($_SERVER['HTTP_HOST'] ?? 'غير معروف') . "<br>";

// 7. اختبار الجلسات
echo "<h3>7. اختبار الجلسات:</h3>";
if (session_start()) {
    echo "✅ الجلسات تعمل بشكل طبيعي<br>";
    echo "معرف الجلسة: " . session_id() . "<br>";
} else {
    echo "❌ مشكلة في الجلسات<br>";
}

echo "<hr>";
echo "<h3>📋 ملخص التشخيص:</h3>";
echo "انسخ هذه المعلومات وأرسلها لي لتحديد المشكلة بدقة.";
?>