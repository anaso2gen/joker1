-- تشغيل هذا في phpMyAdmin إذا فشل التثبيت التلقائي

CREATE DATABASE IF NOT EXISTS learning_platform CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE learning_platform;

-- باقي الجداول كما هو مذكور في السكريبت أعلاه