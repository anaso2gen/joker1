<?php
/**
 * صفحة إنشاء حساب جديد
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 08:27:50
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/session.php';

// إعادة التوجيه إذا كان المستخدم مسجل دخول بالفعل
if ($sessionManager->isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';
$formData = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // التحقق من رمز CSRF
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'رمز الأمان غير صحيح. يرجى إعادة المحاولة.';
        logSecurityEvent('CSRF token mismatch in registration', 'medium');
    } else {
        // جمع وتنظيف البيانات
        $formData = [
            'first_name' => sanitizeInput($_POST['first_name'] ?? ''),
            'last_name' => sanitizeInput($_POST['last_name'] ?? ''),
            'email' => sanitizeInput($_POST['email'] ?? ''),
            'phone' => sanitizeInput($_POST['phone'] ?? ''),
            'password' => $_POST['password'] ?? '',
            'confirm_password' => $_POST['confirm_password'] ?? '',
            'terms_accepted' => isset($_POST['terms_accepted']),
            'newsletter' => isset($_POST['newsletter'])
        ];
        
        // التحقق من صحة البيانات
        $validationErrors = [];
        
        if (empty($formData['first_name'])) {
            $validationErrors[] = 'الاسم الأول مطلوب';
        } elseif (strlen($formData['first_name']) < 2) {
            $validationErrors[] = 'الاسم الأول يجب أن يكون حرفين على الأقل';
        }
        
        if (empty($formData['last_name'])) {
            $validationErrors[] = 'اسم العائلة مطلوب';
        } elseif (strlen($formData['last_name']) < 2) {
            $validationErrors[] = 'اسم العائلة يجب أن يكون حرفين على الأقل';
        }
        
        if (empty($formData['email'])) {
            $validationErrors[] = 'البريد الإلكتروني مطلوب';
        } elseif (!isValidEmail($formData['email'])) {
            $validationErrors[] = 'البريد الإلكتروني غير صحيح';
        }
        
        if (empty($formData['password'])) {
            $validationErrors[] = 'كلمة المرور مطلوبة';
        } elseif (!isStrongPassword($formData['password'])) {
            $validationErrors[] = 'كلمة المرور يجب أن تحتوي على 8 أحرف على الأقل، وتشمل أحرف كبيرة وصغيرة وأرقام';
        }
        
        if ($formData['password'] !== $formData['confirm_password']) {
            $validationErrors[] = 'كلمات المرور غير متطابقة';
        }
        
        if (!$formData['terms_accepted']) {
            $validationErrors[] = 'يجب الموافقة على الشروط والأحكام';
        }
        
        if (!empty($validationErrors)) {
            $error = implode('<br>', $validationErrors);
        } else {
            // التحقق من عدم وجود البريد الإلكتروني مسبقاً
            try {
                $pdo = new PDO(
                    "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
                    DB_USER, DB_PASS,
                    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
                );
                
                $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                $stmt->execute([$formData['email']]);
                
                if ($stmt->fetch()) {
                    $error = 'هذا البريد الإلكتروني مستخدم بالفعل. يرجى استخدام بريد آخر أو <a href="login.php">تسجيل الدخول</a>';
                } else {
                    // إنشاء المستخدم الجديد
                    $hashedPassword = password_hash($formData['password'], PASSWORD_DEFAULT);
                    $activationCode = generateActivationCode(32, 'mixed');
                    
                    $stmt = $pdo->prepare("
                        INSERT INTO users (
                            first_name, last_name, email, phone, password_hash, 
                            activation_code, is_active, newsletter_subscribed, 
                            created_at, last_login
                        ) VALUES (?, ?, ?, ?, ?, ?, 1, ?, NOW(), NOW())
                    ");
                    
                    $stmt->execute([
                        $formData['first_name'],
                        $formData['last_name'],
                        $formData['email'],
                        $formData['phone'],
                        $hashedPassword,
                        $activationCode,
                        $formData['newsletter'] ? 1 : 0
                    ]);
                    
                    $userId = $pdo->lastInsertId();
                    
                    // تسجيل النشاط
                    logActivity("New user registered successfully", 'auth', $userId);
                    
                    // إرسال إيميل ترحيب (اختياري)
                    $welcomeMessage = "
                        <h2>مرحباً بك في " . SITE_NAME . "!</h2>
                        <p>عزيزي/عزيزتي {$formData['first_name']} {$formData['last_name']},</p>
                        <p>تم إنشاء حسابك بنجاح. يمكنك الآن تسجيل الدخول والبدء في استكشاف دوراتنا التعليمية.</p>
                        <p><a href='" . SITE_URL . "/login.php'>تسجيل الدخول الآن</a></p>
                        <p>مع أطيب التحيات،<br>فريق " . SITE_NAME . "</p>
                    ";
                    
                    sendEmail(
                        $formData['email'],
                        'مرحباً بك في ' . SITE_NAME,
                        $welcomeMessage
                    );
                    
                    // إعادة التوجيه لصفحة تسجيل الدخول مع رسالة نجاح
                    header('Location: login.php?registered=success');
                    exit;
                }
                
            } catch (PDOException $e) {
                logSecurityEvent('Registration database error', 'high', [
                    'error' => $e->getMessage(),
                    'email' => $formData['email']
                ]);
                $error = 'حدث خطأ في النظام. يرجى المحاولة لاحقاً.';
            }
        }
    }
}

// تضمين ملف العرض
require_once __DIR__ . '/frontend/views/pages/register.php';
?>