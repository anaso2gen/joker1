/**
 * Service Worker - منصة ترند التعليمية
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 10:50:02
 */

const CACHE_NAME = 'trend-academy-v1.0.0';
const OFFLINE_URL = '/offline.html';

// الملفات المطلوب تخزينها مؤقتاً
const STATIC_CACHE_URLS = [
    '/',
    '/offline.html',
    '/assets/css/main.css',
    '/assets/css/responsive.css',
    '/assets/js/main.js',
    '/assets/js/common.js',
    '/assets/images/logo.png',
    '/assets/images/placeholder.jpg',
    '/assets/fonts/cairo-regular.woff2',
    '/manifest.json'
];

// الموارد الديناميكية
const DYNAMIC_CACHE_URLS = [
    '/api/',
    '/courses/',
    '/lessons/',
    '/user/'
];

// استراتيجيات التخزين المؤقت
const CACHE_STRATEGIES = {
    // Cache First - للملفات الثابتة
    CACHE_FIRST: 'cache-first',
    // Network First - للمحتوى الديناميكي
    NETWORK_FIRST: 'network-first',
    // Stale While Revalidate - للصور والملفات الوسائط
    STALE_WHILE_REVALIDATE: 'stale-while-revalidate'
};

/**
 * تثبيت Service Worker
 */
self.addEventListener('install', event => {
    console.log('Service Worker: Installing...');
    
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('Service Worker: Caching files');
                return cache.addAll(STATIC_CACHE_URLS);
            })
            .then(() => {
                console.log('Service Worker: Installation complete');
                return self.skipWaiting();
            })
            .catch(error => {
                console.error('Service Worker: Installation failed', error);
            })
    );
});

/**
 * تفعيل Service Worker
 */
self.addEventListener('activate', event => {
    console.log('Service Worker: Activating...');
    
    event.waitUntil(
        caches.keys()
            .then(cacheNames => {
                return Promise.all(
                    cacheNames.map(cache => {
                        if (cache !== CACHE_NAME) {
                            console.log('Service Worker: Deleting old cache', cache);
                            return caches.delete(cache);
                        }
                    })
                );
            })
            .then(() => {
                console.log('Service Worker: Activation complete');
                return self.clients.claim();
            })
    );
});

/**
 * اعتراض الطلبات
 */
self.addEventListener('fetch', event => {
    // تجاهل الطلبات غير HTTP/HTTPS
    if (!event.request.url.startsWith('http')) {
        return;
    }
    
    // تجاهل طلبات Chrome Extensions
    if (event.request.url.startsWith('chrome-extension://')) {
        return;
    }
    
    const url = new URL(event.request.url);
    const requestPath = url.pathname;
    
    // تحديد استراتيجية التخزين المؤقت
    let strategy = getStrategy(requestPath, event.request);
    
    event.respondWith(
        handleRequest(event.request, strategy)
    );
});

/**
 * تحديد استراتيجية التخزين المؤقت
 */
function getStrategy(path, request) {
    // الملفات الثابتة - Cache First
    if (path.match(/\.(css|js|woff2?|png|jpg|jpeg|gif|svg|ico)$/)) {
        return CACHE_STRATEGIES.CACHE_FIRST;
    }
    
    // API والبيانات الديناميكية - Network First
    if (path.startsWith('/api/') || path.startsWith('/admin/')) {
        return CACHE_STRATEGIES.NETWORK_FIRST;
    }
    
    // الصور والملفات الوسائط - Stale While Revalidate
    if (path.startsWith('/uploads/') || path.startsWith('/storage/')) {
        return CACHE_STRATEGIES.STALE_WHILE_REVALIDATE;
    }
    
    // الصفحات العادية - Network First مع Fallback
    return CACHE_STRATEGIES.NETWORK_FIRST;
}

/**
 * معالجة الطلب حسب الاستراتيجية
 */
async function handleRequest(request, strategy) {
    switch (strategy) {
        case CACHE_STRATEGIES.CACHE_FIRST:
            return cacheFirst(request);
            
        case CACHE_STRATEGIES.NETWORK_FIRST:
            return networkFirst(request);
            
        case CACHE_STRATEGIES.STALE_WHILE_REVALIDATE:
            return staleWhileRevalidate(request);
            
        default:
            return networkFirst(request);
    }
}

/**
 * Cache First Strategy
 */
async function cacheFirst(request) {
    try {
        const cache = await caches.open(CACHE_NAME);
        const cachedResponse = await cache.match(request);
        
        if (cachedResponse) {
            return cachedResponse;
        }
        
        const networkResponse = await fetch(request);
        
        if (networkResponse.ok) {
            cache.put(request, networkResponse.clone());
        }
        
        return networkResponse;
    } catch (error) {
        console.error('Cache First failed:', error);
        return await handleOffline(request);
    }
}

/**
 * Network First Strategy
 */
async function networkFirst(request) {
    try {
        const networkResponse = await fetch(request);
        
        if (networkResponse.ok) {
            const cache = await caches.open(CACHE_NAME);
            cache.put(request, networkResponse.clone());
        }
        
        return networkResponse;
    } catch (error) {
        console.log('Network failed, trying cache:', error);
        
        const cache = await caches.open(CACHE_NAME);
        const cachedResponse = await cache.match(request);
        
        if (cachedResponse) {
            return cachedResponse;
        }
        
        return await handleOffline(request);
    }
}

/**
 * Stale While Revalidate Strategy
 */
async function staleWhileRevalidate(request) {
    const cache = await caches.open(CACHE_NAME);
    const cachedResponse = await cache.match(request);
    
    // إرجاع الاستجابة من Cache فوراً إذا كانت موجودة
    const fetchPromise = fetch(request)
        .then(networkResponse => {
            if (networkResponse.ok) {
                cache.put(request, networkResponse.clone());
            }
            return networkResponse;
        })
        .catch(() => cachedResponse);
    
    return cachedResponse || fetchPromise;
}

/**
 * معالجة حالة عدم الاتصال
 */
async function handleOffline(request) {
    // للصفحات - إرجاع صفحة offline
    if (request.destination === 'document') {
        const cache = await caches.open(CACHE_NAME);
        return await cache.match(OFFLINE_URL);
    }
    
    // للصور - إرجاع صورة placeholder
    if (request.destination === 'image') {
        const cache = await caches.open(CACHE_NAME);
        return await cache.match('/assets/images/placeholder.jpg');
    }
    
    // للملفات الأخرى - إرجاع استجابة خطأ
    return new Response('غير متوفر في وضع عدم الاتصال', {
        status: 503,
        statusText: 'Service Unavailable',
        headers: {
            'Content-Type': 'text/plain; charset=utf-8'
        }
    });
}

/**
 * معالجة رسائل من الصفحة الرئيسية
 */
self.addEventListener('message', event => {
    if (event.data && event.data.type) {
        switch (event.data.type) {
            case 'SKIP_WAITING':
                self.skipWaiting();
                break;
                
            case 'GET_CACHE_SIZE':
                getCacheSize().then(size => {
                    event.ports[0].postMessage({ size });
                });
                break;
                
            case 'CLEAR_CACHE':
                clearCache().then(success => {
                    event.ports[0].postMessage({ success });
                });
                break;
                
            case 'UPDATE_CACHE':
                updateCache(event.data.urls).then(success => {
                    event.ports[0].postMessage({ success });
                });
                break;
        }
    }
});

/**
 * الحصول على حجم Cache
 */
async function getCacheSize() {
    try {
        const cache = await caches.open(CACHE_NAME);
        const requests = await cache.keys();
        
        let totalSize = 0;
        
        for (const request of requests) {
            const response = await cache.match(request);
            if (response) {
                const blob = await response.blob();
                totalSize += blob.size;
            }
        }
        
        return totalSize;
    } catch (error) {
        console.error('Error calculating cache size:', error);
        return 0;
    }
}

/**
 * مسح Cache
 */
async function clearCache() {
    try {
        const cacheNames = await caches.keys();
        await Promise.all(
            cacheNames.map(name => caches.delete(name))
        );
        return true;
    } catch (error) {
        console.error('Error clearing cache:', error);
        return false;
    }
}

/**
 * تحديث Cache
 */
async function updateCache(urls) {
    try {
        const cache = await caches.open(CACHE_NAME);
        await cache.addAll(urls);
        return true;
    } catch (error) {
        console.error('Error updating cache:', error);
        return false;
    }
}

/**
 * معالجة إشعارات Push
 */
self.addEventListener('push', event => {
    if (!event.data) {
        return;
    }
    
    try {
        const data = event.data.json();
        
        const options = {
            body: data.body || 'رسالة جديدة من منصة ترند التعليمية',
            icon: '/assets/images/notification-icon.png',
            badge: '/assets/images/badge-icon.png',
            image: data.image,
            tag: data.tag || 'trend-academy',
            data: data.data || {},
            actions: data.actions || [
                {
                    action: 'view',
                    title: 'عرض',
                    icon: '/assets/images/view-icon.png'
                },
                {
                    action: 'dismiss',
                    title: 'تجاهل',
                    icon: '/assets/images/dismiss-icon.png'
                }
            ],
            vibrate: [200, 100, 200],
            requireInteraction: data.requireInteraction || false,
            silent: data.silent || false
        };
        
        event.waitUntil(
            self.registration.showNotification(
                data.title || 'منصة ترند التعليمية',
                options
            )
        );
    } catch (error) {
        console.error('Error handling push notification:', error);
    }
});

/**
 * معالجة النقر على الإشعارات
 */
self.addEventListener('notificationclick', event => {
    event.notification.close();
    
    const action = event.action;
    const data = event.notification.data;
    
    if (action === 'dismiss') {
        return;
    }
    
    let url = '/';
    
    if (action === 'view' && data.url) {
        url = data.url;
    } else if (data.defaultUrl) {
        url = data.defaultUrl;
    }
    
    event.waitUntil(
        clients.matchAll({ type: 'window' }).then(clientList => {
            // البحث عن نافذة مفتوحة
            for (const client of clientList) {
                if (client.url === url && 'focus' in client) {
                    return client.focus();
                }
            }
            
            // فتح نافذة جديدة
            if (clients.openWindow) {
                return clients.openWindow(url);
            }
        })
    );
});

/**
 * معالجة إغلاق الإشعارات
 */
self.addEventListener('notificationclose', event => {
    const data = event.notification.data;
    
    // تسجيل إحصائيات إغلاق الإشعار
    if (data.trackClose) {
        fetch('/api/notifications/track', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: 'close',
                notificationId: data.id,
                timestamp: Date.now()
            })
        }).catch(error => {
            console.error('Error tracking notification close:', error);
        });
    }
});

/**
 * معالجة تحديث Service Worker
 */
self.addEventListener('controllerchange', () => {
    window.location.reload();
});

/**
 * معالجة أخطاء غير متوقعة
 */
self.addEventListener('error', event => {
    console.error('Service Worker error:', event.error);
});

/**
 * معالجة Promise المرفوضة
 */
self.addEventListener('unhandledrejection', event => {
    console.error('Service Worker unhandled rejection:', event.reason);
});

// تسجيل معلومات Service Worker
console.log('Service Worker: Script loaded');
console.log('Cache Name:', CACHE_NAME);
console.log('Offline URL:', OFFLINE_URL);