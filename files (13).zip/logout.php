<?php
/**
 * صفحة تسجيل الخروج
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 08:52:12
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/session.php';

// التحقق من وجود رمز CSRF (للحماية من تسجيل خروج غير مرغوب)
if (isset($_GET['token']) && !verifyCSRFToken($_GET['token'])) {
    logSecurityEvent('Invalid CSRF token in logout', 'medium');
    header('Location: index.php');
    exit;
}

// تسجيل الخروج
if ($sessionManager->isLoggedIn()) {
    $sessionManager->logout('User requested logout');
}

// إعادة التوجيه لصفحة تسجيل الدخول مع رسالة نجاح
header('Location: login.php?logout=success');
exit;
?>