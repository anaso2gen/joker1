<?php
/**
 * مدير الجلسات
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 10:04:46
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

class SessionManager {
    private $pdo;
    private $currentUser = null;
    private $sessionLifetime;
    
    public function __construct() {
        $this->sessionLifetime = SESSION_LIFETIME;
        $this->initializeDatabase();
        $this->configureSession();
        $this->startSession();
        $this->loadCurrentUser();
    }
    
    /**
     * تهيئة الاتصال بقاعدة البيانات
     */
    private function initializeDatabase() {
        try {
            $this->pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
                DB_USER, DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
        } catch (PDOException $e) {
            throw new Exception('Database connection failed: ' . $e->getMessage());
        }
    }
    
    /**
     * تكوين إعدادات الجلسة
     */
    private function configureSession() {
        // إعدادات أمان الجلسة
        ini_set('session.cookie_httponly', 1);
        ini_set('session.cookie_secure', isset($_SERVER['HTTPS']));
        ini_set('session.cookie_samesite', 'Lax');
        ini_set('session.use_strict_mode', 1);
        ini_set('session.gc_maxlifetime', $this->sessionLifetime);
        
        // تغيير مسار حفظ الجلسات
        $sessionPath = __DIR__ . '/../storage/sessions';
        if (!is_dir($sessionPath)) {
            mkdir($sessionPath, 0700, true);
        }
        session_save_path($sessionPath);
        
        // تخصيص معالج الجلسة
        session_set_save_handler(
            [$this, 'sessionOpen'],
            [$this, 'sessionClose'],
            [$this, 'sessionRead'],
            [$this, 'sessionWrite'],
            [$this, 'sessionDestroy'],
            [$this, 'sessionGC']
        );
    }
    
    /**
     * بدء الجلسة
     */
    private function startSession() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        // تجديد معرف الجلسة بشكل دوري للأمان
        if (!isset($_SESSION['last_regeneration'])) {
            $_SESSION['last_regeneration'] = time();
        } elseif (time() - $_SESSION['last_regeneration'] > 300) { // كل 5 دقائق
            session_regenerate_id(true);
            $_SESSION['last_regeneration'] = time();
        }
    }
    
    /**
     * تحميل بيانات المستخدم الحالي
     */
    private function loadCurrentUser() {
        if (isset($_SESSION['user_id'])) {
            try {
                $stmt = $this->pdo->prepare("
                    SELECT u.*, us.expires_at 
                    FROM users u
                    LEFT JOIN user_sessions us ON u.id = us.user_id AND us.session_id = ?
                    WHERE u.id = ? AND u.is_active = 1
                ");
                $stmt->execute([session_id(), $_SESSION['user_id']]);
                $user = $stmt->fetch();
                
                if ($user) {
                    // فحص انتهاء صلاحية الجلسة
                    if ($user['expires_at'] && strtotime($user['expires_at']) < time()) {
                        $this->logout();
                        return;
                    }
                    
                    $this->currentUser = $user;
                    $this->updateLastActivity();
                } else {
                    $this->logout();
                }
            } catch (Exception $e) {
                error_log("Error loading current user: " . $e->getMessage());
                $this->logout();
            }
        }
    }
    
    /**
     * تسجيل دخول المستخدم
     */
    public function login($userId, $rememberMe = false) {
        try {
            // الحصول على بيانات المستخدم
            $stmt = $this->pdo->prepare("
                SELECT * FROM users 
                WHERE id = ? AND is_active = 1 AND email_verified = 1
            ");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();
            
            if (!$user) {
                return false;
            }
            
            // إنشاء جلسة جديدة
            session_regenerate_id(true);
            $_SESSION['user_id'] = $userId;
            $_SESSION['login_time'] = time();
            $_SESSION['last_regeneration'] = time();
            
            // حفظ الجلسة في قاعدة البيانات
            $sessionToken = bin2hex(random_bytes(32));
            $expiresAt = $rememberMe ? 
                date('Y-m-d H:i:s', time() + REMEMBER_ME_LIFETIME) : 
                date('Y-m-d H:i:s', time() + $this->sessionLifetime);
            
            $stmt = $this->pdo->prepare("
                INSERT INTO user_sessions (user_id, session_id, session_token, ip_address, user_agent, expires_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE 
                    session_token = VALUES(session_token),
                    ip_address = VALUES(ip_address),
                    user_agent = VALUES(user_agent),
                    expires_at = VALUES(expires_at),
                    created_at = NOW()
            ");
            
            $stmt->execute([
                $userId,
                session_id(),
                $sessionToken,
                getRealIpAddress(),
                $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
                $expiresAt
            ]);
            
            // تحديث آخر تسجيل دخول
            $stmt = $this->pdo->prepare("
                UPDATE users 
                SET last_login = NOW(), last_login_ip = ?
                WHERE id = ?
            ");
            $stmt->execute([getRealIpAddress(), $userId]);
            
            $this->currentUser = $user;
            
            // تنظيف الجلسات القديمة
            $this->cleanupOldSessions($userId);
            
            return true;
        } catch (Exception $e) {
            error_log("Login error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * تسجيل خروج المستخدم
     */
    public function logout() {
        if ($this->currentUser) {
            try {
                // حذف الجلسة من قاعدة البيانات
                $stmt = $this->pdo->prepare("
                    DELETE FROM user_sessions 
                    WHERE user_id = ? AND session_id = ?
                ");
                $stmt->execute([$this->currentUser['id'], session_id()]);
            } catch (Exception $e) {
                error_log("Logout error: " . $e->getMessage());
            }
        }
        
        // تنظيف بيانات الجلسة
        $_SESSION = [];
        $this->currentUser = null;
        
        // حذف كوكيز الجلسة
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        
        session_destroy();
    }
    
    /**
     * فحص تسجيل الدخول
     */
    public function isLoggedIn() {
        return $this->currentUser !== null;
    }
    
    /**
     * الحصول على المستخدم الحالي
     */
    public function getCurrentUser() {
        return $this->currentUser;
    }
    
    /**
     * فحص صلاحيات الإدارة
     */
    public function isAdmin() {
        return $this->currentUser && $this->currentUser['is_admin'];
    }
    
    /**
     * تحديث النشاط الأخير
     */
    private function updateLastActivity() {
        if ($this->currentUser) {
            try {
                $stmt = $this->pdo->prepare("
                    UPDATE user_sessions 
                    SET last_activity = NOW() 
                    WHERE user_id = ? AND session_id = ?
                ");
                $stmt->execute([$this->currentUser['id'], session_id()]);
            } catch (Exception $e) {
                // تجاهل أخطاء تحديث النشاط
            }
        }
    }
    
    /**
     * تنظيف الجلسات القديمة
     */
    private function cleanupOldSessions($userId, $keepCurrent = 5) {
        try {
            // حذف الجلسات المنتهية الصلاحية
            $this->pdo->prepare("DELETE FROM user_sessions WHERE expires_at < NOW()")->execute();
            
            // الاحتفاظ بآخر 5 جلسات فقط للمستخدم
            $stmt = $this->pdo->prepare("
                DELETE FROM user_sessions 
                WHERE user_id = ? AND session_id NOT IN (
                    SELECT session_id FROM (
                        SELECT session_id FROM user_sessions 
                        WHERE user_id = ? 
                        ORDER BY created_at DESC 
                        LIMIT ?
                    ) t
                )
            ");
            $stmt->execute([$userId, $userId, $keepCurrent]);
        } catch (Exception $e) {
            error_log("Session cleanup error: " . $e->getMessage());
        }
    }
    
    /**
     * الحصول على جلسات المستخدم النشطة
     */
    public function getActiveSessions($userId = null) {
        $userId = $userId ?: $this->currentUser['id'];
        
        if (!$userId) {
            return [];
        }
        
        try {
            $stmt = $this->pdo->prepare("
                SELECT session_id, ip_address, user_agent, created_at, last_activity, expires_at,
                       CASE WHEN session_id = ? THEN 1 ELSE 0 END as is_current
                FROM user_sessions 
                WHERE user_id = ? AND expires_at > NOW()
                ORDER BY is_current DESC, last_activity DESC
            ");
            $stmt->execute([session_id(), $userId]);
            
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error getting active sessions: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * إنهاء جلسة محددة
     */
    public function terminateSession($sessionId, $userId = null) {
        $userId = $userId ?: $this->currentUser['id'];
        
        if (!$userId) {
            return false;
        }
        
        try {
            $stmt = $this->pdo->prepare("
                DELETE FROM user_sessions 
                WHERE session_id = ? AND user_id = ?
            ");
            
            return $stmt->execute([$sessionId, $userId]);
        } catch (Exception $e) {
            error_log("Error terminating session: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * إنهاء جميع الجلسات الأخرى
     */
    public function terminateOtherSessions($userId = null) {
        $userId = $userId ?: $this->currentUser['id'];
        
        if (!$userId) {
            return false;
        }
        
        try {
            $stmt = $this->pdo->prepare("
                DELETE FROM user_sessions 
                WHERE user_id = ? AND session_id != ?
            ");
            
            return $stmt->execute([$userId, session_id()]);
        } catch (Exception $e) {
            error_log("Error terminating other sessions: " . $e->getMessage());
            return false;
        }
    }
    
    // Session Handler Methods
    
    public function sessionOpen($savePath, $sessionName) {
        return true;
    }
    
    public function sessionClose() {
        return true;
    }
    
    public function sessionRead($sessionId) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT session_data FROM user_sessions 
                WHERE session_id = ? AND expires_at > NOW()
            ");
            $stmt->execute([$sessionId]);
            $result = $stmt->fetch();
            
            return $result ? $result['session_data'] : '';
        } catch (Exception $e) {
            return '';
        }
    }
    
    public function sessionWrite($sessionId, $sessionData) {
        try {
            $stmt = $this->pdo->prepare("
                UPDATE user_sessions 
                SET session_data = ?, last_activity = NOW()
                WHERE session_id = ?
            ");
            
            return $stmt->execute([$sessionData, $sessionId]);
        } catch (Exception $e) {
            return false;
        }
    }
    
    public function sessionDestroy($sessionId) {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM user_sessions WHERE session_id = ?");
            return $stmt->execute([$sessionId]);
        } catch (Exception $e) {
            return false;
        }
    }
    
    public function sessionGC($maxLifetime) {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM user_sessions WHERE expires_at < NOW()");
            return $stmt->execute();
        } catch (Exception $e) {
            return false;
        }
    }
}
?>