<?php
/**
 * صفحة تسجيل الدخول
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 08:27:50
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/session.php';

// إعادة التوجيه إذا كان المستخدم مسجل دخول بالفعل
if ($sessionManager->isLoggedIn()) {
    $user = $sessionManager->getCurrentUser();
    $redirectUrl = $user['is_admin'] ? 'editdash.php' : 'index.php';
    
    // التحقق من وجود URL مقصود
    if (isset($_SESSION['intended_url'])) {
        $redirectUrl = $_SESSION['intended_url'];
        unset($_SESSION['intended_url']);
    }
    
    header("Location: $redirectUrl");
    exit;
}

$error = '';
$success = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // التحقق من رمز CSRF
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'رمز الأمان غير صحيح. يرجى إعادة المحاولة.';
        logSecurityEvent('CSRF token mismatch in login', 'medium');
    } else {
        $email = sanitizeInput($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $rememberMe = isset($_POST['remember_me']);
        
        if (empty($email) || empty($password)) {
            $error = 'يرجى إدخال البريد الإلكتروني وكلمة المرور';
        } else {
            // محاولة تسجيل الدخول
            $result = $sessionManager->login($email, $password, $rememberMe);
            
            if ($result['success']) {
                // نجح تسجيل الدخول
                $redirectUrl = $result['redirect'];
                
                // التحقق من وجود URL مقصود
                if (isset($_SESSION['intended_url'])) {
                    $redirectUrl = $_SESSION['intended_url'];
                    unset($_SESSION['intended_url']);
                }
                
                header("Location: $redirectUrl");
                exit;
            } else {
                $error = $result['message'];
            }
        }
    }
}

// التحقق من رسائل النجاح (مثل بعد التسجيل)
if (isset($_GET['registered']) && $_GET['registered'] === 'success') {
    $success = 'تم إنشاء حسابك بنجاح! يمكنك الآن تسجيل الدخول.';
}

if (isset($_GET['logout']) && $_GET['logout'] === 'success') {
    $success = 'تم تسجيل الخروج بنجاح. نراك قريباً!';
}

// تضمين ملف العرض
require_once __DIR__ . '/frontend/views/pages/login.php';
?>