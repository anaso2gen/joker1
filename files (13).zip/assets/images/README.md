# دليل الصور - منصة ترند التعليمية
المطور: anaso2gen
التاريخ: 2025-05-29 10:56:01

## هيكل مجلد الصور:

### الشعارات والهوية البصرية
- logo.png (300x100) - الشعار الرئيسي
- logo-white.png (300x100) - الشعار الأبيض
- logo-dark.png (300x100) - الشعار الداكن
- favicon.ico (32x32) - أيقونة الموقع
- favicon-16x16.png
- favicon-32x32.png
- apple-touch-icon.png (180x180)

### أيقونات التطبيق (PWA)
icons/
├── icon-72x72.png
├── icon-96x96.png
├── icon-128x128.png
├── icon-144x144.png
├── icon-152x152.png
├── icon-192x192.png
├── icon-384x384.png
└── icon-512x512.png

### صور الواجهة الرئيسية
- hero-bg.jpg (1920x1080) - خلفية القسم الرئيسي
- hero-illustration.svg - رسم توضيحي للصفحة الرئيسية
- about-us.jpg (800x600) - صورة قسم من نحن
- why-choose-us.jpg (800x600) - لماذا تختارنا

### أيقونات الخدمات والميزات
features/
├── online-learning.svg
├── certified-courses.svg
├── expert-instructors.svg
├── flexible-schedule.svg
├── interactive-content.svg
├── community-support.svg
├── career-guidance.svg
└── lifetime-access.svg

### صور الفئات
categories/
├── programming.jpg (400x300)
├── web-development.jpg (400x300)
├── mobile-development.jpg (400x300)
├── data-science.jpg (400x300)
├── artificial-intelligence.jpg (400x300)
├── cybersecurity.jpg (400x300)
├── digital-marketing.jpg (400x300)
├── graphic-design.jpg (400x300)
├── business.jpg (400x300)
└── languages.jpg (400x300)

### صور الدورات (أمثلة)
courses/
├── course-placeholder.jpg (600x400)
├── javascript-course.jpg (600x400)
├── python-course.jpg (600x400)
├── react-course.jpg (600x400)
├── nodejs-course.jpg (600x400)
├── php-course.jpg (600x400)
├── laravel-course.jpg (600x400)
├── vue-course.jpg (600x400)
├── angular-course.jpg (600x400)
├── flutter-course.jpg (600x400)
└── docker-course.jpg (600x400)

### صور المدربين (أمثلة)
instructors/
├── instructor-placeholder.jpg (300x300)
├── ahmed-ali.jpg (300x300)
├── sara-mohamed.jpg (300x300)
├── omar-hassan.jpg (300x300)
├── fatima-ahmed.jpg (300x300)
└── youssef-mahmoud.jpg (300x300)

### أيقونات التحكم والواجهة
ui/
├── play-button.svg
├── pause-button.svg
├── next-button.svg
├── previous-button.svg
├── fullscreen.svg
├── settings.svg
├── download.svg
├── share.svg
├── bookmark.svg
├── like.svg
├── comment.svg
├── star.svg
├── check.svg
├── close.svg
├── menu.svg
├── search.svg
├── filter.svg
├── sort.svg
├── grid-view.svg
├── list-view.svg
├── edit.svg
├── delete.svg
├── add.svg
├── upload.svg
├── calendar.svg
├── clock.svg
├── user.svg
├── users.svg
├── certificate.svg
├── trophy.svg
├── medal.svg
├── badge.svg
├── progress.svg
├── analytics.svg
├── notification.svg
├── email.svg
├── phone.svg
└── location.svg

### صور الحالات والرسائل
states/
├── empty-state.svg - حالة فارغة
├── no-results.svg - لا توجد نتائج
├── error-404.svg - خطأ 404
├── error-500.svg - خطأ خادم
├── maintenance.svg - صيانة
├── coming-soon.svg - قريباً
├── success.svg - نجاح
├── warning.svg - تحذير
├── info.svg - معلومات
└── loading.svg - تحميل

### صور الشهادات والإنجازات
certificates/
├── certificate-template.jpg (1200x800)
├── certificate-border.png
├── certificate-seal.png
└── watermark.png

### خلفيات ونماذج
backgrounds/
├── pattern-1.svg
├── pattern-2.svg
├── wave-bg.svg
├── gradient-bg.jpg
├── geometric-bg.svg
└── abstract-bg.jpg

### صور وسائل التواصل الاجتماعي
social/
├── facebook.svg
├── twitter.svg
├── instagram.svg
├── linkedin.svg
├── youtube.svg
├── telegram.svg
├── whatsapp.svg
├── snapchat.svg
└── tiktok.svg

### لقطات الشاشة للتطبيق
screenshots/
├── desktop-home.png (1280x720)
├── mobile-courses.png (390x844)
├── tablet-dashboard.png (768x1024)
├── desktop-course-page.png (1280x720)
├── mobile-video-player.png (390x844)
└── desktop-admin-panel.png (1280x720)

### أيقونات الاختصارات
shortcuts/
├── courses-icon.png (96x96)
├── dashboard-icon.png (96x96)
├── wishlist-icon.png (96x96)
└── certificates-icon.png (96x96)

### صور متنوعة
├── placeholder.jpg (800x600) - صورة بديلة
├── avatar-placeholder.png (150x150) - صورة بديلة للملف الشخصي
├── video-thumbnail.jpg (640x360) - صورة مصغرة للفيديو
├── payment-methods.png - طرق الدفع
├── security-badge.png - شارة الأمان
├── ssl-certificate.png - شهادة SSL
└── mobile-app-preview.png (300x600) - معاينة التطبيق

## مواصفات الصور:

### تنسيقات مدعومة:
- PNG: للشعارات والأيقونات مع خلفية شفافة
- JPG/JPEG: للصور الفوتوغرافية والخلفيات
- SVG: للأيقونات والرسوم التوضيحية
- WebP: للصور المحسنة (اختياري)

### أحجام الصور:
- الشعارات: 300x100px (نسبة 3:1)
- صور الدورات: 600x400px (نسبة 3:2)
- صور المدربين: 300x300px (مربعة)
- صور الفئات: 400x300px (نسبة 4:3)
- الأيقونات: 32x32px، 64x64px، 128x128px
- الخلفيات: 1920x1080px أو أكبر

### معايير الجودة:
- دقة: 72-150 DPI للويب
- ضغط: متوسط لتوازن الجودة والحجم
- حجم الملف: أقل من 500KB للصور العادية
- تنسيق الألوان: RGB للويب
- الوضوح: عالي الجودة بدون تشويش

## ملاحظات التطوير:

### تحسين الصور:
- استخدام lazy loading للصور
- توفير أحجام متعددة (responsive images)
- ضغط الصور قبل الرفع
- استخدام WebP كبديل حديث

### إمكانية الوصول:
- إضافة نص بديل (alt text) لجميع الصور
- استخدام أوصاف واضحة ومفيدة
- تجنب الاعتماد على الألوان فقط لنقل المعلومات

### SEO:
- أسماء ملفات وصفية
- أحجام مناسبة لسرعة التحميل
- استخدام البيانات الوصفية