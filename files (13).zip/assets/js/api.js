/**
 * دوال API منفصلة
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 10:26:36
 */

'use strict';

const APIManager = {
    // إعدادات API
    config: {
        baseUrl: '/api.php',
        timeout: 30000,
        retryAttempts: 3,
        retryDelay: 1000,
        enableCache: true,
        cacheTimeout: 5 * 60 * 1000 // 5 دقائق
    },
    
    // cache للاستجابات
    cache: new Map(),
    
    // طلبات معلقة
    pendingRequests: new Map(),
    
    // مدير الأحداث
    events: {},
    
    // تهيئة مدير API
    init() {
        this.setupInterceptors();
        this.setupErrorHandling();
        this.initializeCache();
    },
    
    // إعداد المعترضات
    setupInterceptors() {
        // معترض الطلبات
        this.requestInterceptor = this.createRequestInterceptor();
        
        // معترض الاستجابات
        this.responseInterceptor = this.createResponseInterceptor();
    },
    
    // إنشاء معترض الطلبات
    createRequestInterceptor() {
        return (config) => {
            // إضافة CSRF token
            if (!config.data.csrf_token) {
                const csrfToken = this.getCSRFToken();
                if (csrfToken) {
                    config.data.csrf_token = csrfToken;
                }
            }
            
            // إضافة timestamp
            config.data._timestamp = Date.now();
            
            // إشعال حدث قبل الطلب
            this.emit('request:start', config);
            
            return config;
        };
    },
    
    // إنشاء معترض الاستجابات
    createResponseInterceptor() {
        return (response, error) => {
            if (error) {
                // معالجة الأخطاء
                this.emit('request:error', error);
                
                // إعادة المحاولة للأخطاء المؤقتة
                if (this.isRetryableError(error) && error.retryCount < this.config.retryAttempts) {
                    return this.retryRequest(error.config);
                }
                
                throw error;
            }
            
            // معالجة الاستجابة الناجحة
            this.emit('request:success', response);
            
            return response;
        };
    },
    
    // الطلب الأساسي
    async request(action, data = {}, options = {}) {
        const config = {
            action,
            data,
            options: {
                ...this.config,
                ...options
            }
        };
        
        // تطبيق معترض الطلب
        const processedConfig = this.requestInterceptor(config);
        
        // فحص Cache
        if (this.config.enableCache && options.cache !== false) {
            const cached = this.getCachedResponse(action, data);
            if (cached) {
                return cached;
            }
        }
        
        // فحص الطلبات المعلقة
        const requestKey = this.getRequestKey(action, data);
        if (this.pendingRequests.has(requestKey)) {
            return this.pendingRequests.get(requestKey);
        }
        
        // إنشاء الطلب
        const requestPromise = this.executeRequest(processedConfig);
        
        // حفظ الطلب المعلق
        this.pendingRequests.set(requestKey, requestPromise);
        
        try {
            const response = await requestPromise;
            
            // تطبيق معترض الاستجابة
            const processedResponse = this.responseInterceptor(response);
            
            // حفظ في Cache
            if (this.config.enableCache && options.cache !== false) {
                this.setCachedResponse(action, data, processedResponse);
            }
            
            return processedResponse;
        } catch (error) {
            // تطبيق معترض الخطأ
            return this.responseInterceptor(null, error);
        } finally {
            // إزالة الطلب المعلق
            this.pendingRequests.delete(requestKey);
        }
    },
    
    // تنفيذ الطلب
    async executeRequest(config) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), config.options.timeout);
        
        try {
            const formData = new FormData();
            formData.append('action', config.action);
            
            // إضافة البيانات
            Object.keys(config.data).forEach(key => {
                const value = config.data[key];
                
                if (value instanceof File || value instanceof Blob) {
                    formData.append(key, value);
                } else if (typeof value === 'object') {
                    formData.append(key, JSON.stringify(value));
                } else {
                    formData.append(key, value);
                }
            });
            
            const response = await fetch(this.config.baseUrl, {
                method: 'POST',
                body: formData,
                signal: controller.signal,
                credentials: 'same-origin',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });
            
            clearTimeout(timeoutId);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const result = await response.json();
            
            // التحقق من وجود خطأ في الاستجابة
            if (!result.success && result.error) {
                const error = new Error(result.error.message || 'حدث خطأ غير متوقع');
                error.code = result.error.code;
                error.status = result.error.status || 400;
                error.details = result.error.details;
                throw error;
            }
            
            return result;
            
        } catch (error) {
            clearTimeout(timeoutId);
            
            if (error.name === 'AbortError') {
                const timeoutError = new Error('انتهت مهلة الطلب');
                timeoutError.code = 'TIMEOUT';
                throw timeoutError;
            }
            
            // إضافة معلومات للخطأ
            error.config = config;
            error.retryCount = (error.retryCount || 0);
            
            throw error;
        }
    },
    
    // GET طلب
    async get(action, params = {}, options = {}) {
        return this.request(action, params, { ...options, method: 'GET' });
    },
    
    // POST طلب
    async post(action, data = {}, options = {}) {
        return this.request(action, data, { ...options, method: 'POST' });
    },
    
    // PUT طلب
    async put(action, data = {}, options = {}) {
        return this.request(action, data, { ...options, method: 'PUT' });
    },
    
    // DELETE طلب
    async delete(action, data = {}, options = {}) {
        return this.request(action, data, { ...options, method: 'DELETE' });
    },
    
    // رفع ملف
    async upload(action, file, data = {}, options = {}) {
        const uploadData = {
            ...data,
            file: file
        };
        
        const config = {
            ...options,
            onUploadProgress: options.onProgress,
            timeout: options.timeout || 5 * 60 * 1000 // 5 دقائق للرفع
        };
        
        return this.request(action, uploadData, config);
    },
    
    // طلب مع تتبع التقدم
    async requestWithProgress(action, data = {}, options = {}) {
        const config = { ...options };
        
        if (options.onProgress) {
            config.onUploadProgress = (progressEvent) => {
                const percentCompleted = Math.round(
                    (progressEvent.loaded * 100) / progressEvent.total
                );
                options.onProgress(percentCompleted);
            };
        }
        
        return this.request(action, data, config);
    },
    
    // طلبات متوازية
    async all(requests) {
        const promises = requests.map(req => {
            if (Array.isArray(req)) {
                return this.request(...req);
            } else {
                return this.request(req.action, req.data, req.options);
            }
        });
        
        try {
            const results = await Promise.all(promises);
            return results;
        } catch (error) {
            // في حالة فشل أي طلب، إلغاء الباقي
            throw error;
        }
    },
    
    // إعادة المحاولة
    async retryRequest(config) {
        return new Promise((resolve, reject) => {
            setTimeout(async () => {
                try {
                    config.retryCount = (config.retryCount || 0) + 1;
                    const response = await this.executeRequest(config);
                    resolve(response);
                } catch (error) {
                    reject(error);
                }
            }, this.config.retryDelay * Math.pow(2, config.retryCount || 0)); // Exponential backoff
        });
    },
    
    // فحص إمكانية إعادة المحاولة
    isRetryableError(error) {
        const retryableCodes = ['TIMEOUT', 'NETWORK_ERROR', 'INTERNAL_SERVER_ERROR'];
        const retryableStatuses = [0, 408, 429, 500, 502, 503, 504];
        
        return retryableCodes.includes(error.code) || 
               retryableStatuses.includes(error.status);
    },
    
    // إدارة Cache
    getCachedResponse(action, data) {
        if (!this.config.enableCache) return null;
        
        const key = this.getCacheKey(action, data);
        const cached = this.cache.get(key);
        
        if (cached && Date.now() - cached.timestamp < this.config.cacheTimeout) {
            return cached.data;
        }
        
        // إزالة البيانات منتهية الصلاحية
        if (cached) {
            this.cache.delete(key);
        }
        
        return null;
    },
    
    setCachedResponse(action, data, response) {
        if (!this.config.enableCache) return;
        
        const key = this.getCacheKey(action, data);
        this.cache.set(key, {
            data: response,
            timestamp: Date.now()
        });
    },
    
    getCacheKey(action, data) {
        const sortedData = this.sortObjectKeys(data);
        return `${action}_${JSON.stringify(sortedData)}`;
    },
    
    getRequestKey(action, data) {
        return this.getCacheKey(action, data);
    },
    
    // مسح Cache
    clearCache(pattern = null) {
        if (pattern) {
            for (let key of this.cache.keys()) {
                if (key.includes(pattern)) {
                    this.cache.delete(key);
                }
            }
        } else {
            this.cache.clear();
        }
    },
    
    // تهيئة Cache
    initializeCache() {
        // تنظيف Cache دوري
        setInterval(() => {
            const now = Date.now();
            for (let [key, value] of this.cache.entries()) {
                if (now - value.timestamp > this.config.cacheTimeout) {
                    this.cache.delete(key);
                }
            }
        }, this.config.cacheTimeout);
    },
    
    // إعداد معالجة الأخطاء
    setupErrorHandling() {
        // معالج الأخطاء العام
        this.on('request:error', (error) => {
            console.error('API Error:', error);
            
            // تسجيل الأخطاء المهمة
            if (error.status >= 500) {
                this.logError(error);
            }
            
            // إشعار المستخدم للأخطاء الحرجة
            if (error.code === 'AUTH_REQUIRED') {
                this.handleAuthRequired();
            } else if (error.status >= 500) {
                this.showErrorNotification('حدث خطأ في الخادم. يرجى المحاولة لاحقاً.');
            }
        });
    },
    
    // معالجة المصادقة المطلوبة
    handleAuthRequired() {
        // إعادة توجيه لصفحة تسجيل الدخول
        const currentUrl = encodeURIComponent(window.location.href);
        window.location.href = `/login.php?redirect=${currentUrl}`;
    },
    
    // عرض إشعار خطأ
    showErrorNotification(message) {
        // استخدام نظام الإشعارات العام
        if (window.showNotification) {
            window.showNotification(message, 'error');
        } else {
            alert(message);
        }
    },
    
    // تسجيل الخطأ
    logError(error) {
        const errorData = {
            message: error.message,
            code: error.code,
            status: error.status,
            url: window.location.href,
            userAgent: navigator.userAgent,
            timestamp: new Date().toISOString()
        };
        
        // إرسال لنظام تسجيل الأخطاء
        this.post('log_error', errorData, { cache: false }).catch(() => {
            // تجاهل أخطاء تسجيل الأخطاء
        });
    },
    
    // الحصول على CSRF token
    getCSRFToken() {
        return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') ||
               document.querySelector('input[name="csrf_token"]')?.value;
    },
    
    // ترتيب مفاتيح الكائن
    sortObjectKeys(obj) {
        if (typeof obj !== 'object' || obj === null) return obj;
        
        const sorted = {};
        Object.keys(obj).sort().forEach(key => {
            sorted[key] = obj[key];
        });
        
        return sorted;
    },
    
    // مدير الأحداث
    on(event, callback) {
        if (!this.events[event]) {
            this.events[event] = [];
        }
        this.events[event].push(callback);
    },
    
    off(event, callback) {
        if (this.events[event]) {
            this.events[event] = this.events[event].filter(cb => cb !== callback);
        }
    },
    
    emit(event, data) {
        if (this.events[event]) {
            this.events[event].forEach(callback => {
                try {
                    callback(data);
                } catch (error) {
                    console.error('Event callback error:', error);
                }
            });
        }
    },
    
    // إلغاء جميع الطلبات المعلقة
    cancelAllRequests() {
        this.pendingRequests.clear();
    },
    
    // إحصائيات API
    getStats() {
        return {
            cacheSize: this.cache.size,
            pendingRequests: this.pendingRequests.size,
            cacheHitRate: this.calculateCacheHitRate()
        };
    },
    
    calculateCacheHitRate() {
        // حساب معدل نجاح Cache (مبسط)
        const hits = parseInt(localStorage.getItem('api_cache_hits') || '0');
        const misses = parseInt(localStorage.getItem('api_cache_misses') || '0');
        const total = hits + misses;
        
        return total > 0 ? (hits / total * 100).toFixed(2) + '%' : '0%';
    }
};

// واجهات API محددة
const AuthAPI = {
    async login(credentials) {
        return APIManager.post('login', credentials);
    },
    
    async register(userData) {
        return APIManager.post('register', userData);
    },
    
    async logout() {
        return APIManager.post('logout');
    },
    
    async forgotPassword(email) {
        return APIManager.post('forgot_password', { email });
    },
    
    async resetPassword(token, password) {
        return APIManager.post('reset_password', { token, password });
    },
    
    async verifyOTP(otp) {
        return APIManager.post('verify_otp', { otp });
    },
    
    async resendOTP() {
        return APIManager.post('resend_otp');
    },
    
    async getCurrentUser() {
        return APIManager.get('get_current_user');
    }
};

const CourseAPI = {
    async getAllCourses(filters = {}) {
        return APIManager.get('get_courses', filters);
    },
    
    async getCourse(id) {
        return APIManager.get('get_course', { id });
    },
    
    async enrollCourse(courseId) {
        return APIManager.post('subscribe_course', { course_id: courseId });
    },
    
    async getCourseProgress(courseId) {
        return APIManager.get('get_course_progress', { course_id: courseId });
    },
    
    async addReview(courseId, rating, comment) {
        return APIManager.post('add_review', {
            course_id: courseId,
            rating,
            comment
        });
    },
    
    async searchCourses(query, filters = {}) {
        return APIManager.get('search_courses', { query, ...filters });
    }
};

const LessonAPI = {
    async getLesson(id) {
        return APIManager.get('get_lesson', { id });
    },
    
    async updateProgress(lessonId, progress) {
        return APIManager.post('update_progress', {
            lesson_id: lessonId,
            progress
        });
    },
    
    async addNote(lessonId, content, timestamp) {
        return APIManager.post('add_note', {
            lesson_id: lessonId,
            content,
            timestamp
        });
    },
    
    async getNotes(lessonId) {
        return APIManager.get('get_notes', { lesson_id: lessonId });
    },
    
    async updateNote(noteId, content) {
        return APIManager.post('update_note', {
            note_id: noteId,
            content
        });
    },
    
    async deleteNote(noteId) {
        return APIManager.delete('delete_note', { note_id: noteId });
    }
};

const UserAPI = {
    async updateProfile(data) {
        return APIManager.post('update_profile', data);
    },
    
    async changePassword(currentPassword, newPassword) {
        return APIManager.post('change_password', {
            current_password: currentPassword,
            new_password: newPassword
        });
    },
    
    async uploadAvatar(file) {
        return APIManager.upload('upload_avatar', file);
    },
    
    async getUserCourses() {
        return APIManager.get('get_user_courses');
    },
    
    async getUserStats() {
        return APIManager.get('get_user_stats');
    },
    
    async getWishlist() {
        return APIManager.get('get_wishlist');
    },
    
    async toggleWishlist(courseId) {
        return APIManager.post('toggle_wishlist', { course_id: courseId });
    }
};

const AdminAPI = {
    async getDashboardStats() {
        return APIManager.get('get_dashboard_stats');
    },
    
    async getUsers(filters = {}) {
        return APIManager.get('get_users', filters);
    },
    
    async updateUserStatus(userId, status) {
        return APIManager.post('update_user_status', {
            user_id: userId,
            status
        });
    },
    
    async createCourse(courseData) {
        return APIManager.post('create_course', courseData);
    },
    
    async updateCourse(courseId, courseData) {
        return APIManager.post('update_course', {
            course_id: courseId,
            ...courseData
        });
    },
    
    async deleteCourse(courseId) {
        return APIManager.delete('delete_course', { course_id: courseId });
    }
};

const NotificationAPI = {
    async getNotifications(limit = 10) {
        return APIManager.get('get_notifications', { limit });
    },
    
    async markAsRead(notificationId) {
        return APIManager.post('mark_notification_read', {
            notification_id: notificationId
        });
    },
    
    async markAllAsRead() {
        return APIManager.post('mark_all_read');
    },
    
    async deleteNotification(notificationId) {
        return APIManager.delete('delete_notification', {
            notification_id: notificationId
        });
    }
};

const FileAPI = {
    async uploadFile(file, options = {}) {
        return APIManager.upload('upload_file', file, options);
    },
    
    async deleteFile(fileId) {
        return APIManager.delete('delete_file', { file_id: fileId });
    },
    
    async getFileInfo(fileId) {
        return APIManager.get('get_file_info', { file_id: fileId });
    }
};

// تهيئة مدير API
document.addEventListener('DOMContentLoaded', () => {
    APIManager.init();
});

// تصدير للاستخدام العام
window.APIManager = APIManager;
window.AuthAPI = AuthAPI;
window.CourseAPI = CourseAPI;
window.LessonAPI = LessonAPI;
window.UserAPI = UserAPI;
window.AdminAPI = AdminAPI;
window.NotificationAPI = NotificationAPI;
window.FileAPI = FileAPI;