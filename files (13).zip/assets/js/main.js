/**
 * السكريبت الرئيسي للمنصة
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 10:21:31
 */

'use strict';

// إعدادات عامة
const TrendAcademy = {
    // إعدادات API
    api: {
        baseUrl: '/api.php',
        timeout: 30000,
        retryAttempts: 3
    },
    
    // إعدادات UI
    ui: {
        animationDuration: 300,
        toastDuration: 5000,
        loadingDelay: 100
    },
    
    // cache للبيانات
    cache: new Map(),
    
    // معرف المستخدم الحالي
    currentUser: null,
    
    // حالة التطبيق
    state: {
        isLoading: false,
        theme: localStorage.getItem('theme') || 'light',
        language: localStorage.getItem('language') || 'ar'
    }
};

/**
 * تهيئة التطبيق
 */
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

/**
 * تهيئة التطبيق الرئيسية
 */
function initializeApp() {
    try {
        // تهيئة المكونات الأساسية
        initializeTheme();
        initializeNavigation();
        initializeForms();
        initializeModals();
        initializeTooltips();
        initializeScrollEffects();
        initializeLazyLoading();
        initializeServiceWorker();
        
        // تحميل بيانات المستخدم إذا كان مسجل دخول
        loadCurrentUser();
        
        // تهيئة مكونات الصفحة الحالية
        initializePageSpecific();
        
        console.log('TrendAcademy: Application initialized successfully');
    } catch (error) {
        console.error('TrendAcademy: Initialization failed:', error);
        showNotification('حدث خطأ في تحميل التطبيق', 'error');
    }
}

/**
 * تهيئة النظام اللوني
 */
function initializeTheme() {
    const theme = TrendAcademy.state.theme;
    document.documentElement.setAttribute('data-theme', theme);
    
    // تحديث زر تبديل المظهر
    const themeToggle = document.querySelector('.theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
        updateThemeToggleIcon(theme);
    }
}

/**
 * تبديل المظهر
 */
function toggleTheme() {
    const currentTheme = TrendAcademy.state.theme;
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    
    TrendAcademy.state.theme = newTheme;
    localStorage.setItem('theme', newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
    
    updateThemeToggleIcon(newTheme);
    showNotification(`تم التبديل إلى المظهر ${newTheme === 'light' ? 'الفاتح' : 'المظلم'}`, 'success');
}

/**
 * تحديث أيقونة تبديل المظهر
 */
function updateThemeToggleIcon(theme) {
    const icon = document.querySelector('.theme-toggle i');
    if (icon) {
        icon.className = theme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
    }
}

/**
 * تهيئة التنقل
 */
function initializeNavigation() {
    // تفعيل الرابط النشط
    setActiveNavLink();
    
    // تهيئة القائمة المنسدلة للموبايل
    initializeMobileNav();
    
    // تهيئة البحث
    initializeSearch();
    
    // تهيئة الإشعارات
    initializeNotifications();
}

/**
 * تعيين الرابط النشط في التنقل
 */
function setActiveNavLink() {
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href && currentPath.includes(href)) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
}

/**
 * تهيئة التنقل للموبايل
 */
function initializeMobileNav() {
    const navToggle = document.querySelector('.navbar-toggler');
    const navMenu = document.querySelector('.navbar-collapse');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.classList.toggle('show');
            navToggle.classList.toggle('active');
        });
        
        // إغلاق القائمة عند النقر خارجها
        document.addEventListener('click', function(e) {
            if (!navToggle.contains(e.target) && !navMenu.contains(e.target)) {
                navMenu.classList.remove('show');
                navToggle.classList.remove('active');
            }
        });
    }
}

/**
 * تهيئة البحث
 */
function initializeSearch() {
    const searchForm = document.querySelector('.search-form');
    const searchInput = document.querySelector('.search-input');
    const searchResults = document.querySelector('.search-results');
    
    if (searchInput) {
        let searchTimeout;
        
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            const query = this.value.trim();
            
            if (query.length >= 2) {
                searchTimeout = setTimeout(() => {
                    performSearch(query);
                }, 300);
            } else {
                hideSearchResults();
            }
        });
        
        // إخفاء النتائج عند النقر خارجها
        document.addEventListener('click', function(e) {
            if (!searchInput.contains(e.target) && !searchResults?.contains(e.target)) {
                hideSearchResults();
            }
        });
    }
    
    if (searchForm) {
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const query = searchInput.value.trim();
            if (query) {
                window.location.href = `/courses.php?search=${encodeURIComponent(query)}`;
            }
        });
    }
}

/**
 * تنفيذ البحث
 */
async function performSearch(query) {
    try {
        showSearchLoading();
        
        const response = await apiCall('search_courses', {
            query: query,
            limit: 5
        });
        
        if (response.success) {
            displaySearchResults(response.data);
        } else {
            hideSearchResults();
        }
    } catch (error) {
        console.error('Search error:', error);
        hideSearchResults();
    }
}

/**
 * عرض نتائج البحث
 */
function displaySearchResults(results) {
    const searchResults = document.querySelector('.search-results');
    if (!searchResults) return;
    
    if (results.length === 0) {
        searchResults.innerHTML = '<div class="search-empty">لا توجد نتائج</div>';
    } else {
        searchResults.innerHTML = results.map(course => `
            <a href="/course.php?id=${course.id}" class="search-result-item">
                <img src="${course.image || '/assets/images/default-course.jpg'}" alt="${course.name}">
                <div class="search-result-content">
                    <h6>${course.name}</h6>
                    <p>${course.instructor_name}</p>
                    <span class="price">${course.price > 0 ? course.price + ' ريال' : 'مجاني'}</span>
                </div>
            </a>
        `).join('');
    }
    
    searchResults.classList.add('show');
}

/**
 * إخفاء نتائج البحث
 */
function hideSearchResults() {
    const searchResults = document.querySelector('.search-results');
    if (searchResults) {
        searchResults.classList.remove('show');
    }
}

/**
 * عرض تحميل البحث
 */
function showSearchLoading() {
    const searchResults = document.querySelector('.search-results');
    if (searchResults) {
        searchResults.innerHTML = '<div class="search-loading">جاري البحث...</div>';
        searchResults.classList.add('show');
    }
}

/**
 * تهيئة الإشعارات
 */
function initializeNotifications() {
    const notificationBtn = document.querySelector('.notifications-btn');
    const notificationDropdown = document.querySelector('.notifications-dropdown');
    
    if (notificationBtn && notificationDropdown) {
        notificationBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            notificationDropdown.classList.toggle('show');
            
            if (notificationDropdown.classList.contains('show')) {
                loadNotifications();
            }
        });
        
        // إغلاق القائمة عند النقر خارجها
        document.addEventListener('click', function(e) {
            if (!notificationBtn.contains(e.target) && !notificationDropdown.contains(e.target)) {
                notificationDropdown.classList.remove('show');
            }
        });
    }
    
    // تحديث عدد الإشعارات
    updateNotificationCount();
}

/**
 * تحميل الإشعارات
 */
async function loadNotifications() {
    try {
        const response = await apiCall('get_notifications', { limit: 10 });
        
        if (response.success) {
            displayNotifications(response.data);
        }
    } catch (error) {
        console.error('Failed to load notifications:', error);
    }
}

/**
 * عرض الإشعارات
 */
function displayNotifications(notifications) {
    const container = document.querySelector('.notifications-list');
    if (!container) return;
    
    if (notifications.length === 0) {
        container.innerHTML = '<div class="notification-empty">لا توجد إشعارات جديدة</div>';
        return;
    }
    
    container.innerHTML = notifications.map(notification => `
        <div class="notification-item ${notification.is_read ? '' : 'unread'}" data-id="${notification.id}">
            <div class="notification-icon ${notification.type}">
                <i class="${getNotificationIcon(notification.type)}"></i>
            </div>
            <div class="notification-content">
                <h6>${notification.title}</h6>
                <p>${notification.message}</p>
                <span class="notification-time">${formatTime(notification.created_at)}</span>
            </div>
            ${!notification.is_read ? '<div class="notification-dot"></div>' : ''}
        </div>
    `).join('');
    
    // تفعيل النقر على الإشعارات
    container.querySelectorAll('.notification-item').forEach(item => {
        item.addEventListener('click', function() {
            markNotificationAsRead(this.dataset.id);
        });
    });
}

/**
 * الحصول على أيقونة الإشعار
 */
function getNotificationIcon(type) {
    const icons = {
        'course_enrolled': 'fas fa-graduation-cap',
        'lesson_completed': 'fas fa-check-circle',
        'course_completed': 'fas fa-trophy',
        'payment_received': 'fas fa-credit-card',
        'system': 'fas fa-cog'
    };
    
    return icons[type] || 'fas fa-bell';
}

/**
 * تحديث عدد الإشعارات
 */
async function updateNotificationCount() {
    try {
        const response = await apiCall('get_notifications', { 
            unread_only: true,
            count_only: true 
        });
        
        if (response.success) {
            const badge = document.querySelector('.notifications-badge');
            if (badge) {
                const count = response.data.count;
                if (count > 0) {
                    badge.textContent = count > 99 ? '99+' : count;
                    badge.style.display = 'block';
                } else {
                    badge.style.display = 'none';
                }
            }
        }
    } catch (error) {
        console.error('Failed to update notification count:', error);
    }
}

/**
 * تهيئة النماذج
 */
function initializeForms() {
    // تهيئة validation
    initializeFormValidation();
    
    // تهيئة أزرار إظهار/إخفاء كلمة المرور
    initializePasswordToggle();
    
    // تهيئة مؤشر قوة كلمة المرور
    initializePasswordStrength();
    
    // تهيئة رفع الملفات
    initializeFileUpload();
    
    // تهيئة Auto-save
    initializeAutoSave();
}

/**
 * تهيئة validation للنماذج
 */
function initializeFormValidation() {
    const forms = document.querySelectorAll('.needs-validation');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!form.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
                
                // التركيز على أول حقل خاطئ
                const firstInvalid = form.querySelector(':invalid');
                if (firstInvalid) {
                    firstInvalid.focus();
                }
            }
            
            form.classList.add('was-validated');
        });
        
        // Real-time validation
        const inputs = form.querySelectorAll('input, textarea, select');
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                validateField(this);
            });
            
            input.addEventListener('input', function() {
                if (this.classList.contains('is-invalid')) {
                    validateField(this);
                }
            });
        });
    });
}

/**
 * تنسيق حقل واحد
 */
function validateField(field) {
    const isValid = field.checkValidity();
    
    field.classList.remove('is-valid', 'is-invalid');
    field.classList.add(isValid ? 'is-valid' : 'is-invalid');
    
    // عرض رسالة الخطأ المخصصة
    const feedback = field.parentNode.querySelector('.invalid-feedback');
    if (feedback && !isValid) {
        feedback.textContent = field.validationMessage || 'قيمة غير صحيحة';
    }
    
    return isValid;
}

/**
 * تهيئة أزرار إظهار/إخفاء كلمة المرور
 */
function initializePasswordToggle() {
    const toggleBtns = document.querySelectorAll('.password-toggle');
    
    toggleBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const input = this.parentNode.querySelector('input');
            const icon = this.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.className = 'fas fa-eye-slash';
            } else {
                input.type = 'password';
                icon.className = 'fas fa-eye';
            }
        });
    });
}

/**
 * تهيئة مؤشر قوة كلمة المرور
 */
function initializePasswordStrength() {
    const passwordInputs = document.querySelectorAll('input[type="password"][data-strength]');
    
    passwordInputs.forEach(input => {
        const strengthMeter = input.parentNode.querySelector('.password-strength');
        
        if (strengthMeter) {
            input.addEventListener('input', function() {
                const strength = calculatePasswordStrength(this.value);
                updatePasswordStrengthMeter(strengthMeter, strength);
            });
        }
    });
}

/**
 * حساب قوة كلمة المرور
 */
function calculatePasswordStrength(password) {
    let score = 0;
    let feedback = [];
    
    if (password.length >= 8) score += 1;
    else feedback.push('8 أحرف على الأقل');
    
    if (/[a-z]/.test(password)) score += 1;
    else feedback.push('حرف صغير');
    
    if (/[A-Z]/.test(password)) score += 1;
    else feedback.push('حرف كبير');
    
    if (/[0-9]/.test(password)) score += 1;
    else feedback.push('رقم');
    
    if (/[^A-Za-z0-9]/.test(password)) score += 1;
    else feedback.push('رمز خاص');
    
    const levels = ['weak', 'fair', 'good', 'strong'];
    const level = score <= 1 ? 'weak' : score <= 2 ? 'fair' : score <= 3 ? 'good' : 'strong';
    
    return {
        score: score,
        level: level,
        feedback: feedback
    };
}

/**
 * تحديث مؤشر قوة كلمة المرور
 */
function updatePasswordStrengthMeter(meter, strength) {
    const fill = meter.querySelector('.strength-fill');
    const text = meter.querySelector('.strength-text');
    
    if (fill && text) {
        fill.className = `strength-fill ${strength.level}`;
        
        const messages = {
            weak: 'ضعيفة',
            fair: 'متوسطة', 
            good: 'جيدة',
            strong: 'قوية'
        };
        
        text.textContent = messages[strength.level];
        text.className = `strength-text ${strength.level}`;
    }
    
    meter.classList.toggle('show', strength.score > 0);
}

/**
 * تهيئة رفع الملفات
 */
function initializeFileUpload() {
    const fileInputs = document.querySelectorAll('input[type="file"]');
    
    fileInputs.forEach(input => {
        // إنشاء منطقة السحب والإفلات
        createDropZone(input);
        
        input.addEventListener('change', function() {
            handleFileSelection(this);
        });
    });
}

/**
 * إنشاء منطقة السحب والإفلات
 */
function createDropZone(input) {
    const dropZone = document.createElement('div');
    dropZone.className = 'file-drop-zone';
    dropZone.innerHTML = `
        <div class="drop-zone-content">
            <i class="fas fa-cloud-upload-alt"></i>
            <p>اسحب الملفات هنا أو انقر للاختيار</p>
            <small>الحد الأقصى: ${getMaxFileSize(input)}</small>
        </div>
    `;
    
    input.parentNode.insertBefore(dropZone, input);
    input.style.display = 'none';
    
    // أحداث السحب والإفلات
    dropZone.addEventListener('click', () => input.click());
    dropZone.addEventListener('dragover', handleDragOver);
    dropZone.addEventListener('dragleave', handleDragLeave);
    dropZone.addEventListener('drop', (e) => handleDrop(e, input));
}

/**
 * التعامل مع اختيار الملفات
 */
function handleFileSelection(input) {
    const files = Array.from(input.files);
    const preview = input.parentNode.querySelector('.file-preview') || createFilePreview(input);
    
    preview.innerHTML = '';
    
    files.forEach((file, index) => {
        const fileItem = createFilePreviewItem(file, index, input);
        preview.appendChild(fileItem);
    });
    
    preview.style.display = files.length > 0 ? 'block' : 'none';
}

/**
 * إنشاء معاينة الملف
 */
function createFilePreview(input) {
    const preview = document.createElement('div');
    preview.className = 'file-preview';
    input.parentNode.appendChild(preview);
    return preview;
}

/**
 * إنشاء عنصر معاينة الملف
 */
function createFilePreviewItem(file, index, input) {
    const item = document.createElement('div');
    item.className = 'file-preview-item';
    
    const icon = getFileIcon(file.type);
    const size = formatFileSize(file.size);
    
    item.innerHTML = `
        <div class="file-info">
            <i class="${icon}"></i>
            <div class="file-details">
                <span class="file-name">${file.name}</span>
                <span class="file-size">${size}</span>
            </div>
        </div>
        <button type="button" class="btn btn-sm btn-danger remove-file" data-index="${index}">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    // زر الحذف
    item.querySelector('.remove-file').addEventListener('click', function() {
        removeFileFromInput(input, index);
    });
    
    return item;
}

/**
 * الحصول على أيقونة الملف
 */
function getFileIcon(mimeType) {
    if (mimeType.startsWith('image/')) return 'fas fa-image';
    if (mimeType.startsWith('video/')) return 'fas fa-video';
    if (mimeType.startsWith('audio/')) return 'fas fa-music';
    if (mimeType.includes('pdf')) return 'fas fa-file-pdf';
    if (mimeType.includes('word')) return 'fas fa-file-word';
    if (mimeType.includes('excel')) return 'fas fa-file-excel';
    return 'fas fa-file';
}

/**
 * تنسيق حجم الملف
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * تهيئة الحفظ التلقائي
 */
function initializeAutoSave() {
    const autoSaveForms = document.querySelectorAll('[data-autosave]');
    
    autoSaveForms.forEach(form => {
        const key = form.dataset.autosave;
        let saveTimeout;
        
        // استرجاع البيانات المحفوظة
        restoreFormData(form, key);
        
        // حفظ البيانات عند التغيير
        form.addEventListener('input', function() {
            clearTimeout(saveTimeout);
            saveTimeout = setTimeout(() => {
                saveFormData(form, key);
            }, 1000);
        });
        
        // حذف البيانات المحفوظة عند الإرسال
        form.addEventListener('submit', function() {
            clearFormData(key);
        });
    });
}

/**
 * حفظ بيانات النموذج
 */
function saveFormData(form, key) {
    const formData = new FormData(form);
    const data = {};
    
    for (let [name, value] of formData.entries()) {
        data[name] = value;
    }
    
    localStorage.setItem(`autosave_${key}`, JSON.stringify(data));
    showNotification('تم حفظ البيانات تلقائياً', 'info', 2000);
}

/**
 * استرجاع بيانات النموذج
 */
function restoreFormData(form, key) {
    const savedData = localStorage.getItem(`autosave_${key}`);
    
    if (savedData) {
        try {
            const data = JSON.parse(savedData);
            
            Object.keys(data).forEach(name => {
                const field = form.querySelector(`[name="${name}"]`);
                if (field && field.type !== 'file') {
                    field.value = data[name];
                }
            });
            
            showNotification('تم استرجاع البيانات المحفوظة', 'info', 3000);
        } catch (error) {
            console.error('Failed to restore form data:', error);
        }
    }
}

/**
 * حذف بيانات النموذج المحفوظة
 */
function clearFormData(key) {
    localStorage.removeItem(`autosave_${key}`);
}

/**
 * تهيئة النماذج المنبثقة
 */
function initializeModals() {
    // تهيئة أزرار فتح النماذج
    const modalTriggers = document.querySelectorAll('[data-modal]');
    modalTriggers.forEach(trigger => {
        trigger.addEventListener('click', function(e) {
            e.preventDefault();
            const modalId = this.dataset.modal;
            openModal(modalId);
        });
    });
    
    // تهيئة أزرار إغلاق النماذج
    const closeButtons = document.querySelectorAll('.modal-close, [data-dismiss="modal"]');
    closeButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const modal = this.closest('.modal');
            if (modal) {
                closeModal(modal.id);
            }
        });
    });
    
    // إغلاق النموذج عند النقر على الخلفية
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal')) {
            closeModal(e.target.id);
        }
    });
    
    // إغلاق النموذج بـ ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const openModal = document.querySelector('.modal.show');
            if (openModal) {
                closeModal(openModal.id);
            }
        }
    });
}

/**
 * فتح نموذج منبثق
 */
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('show');
        modal.style.display = 'block';
        document.body.classList.add('modal-open');
        
        // التركيز على أول عنصر قابل للتفاعل
        const focusable = modal.querySelector('input, textarea, select, button');
        if (focusable) {
            setTimeout(() => focusable.focus(), 100);
        }
        
        // تشغيل حدث الفتح
        modal.dispatchEvent(new CustomEvent('modal:opened'));
    }
}

/**
 * إغلاق نموذج منبثق
 */
function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('show');
        setTimeout(() => {
            modal.style.display = 'none';
            document.body.classList.remove('modal-open');
        }, TrendAcademy.ui.animationDuration);
        
        // تشغيل حدث الإغلاق
        modal.dispatchEvent(new CustomEvent('modal:closed'));
    }
}

/**
 * تهيئة tooltips
 */
function initializeTooltips() {
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    
    tooltipElements.forEach(element => {
        element.addEventListener('mouseenter', showTooltip);
        element.addEventListener('mouseleave', hideTooltip);
    });
}

/**
 * عرض tooltip
 */
function showTooltip(e) {
    const element = e.target;
    const text = element.dataset.tooltip;
    const position = element.dataset.tooltipPosition || 'top';
    
    const tooltip = document.createElement('div');
    tooltip.className = `tooltip tooltip-${position}`;
    tooltip.textContent = text;
    tooltip.id = 'current-tooltip';
    
    document.body.appendChild(tooltip);
    
    // حساب الموضع
    const rect = element.getBoundingClientRect();
    const tooltipRect = tooltip.getBoundingClientRect();
    
    let top, left;
    
    switch (position) {
        case 'top':
            top = rect.top - tooltipRect.height - 8;
            left = rect.left + (rect.width / 2) - (tooltipRect.width / 2);
            break;
        case 'bottom':
            top = rect.bottom + 8;
            left = rect.left + (rect.width / 2) - (tooltipRect.width / 2);
            break;
        case 'left':
            top = rect.top + (rect.height / 2) - (tooltipRect.height / 2);
            left = rect.left - tooltipRect.width - 8;
            break;
        case 'right':
            top = rect.top + (rect.height / 2) - (tooltipRect.height / 2);
            left = rect.right + 8;
            break;
    }
    
    tooltip.style.top = `${top}px`;
    tooltip.style.left = `${left}px`;
    tooltip.classList.add('show');
}

/**
 * إخفاء tooltip
 */
function hideTooltip() {
    const tooltip = document.getElementById('current-tooltip');
    if (tooltip) {
        tooltip.remove();
    }
}

/**
 * تهيئة تأثيرات التمرير
 */
function initializeScrollEffects() {
    // تهيئة Intersection Observer للأنيميشنز
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);
    
    // مراقبة العناصر القابلة للأنيميشن
    const animatedElements = document.querySelectorAll('.animate-on-scroll');
    animatedElements.forEach(element => {
        observer.observe(element);
    });
    
    // تهيئة زر العودة للأعلى
    initializeBackToTop();
}

/**
 * تهيئة زر العودة للأعلى
 */
function initializeBackToTop() {
    const backToTopBtn = document.querySelector('.back-to-top');
    
    if (backToTopBtn) {
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                backToTopBtn.classList.add('show');
            } else {
                backToTopBtn.classList.remove('show');
            }
        });
        
        backToTopBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
}

/**
 * تهيئة التحميل الكسول للصور
 */
function initializeLazyLoading() {
    const lazyImages = document.querySelectorAll('img[data-src]');
    
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.classList.remove('lazy');
                    imageObserver.unobserve(img);
                }
            });
        });
        
        lazyImages.forEach(img => {
            imageObserver.observe(img);
        });
    } else {
        // Fallback للمتصفحات القديمة
        lazyImages.forEach(img => {
            img.src = img.dataset.src;
            img.classList.remove('lazy');
        });
    }
}

/**
 * استدعاء API
 */
async function apiCall(action, data = {}, options = {}) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), options.timeout || TrendAcademy.api.timeout);
    
    try {
        // إضافة CSRF token
        if (!data.csrf_token) {
            const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');
            if (csrfToken) {
                data.csrf_token = csrfToken;
            }
        }
        
        const formData = new FormData();
        formData.append('action', action);
        
        Object.keys(data).forEach(key => {
            if (data[key] instanceof File) {
                formData.append(key, data[key]);
            } else if (typeof data[key] === 'object') {
                formData.append(key, JSON.stringify(data[key]));
            } else {
                formData.append(key, data[key]);
            }
        });
        
        const response = await fetch(TrendAcademy.api.baseUrl, {
            method: 'POST',
            body: formData,
            signal: controller.signal,
            credentials: 'same-origin'
        });
        
        clearTimeout(timeoutId);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        
        // التعامل مع أخطاء API
        if (!result.success && result.error) {
            if (result.error.code === 'AUTH_REQUIRED') {
                // إعادة توجيه لصفحة تسجيل الدخول
                window.location.href = '/login.php';
                return;
            }
            
            throw new Error(result.error.message || 'حدث خطأ غير متوقع');
        }
        
        return result;
        
    } catch (error) {
        clearTimeout(timeoutId);
        
        if (error.name === 'AbortError') {
            throw new Error('انتهت مهلة الطلب');
        }
        
        throw error;
    }
}

/**
 * عرض إشعار
 */
function showNotification(message, type = 'info', duration = TrendAcademy.ui.toastDuration) {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="${getNotificationTypeIcon(type)}"></i>
            <span>${message}</span>
        </div>
        <button class="notification-close">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    // إضافة للحاوي
    let container = document.querySelector('.notifications-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'notifications-container';
        document.body.appendChild(container);
    }
    
    container.appendChild(notification);
    
    // إظهار الإشعار
    setTimeout(() => notification.classList.add('show'), 10);
    
    // إخفاء الإشعار تلقائياً
    const hideTimeout = setTimeout(() => {
        hideNotification(notification);
    }, duration);
    
    // زر الإغلاق
    notification.querySelector('.notification-close').addEventListener('click', () => {
        clearTimeout(hideTimeout);
        hideNotification(notification);
    });
}

/**
 * إخفاء إشعار
 */
function hideNotification(notification) {
    notification.classList.remove('show');
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, TrendAcademy.ui.animationDuration);
}

/**
 * الحصول على أيقونة نوع الإشعار
 */
function getNotificationTypeIcon(type) {
    const icons = {
        success: 'fas fa-check-circle',
        error: 'fas fa-exclamation-circle',
        warning: 'fas fa-exclamation-triangle',
        info: 'fas fa-info-circle'
    };
    
    return icons[type] || icons.info;
}

/**
 * تحميل بيانات المستخدم الحالي
 */
async function loadCurrentUser() {
    try {
        const response = await apiCall('get_current_user');
        
        if (response.success) {
            TrendAcademy.currentUser = response.data;
            updateUIForUser(response.data);
        }
    } catch (error) {
        // المستخدم غير مسجل دخول
        TrendAcademy.currentUser = null;
    }
}

/**
 * تحديث واجهة المستخدم بناءً على بيانات المستخدم
 */
function updateUIForUser(user) {
    // تحديث الاسم والصورة
    const userNameElements = document.querySelectorAll('.user-name');
    userNameElements.forEach(element => {
        element.textContent = `${user.first_name} ${user.last_name}`;
    });
    
    const userAvatarElements = document.querySelectorAll('.user-avatar');
    userAvatarElements.forEach(element => {
        element.src = user.avatar || '/assets/images/default-avatar.png';
    });
    
    // إظهار/إخفاء عناصر بناءً على حالة تسجيل الدخول
    const authElements = document.querySelectorAll('.auth-only');
    authElements.forEach(element => {
        element.style.display = 'block';
    });
    
    const guestElements = document.querySelectorAll('.guest-only');
    guestElements.forEach(element => {
        element.style.display = 'none';
    });
}

/**
 * تنسيق الوقت
 */
function formatTime(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (minutes < 1) return 'الآن';
    if (minutes < 60) return `منذ ${minutes} دقيقة`;
    if (hours < 24) return `منذ ${hours} ساعة`;
    if (days < 7) return `منذ ${days} يوم`;
    
    return date.toLocaleDateString('ar-SA');
}

/**
 * تهيئة Service Worker
 */
function initializeServiceWorker() {
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', function() {
            navigator.serviceWorker.register('/sw.js')
                .then(function(registration) {
                    console.log('ServiceWorker registration successful');
                })
                .catch(function(err) {
                    console.log('ServiceWorker registration failed: ', err);
                });
        });
    }
}

/**
 * تهيئة مكونات خاصة بالصفحة
 */
function initializePageSpecific() {
    const page = document.body.dataset.page;
    
    switch (page) {
        case 'home':
            initializeHomePage();
            break;
        case 'courses':
            initializeCoursesPage();
            break;
        case 'course':
            initializeCoursePage();
            break;
        case 'player':
            initializePlayerPage();
            break;
        case 'dashboard':
            initializeDashboardPage();
            break;
    }
}

/**
 * تهيئة الصفحة الرئيسية
 */
function initializeHomePage() {
    // تهيئة عداد الإحصائيات
    initializeCounters();
    
    // تهيئة النشرة البريدية
    initializeNewsletter();
}

/**
 * تهيئة صفحة الدورات
 */
function initializeCoursesPage() {
    // تهيئة الفلاتر
    initializeCourseFilters();
    
    // تهيئة الترتيب
    initializeCourseSorting();
    
    // تهيئة التحميل بالتمرير
    initializeInfiniteScroll();
}

/**
 * تهيئة صفحة الدورة
 */
function initializeCoursePage() {
    // تهيئة التبويبات
    initializeCourseTabs();
    
    // تهيئة التقييمات
    initializeCourseReviews();
    
    // تهيئة منهج الدورة
    initializeCourseCurriculum();
}

/**
 * تهيئة مشغل الفيديو
 */
function initializePlayerPage() {
    // سيتم تحميل ملف player.js منفصل
    if (typeof initializeVideoPlayer === 'function') {
        initializeVideoPlayer();
    }
}

/**
 * تهيئة لوحة