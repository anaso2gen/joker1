/**
 * مشغل الفيديو المحمي مع VdoCipher
 * يتضمن حماية شاملة ضد التسجيل والنسخ
 */

class SecureVideoPlayer {
    constructor() {
        this.playerData = window.playerData;
        this.player = null;
        this.securityEnabled = true;
        this.violationCount = 0;
        this.maxViolations = 3;
        this.watchStartTime = null;
        this.lastProgressUpdate = 0;
        this.progressUpdateInterval = 10; // ثواني
        
        this.init();
    }
    
    /**
     * تهيئة المشغل
     */
    async init() {
        try {
            // فحص أمان المتصفح
            const securityCheck = await this.checkBrowserSecurity();
            if (!securityCheck.allowed) {
                this.showBrowserWarning(securityCheck.warnings);
                return;
            }
            
            // تفعيل الحماية الأمنية
            this.enableSecurityFeatures();
            
            // تحميل قائمة الدروس
            await this.loadLessonsList();
            
            // تهيئة المشغل
            await this.initializePlayer();
            
            // ربط الأحداث
            this.bindEvents();
            
            // تحميل الملاحظات
            this.loadNotes();
            
        } catch (error) {
            console.error('Player initialization error:', error);
            this.showError('خطأ في تهيئة المشغل');
        }
    }
    
    /**
     * فحص أمان المتصفح
     */
    async checkBrowserSecurity() {
        try {
            const response = await fetchAPI('/api/security/check');
            return response.data || { allowed: false, warnings: ['فشل فحص الأمان'] };
        } catch (error) {
            console.error('Security check failed:', error);
            return { allowed: false, warnings: ['فشل فحص الأمان'] };
        }
    }
    
    /**
     * عرض تحذير المتصفح
     */
    showBrowserWarning(warnings) {
        const modal = new bootstrap.Modal(document.getElementById('browserWarningModal'));
        modal.show();
        
        // تسجيل الانتهاك
        this.reportSecurityViolation('unsupported_browser', warnings.join(', '));
    }
    
    /**
     * تفعيل ميزات الحماية
     */
    enableSecurityFeatures() {
        if (!this.securityEnabled) return;
        
        // منع النقر الأيمن
        document.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            this.reportSecurityViolation('right_click', 'محاولة استخدام النقر الأيمن');
        });
        
        // منع اختصارات لوحة المفاتيح الخطيرة
        document.addEventListener('keydown', (e) => {
            const dangerousKeys = [
                'F12', // Developer Tools
                'F5', 'Ctrl+R', 'Cmd+R', // Refresh
                'Ctrl+Shift+I', 'Cmd+Shift+I', // DevTools
                'Ctrl+Shift+C', 'Cmd+Shift+C', // Inspect
                'Ctrl+U', 'Cmd+U', // View Source
                'Ctrl+S', 'Cmd+S', // Save
                'Ctrl+P', 'Cmd+P', // Print
                'PrintScreen', 'Ctrl+PrintScreen' // Screenshot
            ];
            
            const key = e.key;
            const keyCombo = (e.ctrlKey || e.metaKey ? 'Ctrl+' : '') + 
                           (e.shiftKey ? 'Shift+' : '') + key;
            
            if (dangerousKeys.includes(key) || dangerousKeys.includes(keyCombo)) {
                e.preventDefault();
                e.stopPropagation();
                this.reportSecurityViolation('dangerous_keypress', `مفتاح محظور: ${keyCombo}`);
                return false;
            }
        });
        
        // كشف أدوات المطور
        this.detectDevTools();
        
        // منع السحب والإفلات
        document.addEventListener('dragstart', (e) => {
            e.preventDefault();
            this.reportSecurityViolation('drag_attempt', 'محاولة سحب وإفلات');
        });
        
        // منع التحديد
        document.body.classList.add('no-select');
        
        // مراقبة تغيير حجم النافذة (قد يدل على فتح DevTools)
        let windowSize = { width: window.innerWidth, height: window.innerHeight };
        window.addEventListener('resize', () => {
            const newSize = { width: window.innerWidth, height: window.innerHeight };
            const widthDiff = Math.abs(newSize.width - windowSize.width);
            const heightDiff = Math.abs(newSize.height - windowSize.height);
            
            // إذا كان التغيير كبيراً في الارتفاع، قد يكون DevTools
            if (heightDiff > 100 && widthDiff < 50) {
                this.reportSecurityViolation('window_resize_suspicious', 
                    `تغيير مشبوه في حجم النافذة: ${heightDiff}px`);
            }
            
            windowSize = newSize;
        });
        
        // مراقبة حالة focus للنافذة
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                this.pauseVideo();
                this.reportSecurityViolation('tab_hidden', 'تم إخفاء التبويب أثناء المشاهدة');
            }
        });
    }
    
    /**
     * كشف أدوات المطور
     */
    detectDevTools() {
        const threshold = 160;
        
        const detectLoop = () => {
            const widthThreshold = window.outerWidth - window.innerWidth > threshold;
            const heightThreshold = window.outerHeight - window.innerHeight > threshold;
            
            if (widthThreshold || heightThreshold) {
                this.reportSecurityViolation('dev_tools_detected', 'تم اكتشاف أدوات المطور');
            }
        };
        
        setInterval(detectLoop, 1000);
        
        // كشف console
        const originalLog = console.log;
        console.log = function(...args) {
            player.reportSecurityViolation('console_access', 'محاولة الوصول للـ console');
            return originalLog.apply(console, args);
        };
    }
    
    /**
     * تحميل قائمة الدروس
     */
    async loadLessonsList() {
        try {
            const response = await fetchAPI(`/api/lesson/get_all?course_id=${this.playerData.courseId}`);
            
            if (response.success) {
                this.displayLessonsList(response.lessons);
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            console.error('Error loading lessons:', error);
            document.getElementById('lessonsList').innerHTML = `
                <div class="text-center py-3">
                    <i class="fas fa-exclamation-triangle text-warning"></i>
                    <p class="mt-2 small text-muted">خطأ في تحميل الدروس</p>
                </div>
            `;
        }
    }
    
    /**
     * عرض قائمة الدروس
     */
    displayLessonsList(lessons) {
        const container = document.getElementById('lessonsList');
        container.innerHTML = '';
        
        lessons.forEach((lesson, index) => {
            const isActive = lesson.id === this.playerData.lessonId;
            const isCompleted = lesson.progress && lesson.progress.is_completed;
            const isLocked = !lesson.is_preview && !lesson.has_access;
            
            const lessonItem = document.createElement('div');
            lessonItem.className = `lesson-item ${isActive ? 'active' : ''} ${isCompleted ? 'completed' : ''}`;
            
            lessonItem.innerHTML = `
                <div class="lesson-icon">
                    ${isCompleted ? '<i class="fas fa-check"></i>' : 
                      isLocked ? '<i class="fas fa-lock"></i>' : 
                      '<i class="fas fa-play"></i>'}
                </div>
                <div class="lesson-info">
                    <div class="lesson-name">${lesson.title}</div>
                    <div class="lesson-duration">
                        ${lesson.duration ? this.formatDuration(lesson.duration) : 'غير محدد'}
                        ${lesson.is_preview ? ' • معاينة مجانية' : ''}
                    </div>
                </div>
            `;
            
            if (!isLocked && !isActive) {
                lessonItem.style.cursor = 'pointer';
                lessonItem.addEventListener('click', () => {
                    window.location.href = `/player.php?lesson_id=${lesson.id}`;
                });
            }
            
            container.appendChild(lessonItem);
        });
    }
    
    /**
     * تهيئة مشغل VdoCipher
     */
    async initializePlayer() {
        if (!this.playerData.videoId) {
            this.showError('معرف الفيديو غير متاح');
            return;
        }
        
        try {
            // الحصول على OTP
            const otpData = await this.getOTP();
            
            if (!otpData.success) {
                throw new Error(otpData.message);
            }
            
            // إعداد المشغل
            const playerConfig = {
                otp: otpData.data.otp,
                playbackInfo: otpData.data.playback_info,
                theme: "9ae8bbe8dd964ddc9bdb932cca1cb59a",
                container: document.getElementById("vdocipherPlayer"),
                hidelogo: true,
                hideTitle: true,
                hideAutoplay: true,
                muted: false,
                autoplay: false,
                playsinline: true
            };
            
            this.player = new VdoPlayer(playerConfig);
            
            // ربط أحداث المشغل
            this.bindPlayerEvents();
            
            // إخفاء شاشة التحميل
            document.getElementById('videoOverlay').style.display = 'none';
            
        } catch (error) {
            console.error('Player initialization error:', error);
            this.showError('خطأ في تهيئة المشغل: ' + error.message);
        }
    }
    
    /**
     * الحصول على OTP من الخادم
     */
    async getOTP() {
        try {
            const response = await fetchAPI('/api/otp/generate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': this.playerData.csrfToken
                },
                body: JSON.stringify({
                    lesson_id: this.playerData.lessonId,
                    video_id: this.playerData.videoId,
                    session_id: this.playerData.sessionId
                })
            });
            
            return response;
        } catch (error) {
            console.error('OTP generation error:', error);
            throw new Error('فشل في الحصول على رمز التشغيل');
        }
    }
    
    /**
     * ربط أحداث المشغل
     */
    bindPlayerEvents() {
        if (!this.player) return;
        
        // بداية التشغيل
        this.player.on('play', () => {
            this.watchStartTime = Date.now();
            this.startProgressTracking();
        });
        
        // إيقاف مؤقت
        this.player.on('pause', () => {
            this.updateWatchProgress();
        });
        
        // تحديث الوقت
        this.player.on('timeupdate', (data) => {
            this.updateProgressBar(data.currentTime, data.duration);
            
            // تحديث التقدم كل فترة
            if (Date.now() - this.lastProgressUpdate > this.progressUpdateInterval * 1000) {
                this.updateWatchProgress();
                this.lastProgressUpdate = Date.now();
            }
        });
        
        // انتهاء الفيديو
        this.player.on('ended', () => {
            this.markLessonComplete();
        });
        
        // خطأ في التشغيل
        this.player.on('error', (error) => {
            console.error('Player error:', error);
            this.showError('خطأ في تشغيل الفيديو');
        });
        
        // محاولة تحميل الفيديو
        this.player.on('download', () => {
            this.reportSecurityViolation('download_attempt', 'محاولة تحميل الفيديو');
        });
    }
    
    /**
     * بدء تتبع التقدم
     */
    startProgressTracking() {
        // العودة للموضع الأخير
        if (this.playerData.lastPosition > 0) {
            this.player.currentTime = this.playerData.lastPosition;
        }
        
        // بدء تتبع دوري للتقدم
        this.progressTracker = setInterval(() => {
            this.updateWatchProgress();
        }, this.progressUpdateInterval * 1000);
    }
    
    /**
     * تحديث شريط التقدم
     */
    updateProgressBar(currentTime, duration) {
        const progressBar = document.getElementById('progressBar');
        const currentTimeSpan = document.getElementById('currentTime');
        
        if (progressBar && duration > 0) {
            const percentage = (currentTime / duration) * 100;
            progressBar.style.width = percentage + '%';
        }
        
        if (currentTimeSpan) {
            currentTimeSpan.textContent = this.formatDuration(currentTime);
        }
    }
    
    /**
     * تحديث تقدم المشاهدة في الخادم
     */
    async updateWatchProgress() {
        if (!this.player) return;
        
        try {
            const currentTime = this.player.currentTime || 0;
            const duration = this.player.duration || this.playerData.duration;
            
            await fetchAPI('/api/progress/update', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': this.playerData.csrfToken
                },
                body: JSON.stringify({
                    lesson_id: this.playerData.lessonId,
                    last_position: Math.floor(currentTime),
                    watch_time: Math.floor((Date.now() - this.watchStartTime) / 1000),
                    duration: duration
                })
            });
        } catch (error) {
            console.error('Progress update error:', error);
        }
    }
    
    /**
     * تحديد الدرس كمكتمل
     */
    async markLessonComplete() {
        try {
            const response = await fetchAPI('/api/progress/complete', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': this.playerData.csrfToken
                },
                body: JSON.stringify({
                    lesson_id: this.playerData.lessonId
                })
            });
            
            if (response.success) {
                showToast('تهانينا! تم إكمال الدرس بنجاح', 'success');
                
                // تحديث واجهة المستخدم
                const completeBtn = document.getElementById('completeBtn');
                if (completeBtn) {
                    completeBtn.innerHTML = '<i class="fas fa-check"></i> مكتمل';
                    completeBtn.classList.remove('btn-outline-success');
                    completeBtn.classList.add('btn-success');
                    completeBtn.disabled = true;
                }
            }
        } catch (error) {
            console.error('Complete lesson error:', error);
        }
    }
    
    /**
     * ربط الأحداث العامة
     */
    bindEvents() {
        // زر تشغيل في الـ overlay
        const playButton = document.getElementById('playButton');
        if (playButton) {
            playButton.addEventListener('click', () => {
                if (this.player) {
                    this.player.play();
                }
            });
        }
        
        // زر ملء الشاشة
        const fullscreenBtn = document.getElementById('fullscreenBtn');
        if (fullscreenBtn) {
            fullscreenBtn.addEventListener('click', () => {
                this.toggleFullscreen();
            });
        }
        
        // زر إكمال الدرس
        const completeBtn = document.getElementById('completeBtn');
        if (completeBtn) {
            completeBtn.addEventListener('click', () => {
                this.markLessonComplete();
            });
        }
        
        // زر إخفاء/إظهار الشريط الجانبي
        const toggleSidebar = document.getElementById('toggleSidebar');
        if (toggleSidebar) {
            toggleSidebar.addEventListener('click', () => {
                const sidebar = document.querySelector('.sidebar-section');
                sidebar.classList.toggle('show');
            });
        }
        
        // حفظ الملاحظات
        const saveNotesBtn = document.getElementById('saveNotesBtn');
        if (saveNotesBtn) {
            saveNotesBtn.addEventListener('click', () => {
                this.saveNotes();
            });
        }
    }
    
    /**
     * تبديل ملء الشاشة
     */
    toggleFullscreen() {
        const container = document.getElementById('videoContainer');
        
        if (!document.fullscreenElement) {
            container.requestFullscreen().catch(err => {
                console.error('Fullscreen error:', err);
            });
        } else {
            document.exitFullscreen();
        }
    }
    
    /**
     * تحميل الملاحظات
     */
    async loadNotes() {
        try {
            const response = await fetchAPI(`/api/lesson/notes?lesson_id=${this.playerData.lessonId}`);
            
            if (response.success && response.notes) {
                document.getElementById('notesTextarea').value = response.notes;
            }
        } catch (error) {
            console.error('Load notes error:', error);
        }
    }
    
    /**
     * حفظ الملاحظات
     */
    async saveNotes() {
        const notes = document.getElementById('notesTextarea').value;
        
        try {
            const response = await fetchAPI('/api/lesson/save_notes', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': this.playerData.csrfToken
                },
                body: JSON.stringify({
                    lesson_id: this.playerData.lessonId,
                    notes: notes
                })
            });
            
            if (response.success) {
                showToast('تم حفظ الملاحظات بنجاح', 'success');
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            console.error('Save notes error:', error);
            showToast('خطأ في حفظ الملاحظات', 'error');
        }
    }
    
    /**
     * إيقاف الفيديو مؤقتاً
     */
    pauseVideo() {
        if (this.player) {
            this.player.pause();
        }
    }
    
    /**
     * الإبلاغ عن انتهاك أمني
     */
    async reportSecurityViolation(type, details) {
        this.violationCount++;
        
        try {
            await fetchAPI('/api/security/violation', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': this.playerData.csrfToken
                },
                body: JSON.stringify({
                    violation_type: type,
                    details: details,
                    lesson_id: this.playerData.lessonId,
                    session_id: this.playerData.sessionId
                })
            });
        } catch (error) {
            console.error('Security violation report error:', error);
        }
        
        // إجراءات حسب نوع الانتهاك
        if (['dev_tools_detected', 'download_attempt'].includes(type)) {
            this.showSecurityWarning(type, details);
        }
        
        // إنهاء الجلسة بعد تجاوز الحد المسموح
        if (this.violationCount >= this.maxViolations) {
            this.terminateSession();
        }
    }
    
    /**
     * عرض تحذير أمني
     */
    showSecurityWarning(type, details) {
        const messages = {
            'dev_tools_detected': 'تم اكتشاف أدوات المطور. سيتم إيقاف التشغيل.',
            'download_attempt': 'محاولة تحميل الفيديو غير مسموحة.',
            'screen_recording': 'تم اكتشاف تسجيل الشاشة. سيتم إنهاء الجلسة.'
        };
        
        document.getElementById('securityMessage').textContent = 
            messages[type] || 'انتهاك أمني تم اكتشافه';
        
        const modal = new bootstrap.Modal(document.getElementById('securityWarningModal'));
        modal.show();
        
        // إيقاف الفيديو
        this.pauseVideo();
    }
    
    /**
     * إنهاء الجلسة
     */
    terminateSession() {
        window.location.href = '/login.php?security_violation=1';
    }
    
    /**
     * عرض رسالة خطأ
     */
    showError(message) {
        const overlay = document.getElementById('videoOverlay');
        overlay.innerHTML = `
            <div class="text-center">
                <i class="fas fa-exclamation-triangle fa-3x text-warning mb-3"></i>
                <h5 class="text-white">${message}</h5>
                <button class="btn btn-primary mt-3" onclick="location.reload()">
                    <i class="fas fa-redo me-2"></i>إعادة المحاولة
                </button>
            </div>
        `;
        overlay.style.display = 'flex';
    }
    
    /**
     * تنسيق المدة
     */
    formatDuration(seconds) {
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = Math.floor(seconds % 60);
        
        if (hours > 0) {
            return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        } else {
            return `${minutes}:${secs.toString().padStart(2, '0')}`;
        }
    }
}

// معالجة انتهاك الأمان
function handleSecurityViolation() {
    window.location.href = '/login.php?security_violation=1';
}

// تهيئة المشغل عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    window.player = new SecureVideoPlayer();
});

// حماية إضافية ضد إغلاق النافذة أثناء المشاهدة
window.addEventListener('beforeunload', function(e) {
    if (window.player && window.player.player && !window.player.player.paused) {
        const message = 'سيتم إيقاف الفيديو إذا غادرت الصفحة. هل تريد المتابعة؟';
        e.returnValue = message;
        return message;
    }
});