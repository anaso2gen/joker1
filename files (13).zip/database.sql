-- إنشاء قاعدة البيانات
CREATE DATABASE IF NOT EXISTS learning_platform CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE learning_platform;

-- جدول المستخدمين
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    user_id VARCHAR(36) UNIQUE NOT NULL,
    is_admin TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- جدول الجلسات
CREATE TABLE sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- جدول الكورسات
CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    image_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- جدول الأقسام
CREATE TABLE sections (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    order_index INT DEFAULT 0,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

-- جدول الدروس
CREATE TABLE lessons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    section_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    vdocipher_video_id VARCHAR(255) NOT NULL,
    order_index INT DEFAULT 0,
    duration INT DEFAULT 0,
    FOREIGN KEY (section_id) REFERENCES sections(id) ON DELETE CASCADE
);

-- جدول الاشتراكات
CREATE TABLE subscriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    course_id INT NOT NULL,
    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    UNIQUE KEY unique_subscription (user_id, course_id)
);

-- جدول الأكواد
CREATE TABLE codes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    course_id INT NOT NULL,
    is_active TINYINT(1) DEFAULT 1,
    uses_count INT DEFAULT 0,
    max_uses INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

-- إدراج مستخدم مسؤول افتراضي
INSERT INTO users (email, password, user_id, is_admin) VALUES 
('admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', UUID(), 1);

-- إدراج بيانات تجريبية
INSERT INTO courses (name, code, description) VALUES 
('البرمجة الأساسية', 'PROG001', 'تعلم أساسيات البرمجة'),
('تطوير المواقع', 'WEB001', 'تعلم تطوير المواقع الإلكترونية');

INSERT INTO sections (course_id, name, order_index) VALUES 
(1, 'مقدمة في البرمجة', 1),
(1, 'المتغيرات والدوال', 2),
(2, 'HTML الأساسي', 1),
(2, 'CSS والتصميم', 2);

INSERT INTO lessons (section_id, title, vdocipher_video_id, order_index) VALUES 
(1, 'ما هي البرمجة؟', 'sample_video_1', 1),
(1, 'إعداد بيئة العمل', 'sample_video_2', 2),
(2, 'تعريف المتغيرات', 'sample_video_3', 1),
(3, 'بنية HTML', 'sample_video_4', 1),
(4, 'أساسيات CSS', 'sample_video_5', 1);

INSERT INTO codes (code, course_id, is_active, max_uses) VALUES 
('PROG2024', 1, 1, 100),
('WEB2024', 2, 1, 50);