<?php
/**
 * لوحة التحكم للمسؤولين
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 08:36:29
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/session.php';

// طلب صلاحيات إدارية
$sessionManager->requireAdmin();

$user = $sessionManager->getCurrentUser();
$page = $_GET['page'] ?? 'dashboard';

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    
    // جلب الإحصائيات العامة
    $stats = [];
    
    // إجمالي المستخدمين
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM users WHERE is_active = 1");
    $stats['total_users'] = $stmt->fetch()['count'];
    
    // المستخدمين الجدد هذا الشهر
    $stmt = $pdo->query("
        SELECT COUNT(*) as count FROM users 
        WHERE is_active = 1 AND created_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)
    ");
    $stats['new_users'] = $stmt->fetch()['count'];
    
    // إجمالي الدورات
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM courses WHERE is_active = 1");
    $stats['total_courses'] = $stmt->fetch()['count'];
    
    // إجمالي الاشتراكات النشطة
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM subscriptions WHERE is_active = 1");
    $stats['active_subscriptions'] = $stmt->fetch()['count'];
    
    // الاشتراكات الجديدة هذا الشهر
    $stmt = $pdo->query("
        SELECT COUNT(*) as count FROM subscriptions 
        WHERE is_active = 1 AND created_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)
    ");
    $stats['new_subscriptions'] = $stmt->fetch()['count'];
    
    // أكواد التفعيل المستخدمة
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM activation_codes WHERE used_count > 0");
    $stats['used_codes'] = $stmt->fetch()['count'];
    
    // بيانات الرسم البياني للمستخدمين الجدد (آخر 7 أيام)
    $stmt = $pdo->query("
        SELECT DATE(created_at) as date, COUNT(*) as count 
        FROM users 
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        GROUP BY DATE(created_at)
        ORDER BY date ASC
    ");
    $userChartData = $stmt->fetchAll();
    
    // أحدث المستخدمين
    $stmt = $pdo->prepare("
        SELECT * FROM users 
        WHERE is_active = 1 
        ORDER BY created_at DESC 
        LIMIT 10
    ");
    $stmt->execute();
    $recentUsers = $stmt->fetchAll();
    
    // أحدث الاشتراكات
    $stmt = $pdo->prepare("
        SELECT s.*, u.first_name, u.last_name, u.email, c.name as course_name
        FROM subscriptions s
        JOIN users u ON s.user_id = u.id
        JOIN courses c ON s.course_id = c.id
        WHERE s.is_active = 1
        ORDER BY s.created_at DESC
        LIMIT 10
    ");
    $stmt->execute();
    $recentSubscriptions = $stmt->fetchAll();
    
    // الدورات الأكثر شعبية
    $stmt = $pdo->prepare("
        SELECT c.name, COUNT(s.id) as subscriptions_count
        FROM courses c
        LEFT JOIN subscriptions s ON c.id = s.course_id AND s.is_active = 1
        WHERE c.is_active = 1
        GROUP BY c.id, c.name
        ORDER BY subscriptions_count DESC
        LIMIT 5
    ");
    $stmt->execute();
    $popularCourses = $stmt->fetchAll();
    
    // سجل الأمان الأخير
    $stmt = $pdo->prepare("
        SELECT * FROM security_logs 
        ORDER BY created_at DESC 
        LIMIT 10
    ");
    $stmt->execute();
    $securityLogs = $stmt->fetchAll();
    
} catch (PDOException $e) {
    logSecurityEvent('Admin dashboard load failed', 'medium', ['error' => $e->getMessage()]);
    $stats = [];
    $userChartData = [];
    $recentUsers = [];
    $recentSubscriptions = [];
    $popularCourses = [];
    $securityLogs = [];
}

// تضمين ملف العرض
require_once __DIR__ . '/frontend/views/pages/dashboard.php';
?>