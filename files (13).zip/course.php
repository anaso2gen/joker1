<?php
/**
 * صفحة عرض تفاصيل الدورة
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 08:55:29
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/session.php';

$user = $sessionManager->isLoggedIn() ? $sessionManager->getCurrentUser() : null;
$courseId = intval($_GET['id'] ?? 0);

if (!$courseId) {
    header('Location: courses.php');
    exit;
}

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    
    // جلب تفاصيل الدورة
    $stmt = $pdo->prepare("
        SELECT c.*, 
               (SELECT COUNT(*) FROM subscriptions s WHERE s.course_id = c.id AND s.is_active = 1) as students_count,
               (SELECT AVG(rating) FROM course_reviews cr WHERE cr.course_id = c.id) as avg_rating,
               (SELECT COUNT(*) FROM course_reviews cr WHERE cr.course_id = c.id) as reviews_count
        FROM courses c 
        WHERE c.id = ? AND c.is_active = 1
    ");
    $stmt->execute([$courseId]);
    $course = $stmt->fetch();
    
    if (!$course) {
        showErrorPage(404, 'الدورة غير موجودة أو غير متاحة');
    }
    
    // جلب أقسام ودروس الدورة
    $stmt = $pdo->prepare("
        SELECT s.*, 
               COUNT(l.id) as lessons_count,
               SUM(l.duration) as total_duration
        FROM sections s 
        LEFT JOIN lessons l ON s.id = l.section_id AND l.is_active = 1
        WHERE s.course_id = ? 
        GROUP BY s.id 
        ORDER BY s.sort_order
    ");
    $stmt->execute([$courseId]);
    $sections = $stmt->fetchAll();
    
    // إضافة الدروس لكل قسم
    foreach ($sections as &$section) {
        $stmt = $pdo->prepare("
            SELECT l.* 
            FROM lessons l 
            WHERE l.section_id = ? AND l.is_active = 1 
            ORDER BY l.sort_order
        ");
        $stmt->execute([$section['id']]);
        $section['lessons'] = $stmt->fetchAll();
    }
    
    // فحص اشتراك المستخدم
    $userSubscribed = false;
    $userProgress = [];
    $subscription = null;
    
    if ($user) {
        $stmt = $pdo->prepare("
            SELECT * FROM subscriptions 
            WHERE user_id = ? AND course_id = ? AND is_active = 1
        ");
        $stmt->execute([$user['id'], $courseId]);
        $subscription = $stmt->fetch();
        $userSubscribed = $subscription !== false;
        
        if ($userSubscribed) {
            // جلب تقدم المستخدم
            $stmt = $pdo->prepare("
                SELECT l.id, lp.completed, lp.last_position, lp.started_at, lp.completed_at
                FROM lessons l
                JOIN sections s ON l.section_id = s.id
                LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = ?
                WHERE s.course_id = ? AND l.is_active = 1
                ORDER BY s.sort_order, l.sort_order
            ");
            $stmt->execute([$user['id'], $courseId]);
            $progressData = $stmt->fetchAll();
            
            foreach ($progressData as $progress) {
                $userProgress[$progress['id']] = $progress;
            }
        }
    }
    
    // جلب التقييمات
    $stmt = $pdo->prepare("
        SELECT cr.*, u.first_name, u.last_name, u.avatar_url
        FROM course_reviews cr
        JOIN users u ON cr.user_id = u.id
        WHERE cr.course_id = ? AND cr.is_approved = 1
        ORDER BY cr.created_at DESC
        LIMIT 10
    ");
    $stmt->execute([$courseId]);
    $reviews = $stmt->fetchAll();
    
    // جلب دورات مشابهة
    $stmt = $pdo->prepare("
        SELECT c.*, 
               (SELECT COUNT(*) FROM subscriptions s WHERE s.course_id = c.id AND s.is_active = 1) as students_count,
               (SELECT COUNT(*) FROM lessons l JOIN sections sec ON l.section_id = sec.id WHERE sec.course_id = c.id) as lessons_count
        FROM courses c 
        WHERE c.category = ? AND c.id != ? AND c.is_active = 1
        ORDER BY c.created_at DESC 
        LIMIT 4
    ");
    $stmt->execute([$course['category'], $courseId]);
    $relatedCourses = $stmt->fetchAll();
    
    // تسجيل زيارة الصفحة
    logActivity("Course viewed: {$course['name']}", 'course', $user['id'] ?? null);
    
} catch (PDOException $e) {
    logSecurityEvent('Failed to load course details', 'medium', ['error' => $e->getMessage()]);
    showErrorPage(500, 'حدث خطأ في تحميل تفاصيل الدورة');
}

// حساب إحصائيات التقدم
$totalLessons = 0;
$completedLessons = 0;
$totalDuration = 0;
$previewLessons = 0;

foreach ($sections as $section) {
    $totalLessons += count($section['lessons']);
    $totalDuration += $section['total_duration'] ?? 0;
    
    foreach ($section['lessons'] as $lesson) {
        if ($lesson['is_preview']) {
            $previewLessons++;
        }
        
        if (isset($userProgress[$lesson['id']]) && $userProgress[$lesson['id']]['completed']) {
            $completedLessons++;
        }
    }
}

$progressPercentage = $totalLessons > 0 ? round(($completedLessons / $totalLessons) * 100) : 0;

// دالة للتحقق من إمكانية الوصول للدرس
function canAccessLesson($lesson, $userSubscribed) {
    return $lesson['is_preview'] || $userSubscribed;
}

// تضمين ملف العرض
require_once __DIR__ . '/frontend/views/pages/course-details.php';
?>