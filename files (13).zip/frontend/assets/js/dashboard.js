// إكمال JavaScript للوحة التحكم

// عرض رسالة فارغة
            container.innerHTML = `
                <div class="text-center p-4">
                    <lottie-player
                        src="https://assets1.lottiefiles.com/packages/lf20_UJNc2t.json"
                        background="transparent"
                        speed="1"
                        style="width: 150px; height: 150px; margin: 0 auto;"
                        loop
                        autoplay>
                    </lottie-player>
                    <p class="text-muted mt-2">لا توجد دورات حالياً</p>
                </div>
            `;
        }
    } catch (error) {
        console.error("Error loading courses:", error);
        document.getElementById("coursesList").innerHTML = `
            <div class="text-center p-4">
                <i class="fas fa-exclamation-triangle fa-3x text-danger mb-2"></i>
                <p class="text-danger">خطأ في تحميل الدورات</p>
            </div>
        `;
    }
}

// إنشاء عنصر دورة في القائمة
function createCourseListItem(course) {
    const item = document.createElement("div");
    item.className = "list-item";
    item.setAttribute("data-aos", "fade-up");
    
    const statusIcon = course.is_active ? 
        '<i class="fas fa-check-circle text-success"></i>' : 
        '<i class="fas fa-times-circle text-danger"></i>';
    
    const statusText = course.is_active ? 'نشط' : 'غير نشط';
    
    item.innerHTML = `
        <div class="item-info">
            <div class="item-title">${course.name}</div>
            <div class="item-meta">
                ${statusIcon} ${statusText} • 
                <i class="fas fa-users me-1"></i>${course.subscribers_count || 0} مشترك • 
                <i class="fas fa-video me-1"></i>${course.lessons_count || 0} درس
            </div>
        </div>
        <div class="item-actions">
            <button class="btn btn-sm btn-outline-primary" onclick="openCourseModal('edit', ${course.id})" title="تعديل">
                <i class="fas fa-edit"></i>
            </button>
            <button class="btn btn-sm btn-outline-success" onclick="manageSections(${course.id})" title="إدارة الأقسام">
                <i class="fas fa-folder"></i>
            </button>
            <button class="btn btn-sm btn-outline-danger" onclick="deleteCourse(${course.id})" title="حذف">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `;
    
    return item;
}

// تحميل المستخدمين
async function loadUsers() {
    try {
        const response = await fetchAPI("/api/user/get_all?admin=1");
        const container = document.getElementById("usersList");
        
        if (response.success && response.users.length > 0) {
            container.innerHTML = "";
            
            response.users.forEach(user => {
                const item = createUserListItem(user);
                container.appendChild(item);
            });
        } else {
            container.innerHTML = `
                <div class="text-center p-4">
                    <lottie-player
                        src="https://assets6.lottiefiles.com/packages/lf20_jvsq0s29.json"
                        background="transparent"
                        speed="1"
                        style="width: 150px; height: 150px; margin: 0 auto;"
                        loop
                        autoplay>
                    </lottie-player>
                    <p class="text-muted mt-2">لا يوجد مستخدمين</p>
                </div>
            `;
        }
    } catch (error) {
        console.error("Error loading users:", error);
        document.getElementById("usersList").innerHTML = `
            <div class="text-center p-4">
                <i class="fas fa-exclamation-triangle fa-3x text-danger mb-2"></i>
                <p class="text-danger">خطأ في تحميل المستخدمين</p>
            </div>
        `;
    }
}

// إنشاء عنصر مستخدم في القائمة
function createUserListItem(user) {
    const item = document.createElement("div");
    item.className = "list-item";
    item.setAttribute("data-aos", "fade-up");
    
    const roleIcon = user.is_admin ? 
        '<i class="fas fa-crown text-warning"></i>' : 
        '<i class="fas fa-user text-primary"></i>';
    
    const roleText = user.is_admin ? 'مسؤول' : 'مستخدم';
    const statusIcon = user.is_active ? 
        '<i class="fas fa-check-circle text-success"></i>' : 
        '<i class="fas fa-times-circle text-danger"></i>';
    
    const lastLogin = user.last_login ? 
        new Date(user.last_login).toLocaleDateString('ar-SA') : 'لم يسجل دخول';
    
    item.innerHTML = `
        <div class="item-info">
            <div class="item-title">${user.email}</div>
            <div class="item-meta">
                ${roleIcon} ${roleText} • 
                ${statusIcon} • 
                <i class="fas fa-calendar me-1"></i>آخر دخول: ${lastLogin}
            </div>
        </div>
        <div class="item-actions">
            <button class="btn btn-sm btn-outline-info" onclick="viewUserDetails(${user.id})" title="عرض التفاصيل">
                <i class="fas fa-eye"></i>
            </button>
            <button class="btn btn-sm btn-outline-primary" onclick="editUser(${user.id})" title="تعديل">
                <i class="fas fa-edit"></i>
            </button>
            <button class="btn btn-sm btn-outline-warning" onclick="toggleUserStatus(${user.id})" title="تغيير الحالة">
                <i class="fas fa-toggle-on"></i>
            </button>
        </div>
    `;
    
    return item;
}

// تحميل الأكواد
async function loadCodes() {
    try {
        const response = await fetchAPI("/api/code/get_all?admin=1");
        const container = document.getElementById("codesList");
        
        if (response.success && response.codes.length > 0) {
            container.innerHTML = "";
            
            response.codes.forEach(code => {
                const item = createCodeListItem(code);
                container.appendChild(item);
            });
        } else {
            container.innerHTML = `
                <div class="text-center p-4">
                    <lottie-player
                        src="https://assets9.lottiefiles.com/packages/lf20_w51pcehl.json"
                        background="transparent"
                        speed="1"
                        style="width: 150px; height: 150px; margin: 0 auto;"
                        loop
                        autoplay>
                    </lottie-player>
                    <p class="text-muted mt-2">لا توجد أكواد</p>
                </div>
            `;
        }
    } catch (error) {
        console.error("Error loading codes:", error);
        document.getElementById("codesList").innerHTML = `
            <div class="text-center p-4">
                <i class="fas fa-exclamation-triangle fa-3x text-danger mb-2"></i>
                <p class="text-danger">خطأ في تحميل الأكواد</p>
            </div>
        `;
    }
}

// إنشاء عنصر كود في القائمة
function createCodeListItem(code) {
    const item = document.createElement("div");
    item.className = "list-item";
    item.setAttribute("data-aos", "fade-up");
    
    const statusIcon = code.is_active ? 
        '<i class="fas fa-check-circle text-success"></i>' : 
        '<i class="fas fa-times-circle text-danger"></i>';
    
    const usageInfo = code.max_uses > 0 ? 
        `${code.uses_count}/${code.max_uses}` : 
        `${code.uses_count}/∞`;
    
    const expiryInfo = code.expires_at ? 
        new Date(code.expires_at).toLocaleDateString('ar-SA') : 'لا ينتهي';
    
    item.innerHTML = `
        <div class="item-info">
            <div class="item-title">
                <span class="badge bg-primary">${code.code}</span>
                ${code.course_name}
            </div>
            <div class="item-meta">
                ${statusIcon} • 
                <i class="fas fa-users me-1"></i>استخدامات: ${usageInfo} • 
                <i class="fas fa-calendar me-1"></i>ينتهي: ${expiryInfo}
            </div>
        </div>
        <div class="item-actions">
            <button class="btn btn-sm btn-outline-primary" onclick="openCodeModal('edit', ${code.id})" title="تعديل">
                <i class="fas fa-edit"></i>
            </button>
            <button class="btn btn-sm btn-outline-info" onclick="copyCode('${code.code}')" title="نسخ الكود">
                <i class="fas fa-copy"></i>
            </button>
            <button class="btn btn-sm btn-outline-danger" onclick="disableCode(${code.id})" title="تعطيل">
                <i class="fas fa-ban"></i>
            </button>
        </div>
    `;
    
    return item;
}

// تحميل التحليلات
async function loadAnalytics() {
    try {
        const response = await fetchAPI("/api/dashboard/analytics");
        
        if (response.success) {
            document.getElementById("totalViews").textContent = response.analytics.total_views || 0;
            document.getElementById("avgWatchTime").textContent = formatDuration(response.analytics.avg_watch_time || 0);
            document.getElementById("newUsers").textContent = response.analytics.new_users || 0;
            document.getElementById("completionRate").textContent = (response.analytics.completion_rate || 0) + '%';
            
            // تحديث الرسم البياني
            updateChart(response.analytics.chart_data || []);
        }
    } catch (error) {
        console.error("Error loading analytics:", error);
    }
}

// إعداد فلاتر البحث
function setupSearchFilters() {
    // فلتر البحث في الدورات
    const courseSearch = document.getElementById("courseSearch");
    const courseFilter = document.getElementById("courseFilter");
    
    if (courseSearch) {
        courseSearch.addEventListener("input", debounce(filterCourses, 300));
    }
    
    if (courseFilter) {
        courseFilter.addEventListener("change", filterCourses);
    }
    
    // فلتر البحث في المستخدمين
    const userSearch = document.getElementById("userSearch");
    const userFilter = document.getElementById("userFilter");
    
    if (userSearch) {
        userSearch.addEventListener("input", debounce(filterUsers, 300));
    }
    
    if (userFilter) {
        userFilter.addEventListener("change", filterUsers);
    }
    
    // فلتر البحث في الأكواد
    const codeSearch = document.getElementById("codeSearch");
    const codeFilter = document.getElementById("codeFilter");
    
    if (codeSearch) {
        codeSearch.addEventListener("input", debounce(filterCodes, 300));
    }
    
    if (codeFilter) {
        codeFilter.addEventListener("change", filterCodes);
    }
}

// فلترة الدورات
function filterCourses() {
    const searchTerm = document.getElementById("courseSearch").value.toLowerCase();
    const filterValue = document.getElementById("courseFilter").value;
    const items = document.querySelectorAll("#coursesList .list-item");
    
    items.forEach(item => {
        const title = item.querySelector(".item-title").textContent.toLowerCase();
        const meta = item.querySelector(".item-meta").textContent;
        
        const matchesSearch = title.includes(searchTerm);
        const matchesFilter = !filterValue || 
            (filterValue === "active" && meta.includes("نشط")) ||
            (filterValue === "inactive" && meta.includes("غير نشط"));
        
        item.style.display = matchesSearch && matchesFilter ? "flex" : "none";
    });
}

// فلترة المستخدمين
function filterUsers() {
    const searchTerm = document.getElementById("userSearch").value.toLowerCase();
    const filterValue = document.getElementById("userFilter").value;
    const items = document.querySelectorAll("#usersList .list-item");
    
    items.forEach(item => {
        const title = item.querySelector(".item-title").textContent.toLowerCase();
        const meta = item.querySelector(".item-meta").textContent;
        
        const matchesSearch = title.includes(searchTerm);
        const matchesFilter = !filterValue || 
            (filterValue === "admin" && meta.includes("مسؤول")) ||
            (filterValue === "user" && meta.includes("مستخدم") && !meta.includes("مسؤول"));
        
        item.style.display = matchesSearch && matchesFilter ? "flex" : "none";
    });
}

// فلترة الأكواد
function filterCodes() {
    const searchTerm = document.getElementById("codeSearch").value.toLowerCase();
    const filterValue = document.getElementById("codeFilter").value;
    const items = document.querySelectorAll("#codesList .list-item");
    
    items.forEach(item => {
        const title = item.querySelector(".item-title").textContent.toLowerCase();
        const meta = item.querySelector(".item-meta").textContent;
        
        const matchesSearch = title.includes(searchTerm);
        const matchesFilter = !filterValue || 
            (filterValue === "active" && meta.includes("check-circle text-success")) ||
            (filterValue === "expired" && meta.includes("منتهي")) ||
            (filterValue === "used" && meta.includes("مستخدم"));
        
        item.style.display = matchesSearch && matchesFilter ? "flex" : "none";
    });
}

// تهيئة الرسم البياني
function initializeChart() {
    const ctx = document.getElementById("analyticsChart");
    if (!ctx) return;
    
    // إنشاء رسم بياني أساسي
    window.analyticsChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو'],
            datasets: [{
                label: 'المشاهدات',
                data: [12, 19, 3, 5, 2, 3],
                borderColor: '#667eea',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// تحديث الرسم البياني
function updateChart(data) {
    if (window.analyticsChart && data.length > 0) {
        window.analyticsChart.data.labels = data.map(item => item.label);
        window.analyticsChart.data.datasets[0].data = data.map(item => item.value);
        window.analyticsChart.update();
    }
}

// فتح نموذج الدورة
async function openCourseModal(mode, courseId = null) {
    const modal = new bootstrap.Modal(document.getElementById("courseModal"));
    const title = document.getElementById("courseModalTitle");
    const form = document.getElementById("courseForm");
    
    // إعادة تعيين النموذج
    form.reset();
    document.getElementById("courseId").value = "";
    
    if (mode === "create") {
        title.innerHTML = '<i class="fas fa-plus me-2"></i>إضافة دورة جديدة';
    } else if (mode === "edit" && courseId) {
        title.innerHTML = '<i class="fas fa-edit me-2"></i>تعديل الدورة';
        
        try {
            // تحميل بيانات الدورة
            const response = await fetchAPI(`/api/course/get?id=${courseId}`);
            
            if (response.success) {
                const course = response.course;
                document.getElementById("courseId").value = course.id;
                document.getElementById("courseName").value = course.name;
                document.getElementById("courseCode").value = course.code;
                document.getElementById("courseDescription").value = course.description || "";
                document.getElementById("coursePrice").value = course.price || "";
                document.getElementById("courseOrder").value = course.sort_order || "";
                document.getElementById("courseActive").checked = course.is_active;
            }
        } catch (error) {
            console.error("Error loading course:", error);
            showToast("خطأ في تحميل بيانات الدورة", "error");
            return;
        }
    }
    
    modal.show();
}

// حفظ الدورة
async function saveCourse() {
    const form = document.getElementById("courseForm");
    const formData = new FormData(form);
    const courseId = document.getElementById("courseId").value;
    
    try {
        const endpoint = courseId ? `/api/course/update` : `/api/course/create`;
        const response = await fetchAPI(endpoint, {
            method: "POST",
            body: formData
        });
        
        if (response.success) {
            showToast("تم حفظ الدورة بنجاح!", "success");
            bootstrap.Modal.getInstance(document.getElementById("courseModal")).hide();
            loadCourses();
            loadStatistics();
        } else {
            showToast(response.message || "خطأ في حفظ الدورة", "error");
        }
    } catch (error) {
        console.error("Error saving course:", error);
        showToast("خطأ في حفظ الدورة", "error");
    }
}

// فتح نموذج الكود
async function openCodeModal(mode, codeId = null) {
    const modal = new bootstrap.Modal(document.getElementById("codeModal"));
    const title = document.getElementById("codeModalTitle");
    const form = document.getElementById("codeForm");
    const courseSelect = document.getElementById("codeCourse");
    
    // إعادة تعيين النموذج
    form.reset();
    document.getElementById("codeIdInput").value = "";
    
    // تحميل قائمة الدورات
    try {
        const coursesResponse = await fetchAPI("/api/course/get_all");
        courseSelect.innerHTML = '<option value="">اختر الدورة...</option>';
        
        if (coursesResponse.success) {
            coursesResponse.courses.forEach(course => {
                courseSelect.innerHTML += `<option value="${course.id}">${course.name}</option>`;
            });
        }
    } catch (error) {
        console.error("Error loading courses for code modal:", error);
    }
    
    if (mode === "create") {
        title.innerHTML = '<i class="fas fa-plus me-2"></i>إنشاء كود اشتراك جديد';
        generateRandomCode();
    } else if (mode === "edit" && codeId) {
        title.innerHTML = '<i class="fas fa-edit me-2"></i>تعديل كود الاشتراك';
        
        try {
            const response = await fetchAPI(`/api/code/get?id=${codeId}`);
            
            if (response.success) {
                const code = response.code;
                document.getElementById("codeIdInput").value = code.id;
                document.getElementById("codeValue").value = code.code;
                document.getElementById("codeCourse").value = code.course_id;
                document.getElementById("codeMaxUses").value = code.max_uses;
                document.getElementById("codeExpiry").value = code.expires_at ? 
                    new Date(code.expires_at).toISOString().slice(0, 16) : "";
                document.getElementById("codeActive").checked = code.is_active;
            }
        } catch (error) {
            console.error("Error loading code:", error);
            showToast("خطأ في تحميل بيانات الكود", "error");
            return;
        }
    }
    
    modal.show();
}

// توليد كود عشوائي
function generateRandomCode() {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let code = "";
    
    for (let i = 0; i < 12; i++) {
        if (i > 0 && i % 4 === 0) {
            code += "-";
        }
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    document.getElementById("codeValue").value = code;
}

// حفظ الكود
async function saveCode() {
    const form = document.getElementById("codeForm");
    const formData = new FormData(form);
    const codeId = document.getElementById("codeIdInput").value;
    
    try {
        const endpoint = codeId ? `/api/code/update` : `/api/code/create`;
        const response = await fetchAPI(endpoint, {
            method: "POST",
            body: formData
        });
        
        if (response.success) {
            showToast("تم حفظ الكود بنجاح!", "success");
            bootstrap.Modal.getInstance(document.getElementById("codeModal")).hide();
            loadCodes();
            loadStatistics();
        } else {
            showToast(response.message || "خطأ في حفظ الكود", "error");
        }
    } catch (error) {
        console.error("Error saving code:", error);
        showToast("خطأ في حفظ الكود", "error");
    }
}

// نسخ الكود
function copyCode(code) {
    navigator.clipboard.writeText(code).then(() => {
        showToast("تم نسخ الكود بنجاح!", "success");
    }).catch(() => {
        showToast("فشل في نسخ الكود", "error");
    });
}

// حذف دورة
async function deleteCourse(courseId) {
    if (!confirm("هل أنت متأكد من حذف هذه الدورة؟ سيتم حذف جميع البيانات المرتبطة بها.")) {
        return;
    }
    
    try {
        const response = await fetchAPI(`/api/course/delete`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ id: courseId })
        });
        
        if (response.success) {
            showToast("تم حذف الدورة بنجاح!", "success");
            loadCourses();
            loadStatistics();
        } else {
            showToast(response.message || "خطأ في حذف الدورة", "error");
        }
    } catch (error) {
        console.error("Error deleting course:", error);
        showToast("خطأ في حذف الدورة", "error");
    }
}

// تعطيل كود
async function disableCode(codeId) {
    if (!confirm("هل أنت متأكد من تعطيل هذا الكود؟")) {
        return;
    }
    
    try {
        const response = await fetchAPI(`/api/code/disable?id=${codeId}`, {
            method: "POST"
        });
        
        if (response.success) {
            showToast("تم تعطيل الكود بنجاح!", "success");
            loadCodes();
        } else {
            showToast(response.message || "خطأ في تعطيل الكود", "error");
        }
    } catch (error) {
        console.error("Error disabling code:", error);
        showToast("خطأ في تعطيل الكود", "error");
    }
}

// الإجراءات السريعة
function refreshDashboard() {
    showToast("جاري تحديث البيانات...", "info");
    initializeDashboard();
}

function backupDatabase() {
    showToast("جاري إنشاء نسخة احتياطية...", "info");
    // تنفيذ النسخ الاحتياطي
}

function clearCache() {
    showToast("جاري مسح الكاش...", "info");
    // تنفيذ مسح الكاش
}

function checkSystemHealth() {
    showToast("جاري فحص صحة النظام...", "info");
    // تنفيذ فحص النظام
}

function viewLogs() {
    window.open("/admin/logs.php", "_blank");
}

function manageSettings() {
    window.open("/admin/settings.php", "_blank");
}

function securityReport() {
    window.open("/admin/security.php", "_blank");
}

// تصدير التقارير
function exportReport(type) {
    const url = `/api/dashboard/export?type=${type}`;
    window.open(url, "_blank");
}

function exportUsers() {
    const url = `/api/user/export`;
    window.open(url, "_blank");
}

// دالة debounce للبحث
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// تنسيق المدة
function formatDuration(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
        return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    } else {
        return `${minutes}:${secs.toString().padStart(2, '0')}`;
    }
}