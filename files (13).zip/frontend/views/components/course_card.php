<?php
/**
 * بطاقة الدورة - مكون محسن
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:06:39
 */

// التأكد من وجود بيانات الدورة
if (!isset($course)) {
    return;
}

// التحقق من حالة الاشتراك
$isEnrolled = in_array($course['id'], $userSubscriptions ?? []);
$levelColor = getLevelColor($course['level'] ?? 'beginner');
$levelText = getLevelText($course['level'] ?? 'beginner');
?>

<div class="course-card h-100">
    <div class="card border-0 shadow-sm h-100 course-card-hover">
        <!-- Course Image -->
        <div class="position-relative course-image-container">
            <img src="<?= htmlspecialchars($course['image_url'] ?: 'https://via.placeholder.com/400x250?text=دورة+تدريبية') ?>" 
                 class="card-img-top course-image" 
                 alt="<?= htmlspecialchars($course['name']) ?>"
                 loading="lazy"
                 onerror="this.src='https://via.placeholder.com/400x250?text=دورة+تدريبية'">
            
            <!-- Course Level Badge -->
            <span class="badge bg-<?= $levelColor ?> position-absolute top-0 start-0 m-2 level-badge">
                <?= $levelText ?>
            </span>
            
            <!-- Enrollment Status -->
            <?php if ($isEnrolled): ?>
                <span class="badge bg-success position-absolute top-0 end-0 m-2">
                    <i class="fas fa-check-circle me-1"></i>مسجل
                </span>
            <?php endif; ?>
            
            <!-- Course Preview -->
            <?php if (!empty($course['preview_video'])): ?>
                <div class="course-preview-btn">
                    <button class="btn btn-primary btn-sm rounded-circle" 
                            onclick="previewCourse(<?= $course['id'] ?>)" 
                            title="معاينة الدورة">
                        <i class="fas fa-play"></i>
                    </button>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="card-body d-flex flex-column">
            <!-- Course Category -->
            <?php if (!empty($course['category'])): ?>
                <div class="course-category mb-2">
                    <span class="badge bg-light text-dark category-badge">
                        <i class="fas fa-tag me-1"></i><?= htmlspecialchars($course['category']) ?>
                    </span>
                </div>
            <?php endif; ?>
            
            <!-- Course Title -->
            <h5 class="card-title course-title mb-2">
                <a href="course.php?id=<?= $course['id'] ?>" class="text-decoration-none text-dark course-link">
                    <?= htmlspecialchars($course['name']) ?>
                </a>
            </h5>
            
            <!-- Course Description -->
            <p class="card-text text-muted course-description mb-3">
                <?= htmlspecialchars(substr($course['short_description'] ?: $course['description'], 0, 120)) ?>
                <?php if (strlen($course['short_description'] ?: $course['description']) > 120): ?>...<?php endif; ?>
            </p>
            
            <!-- Course Stats -->
            <div class="course-stats mb-3">
                <div class="row g-2 text-center">
                    <div class="col-4">
                        <div class="stat-item">
                            <i class="fas fa-users text-primary"></i>
                            <small class="d-block text-muted"><?= number_format($course['students_count'] ?? 0) ?></small>
                            <small class="text-muted">طالب</small>
                        </div>
                    </div>
                    
                    <div class="col-4">
                        <div class="stat-item">
                            <i class="fas fa-play-circle text-success"></i>
                            <small class="d-block text-muted"><?= $course['lessons_count'] ?? 0 ?></small>
                            <small class="text-muted">درس</small>
                        </div>
                    </div>
                    
                    <?php if (!empty($course['avg_rating'])): ?>
                        <div class="col-4">
                            <div class="stat-item">
                                <i class="fas fa-star text-warning"></i>
                                <small class="d-block text-muted"><?= number_format($course['avg_rating'], 1) ?></small>
                                <small class="text-muted">تقييم</small>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="col-4">
                            <div class="stat-item">
                                <i class="fas fa-clock text-info"></i>
                                <small class="d-block text-muted">جديد</small>
                                <small class="text-muted">حديث</small>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Course Rating -->
            <?php if (!empty($course['avg_rating'])): ?>
                <div class="course-rating mb-3">
                    <div class="d-flex align-items-center justify-content-between">
                        <div class="rating-stars">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <i class="fas fa-star <?= $i <= round($course['avg_rating']) ? 'text-warning' : 'text-muted' ?>"></i>
                            <?php endfor; ?>
                        </div>
                        <small class="text-muted">
                            (<?= number_format($course['reviews_count'] ?? 0) ?> تقييم)
                        </small>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- Course Footer -->
            <div class="card-footer bg-transparent border-0 px-0 pb-0 mt-auto">
                <div class="d-flex justify-content-between align-items-center">
                    <!-- Course Price -->
                    <div class="course-price">
                        <?php if ($course['price'] == 0): ?>
                            <span class="h6 text-success mb-0 fw-bold">مجاني</span>
                        <?php else: ?>
                            <span class="h6 text-primary mb-0 fw-bold">
                                <?= number_format($course['price'], 2) ?> ر.س
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Action Buttons -->
                    <div class="course-actions">
                        <?php if ($isEnrolled): ?>
                            <a href="player.php?course=<?= $course['id'] ?>" 
                               class="btn btn-success btn-sm action-btn">
                                <i class="fas fa-play me-1"></i>متابعة
                            </a>
                        <?php else: ?>
                            <a href="course.php?id=<?= $course['id'] ?>" 
                               class="btn btn-primary btn-sm action-btn">
                                <i class="fas fa-eye me-1"></i>عرض
                            </a>
                        <?php endif; ?>
                        
                        <!-- Wishlist Button -->
                        <button class="btn btn-outline-danger btn-sm ms-1 wishlist-btn" 
                                onclick="toggleWishlist(<?= $course['id'] ?>)"
                                title="إضافة للمفضلة">
                            <i class="far fa-heart"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.course-card {
    transition: all 0.3s ease;
}

.course-card-hover:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.15) !important;
}

.course-image-container {
    overflow: hidden;
    height: 200px;
}

.course-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.course-card-hover:hover .course-image {
    transform: scale(1.05);
}

.course-preview-btn {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    opacity: 0;
    transition: opacity 0.3s ease;
}

.course-card-hover:hover .course-preview-btn {
    opacity: 1;
}

.course-title {
    font-size: 1.1rem;
    line-height: 1.4;
    min-height: 2.8rem;
}

.course-link:hover {
    color: #667eea !important;
}

.course-description {
    font-size: 0.9rem;
    line-height: 1.5;
    min-height: 3rem;
}

.course-stats .stat-item {
    padding: 0.5rem;
    border-radius: 8px;
    transition: background 0.3s ease;
}

.course-stats .stat-item:hover {
    background: #f8f9fa;
}

.course-stats i {
    font-size: 1.2rem;
    margin-bottom: 0.25rem;
}

.rating-stars {
    font-size: 0.9rem;
}

.level-badge {
    font-size: 0.75rem;
    font-weight: 600;
}

.category-badge {
    font-size: 0.8rem;
    border: 1px solid #dee2e6;
}

.action-btn {
    min-width: 70px;
    font-weight: 500;
}

.wishlist-btn {
    width: 32px;
    height: 32px;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;
}

.wishlist-btn.active {
    background: #dc3545;
    border-color: #dc3545;
    color: white;
}

.wishlist-btn.active i {
    class: "fas fa-heart";
}

@media (max-width: 768px) {
    .course-image-container {
        height: 180px;
    }
    
    .course-title {
        font-size: 1rem;
        min-height: 2.4rem;
    }
    
    .course-description {
        min-height: 2.5rem;
    }
    
    .course-stats {
        font-size: 0.8rem;
    }
}
</style>

<script>
// معاينة الدورة
function previewCourse(courseId) {
    // يمكن إضافة modal للمعاينة أو فتح رابط معاينة
    window.open(`course.php?id=${courseId}#preview`, '_blank');
}

// إضافة/إزالة من المفضلة
function toggleWishlist(courseId) {
    const btn = event.target.closest('.wishlist-btn');
    const icon = btn.querySelector('i');
    
    fetch('api.php?action=toggle_wishlist', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ course_id: courseId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            if (data.added) {
                btn.classList.add('active');
                icon.className = 'fas fa-heart';
                btn.title = 'إزالة من المفضلة';
            } else {
                btn.classList.remove('active');
                icon.className = 'far fa-heart';
                btn.title = 'إضافة للمفضلة';
            }
        } else {
            alert(data.message || 'حدث خطأ');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('حدث خطأ في الشبكة');
    });
}
</script>