<?php
/**
 * مكون الأقسام المنسدلة
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

function renderSectionAccordion($sections, $courseId, $userSubscribed = false) {
    if (empty($sections)) {
        return '<div class="text-center py-4">
                    <i class="fas fa-folder-open text-muted" style="font-size: 3rem;"></i>
                    <h5 class="text-muted mt-3">لا توجد أقسام في هذه الدورة</h5>
                </div>';
    }
    
    ob_start();
    ?>
    <div class="accordion" id="sectionsAccordion">
        <?php foreach ($sections as $index => $section): ?>
        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button <?php echo $index > 0 ? 'collapsed' : ''; ?>" 
                        type="button" 
                        data-bs-toggle="collapse" 
                        data-bs-target="#section<?php echo $section['id']; ?>"
                        data-section-id="<?php echo $section['id']; ?>"
                        onclick="loadSectionLessons(<?php echo $section['id']; ?>)">
                    <div class="section-header-content">
                        <div class="section-title">
                            <i class="fas fa-folder me-2"></i>
                            <?php echo htmlspecialchars($section['name']); ?>
                        </div>
                        <div class="section-meta">
                            <span class="badge bg-primary me-2">
                                <?php echo $section['lessons_count'] ?? 0; ?> درس
                            </span>
                            <?php if (!empty($section['total_duration'])): ?>
                            <span class="badge bg-info">
                                <?php echo formatDuration($section['total_duration']); ?>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </button>
            </h2>
            <div id="section<?php echo $section['id']; ?>" 
                 class="accordion-collapse collapse <?php echo $index === 0 ? 'show' : ''; ?>" 
                 data-bs-parent="#sectionsAccordion">
                <div class="accordion-body">
                    <div class="lessons-container" id="lessons-<?php echo $section['id']; ?>">
                        <div class="text-center py-3">
                            <div class="spinner-border spinner-border-sm text-primary" role="status"></div>
                            <small class="text-muted d-block mt-2">جاري تحميل الدروس...</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php
    return ob_get_clean();
}
?>