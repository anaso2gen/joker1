<?php
/**
 * مكون النماذج المتقدم
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:16:04
 */

// التأكد من وجود البيانات المطلوبة
if (!isset($formConfig)) {
    return;
}

$formId = $formConfig['id'] ?? 'dynamic-form';
$formMethod = $formConfig['method'] ?? 'POST';
$formAction = $formConfig['action'] ?? '';
$formClass = $formConfig['class'] ?? '';
$fields = $formConfig['fields'] ?? [];
$submitButton = $formConfig['submit'] ?? ['text' => 'إرسال', 'class' => 'btn-primary'];
?>

<form id="<?= $formId ?>" method="<?= $formMethod ?>" action="<?= $formAction ?>" 
      class="advanced-form <?= $formClass ?>" novalidate>
    
    <!-- CSRF Token -->
    <?php if ($formMethod === 'POST'): ?>
        <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
    <?php endif; ?>
    
    <!-- Dynamic Fields -->
    <?php foreach ($fields as $field): ?>
        <div class="form-group mb-3" data-field="<?= $field['name'] ?>">
            <?php
            $fieldType = $field['type'] ?? 'text';
            $fieldName = $field['name'] ?? '';
            $fieldLabel = $field['label'] ?? '';
            $fieldValue = $field['value'] ?? '';
            $fieldRequired = $field['required'] ?? false;
            $fieldPlaceholder = $field['placeholder'] ?? '';
            $fieldClass = $field['class'] ?? '';
            $fieldAttributes = $field['attributes'] ?? [];
            $fieldOptions = $field['options'] ?? [];
            $fieldValidation = $field['validation'] ?? [];
            $fieldHelp = $field['help'] ?? '';
            ?>
            
            <?php if ($fieldType === 'text' || $fieldType === 'email' || $fieldType === 'password' || $fieldType === 'tel' || $fieldType === 'url'): ?>
                <!-- Text Input -->
                <div class="form-floating">
                    <input type="<?= $fieldType ?>" 
                           class="form-control <?= $fieldClass ?>" 
                           id="<?= $fieldName ?>" 
                           name="<?= $fieldName ?>"
                           value="<?= htmlspecialchars($fieldValue) ?>"
                           placeholder="<?= htmlspecialchars($fieldPlaceholder ?: $fieldLabel) ?>"
                           <?= $fieldRequired ? 'required' : '' ?>
                           <?php foreach ($fieldAttributes as $attr => $value): ?>
                               <?= $attr ?>="<?= htmlspecialchars($value) ?>"
                           <?php endforeach; ?>>
                    <label for="<?= $fieldName ?>"><?= htmlspecialchars($fieldLabel) ?></label>
                    <?php if ($fieldRequired): ?>
                        <span class="required-asterisk">*</span>
                    <?php endif; ?>
                </div>
                
            <?php elseif ($fieldType === 'textarea'): ?>
                <!-- Textarea -->
                <div class="form-floating">
                    <textarea class="form-control <?= $fieldClass ?>" 
                              id="<?= $fieldName ?>" 
                              name="<?= $fieldName ?>"
                              placeholder="<?= htmlspecialchars($fieldPlaceholder ?: $fieldLabel) ?>"
                              style="height: <?= $field['height'] ?? '100px' ?>"
                              <?= $fieldRequired ? 'required' : '' ?>
                              <?php foreach ($fieldAttributes as $attr => $value): ?>
                                  <?= $attr ?>="<?= htmlspecialchars($value) ?>"
                              <?php endforeach; ?>><?= htmlspecialchars($fieldValue) ?></textarea>
                    <label for="<?= $fieldName ?>"><?= htmlspecialchars($fieldLabel) ?></label>
                    <?php if ($fieldRequired): ?>
                        <span class="required-asterisk">*</span>
                    <?php endif; ?>
                </div>
                
            <?php elseif ($fieldType === 'select'): ?>
                <!-- Select -->
                <div class="form-floating">
                    <select class="form-select <?= $fieldClass ?>" 
                            id="<?= $fieldName ?>" 
                            name="<?= $fieldName ?>"
                            <?= $fieldRequired ? 'required' : '' ?>
                            <?php foreach ($fieldAttributes as $attr => $value): ?>
                                <?= $attr ?>="<?= htmlspecialchars($value) ?>"
                            <?php endforeach; ?>>
                        <?php if (!$fieldRequired): ?>
                            <option value="">اختر...</option>
                        <?php endif; ?>
                        <?php foreach ($fieldOptions as $optionValue => $optionLabel): ?>
                            <option value="<?= htmlspecialchars($optionValue) ?>" 
                                    <?= $fieldValue == $optionValue ? 'selected' : '' ?>>
                                <?= htmlspecialchars($optionLabel) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <label for="<?= $fieldName ?>"><?= htmlspecialchars($fieldLabel) ?></label>
                    <?php if ($fieldRequired): ?>
                        <span class="required-asterisk">*</span>
                    <?php endif; ?>
                </div>
                
            <?php elseif ($fieldType === 'checkbox'): ?>
                <!-- Checkbox -->
                <div class="form-check">
                    <input class="form-check-input <?= $fieldClass ?>" 
                           type="checkbox" 
                           id="<?= $fieldName ?>" 
                           name="<?= $fieldName ?>"
                           value="1"
                           <?= $fieldValue ? 'checked' : '' ?>
                           <?= $fieldRequired ? 'required' : '' ?>
                           <?php foreach ($fieldAttributes as $attr => $value): ?>
                               <?= $attr ?>="<?= htmlspecialchars($value) ?>"
                           <?php endforeach; ?>>
                    <label class="form-check-label" for="<?= $fieldName ?>">
                        <?= htmlspecialchars($fieldLabel) ?>
                        <?php if ($fieldRequired): ?>
                            <span class="required-asterisk">*</span>
                        <?php endif; ?>
                    </label>
                </div>
                
            <?php elseif ($fieldType === 'radio'): ?>
                <!-- Radio Buttons -->
                <div class="form-group-label mb-2">
                    <label class="form-label"><?= htmlspecialchars($fieldLabel) ?></label>
                    <?php if ($fieldRequired): ?>
                        <span class="required-asterisk">*</span>
                    <?php endif; ?>
                </div>
                <?php foreach ($fieldOptions as $optionValue => $optionLabel): ?>
                    <div class="form-check">
                        <input class="form-check-input <?= $fieldClass ?>" 
                               type="radio" 
                               id="<?= $fieldName ?>_<?= $optionValue ?>" 
                               name="<?= $fieldName ?>"
                               value="<?= htmlspecialchars($optionValue) ?>"
                               <?= $fieldValue == $optionValue ? 'checked' : '' ?>
                               <?= $fieldRequired ? 'required' : '' ?>
                               <?php foreach ($fieldAttributes as $attr => $value): ?>
                                   <?= $attr ?>="<?= htmlspecialchars($value) ?>"
                               <?php endforeach; ?>>
                        <label class="form-check-label" for="<?= $fieldName ?>_<?= $optionValue ?>">
                            <?= htmlspecialchars($optionLabel) ?>
                        </label>
                    </div>
                <?php endforeach; ?>
                
            <?php elseif ($fieldType === 'file'): ?>
                <!-- File Upload -->
                <div class="file-upload-container">
                    <label class="form-label" for="<?= $fieldName ?>">
                        <?= htmlspecialchars($fieldLabel) ?>
                        <?php if ($fieldRequired): ?>
                            <span class="required-asterisk">*</span>
                        <?php endif; ?>
                    </label>
                    <div class="file-upload-wrapper">
                        <input type="file" 
                               class="form-control file-input <?= $fieldClass ?>" 
                               id="<?= $fieldName ?>" 
                               name="<?= $fieldName ?>"
                               <?= $fieldRequired ? 'required' : '' ?>
                               <?php foreach ($fieldAttributes as $attr => $value): ?>
                                   <?= $attr ?>="<?= htmlspecialchars($value) ?>"
                               <?php endforeach; ?>>
                        <div class="file-upload-preview" id="<?= $fieldName ?>_preview"></div>
                    </div>
                </div>
                
            <?php elseif ($fieldType === 'date' || $fieldType === 'datetime-local' || $fieldType === 'time'): ?>
                <!-- Date/Time Input -->
                <div class="form-floating">
                    <input type="<?= $fieldType ?>" 
                           class="form-control <?= $fieldClass ?>" 
                           id="<?= $fieldName ?>" 
                           name="<?= $fieldName ?>"
                           value="<?= htmlspecialchars($fieldValue) ?>"
                           <?= $fieldRequired ? 'required' : '' ?>
                           <?php foreach ($fieldAttributes as $attr => $value): ?>
                               <?= $attr ?>="<?= htmlspecialchars($value) ?>"
                           <?php endforeach; ?>>
                    <label for="<?= $fieldName ?>"><?= htmlspecialchars($fieldLabel) ?></label>
                    <?php if ($fieldRequired): ?>
                        <span class="required-asterisk">*</span>
                    <?php endif; ?>
                </div>
                
            <?php elseif ($fieldType === 'number'): ?>
                <!-- Number Input -->
                <div class="form-floating">
                    <input type="number" 
                           class="form-control <?= $fieldClass ?>" 
                           id="<?= $fieldName ?>" 
                           name="<?= $fieldName ?>"
                           value="<?= htmlspecialchars($fieldValue) ?>"
                           placeholder="<?= htmlspecialchars($fieldPlaceholder ?: $fieldLabel) ?>"
                           <?= $fieldRequired ? 'required' : '' ?>
                           <?php foreach ($fieldAttributes as $attr => $value): ?>
                               <?= $attr ?>="<?= htmlspecialchars($value) ?>"
                           <?php endforeach; ?>>
                    <label for="<?= $fieldName ?>"><?= htmlspecialchars($fieldLabel) ?></label>
                    <?php if ($fieldRequired): ?>
                        <span class="required-asterisk">*</span>
                    <?php endif; ?>
                </div>
                
            <?php elseif ($fieldType === 'hidden'): ?>
                <!-- Hidden Input -->
                <input type="hidden" 
                       id="<?= $fieldName ?>" 
                       name="<?= $fieldName ?>"
                       value="<?= htmlspecialchars($fieldValue) ?>">
                       
            <?php endif; ?>
            
            <!-- Field Help Text -->
            <?php if ($fieldHelp): ?>
                <div class="form-text"><?= htmlspecialchars($fieldHelp) ?></div>
            <?php endif; ?>
            
            <!-- Field Validation Feedback -->
            <div class="invalid-feedback" id="<?= $fieldName ?>_error"></div>
            <div class="valid-feedback">يبدو جيداً!</div>
        </div>
    <?php endforeach; ?>
    
    <!-- Submit Button -->
    <div class="form-submit mt-4">
        <button type="submit" class="btn <?= $submitButton['class'] ?> btn-lg w-100 submit-btn">
            <span class="submit-text">
                <i class="<?= $submitButton['icon'] ?? 'fas fa-paper-plane' ?> me-2"></i>
                <?= htmlspecialchars($submitButton['text']) ?>
            </span>
            <span class="submit-loading d-none">
                <i class="fas fa-spinner fa-spin me-2"></i>جاري الإرسال...
            </span>
        </button>
    </div>
</form>

<style>
.advanced-form {
    max-width: 100%;
}

.form-floating {
    position: relative;
    margin-bottom: 1rem;
}

.form-floating > .form-control:focus ~ label,
.form-floating > .form-control:not(:placeholder-shown) ~ label,
.form-floating > .form-select ~ label {
    opacity: 0.65;
    transform: scale(0.85) translateY(-0.5rem) translateX(0.15rem);
    color: #667eea;
}

.form-floating > .form-control:focus,
.form-floating > .form-select:focus {
    border-color: #667eea;
    box-shadow: 0 0 0 0.25rem rgba(102, 126, 234, 0.25);
}

.required-asterisk {
    color: #dc3545;
    margin-right: 0.25rem;
    font-weight: bold;
}

.form-check-input:checked {
    background-color: #667eea;
    border-color: #667eea;
}

.form-check-input:focus {
    border-color: #667eea;
    box-shadow: 0 0 0 0.25rem rgba(102, 126, 234, 0.25);
}

.file-upload-container {
    margin-bottom: 1rem;
}

.file-upload-wrapper {
    position: relative;
}

.file-input {
    border: 2px dashed #dee2e6;
    border-radius: 10px;
    padding: 2rem 1rem;
    text-align: center;
    transition: all 0.3s ease;
    cursor: pointer;
}

.file-input:hover {
    border-color: #667eea;
    background-color: rgba(102, 126, 234, 0.05);
}

.file-input:focus {
    border-color: #667eea;
    box-shadow: 0 0 0 0.25rem rgba(102, 126, 234, 0.25);
}

.file-upload-preview {
    margin-top: 1rem;
    text-align: center;
}

.file-upload-preview img {
    max-width: 200px;
    max-height: 200px;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.submit-btn {
    background: linear-gradient(45deg, #667eea, #764ba2);
    border: none;
    border-radius: 25px;
    padding: 1rem 2rem;
    font-weight: 600;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.submit-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
    transition: left 0.5s;
}

.submit-btn:hover::before {
    left: 100%;
}

.submit-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
}

.submit-btn:disabled {
    background: #6c757d;
    transform: none;
    box-shadow: none;
}

.form-control.is-invalid,
.form-select.is-invalid {
    border-color: #dc3545;
    box-shadow: 0 0 0 0.25rem rgba(220, 53, 69, 0.25);
}

.form-control.is-valid,
.form-select.is-valid {
    border-color: #28a745;
    box-shadow: 0 0 0 0.25rem rgba(40, 167, 69, 0.25);
}

.invalid-feedback {
    display: none;
    color: #dc3545;
    font-size: 0.875em;
    margin-top: 0.25rem;
}

.valid-feedback {
    display: none;
    color: #28a745;
    font-size: 0.875em;
    margin-top: 0.25rem;
}

.is-invalid ~ .invalid-feedback {
    display: block;
}

.is-valid ~ .valid-feedback {
    display: block;
}

.form-group-label {
    font-weight: 600;
    color: #333;
}

/* تحسينات الموبايل */
@media (max-width: 768px) {
    .submit-btn {
        padding: 0.8rem 1.5rem;
        font-size: 0.9rem;
    }
    
    .file-input {
        padding: 1.5rem 0.5rem;
    }
}

/* تأثيرات الأنيميشن */
.form-group {
    animation: slideInUp 0.3s ease-out;
}

@keyframes slideInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Real-time validation styles */
.field-validating {
    position: relative;
}

.field-validating::after {
    content: '';
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    width: 20px;
    height: 20px;
    border: 2px solid #667eea;
    border-top: 2px solid transparent;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% { transform: translateY(-50%) rotate(0deg); }
    100% { transform: translateY(-50%) rotate(360deg); }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('<?= $formId ?>');
    if (!form) return;
    
    // Real-time validation
    const fields = form.querySelectorAll('.form-control, .form-select, .form-check-input');
    
    fields.forEach(field => {
        // Validation on input/change
        field.addEventListener('input', function() {
            validateField(this);
        });
        
        field.addEventListener('blur', function() {
            validateField(this);
        });
        
        // File upload preview
        if (field.type === 'file') {
            field.addEventListener('change', function() {
                previewFile(this);
            });
        }
    });
    
    // Form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (validateForm()) {
            submitForm();
        }
    });
    
    // Field validation function
    function validateField(field) {
        const fieldContainer = field.closest('.form-group');
        const fieldName = field.name;
        const fieldValue = field.value.trim();
        const isRequired = field.hasAttribute('required');
        const fieldType = field.type;
        
        // Remove previous validation classes
        field.classList.remove('is-valid', 'is-invalid');
        fieldContainer.classList.remove('field-validating');
        
        let isValid = true;
        let errorMessage = '';
        
        // Required validation
        if (isRequired && !fieldValue) {
            isValid = false;
            errorMessage = 'هذا الحقل مطلوب';
        }
        
        // Type-specific validation
        if (fieldValue && isValid) {
            switch (fieldType) {
                case 'email':
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!emailRegex.test(fieldValue)) {
                        isValid = false;
                        errorMessage = 'يرجى إدخال بريد إلكتروني صحيح';
                    }
                    break;
                    
                case 'tel':
                    const phoneRegex = /^[\+]?[0-9\s\-\(\)]{10,}$/;
                    if (!phoneRegex.test(fieldValue)) {
                        isValid = false;
                        errorMessage = 'يرجى إدخال رقم هاتف صحيح';
                    }
                    break;
                    
                case 'password':
                    if (fieldValue.length < 8) {
                        isValid = false;
                        errorMessage = 'كلمة المرور يجب أن تكون 8 أحرف على الأقل';
                    } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(fieldValue)) {
                        isValid = false;
                        errorMessage = 'كلمة المرور يجب أن تحتوي على أحرف كبيرة وصغيرة وأرقام';
                    }
                    break;
                    
                case 'url':
                    try {
                        new URL(fieldValue);
                    } catch {
                        isValid = false;
                        errorMessage = 'يرجى إدخال رابط صحيح';
                    }
                    break;
            }
        }
        
        // Custom validation rules
        const customValidation = field.dataset.validation;
        if (customValidation && fieldValue && isValid) {
            // يمكن إضافة قواعد تحقق مخصصة هنا
        }
        
        // Apply validation results
        if (isValid) {
            field.classList.add('is-valid');
        } else {
            field.classList.add('is-invalid');
            const errorElement = fieldContainer.querySelector('.invalid-feedback');
            if (errorElement) {
                errorElement.textContent = errorMessage;
            }
        }
        
        return isValid;
    }
    
    // Form validation
    function validateForm() {
        let isFormValid = true;
        
        fields.forEach(field => {
            if (!validateField(field)) {
                isFormValid = false;
            }
        });
        
        return isFormValid;
    }
    
    // File preview
    function previewFile(input) {
        const file = input.files[0];
        const previewContainer = document.getElementById(input.name + '_preview');
        
        if (!previewContainer) return;
        
        previewContainer.innerHTML = '';
        
        if (file) {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                if (file.type.startsWith('image/')) {
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.style.maxWidth = '200px';
                    img.style.maxHeight = '200px';
                    img.style.borderRadius = '10px';
                    previewContainer.appendChild(img);
                } else {
                    const fileInfo = document.createElement('div');
                    fileInfo.className = 'alert alert-info';
                    fileInfo.innerHTML = `
                        <i class="fas fa-file me-2"></i>
                        <strong>${file.name}</strong><br>
                        <small>الحجم: ${(file.size / 1024 / 1024).toFixed(2)} ميجابايت</small>
                    `;
                    previewContainer.appendChild(fileInfo);
                }
            };
            
            reader.readAsDataURL(file);
        }
    }
    
    // Form submission
    function submitForm() {
        const submitBtn = form.querySelector('.submit-btn');
        const submitText = submitBtn.querySelector('.submit-text');
        const submitLoading = submitBtn.querySelector('.submit-loading');
        
        // Show loading state
        submitBtn.disabled = true;
        submitText.classList.add('d-none');
        submitLoading.classList.remove('d-none');
        
        // Create FormData
        const formData = new FormData(form);
        
        // Submit via AJAX
        fetch(form.action || window.location.href, {
            method: form.method,
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Success handling
                showAlert('success', data.message || 'تم الإرسال بنجاح');
                
                if (data.redirect) {
                    setTimeout(() => {
                        window.location.href = data.redirect;
                    }, 1000);
                } else {
                    form.reset();
                }
            } else {
                // Error handling
                showAlert('danger', data.message || 'حدث خطأ أثناء الإرسال');
                
                // Field-specific errors
                if (data.errors) {
                    Object.keys(data.errors).forEach(fieldName => {
                        const field = form.querySelector(`[name="${fieldName}"]`);
                        if (field) {
                            field.classList.add('is-invalid');
                            const errorElement = field.closest('.form-group').querySelector('.invalid-feedback');
                            if (errorElement) {
                                errorElement.textContent = data.errors[fieldName];
                            }
                        }
                    });
                }
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showAlert('danger', 'حدث خطأ في الشبكة');
        })
        .finally(() => {
            // Reset button state
            submitBtn.disabled = false;
            submitText.classList.remove('d-none');
            submitLoading.classList.add('d-none');
        });
    }
    
    // Show alert
    function showAlert(type, message) {
        const alertContainer = document.createElement('div');
        alertContainer.className = `alert alert-${type} alert-dismissible fade show`;
        alertContainer.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        form.insertBefore(alertContainer, form.firstChild);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            alertContainer.remove();
        }, 5000);
    }
});
</script>