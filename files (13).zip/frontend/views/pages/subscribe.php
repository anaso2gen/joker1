<?php
/**
 * واجهة صفحة الاشتراك مع التحقق من الأكواد ومعاينة الدورات
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

// تضمين رأس الصفحة
include_once __DIR__ . '/../layout/header.php';
?>

<div class="subscribe-container py-5">
    <div class="container">
        <!-- Hero Section -->
        <div class="row justify-content-center mb-5">
            <div class="col-lg-8 text-center" data-aos="fade-up">
                <div class="subscribe-hero">
                    <lottie-player
                        src="https://assets1.lottiefiles.com/packages/lf20_jcikwtux.json"
                        background="transparent"
                        speed="1"
                        style="width: 150px; height: 150px; margin: 0 auto;"
                        loop
                        autoplay>
                    </lottie-player>
                    
                    <h1 class="hero-title mt-3 mb-3">فعل اشتراكك الآن</h1>
                    <p class="hero-subtitle text-muted">
                        أدخل كود التفعيل الخاص بك للوصول إلى الدورة التدريبية
                    </p>
                </div>
            </div>
        </div>
        
        <!-- Subscription Form -->
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-8">
                <div class="subscription-card" data-aos="fade-up" data-aos-delay="200">
                    <div class="card-header text-center">
                        <h4 class="mb-0">
                            <i class="fas fa-key me-2 text-primary"></i>
                            كود التفعيل
                        </h4>
                    </div>
                    
                    <div class="card-body">
                        <!-- Code Input Form -->
                        <form id="subscriptionForm" class="subscription-form">
                            <div class="mb-4">
                                <label for="activationCode" class="form-label fw-bold">
                                    <i class="fas fa-ticket-alt me-2"></i>
                                    كود التفعيل
                                </label>
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text">
                                        <i class="fas fa-hashtag"></i>
                                    </span>
                                    <input type="text" 
                                           class="form-control code-input" 
                                           id="activationCode" 
                                           name="code"
                                           placeholder="أدخل كود التفعيل"
                                           autocomplete="off"
                                           required>
                                    <button type="button" 
                                            class="btn btn-outline-secondary" 
                                            id="validateCodeBtn"
                                            title="التحقق من الكود">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                                <div class="invalid-feedback"></div>
                                <small class="form-text text-muted">
                                    <i class="fas fa-info-circle me-1"></i>
                                    كود التفعيل يتكون من أحرف وأرقام باللغة الإنجليزية
                                </small>
                            </div>
                            
                            <!-- Code Validation Result -->
                            <div id="codeValidationResult" class="code-result d-none mb-4">
                                <!-- سيتم عرض نتيجة التحقق هنا -->
                            </div>
                            
                            <!-- Subscription Button -->
                            <div class="d-grid">
                                <button type="submit" 
                                        class="btn btn-primary btn-lg subscription-btn" 
                                        id="subscribeBtn"
                                        disabled>
                                    <span class="btn-text">
                                        <i class="fas fa-rocket me-2"></i>
                                        تفعيل الاشتراك
                                    </span>
                                    <span class="btn-spinner d-none">
                                        <span class="spinner-border spinner-border-sm me-2"></span>
                                        جاري التفعيل...
                                    </span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Help Section -->
                <div class="help-section mt-4" data-aos="fade-up" data-aos-delay="400">
                    <div class="card border-info">
                        <div class="card-body">
                            <h6 class="card-title text-info">
                                <i class="fas fa-question-circle me-2"></i>
                                هل تحتاج مساعدة؟
                            </h6>
                            <div class="help-content">
                                <div class="accordion" id="helpAccordion">
                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button" 
                                                    data-bs-toggle="collapse" data-bs-target="#help1">
                                                أين أجد كود التفعيل؟
                                            </button>
                                        </h2>
                                        <div id="help1" class="accordion-collapse collapse" data-bs-parent="#helpAccordion">
                                            <div class="accordion-body">
                                                <p>يمكنك العثور على كود التفعيل في:</p>
                                                <ul>
                                                    <li>البريد الإلكتروني المرسل إليك بعد الشراء</li>
                                                    <li>رسالة التأكيد النصية</li>
                                                    <li>إيصال الشراء</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button" 
                                                    data-bs-toggle="collapse" data-bs-target="#help2">
                                                كود التفعيل لا يعمل؟
                                            </button>
                                        </h2>
                                        <div id="help2" class="accordion-collapse collapse" data-bs-parent="#helpAccordion">
                                            <div class="accordion-body">
                                                <p>تأكد من الآتي:</p>
                                                <ul>
                                                    <li>إدخال الكود بشكل صحيح (بدون مسافات)</li>
                                                    <li>عدم انتهاء صلاحية الكود</li>
                                                    <li>عدم استخدام الكود مسبقاً</li>
                                                </ul>
                                                <p>إذا استمرت المشكلة، تواصل مع الدعم الفني.</p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button" 
                                                    data-bs-toggle="collapse" data-bs-target="#help3">
                                                كيف أتواصل مع الدعم؟
                                            </button>
                                        </h2>
                                        <div id="help3" class="accordion-collapse collapse" data-bs-parent="#helpAccordion">
                                            <div class="accordion-body">
                                                <p>يمكنك التواصل معنا عبر:</p>
                                                <div class="contact-methods">
                                                    <a href="mailto:support@example.com" class="btn btn-sm btn-outline-primary me-2">
                                                        <i class="fas fa-envelope me-1"></i>البريد الإلكتروني
                                                    </a>
                                                    <a href="tel:+966123456789" class="btn btn-sm btn-outline-success me-2">
                                                        <i class="fas fa-phone me-1"></i>الهاتف
                                                    </a>
                                                    <a href="/contact.php" class="btn btn-sm btn-outline-info">
                                                        <i class="fas fa-comments me-1"></i>المحادثة المباشرة
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- My Subscriptions -->
        <div class="row mt-5">
            <div class="col-12">
                <div class="my-subscriptions" data-aos="fade-up">
                    <div class="section-header text-center mb-4">
                        <h3>
                            <i class="fas fa-graduation-cap me-2 text-primary"></i>
                            اشتراكاتي الحالية
                        </h3>
                        <p class="text-muted">الدورات التي أنت مشترك بها حالياً</p>
                    </div>
                    
                    <div id="mySubscriptions" class="subscriptions-grid">
                        <!-- Loading State -->
                        <div class="loading-subscriptions text-center py-5">
                            <div class="spinner-border text-primary mb-3"></div>
                            <p class="text-muted">جاري تحميل اشتراكاتك...</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Success Modal -->
<div class="modal fade" id="successModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-success">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title">
                    <i class="fas fa-check-circle me-2"></i>
                    تم التفعيل بنجاح!
                </h5>
            </div>
            <div class="modal-body text-center">
                <lottie-player
                    src="https://assets4.lottiefiles.com/packages/lf20_lk80fpsm.json"
                    background="transparent"
                    speed="1"
                    style="width: 150px; height: 150px; margin: 0 auto;"
                    autoplay>
                </lottie-player>
                
                <h6 class="mt-3 text-success">تهانينا!</h6>
                <p id="successMessage" class="text-muted"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" id="startLearningBtn">
                    <i class="fas fa-play me-2"></i>ابدأ التعلم الآن
                </button>
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    إغلاق
                </button>
            </div>
        </div>
    </div>
</div>

<style>
/* تنسيقات صفحة الاشتراك */
.subscribe-page {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    min-height: 100vh;
}

.subscribe-container {
    position: relative;
    z-index: 1;
}

.hero-title {
    font-size: 2.5rem;
    font-weight: 700;
    color: #2c3e50;
    margin-bottom: 1rem;
}

.hero-subtitle {
    font-size: 1.125rem;
    line-height: 1.6;
}

.subscription-card {
    background: white;
    border-radius: 20px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.1);
    overflow: hidden;
    border: none;
}

.subscription-card .card-header {
    background: linear-gradient(135deg, #007bff, #0056b3);
    color: white;
    padding: 2rem 2rem 1.5rem;
    border: none;
}

.subscription-card .card-body {
    padding: 2rem;
}

.code-input {
    font-family: 'Courier New', monospace;
    font-size: 1.125rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 2px;
    text-align: center;
    border: 2px solid #e9ecef;
    transition: all 0.3s ease;
}

.code-input:focus {
    border-color: #007bff;
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    transform: scale(1.02);
}

.code-input.is-valid {
    border-color: #28a745;
    background-color: #f8fff9;
}

.code-input.is-invalid {
    border-color: #dc3545;
    background-color: #fff8f8;
}

.subscription-btn {
    padding: 1rem 2rem;
    font-size: 1.125rem;
    font-weight: 600;
    border-radius: 50px;
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
}

.subscription-btn:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(0, 123, 255, 0.3);
}

.subscription-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}

.code-result {
    border-radius: 15px;
    padding: 1.5rem;
    margin: 1rem 0;
    animation: slideDown 0.3s ease-out;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.code-result.valid {
    background: linear-gradient(135deg, #d4edda, #c3e6cb);
    border: 2px solid #28a745;
    color: #155724;
}

.code-result.invalid {
    background: linear-gradient(135deg, #f8d7da, #f1aeb5);
    border: 2px solid #dc3545;
    color: #721c24;
}

.course-preview {
    background: white;
    border-radius: 15px;
    padding: 1.5rem;
    margin-top: 1rem;
    box-shadow: 0 5px 20px rgba(0,0,0,0.1);
}

.course-image {
    width: 80px;
    height: 80px;
    border-radius: 15px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 2rem;
}

.course-info h5 {
    color: #2c3e50;
    font-weight: 600;
    margin-bottom: 0.5rem;
}

.course-meta {
    display: flex;
    gap: 1rem;
    font-size: 0.875rem;
    color: #6c757d;
}

.help-section .accordion-button {
    font-weight: 500;
    padding: 1rem 1.25rem;
}

.help-section .accordion-button:not(.collapsed) {
    background: rgba(13, 202, 240, 0.1);
    color: #0dcaf0;
}

.contact-methods {
    margin-top: 1rem;
}

.subscriptions-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 1.5rem;
    margin-top: 2rem;
}

.subscription-item {
    background: white;
    border-radius: 15px;
    padding: 1.5rem;
    box-shadow: 0 5px 20px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
    border: 1px solid #e9ecef;
}

.subscription-item:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 40px rgba(0,0,0,0.15);
    border-color: #007bff;
}

.subscription-course {
    display: flex;
    align-items: center;
    margin-bottom: 1rem;
}

.subscription-course-image {
    width: 60px;
    height: 60px;
    border-radius: 10px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    margin-right: 1rem;
}

.subscription-course-info h6 {
    margin: 0 0 0.25rem 0;
    color: #2c3e50;
    font-weight: 600;
}

.subscription-progress {
    margin: 1rem 0;
}

.progress {
    height: 8px;
    border-radius: 4px;
    background: #e9ecef;
}

.progress-bar {
    background: linear-gradient(90deg, #007bff, #0056b3);
    border-radius: 4px;
}

.subscription-stats {
    display: flex;
    justify-content: space-between;
    margin-bottom: 1rem;
    font-size: 0.875rem;
    color: #6c757d;
}

.subscription-actions {
    display: flex;
    gap: 0.5rem;
}

/* Loading States */
.loading-subscriptions {
    grid-column: 1 / -1;
}

/* Empty State */
.empty-subscriptions {
    grid-column: 1 / -1;
    text-align: center;
    padding: 3rem 1rem;
}

.empty-subscriptions i {
    font-size: 4rem;
    color: #dee2e6;
    margin-bottom: 1rem;
}

/* Responsive Design */
@media (max-width: 768px) {
    .hero-title {
        font-size: 2rem;
    }
    
    .subscription-card .card-header,
    .subscription-card .card-body {
        padding: 1.5rem;
    }
    
    .code-input {
        font-size: 1rem;
        letter-spacing: 1px;
    }
    
    .subscriptions-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
    
    .contact-methods .btn {
        display: block;
        width: 100%;
        margin-bottom: 0.5rem;
    }
}

/* Animation Classes */
.fade-in {
    animation: fadeIn 0.5s ease-in;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

.bounce-in {
    animation: bounceIn 0.6s ease-out;
}

@keyframes bounceIn {
    0% { transform: scale(0.3); opacity: 0; }
    50% { transform: scale(1.05); }
    70% { transform: scale(0.9); }
    100% { transform: scale(1); opacity: 1; }
}

/* Dark Theme Support */
.theme-dark .subscription-card {
    background: #2d2d2d;
}

.theme-dark .code-input {
    background: #404040;
    border-color: #555;
    color: #fff;
}

.theme-dark .code-input:focus {
    background: #404040;
    color: #fff;
}

.theme-dark .course-preview {
    background: #404040;
}

.theme-dark .subscription-item {
    background: #2d2d2d;
    border-color: #404040;
}

.theme-dark .help-section .card {
    background: #2d2d2d;
    border-color: #17a2b8;
}
</style>

<?php
// JavaScript مخصص للصفحة
$additionalScripts = '
<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    initializeSubscribePage();
});

// تهيئة صفحة الاشتراك
function initializeSubscribePage() {
    loadMySubscriptions();
    setupCodeValidation();
    setupSubscriptionForm();
    setupHelpSection();
}

// تحميل اشتراكاتي
async function loadMySubscriptions() {
    try {
        const response = await fetchAPI("/api/subscribe/my_courses");
        
        if (response.success) {
            displayMySubscriptions(response.data.subscriptions);
        } else {
            showEmptySubscriptions();
        }
    } catch (error) {
        console.error("Error loading subscriptions:", error);
        showSubscriptionsError();
    }
}

// عرض الاشتراكات
function displayMySubscriptions(subscriptions) {
    const container = document.getElementById("mySubscriptions");
    
    if (subscriptions.length === 0) {
        showEmptySubscriptions();
        return;
    }
    
    container.innerHTML = "";
    
    subscriptions.forEach(subscription => {
        const item = createSubscriptionItem(subscription);
        container.appendChild(item);
    });
}

// إنشاء عنصر اشتراك
function createSubscriptionItem(subscription) {
    const item = document.createElement("div");
    item.className = "subscription-item fade-in";
    
    const progressPercentage = subscription.progress_percentage || 0;
    const completedLessons = subscription.completed_lessons || 0;
    const totalLessons = subscription.lessons_count || 0;
    
    item.innerHTML = `
        <div class="subscription-course">
            <div class="subscription-course-image">
                ${subscription.image_url ? 
                    `<img src="${subscription.image_url}" alt="${subscription.name}" class="w-100 h-100" style="object-fit: cover; border-radius: 10px;">` :
                    `<i class="fas fa-graduation-cap"></i>`
                }
            </div>
            <div class="subscription-course-info">
                <h6>${subscription.name}</h6>
                <small class="text-muted">مشترك منذ: ${formatDate(subscription.subscribed_at)}</small>
            </div>
        </div>
        
        <div class="subscription-progress">
            <div class="d-flex justify-content-between mb-2">
                <small class="text-muted">التقدم</small>
                <small class="fw-bold">${Math.round(progressPercentage)}%</small>
            </div>
            <div class="progress">
                <div class="progress-bar" style="width: ${progressPercentage}%"></div>
            </div>
        </div>
        
        <div class="subscription-stats">
            <span><i class="fas fa-play-circle me-1"></i>${completedLessons}/${totalLessons} درس</span>
            <span><i class="fas fa-clock me-1"></i>${subscription.total_duration || "غير محدد"}</span>
        </div>
        
        <div class="subscription-actions">
            <a href="/course.php?id=${subscription.course_id}" class="btn btn-primary btn-sm flex-fill">
                <i class="fas fa-eye me-1"></i>عرض الدورة
            </a>
            ${completedLessons > 0 ? 
                `<a href="/player.php?lesson_id=${subscription.last_lesson_id || ""}" class="btn btn-outline-success btn-sm">
                    <i class="fas fa-play me-1"></i>متابعة
                </a>` : 
                `<a href="/course.php?id=${subscription.course_id}" class="btn btn-outline-primary btn-sm">
                    <i class="fas fa-rocket me-1"></i>ابدأ
                </a>`
            }
        </div>
    `;
    
    return item;
}

// عرض حالة فارغة للاشتراكات
function showEmptySubscriptions() {
    const container = document.getElementById("mySubscriptions");
    container.innerHTML = `
        <div class="empty-subscriptions">
            <i class="fas fa-graduation-cap"></i>
            <h5 class="text-muted">لا توجد اشتراكات حالياً</h5>
            <p class="text-muted">استخدم كود التفعيل أعلاه للاشتراك في دورة جديدة</p>
        </div>
    `;
}

// عرض خطأ في تحميل الاشتراكات
function showSubscriptionsError() {
    const container = document.getElementById("mySubscriptions");
    container.innerHTML = `
        <div class="empty-subscriptions">
            <i class="fas fa-exclamation-triangle text-warning"></i>
            <h5 class="text-warning">خطأ في تحميل الاشتراكات</h5>
            <button class="btn btn-primary mt-2" onclick="loadMySubscriptions()">
                <i class="fas fa-redo me-1"></i>إعادة المحاولة
            </button>
        </div>
    `;
}

// إعداد التحقق من الكود
function setupCodeValidation() {
    const codeInput = document.getElementById("activationCode");
    const validateBtn = document.getElementById("validateCodeBtn");
    const subscribeBtn = document.getElementById("subscribeBtn");
    
    // التحقق التلقائي عند الكتابة
    let validateTimeout;
    codeInput.addEventListener("input", function() {
        clearTimeout(validateTimeout);
        const code = this.value.trim();
        
        // إخفاء النتائج السابقة
        hideValidationResult();
        subscribeBtn.disabled = true;
        
        if (code.length >= 3) {
            validateTimeout = setTimeout(() => {
                validateCode(code);
            }, 1000);
        }
    });
    
    // زر التحقق اليدوي
    validateBtn.addEventListener("click", function() {
        const code = codeInput.value.trim();
        if (code) {
            validateCode(code);
        }
    });
}

// التحقق من صحة الكود
async function validateCode(code) {
    const resultContainer = document.getElementById("codeValidationResult");
    const subscribeBtn = document.getElementById("subscribeBtn");
    const codeInput = document.getElementById("activationCode");
    
    try {
        showValidationLoading();
        
        const response = await fetchAPI("/api/subscribe/check_code", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: `code=${encodeURIComponent(code)}&_token=${document.querySelector(\'meta[name="csrf-token"]\')?.content || ""}`
        });
        
        if (response.success && response.data.valid) {
            showValidationSuccess(response.data.code_info);
            codeInput.classList.remove("is-invalid");
            codeInput.classList.add("is-valid");
            subscribeBtn.disabled = false;
        } else {
            showValidationError(response.message || "الكود غير صالح");
            codeInput.classList.remove("is-valid");
            codeInput.classList.add("is-invalid");
            subscribeBtn.disabled = true;
        }
    } catch (error) {
        console.error("Code validation error:", error);
        showValidationError("خطأ في التحقق من الكود");
        codeInput.classList.remove("is-valid");
        codeInput.classList.add("is-invalid");
        subscribeBtn.disabled = true;
    }
}

// عرض تحميل التحقق
function showValidationLoading() {
    const container = document.getElementById("codeValidationResult");
    container.className = "code-result";
    container.innerHTML = `
        <div class="text-center">
            <div class="spinner-border spinner-border-sm text-primary me-2"></div>
            <span>جاري التحقق من الكود...</span>
        </div>
    `;
    container.classList.remove("d-none");
}

// عرض نجاح التحقق
function showValidationSuccess(codeInfo) {
    const container = document.getElementById("codeValidationResult");
    container.className = "code-result valid";
    container.innerHTML = `
        <div class="d-flex align-items-start">
            <i class="fas fa-check-circle fa-2x text-success me-3 mt-1"></i>
            <div class="flex-grow-1">
                <h6 class="mb-2">
                    <i class="fas fa-graduation-cap me-2"></i>
                    ${codeInfo.course_name}
                </h6>
                <p class="mb-2">${codeInfo.course_description || "وصف غير متاح"}</p>
                <div class="course-preview">
                    <div class="d-flex align-items-center">
                        <div class="course-image me-3">
                            ${codeInfo.course_image ? 
                                `<img src="${codeInfo.course_image}" alt="${codeInfo.course_name}" class="w-100 h-100" style="object-fit: cover; border-radius: 15px;">` :
                                `<i class="fas fa-graduation-cap"></i>`
                            }
                        </div>
                        <div class="course-info flex-grow-1">
                            <div class="course-meta">
                                <span><i class="fas fa-users me-1"></i>${codeInfo.stats?.subscribers_count || 0} طالب</span>
                                <span><i class="fas fa-play-circle me-1"></i>${codeInfo.stats?.lessons_count || 0} درس</span>
                                <span><i class="fas fa-clock me-1"></i>${codeInfo.stats?.total_duration || "غير محدد"}</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mt-2">
                    <small class="text-success">
                        <i class="fas fa-info-circle me-1"></i>
                        الكود صالح وجاهز للتفعيل
                        ${codeInfo.remaining_uses !== "غير محدود" ? ` • ${codeInfo.remaining_uses} استخدام متبقي` : ""}
                    </small>
                </div>
            </div>
        </div>
    `;
    container.classList.remove("d-none");
}

// عرض خطأ التحقق
function showValidationError(message) {
    const container = document.getElementById("codeValidationResult");
    container.className = "code-result invalid";
    container.innerHTML = `
        <div class="d-flex align-items-center">
            <i class="fas fa-times-circle fa-2x text-danger me-3"></i>
            <div>
                <h6 class="mb-1">كود غير صالح</h6>
                <p class="mb-0">${message}</p>
            </div>
        </div>
    `;
    container.classList.remove("d-none");
}

// إخفاء نتيجة التحقق
function hideValidationResult() {
    const container = document.getElementById("codeValidationResult");
    container.classList.add("d-none");
}

// إعداد نموذج الاشتراك
function setupSubscriptionForm() {
    const form = document.getElementById("subscriptionForm");
    const subscribeBtn = document.getElementById("subscribeBtn");
    
    form.addEventListener("submit", async function(e) {
        e.preventDefault();
        
        const code = document.getElementById("activationCode").value.trim();
        if (!code) return;
        
        setButtonLoading(subscribeBtn, true);
        
        try {
            const response = await fetchAPI("/api/subscribe/activate", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                body: `code=${encodeURIComponent(code)}&_token=${document.querySelector(\'meta[name="csrf-token"]\')?.content || ""}`
            });
            
            if (response.success) {
                showSuccessModal(response.data.subscription);
                form.reset();
                hideValidationResult();
                subscribeBtn.disabled = true;
                loadMySubscriptions(); // إعادة تحميل الاشتراكات
            } else {
                showToast(response.message || "خطأ في تفعيل الاشتراك", "error");
            }
        } catch (error) {
            console.error("Subscription error:", error);
            showToast("خطأ في تفعيل الاشتراك", "error");
        } finally {
            setButtonLoading(subscribeBtn, false);
        }
    });
}

// عرض مودال النجاح
function showSuccessModal(subscription) {
    const modal = new bootstrap.Modal(document.getElementById("successModal"));
    const message = document.getElementById("successMessage");
    const startBtn = document.getElementById("startLearningBtn");
    
    message.textContent = `تم تفعيل اشتراكك في دورة "${subscription.course_name}" بنجاح!`;
    
    startBtn.onclick = function() {
        window.location.href = `/course.php?id=${subscription.course_id}`;
    };
    
    modal.show();
}

// إعداد قسم المساعدة
function setupHelpSection() {
    // إضافة تأثيرات بصرية للأكورديون
    const accordionItems = document.querySelectorAll(".accordion-button");
    
    accordionItems.forEach(button => {
        button.addEventListener("click", function() {
            // إضافة تأثير بصري عند الفتح
            setTimeout(() => {
                if (!this.classList.contains("collapsed")) {
                    this.closest(".accordion-item").classList.add("bounce-in");
                }
            }, 100);
        });
    });
}

// تنسيق التاريخ
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString("ar-SA", {
        year: "numeric",
        month: "long",
        day: "numeric"
    });
}

// دالة مساعدة لحالة التحميل للأزرار
function setButtonLoading(button, isLoading) {
    const textSpan = button.querySelector(".btn-text");
    const spinnerSpan = button.querySelector(".btn-spinner");
    
    if (isLoading) {
        button.disabled = true;
        if (textSpan) textSpan.classList.add("d-none");
        if (spinnerSpan) spinnerSpan.classList.remove("d-none");
    } else {
        button.disabled = false;
        if (textSpan) textSpan.classList.remove("d-none");
        if (spinnerSpan) spinnerSpan.classList.add("d-none");
    }
}
</script>
';

// تضمين تذييل الصفحة
include_once __DIR__ . '/../layout/footer.php';
?>