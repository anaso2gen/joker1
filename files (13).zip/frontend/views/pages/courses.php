<?php
/**
 * صفحة عرض جميع الدورات - العرض
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:06:39
 */

$pageTitle = 'جميع الدورات التدريبية';
$pageDescription = 'استكشف مجموعة واسعة من الدورات التدريبية المتخصصة في مختلف المجالات';

include __DIR__ . '/../layout/header.php';
?>

<style>
    .courses-hero {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 4rem 0 2rem;
        position: relative;
        overflow: hidden;
    }
    
    .courses-hero::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="pattern" width="20" height="20" patternUnits="userSpaceOnUse"><circle cx="10" cy="10" r="2" fill="rgba(255,255,255,0.1)"/></pattern></defs><rect width="100" height="100" fill="url(%23pattern)"/></svg>');
        opacity: 0.3;
    }
    
    .courses-hero > * {
        position: relative;
        z-index: 1;
    }
    
    .search-section {
        background: white;
        border-radius: 20px;
        padding: 2rem;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        margin-top: -3rem;
        position: relative;
        z-index: 2;
    }
    
    .filter-sidebar {
        background: white;
        border-radius: 15px;
        padding: 1.5rem;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        position: sticky;
        top: 100px;
    }
    
    .filter-group {
        margin-bottom: 2rem;
    }
    
    .filter-title {
        font-weight: 600;
        color: #333;
        margin-bottom: 1rem;
        padding-bottom: 0.5rem;
        border-bottom: 2px solid #667eea;
    }
    
    .filter-option {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0.5rem 0;
        cursor: pointer;
        transition: all 0.3s ease;
        border-radius: 8px;
        padding: 0.5rem 0.8rem;
    }
    
    .filter-option:hover {
        background: #f8f9fa;
    }
    
    .filter-option input[type="checkbox"],
    .filter-option input[type="radio"] {
        margin-left: 0.5rem;
    }
    
    .filter-count {
        background: #e9ecef;
        color: #6c757d;
        padding: 0.2rem 0.5rem;
        border-radius: 12px;
        font-size: 0.8rem;
    }
    
    .courses-header {
        display: flex;
        justify-content: between;
        align-items: center;
        flex-wrap: wrap;
        gap: 1rem;
        margin-bottom: 2rem;
    }
    
    .courses-count {
        color: #6c757d;
    }
    
    .sort-dropdown {
        min-width: 200px;
    }
    
    .courses-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 2rem;
        margin-bottom: 3rem;
    }
    
    .course-card-wrapper {
        transition: transform 0.3s ease;
    }
    
    .course-card-wrapper:hover {
        transform: translateY(-5px);
    }
    
    .no-courses {
        text-align: center;
        padding: 4rem 2rem;
        color: #6c757d;
    }
    
    .no-courses i {
        font-size: 4rem;
        margin-bottom: 1rem;
        opacity: 0.5;
    }
    
    .pagination-wrapper {
        display: flex;
        justify-content: center;
        margin-top: 3rem;
    }
    
    .page-link {
        border-radius: 8px;
        margin: 0 2px;
        border: none;
        background: #f8f9fa;
        color: #667eea;
    }
    
    .page-link:hover {
        background: #667eea;
        color: white;
    }
    
    .page-item.active .page-link {
        background: #667eea;
        border-color: #667eea;
    }
    
    .level-badge {
        font-size: 0.75rem;
        padding: 0.3rem 0.6rem;
        border-radius: 12px;
    }
    
    .level-beginner {
        background: #d4edda;
        color: #155724;
    }
    
    .level-intermediate {
        background: #fff3cd;
        color: #856404;
    }
    
    .level-advanced {
        background: #f8d7da;
        color: #721c24;
    }
    
    .search-input {
        border-radius: 25px;
        border: 2px solid #e9ecef;
        padding: 0.8rem 1.5rem;
        font-size: 1.1rem;
        transition: all 0.3s ease;
    }
    
    .search-input:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 0.25rem rgba(102, 126, 234, 0.25);
    }
    
    .search-btn {
        border-radius: 25px;
        padding: 0.8rem 2rem;
        background: linear-gradient(45deg, #667eea, #764ba2);
        border: none;
        color: white;
        font-weight: 600;
    }
    
    .search-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        color: white;
    }
    
    .quick-filters {
        display: flex;
        gap: 0.5rem;
        flex-wrap: wrap;
        margin-top: 1rem;
    }
    
    .quick-filter {
        background: #f8f9fa;
        border: 1px solid #e9ecef;
        border-radius: 20px;
        padding: 0.4rem 1rem;
        text-decoration: none;
        color: #6c757d;
        transition: all 0.3s ease;
        font-size: 0.9rem;
    }
    
    .quick-filter:hover,
    .quick-filter.active {
        background: #667eea;
        color: white;
        border-color: #667eea;
    }
    
    .loading-skeleton {
        animation: pulse 1.5s ease-in-out infinite;
    }
    
    @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.5; }
        100% { opacity: 1; }
    }
    
    @media (max-width: 768px) {
        .courses-hero {
            padding: 2rem 0 1rem;
        }
        
        .search-section {
            margin-top: -2rem;
            padding: 1.5rem;
        }
        
        .filter-sidebar {
            position: static;
            margin-bottom: 2rem;
        }
        
        .courses-header {
            flex-direction: column;
            align-items: stretch;
        }
        
        .courses-grid {
            grid-template-columns: 1fr;
            gap: 1.5rem;
        }
        
        .quick-filters {
            justify-content: center;
        }
    }
</style>

<!-- Hero Section -->
<section class="courses-hero">
    <div class="container">
        <div class="text-center">
            <h1 class="display-4 fw-bold mb-3" data-aos="fade-up">
                اكتشف الدورات التدريبية
            </h1>
            <p class="lead mb-0" data-aos="fade-up" data-aos-delay="100">
                أكثر من <?= number_format($totalCourses) ?> دورة تدريبية في مختلف المجالات
            </p>
        </div>
    </div>
</section>

<!-- Search Section -->
<div class="container">
    <div class="search-section" data-aos="fade-up" data-aos-delay="200">
        <form method="get" action="courses.php">
            <div class="row align-items-end">
                <div class="col-lg-6">
                    <label for="search" class="form-label fw-bold">البحث عن الدورات</label>
                    <input type="text" class="form-control search-input" id="search" name="search" 
                           placeholder="ابحث عن اسم الدورة، الوصف، أو الكلمات المفتاحية..." 
                           value="<?= htmlspecialchars($search) ?>">
                </div>
                
                <div class="col-lg-3">
                    <label for="category" class="form-label fw-bold">الفئة</label>
                    <select class="form-select" id="category" name="category">
                        <option value="">جميع الفئات</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= htmlspecialchars($cat['category']) ?>" 
                                    <?= $category === $cat['category'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cat['category']) ?> (<?= $cat['count'] ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="col-lg-3">
                    <button type="submit" class="btn search-btn w-100">
                        <i class="fas fa-search me-2"></i>بحث
                    </button>
                </div>
            </div>
            
            <!-- Quick Filters -->
            <div class="quick-filters">
                <a href="courses.php" class="quick-filter <?= empty($search) && empty($category) && empty($level) ? 'active' : '' ?>">
                    جميع الدورات
                </a>
                <a href="courses.php?level=beginner" class="quick-filter <?= $level === 'beginner' ? 'active' : '' ?>">
                    مبتدئ
                </a>
                <a href="courses.php?level=intermediate" class="quick-filter <?= $level === 'intermediate' ? 'active' : '' ?>">
                    متوسط
                </a>
                <a href="courses.php?level=advanced" class="quick-filter <?= $level === 'advanced' ? 'active' : '' ?>">
                    متقدم
                </a>
                <a href="courses.php?sort=popular" class="quick-filter <?= $sortBy === 'popular' ? 'active' : '' ?>">
                    الأكثر شعبية
                </a>
                <a href="courses.php?sort=latest" class="quick-filter <?= $sortBy === 'latest' ? 'active' : '' ?>">
                    الأحدث
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Main Content -->
<div class="container mt-5">
    <div class="row">
        <!-- Sidebar Filters -->
        <div class="col-lg-3">
            <div class="filter-sidebar" data-aos="fade-right">
                <h5 class="mb-3">
                    <i class="fas fa-filter me-2"></i>تصفية النتائج
                </h5>
                
                <!-- Level Filter -->
                <div class="filter-group">
                    <div class="filter-title">المستوى</div>
                    <?php foreach ($levels as $levelOption): ?>
                        <label class="filter-option">
                            <span>
                                <input type="radio" name="level_filter" value="<?= htmlspecialchars($levelOption['level']) ?>"
                                       <?= $level === $levelOption['level'] ? 'checked' : '' ?>
                                       onchange="applyFilter()">
                                <?= getLevelText($levelOption['level']) ?>
                            </span>
                            <span class="filter-count"><?= $levelOption['count'] ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>
                
                <!-- Category Filter -->
                <div class="filter-group">
                    <div class="filter-title">الفئات</div>
                    <?php foreach ($categories as $cat): ?>
                        <label class="filter-option">
                            <span>
                                <input type="radio" name="category_filter" value="<?= htmlspecialchars($cat['category']) ?>"
                                       <?= $category === $cat['category'] ? 'checked' : '' ?>
                                       onchange="applyFilter()">
                                <?= htmlspecialchars($cat['category']) ?>
                            </span>
                            <span class="filter-count"><?= $cat['count'] ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>
                
                <!-- Price Filter -->
                <div class="filter-group">
                    <div class="filter-title">السعر</div>
                    <label class="filter-option">
                        <span>
                            <input type="radio" name="price_filter" value="free" onchange="applyFilter()">
                            مجاني
                        </span>
                    </label>
                    <label class="filter-option">
                        <span>
                            <input type="radio" name="price_filter" value="paid" onchange="applyFilter()">
                            مدفوع
                        </span>
                    </label>
                </div>
                
                <!-- Clear Filters -->
                <button type="button" class="btn btn-outline-secondary w-100" onclick="clearFilters()">
                    <i class="fas fa-times me-2"></i>مسح الفلاتر
                </button>
            </div>
        </div>
        
        <!-- Courses Grid -->
        <div class="col-lg-9">
            <!-- Courses Header -->
            <div class="courses-header" data-aos="fade-left">
                <div>
                    <h4 class="mb-1">الدورات المتاحة</h4>
                    <p class="courses-count mb-0">
                        عرض <?= count($courses) ?> من أصل <?= number_format($totalCourses) ?> دورة
                        <?php if ($search): ?>
                            لـ "<?= htmlspecialchars($search) ?>"
                        <?php endif; ?>
                    </p>
                </div>
                
                <div class="d-flex align-items-center gap-2">
                    <label for="sort" class="form-label mb-0 text-nowrap">ترتيب بواسطة:</label>
                    <select class="form-select sort-dropdown" id="sort" name="sort" onchange="applySort()">
                        <option value="latest" <?= $sortBy === 'latest' ? 'selected' : '' ?>>الأحدث</option>
                        <option value="popular" <?= $sortBy === 'popular' ? 'selected' : '' ?>>الأكثر شعبية</option>
                        <option value="rating" <?= $sortBy === 'rating' ? 'selected' : '' ?>>الأعلى تقييماً</option>
                        <option value="price_low" <?= $sortBy === 'price_low' ? 'selected' : '' ?>>السعر: من الأقل للأعلى</option>
                        <option value="price_high" <?= $sortBy === 'price_high' ? 'selected' : '' ?>>السعر: من الأعلى للأقل</option>
                        <option value="alphabetical" <?= $sortBy === 'alphabetical' ? 'selected' : '' ?>>أبجدياً</option>
                    </select>
                </div>
            </div>
            
            <!-- Courses Grid -->
            <?php if (empty($courses)): ?>
                <div class="no-courses" data-aos="fade-up">
                    <i class="fas fa-graduation-cap"></i>
                    <h4>لا توجد دورات</h4>
                    <p>لم نجد أي دورات تطابق معايير البحث المحددة.</p>
                    <button class="btn btn-primary" onclick="clearFilters()">
                        <i class="fas fa-refresh me-2"></i>عرض جميع الدورات
                    </button>
                </div>
            <?php else: ?>
                <div class="courses-grid">
                    <?php foreach ($courses as $index => $course): ?>
                        <div class="course-card-wrapper" data-aos="fade-up" data-aos-delay="<?= $index * 50 ?>">
                            <?php include __DIR__ . '/../components/course_card.php'; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                    <div class="pagination-wrapper" data-aos="fade-up">
                        <nav aria-label="صفحات الدورات">
                            <ul class="pagination">
                                <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="<?= buildPaginationUrl($page - 1) ?>">
                                            <i class="fas fa-chevron-right"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                                
                                <?php
                                $startPage = max(1, $page - 2);
                                $endPage = min($totalPages, $page + 2);
                                
                                if ($startPage > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="<?= buildPaginationUrl(1) ?>">1</a>
                                    </li>
                                    <?php if ($startPage > 2): ?>
                                        <li class="page-item disabled">
                                            <span class="page-link">...</span>
                                        </li>
                                    <?php endif;
                                endif;
                                
                                for ($i = $startPage; $i <= $endPage; $i++): ?>
                                    <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                                        <a class="page-link" href="<?= buildPaginationUrl($i) ?>"><?= $i ?></a>
                                    </li>
                                <?php endfor;
                                
                                if ($endPage < $totalPages): ?>
                                    <?php if ($endPage < $totalPages - 1): ?>
                                        <li class="page-item disabled">
                                            <span class="page-link">...</span>
                                        </li>
                                    <?php endif; ?>
                                    <li class="page-item">
                                        <a class="page-link" href="<?= buildPaginationUrl($totalPages) ?>"><?= $totalPages ?></a>
                                    </li>
                                <?php endif;
                                
                                if ($page < $totalPages): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="<?= buildPaginationUrl($page + 1) ?>">
                                            <i class="fas fa-chevron-left"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    // تهيئة AOS
    AOS.init({
        duration: 600,
        easing: 'ease-in-out',
        once: true
    });
    
    // دالة بناء رابط الصفحة
    function buildUrl(params = {}) {
        const url = new URL(window.location.href);
        
        // الحفاظ على المعاملات الحالية
        const currentParams = {
            search: '<?= htmlspecialchars($search) ?>',
            category: '<?= htmlspecialchars($category) ?>',
            level: '<?= htmlspecialchars($level) ?>',
            sort: '<?= htmlspecialchars($sortBy) ?>',
            page: '<?= $page ?>'
        };
        
        // دمج المعاملات الجديدة
        const finalParams = { ...currentParams, ...params };
        
        // إزالة المعاملات الفارغة
        Object.keys(finalParams).forEach(key => {
            if (finalParams[key]) {
                url.searchParams.set(key, finalParams[key]);
            } else {
                url.searchParams.delete(key);
            }
        });
        
        return url.pathname + url.search;
    }
    
    // تطبيق الفلتر
    function applyFilter() {
        const level = document.querySelector('input[name="level_filter"]:checked')?.value || '';
        const category = document.querySelector('input[name="category_filter"]:checked')?.value || '';
        const price = document.querySelector('input[name="price_filter"]:checked')?.value || '';
        
        window.location.href = buildUrl({ level, category, price, page: 1 });
    }
    
    // تطبيق الترتيب
    function applySort() {
        const sort = document.getElementById('sort').value;
        window.location.href = buildUrl({ sort, page: 1 });
    }
    
    // مسح الفلاتر
    function clearFilters() {
        window.location.href = 'courses.php';
    }
    
    // البحث المباشر
    let searchTimeout;
    document.getElementById('search')?.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            // يمكن إضافة بحث AJAX هنا
        }, 300);
    });
    
    // تحسين تجربة المستخدم
    document.addEventListener('DOMContentLoaded', function() {
        // إضافة loading state للأزرار
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function() {
                const submitBtn = this.querySelector('button[type="submit"]');
                if (submitBtn) {
                    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>جاري البحث...';
                    submitBtn.disabled = true;
                }
            });
        });
        
        // Lazy loading للصور
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.classList.remove('loading-skeleton');
                        observer.unobserve(img);
                    }
                });
            });
            
            document.querySelectorAll('img[data-src]').forEach(img => {
                imageObserver.observe(img);
            });
        }
    });
</script>

<?php
// دالة مساعدة لبناء روابط الصفحات
function buildPaginationUrl($pageNum) {
    $params = $_GET;
    $params['page'] = $pageNum;
    return 'courses.php?' . http_build_query($params);
}
?>

<?php include __DIR__ . '/../layout/footer.php'; ?>