<?php
/**
 * الصفحة الرئيسية
 * منصة ترند التعليمية - Learning Management System
 */

$pageTitle = 'الصفحة الرئيسية';
$pageDescription = 'اكتشف عالماً من المعرفة والتعلم مع أفضل الدورات التدريبية';

include __DIR__ . '/../layout/header.php';
?>

<!-- Hero Section -->
<section class="hero-section bg-primary text-white py-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h1 class="display-4 fw-bold mb-4">ابدأ رحلتك التعليمية معنا</h1>
                <p class="lead mb-4">اكتشف آلاف الدورات التدريبية في مختلف المجالات وطور مهاراتك مع خبراء في المجال</p>
                <div class="d-flex gap-3">
                    <a href="courses.php" class="btn btn-light btn-lg">استكشف الدورات</a>
                    <?php if (!isset($sessionManager) || !$sessionManager->isLoggedIn()): ?>
                        <a href="register.php" class="btn btn-outline-light btn-lg">انضم إلينا</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-6">
                <img src="https://via.placeholder.com/600x400/007bff/ffffff?text=تعلم+مع+ترند" 
                     class="img-fluid rounded" alt="التعلم الإلكتروني">
            </div>
        </div>
    </div>
</section>

<!-- Stats Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-3 mb-4">
                <div class="card border-0 h-100">
                    <div class="card-body">
                        <i class="fas fa-book fa-3x text-primary mb-3"></i>
                        <h3 class="fw-bold"><?= number_format($stats['courses'] ?? 0) ?></h3>
                        <p class="text-muted">دورة تدريبية</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card border-0 h-100">
                    <div class="card-body">
                        <i class="fas fa-users fa-3x text-success mb-3"></i>
                        <h3 class="fw-bold"><?= number_format($stats['students'] ?? 0) ?></h3>
                        <p class="text-muted">طالب نشط</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card border-0 h-100">
                    <div class="card-body">
                        <i class="fas fa-chalkboard-teacher fa-3x text-warning mb-3"></i>
                        <h3 class="fw-bold"><?= number_format($stats['instructors'] ?? 0) ?></h3>
                        <p class="text-muted">مدرب خبير</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card border-0 h-100">
                    <div class="card-body">
                        <i class="fas fa-clock fa-3x text-info mb-3"></i>
                        <h3 class="fw-bold"><?= number_format($stats['hours'] ?? 0) ?></h3>
                        <p class="text-muted">ساعة تدريبية</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Featured Courses -->
<?php if (!empty($featuredCourses)): ?>
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">الدورات المميزة</h2>
            <p class="text-muted">اكتشف أفضل دوراتنا التدريبية</p>
        </div>
        
        <div class="row">
            <?php foreach ($featuredCourses as $course): ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <img src="<?= htmlspecialchars($course['image_url'] ?: 'https://via.placeholder.com/350x200') ?>" 
                             class="card-img-top" alt="<?= htmlspecialchars($course['name']) ?>" style="height: 200px; object-fit: cover;">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($course['name']) ?></h5>
                            <p class="card-text text-muted"><?= htmlspecialchars(substr($course['description'], 0, 100)) ?>...</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted">
                                    <i class="fas fa-users me-1"></i><?= $course['students_count'] ?> طالب
                                </small>
                                <small class="text-muted">
                                    <i class="fas fa-play-circle me-1"></i><?= $course['lessons_count'] ?> درس
                                </small>
                            </div>
                        </div>
                        <div class="card-footer bg-transparent">
                            <a href="course.php?id=<?= $course['id'] ?>" class="btn btn-primary w-100">
                                عرض التفاصيل
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="text-center mt-4">
            <a href="courses.php" class="btn btn-outline-primary btn-lg">عرض جميع الدورات</a>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Call to Action -->
<section class="py-5 bg-primary text-white">
    <div class="container text-center">
        <h2 class="fw-bold mb-4">هل أنت مستعد لبدء رحلتك التعليمية؟</h2>
        <p class="lead mb-4">انضم إلى آلاف الطلاب واكتسب مهارات جديدة اليوم</p>
        <?php if (!isset($sessionManager) || !$sessionManager->isLoggedIn()): ?>
            <a href="register.php" class="btn btn-light btn-lg me-3">ابدأ مجاناً</a>
            <a href="courses.php" class="btn btn-outline-light btn-lg">استكشف الدورات</a>
        <?php else: ?>
            <a href="courses.php" class="btn btn-light btn-lg me-3">استكشف الدورات</a>
            <a href="subscribe.php" class="btn btn-outline-light btn-lg">فعل كود الاشتراك</a>
        <?php endif; ?>
    </div>
</section>

<?php include __DIR__ . '/../layout/footer.php'; ?>