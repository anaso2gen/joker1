<?php
/**
 * واجهة صفحة إنشاء حساب جديد مع العناصر المرئية المحسنة
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

// تضمين رأس الصفحة
include_once __DIR__ . '/../layout/header.php';
?>

<div class="register-container">
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-lg-8 col-md-10">
                <div class="register-card" data-aos="zoom-in" data-aos-duration="800">
                    <div class="row g-0">
                        <!-- Left Side - Animation -->
                        <div class="col-lg-5 register-animation-side">
                            <div class="animation-container">
                                <lottie-player
                                    src="https://assets4.lottiefiles.com/packages/lf20_jcikwtux.json"
                                    background="transparent"
                                    speed="1"
                                    style="width: 100%; height: 300px;"
                                    loop
                                    autoplay>
                                </lottie-player>
                                <div class="welcome-text">
                                    <h3 class="text-white fw-bold mb-3">انضم إلينا اليوم!</h3>
                                    <p class="text-white-50">أنشئ حسابك وابدأ رحلتك التعليمية مع أفضل المحتوى</p>
                                    
                                    <div class="features-list mt-4">
                                        <div class="feature-item" data-aos="fade-right" data-aos-delay="200">
                                            <i class="fas fa-check-circle me-2"></i>
                                            <span>وصول فوري للدورات</span>
                                        </div>
                                        <div class="feature-item" data-aos="fade-right" data-aos-delay="300">
                                            <i class="fas fa-check-circle me-2"></i>
                                            <span>تتبع التقدم الشخصي</span>
                                        </div>
                                        <div class="feature-item" data-aos="fade-right" data-aos-delay="400">
                                            <i class="fas fa-check-circle me-2"></i>
                                            <span>شهادات معتمدة</span>
                                        </div>
                                        <div class="feature-item" data-aos="fade-right" data-aos-delay="500">
                                            <i class="fas fa-check-circle me-2"></i>
                                            <span>دعم فني متواصل</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Right Side - Form -->
                        <div class="col-lg-7 register-form-side">
                            <div class="form-container">
                                <div class="text-center mb-4" data-aos="fade-down" data-aos-delay="200">
                                    <div class="register-icon mb-3">
                                        <i class="fas fa-user-plus text-primary" style="font-size: 3rem;" data-aos="pulse" data-aos-delay="600"></i>
                                    </div>
                                    <h2 class="fw-bold text-primary">إنشاء حساب جديد</h2>
                                    <p class="text-muted">املأ البيانات أدناه لإنشاء حسابك</p>
                                </div>

                                <form id="registerForm" class="register-form">
                                    <!-- Personal Information -->
                                    <div class="form-section mb-4" data-aos="fade-up" data-aos-delay="300">
                                        <h6 class="section-title">
                                            <i class="fas fa-user me-2 text-primary"></i>المعلومات الشخصية
                                        </h6>
                                        
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <label for="firstName" class="form-label">
                                                    <i class="fas fa-user me-1"></i>الاسم الأول *
                                                </label>
                                                <div class="input-with-icon">
                                                    <i class="fas fa-user input-icon"></i>
                                                    <input type="text" class="form-control ps-5" id="firstName" name="first_name" required>
                                                </div>
                                                <div class="invalid-feedback"></div>
                                            </div>
                                            
                                            <div class="col-md-6">
                                                <label for="lastName" class="form-label">
                                                    <i class="fas fa-user me-1"></i>الاسم الأخير *
                                                </label>
                                                <div class="input-with-icon">
                                                    <i class="fas fa-user input-icon"></i>
                                                    <input type="text" class="form-control ps-5" id="lastName" name="last_name" required>
                                                </div>
                                                <div class="invalid-feedback"></div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Account Information -->
                                    <div class="form-section mb-4" data-aos="fade-up" data-aos-delay="400">
                                        <h6 class="section-title">
                                            <i class="fas fa-envelope me-2 text-success"></i>معلومات الحساب
                                        </h6>
                                        
                                        <div class="mb-3">
                                            <label for="email" class="form-label">
                                                <i class="fas fa-envelope me-1"></i>البريد الإلكتروني *
                                            </label>
                                            <div class="input-with-icon">
                                                <i class="fas fa-at input-icon"></i>
                                                <input type="email" class="form-control ps-5" id="email" name="email" required>
                                            </div>
                                            <div class="invalid-feedback"></div>
                                            <div class="form-text">
                                                <i class="fas fa-info-circle me-1"></i>
                                                سيتم استخدام البريد الإلكتروني لتسجيل الدخول
                                            </div>
                                        </div>
                                        
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <label for="password" class="form-label">
                                                    <i class="fas fa-lock me-1"></i>كلمة المرور *
                                                </label>
                                                <div class="password-input">
                                                    <i class="fas fa-key input-icon"></i>
                                                    <input type="password" class="form-control ps-5 pe-5" id="password" name="password" required>
                                                    <button type="button" class="password-toggle" onclick="togglePasswordVisibility('password', this)">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                </div>
                                                <div class="invalid-feedback"></div>
                                                <div class="password-strength" id="passwordStrength"></div>
                                            </div>
                                            
                                            <div class="col-md-6">
                                                <label for="confirmPassword" class="form-label">
                                                    <i class="fas fa-shield-alt me-1"></i>تأكيد كلمة المرور *
                                                </label>
                                                <div class="password-input">
                                                    <i class="fas fa-check-double input-icon"></i>
                                                    <input type="password" class="form-control ps-5 pe-5" id="confirmPassword" name="confirm_password" required>
                                                    <button type="button" class="password-toggle" onclick="togglePasswordVisibility('confirmPassword', this)">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                </div>
                                                <div class="invalid-feedback"></div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Optional Information -->
                                    <div class="form-section mb-4" data-aos="fade-up" data-aos-delay="500">
                                        <h6 class="section-title">
                                            <i class="fas fa-info-circle me-2 text-info"></i>معلومات إضافية (اختيارية)
                                        </h6>
                                        
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <label for="phone" class="form-label">
                                                    <i class="fas fa-phone me-1"></i>رقم الهاتف
                                                </label>
                                                <div class="input-with-icon">
                                                    <i class="fas fa-mobile-alt input-icon"></i>
                                                    <input type="tel" class="form-control ps-5" id="phone" name="phone">
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-6">
                                                <label for="birthDate" class="form-label">
                                                    <i class="fas fa-calendar me-1"></i>تاريخ الميلاد
                                                </label>
                                                <div class="input-with-icon">
                                                    <i class="fas fa-birthday-cake input-icon"></i>
                                                    <input type="date" class="form-control ps-5" id="birthDate" name="birth_date">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Terms and Conditions -->
                                    <div class="form-section mb-4" data-aos="fade-up" data-aos-delay="600">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="agreeTerms" name="agree_terms" required>
                                            <label class="form-check-label" for="agreeTerms">
                                                <i class="fas fa-handshake me-1 text-warning"></i>
                                                أوافق على 
                                                <a href="#" class="text-primary fw-semibold">الشروط والأحكام</a> 
                                                و 
                                                <a href="#" class="text-primary fw-semibold">سياسة الخصوصية</a>
                                            </label>
                                            <div class="invalid-feedback"></div>
                                        </div>
                                        
                                        <div class="form-check mt-2">
                                            <input class="form-check-input" type="checkbox" id="subscribeNewsletter" name="subscribe_newsletter">
                                            <label class="form-check-label" for="subscribeNewsletter">
                                                <i class="fas fa-bell me-1 text-info"></i>
                                                أرغب في تلقي النشرة الإخبارية والتحديثات
                                            </label>
                                        </div>
                                    </div>

                                    <!-- Submit Button -->
                                    <div class="d-grid mb-3" data-aos="zoom-in" data-aos-delay="700">
                                        <button type="submit" class="btn btn-primary btn-lg register-btn" id="registerBtn">
                                            <span class="btn-text">
                                                <i class="fas fa-user-plus me-2"></i>إنشاء الحساب
                                            </span>
                                            <span class="btn-spinner d-none">
                                                <span class="spinner-border spinner-border-sm me-2"></span>
                                                جاري إنشاء الحساب...
                                            </span>
                                        </button>
                                    </div>
                                </form>

                                <!-- Login Link -->
                                <div class="text-center" data-aos="fade-up" data-aos-delay="800">
                                    <p class="text-muted">
                                        لديك حساب بالفعل؟ 
                                        <a href="<?php echo SITE_URL; ?>/login.php" class="text-primary text-decoration-none fw-semibold">
                                            <i class="fas fa-sign-in-alt me-1"></i>سجل دخولك هنا
                                        </a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* تنسيقات صفحة التسجيل */
.register-page {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    padding: 2rem 0;
}

.register-card {
    background: white;
    border-radius: 25px;
    overflow: hidden;
    box-shadow: 0 20px 60px rgba(0,0,0,0.2);
    max-width: 900px;
    margin: 0 auto;
}

.register-animation-side {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    position: relative;
    padding: 3rem 2rem;
    display: flex;
    align-items: center;
}

.animation-container {
    text-align: center;
    width: 100%;
}

.welcome-text h3 {
    font-size: 1.75rem;
}

.features-list {
    text-align: left;
}

.feature-item {
    color: white;
    margin-bottom: 0.75rem;
    font-size: 0.95rem;
}

.feature-item i {
    color: #ffd700;
}

.register-form-side {
    padding: 3rem 2rem;
}

.form-container {
    max-width: 450px;
    margin: 0 auto;
}

.section-title {
    font-weight: 600;
    margin-bottom: 1rem;
    padding-bottom: 0.5rem;
    border-bottom: 2px solid #f8f9fa;
    color: #2c3e50;
}

.form-section {
    background: #f8f9fa;
    padding: 1.5rem;
    border-radius: 12px;
    border-left: 4px solid #007bff;
}

.input-with-icon {
    position: relative;
}

.input-icon {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: #6c757d;
    z-index: 5;
}

.password-input {
    position: relative;
}

.password-input .input-icon {
    left: 15px;
}

.password-toggle {
    position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    color: #6c757d;
    cursor: pointer;
    z-index: 5;
    transition: color 0.3s ease;
}

.password-toggle:hover {
    color: #007bff;
}

.password-strength {
    margin-top: 0.5rem;
    font-size: 0.8rem;
}

.strength-weak { color: #dc3545; }
.strength-medium { color: #ffc107; }
.strength-strong { color: #28a745; }

.register-btn {
    background: linear-gradient(45deg, #667eea, #764ba2);
    border: none;
    position: relative;
    overflow: hidden;
    font-weight: 600;
    transition: all 0.3s ease;
}

.register-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
    transition: left 0.5s;
}

.register-btn:hover::before {
    left: 100%;
}

.register-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(102,126,234,0.4);
}

/* Responsive Design */
@media (max-width: 768px) {
    .register-animation-side {
        padding: 2rem 1rem;
        text-align: center;
    }
    
    .register-form-side {
        padding: 2rem 1rem;
    }
    
    .form-section {
        padding: 1rem;
    }
    
    .welcome-text h3 {
        font-size: 1.5rem;
    }
    
    .features-list {
        text-align: center;
    }
    
    .register-card {
        margin: 1rem;
        border-radius: 15px;
    }
}

@media (max-width: 576px) {
    .form-container {
        max-width: 100%;
    }
    
    .section-title {
        font-size: 1rem;
    }
    
    .register-btn {
        padding: 1rem;
    }
}

/* Animation Classes */
.form-section {
    transition: all 0.3s ease;
}

.form-section:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.input-with-icon input:focus + .input-icon,
.password-input input:focus + .input-icon {
    color: #007bff;
    transform: translateY(-50%) scale(1.1);
}
</style>

<?php
// تضمين تذييل الصفحة
$additionalScripts = '
<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    setupRegisterForm();
    setupPasswordStrength();
});

// إعداد نموذج التسجيل
function setupRegisterForm() {
    const registerForm = document.getElementById("registerForm");
    
    registerForm.addEventListener("submit", async function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const registerBtn = document.getElementById("registerBtn");
        
        // التحقق من صحة البيانات
        if (!validateRegistrationForm(formData)) {
            return;
        }
        
        // إظهار حالة التحميل
        setButtonLoading(registerBtn, true);
        clearFormErrors();
        
        try {
            const response = await fetchAPI("/api/auth/register", {
                method: "POST",
                body: formData
            });
            
            if (response.success) {
                // Animation للنجاح
                registerBtn.innerHTML = `<i class="fas fa-check-circle me-2"></i>تم إنشاء الحساب!`;
                registerBtn.classList.remove("btn-primary");
                registerBtn.classList.add("btn-success");
                
                showSuccessMessage(response.user);
                
                // إعادة توجيه بعد تأخير
                setTimeout(() => {
                    window.location.href = response.redirect_to || "/login.php";
                }, 3000);
                
            } else {
                showToast(response.message || "خطأ في إنشاء الحساب", "error");
                
                // Animation للخطأ
                registerBtn.classList.add("animate__animated", "animate__shakeX");
                setTimeout(() => {
                    registerBtn.classList.remove("animate__animated", "animate__shakeX");
                }, 1000);
                
                // إظهار أخطاء الحقول
                if (response.errors) {
                    Object.keys(response.errors).forEach(field => {
                        showFieldError(field, response.errors[field]);
                    });
                }
            }
        } catch (error) {
            console.error("Registration error:", error);
            showToast("خطأ في الاتصال بالخادم", "error");
        } finally {
            setButtonLoading(registerBtn, false);
        }
    });
}

// إعداد مؤشر قوة كلمة المرور
function setupPasswordStrength() {
    const passwordInput = document.getElementById("password");
    const strengthIndicator = document.getElementById("passwordStrength");
    
    passwordInput.addEventListener("input", function() {
        const password = this.value;
        const strength = calculatePasswordStrength(password);
        
        strengthIndicator.innerHTML = getStrengthIndicator(strength);
    });
}

// حساب قوة كلمة المرور
function calculatePasswordStrength(password) {
    let score = 0;
    
    // الطول
    if (password.length >= 8) score += 1;
    if (password.length >= 12) score += 1;
    
    // أحرف كبيرة وصغيرة
    if (/[a-z]/.test(password)) score += 1;
    if (/[A-Z]/.test(password)) score += 1;
    
    // أرقام
    if (/[0-9]/.test(password)) score += 1;
    
    // رموز خاصة
    if (/[^A-Za-z0-9]/.test(password)) score += 1;
    
    return score;
}

// عرض مؤشر قوة كلمة المرور
function getStrengthIndicator(score) {
    if (score <= 2) {
        return `<span class="strength-weak"><i class="fas fa-times-circle me-1"></i>ضعيفة</span>`;
    } else if (score <= 4) {
        return `<span class="strength-medium"><i class="fas fa-exclamation-triangle me-1"></i>متوسطة</span>`;
    } else {
        return `<span class="strength-strong"><i class="fas fa-check-circle me-1"></i>قوية</span>`;
    }
}

// التحقق من صحة نموذج التسجيل
function validateRegistrationForm(formData) {
    const errors = {};
    
    // الحقول المطلوبة
    const requiredFields = {
        "first_name": "الاسم الأول",
        "last_name": "الاسم الأخير", 
        "email": "البريد الإلكتروني",
        "password": "كلمة المرور",
        "confirm_password": "تأكيد كلمة المرور"
    };
    
    Object.keys(requiredFields).forEach(field => {
        const value = formData.get(field);
        if (!value || value.trim() === "") {
            errors[field] = requiredFields[field] + " مطلوب";
        }
    });
    
    // التحقق من البريد الإلكتروني
    const email = formData.get("email");
    if (email && !isValidEmail(email)) {
        errors.email = "البريد الإلكتروني غير صالح";
    }
    
    // التحقق من كلمة المرور
    const password = formData.get("password");
    const confirmPassword = formData.get("confirm_password");
    
    if (password && password.length < 8) {
        errors.password = "كلمة المرور يجب أن تكون 8 أحرف على الأقل";
    }
    
    if (password !== confirmPassword) {
        errors.confirm_password = "كلمة المرور غير متطابقة";
    }
    
    // التحقق من الموافقة على الشروط
    const agreeTerms = formData.get("agree_terms");
    if (!agreeTerms) {
        errors.agreeTerms = "يجب الموافقة على الشروط والأحكام";
    }
    
    // إظهار الأخطاء
    if (Object.keys(errors).length > 0) {
        Object.keys(errors).forEach(field => {
            showFieldError(field, errors[field]);
        });
        
        // التمرير إلى أول خطأ
        const firstErrorField = document.querySelector(".is-invalid");
        if (firstErrorField) {
            firstErrorField.scrollIntoView({behavior: "smooth", block: "center"});
        }
        
        return false;
    }
    
    return true;
}

// عرض رسالة النجاح
function showSuccessMessage(user) {
    const container = document.querySelector(".register-container .container");
    
    const successHtml = `
        <div class="success-message text-center" data-aos="zoom-in">
            <div class="success-animation mb-4">
                <lottie-player
                    src="https://assets4.lottiefiles.com/packages/lf20_lk80fpsm.json"
                    background="transparent"
                    speed="1"
                    style="width: 300px; height: 200px; margin: 0 auto;"
                    autoplay>
                </lottie-player>
            </div>
            <h2 class="fw-bold text-success mb-3">تم إنشاء الحساب بنجاح! 🎉</h2>
            <div class="alert alert-success">
                <i class="fas fa-user-check me-2"></i>
                مرحباً <strong>${user.name}</strong>! تم إنشاء حسابك بنجاح
            </div>
            <p class="lead text-muted mb-4">
                يمكنك الآن تسجيل الدخول والبدء في استكشاف الدورات المتاحة
            </p>
            <div class="mt-4">
                <a href="/login.php" class="btn btn-primary btn-lg me-3">
                    <i class="fas fa-sign-in-alt me-2"></i>تسجيل الدخول
                </a>
                <a href="/index.php" class="btn btn-outline-primary btn-lg">
                    <i class="fas fa-home me-2"></i>الصفحة الرئيسية
                </a>
            </div>
        </div>
    `;
    
    container.innerHTML = successHtml;
    AOS.refresh();
}

// تبديل إظهار كلمة المرور
function togglePasswordVisibility(inputId, button) {
    const input = document.getElementById(inputId);
    const icon = button.querySelector("i");
    
    if (input.type === "password") {
        input.type = "text";
        icon.className = "fas fa-eye-slash";
        button.setAttribute("title", "إخفاء كلمة المرور");
    } else {
        input.type = "password";
        icon.className = "fas fa-eye";
        button.setAttribute("title", "إظهار كلمة المرور");
    }
    
    // تأثير بصري
    button.style.transform = "scale(0.9)";
    setTimeout(() => {
        button.style.transform = "scale(1)";
    }, 100);
}

// التحقق من صحة البريد الإلكتروني
function isValidEmail(email) {
    const emailRegex = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
    return emailRegex.test(email);
}
</script>
';

include_once __DIR__ . '/../layout/footer.php';
?>