<?php
/**
 * تذييل صفحات المصادقة
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 08:57:21
 */
?>
    </main>
    
    <!-- Footer -->
    <footer class="auth-footer text-center text-white-50 py-3">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <p class="mb-2">
                        © <?= date('Y') ?> <?= SITE_NAME ?> - جميع الحقوق محفوظة
                    </p>
                    <div class="footer-links">
                        <a href="#" class="text-white-50 text-decoration-none me-3" data-bs-toggle="modal" data-bs-target="#privacyModal">
                            <i class="fas fa-shield-alt me-1"></i>سياسة الخصوصية
                        </a>
                        <a href="#" class="text-white-50 text-decoration-none me-3" data-bs-toggle="modal" data-bs-target="#termsModal">
                            <i class="fas fa-file-contract me-1"></i>شروط الاستخدام
                        </a>
                        <a href="#" class="text-white-50 text-decoration-none" data-bs-toggle="modal" data-bs-target="#supportModal">
                            <i class="fas fa-headset me-1"></i>الدعم الفني
                        </a>
                    </div>
                    <div class="social-links mt-3">
                        <a href="#" class="text-white-50 me-3" title="تويتر">
                            <i class="fab fa-twitter fa-lg"></i>
                        </a>
                        <a href="#" class="text-white-50 me-3" title="فيسبوك">
                            <i class="fab fa-facebook fa-lg"></i>
                        </a>
                        <a href="#" class="text-white-50 me-3" title="يوتيوب">
                            <i class="fab fa-youtube fa-lg"></i>
                        </a>
                        <a href="#" class="text-white-50" title="لينكد إن">
                            <i class="fab fa-linkedin fa-lg"></i>
                        </a>
                    </div>
                    <small class="d-block mt-2 opacity-75">
                        تم التطوير بواسطة <strong>anaso2gen</strong>
                    </small>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Privacy Policy Modal -->
    <div class="modal fade" id="privacyModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-shield-alt me-2"></i>سياسة الخصوصية
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="privacy-content">
                        <h6>جمع البيانات</h6>
                        <p>نحن نجمع المعلومات التي تقدمها لنا مباشرة، مثل اسمك وبريدك الإلكتروني عند إنشاء حساب.</p>
                        
                        <h6>استخدام البيانات</h6>
                        <p>نستخدم معلوماتك لتوفير وتحسين خدماتنا التعليمية وللتواصل معك بشأن حسابك.</p>
                        
                        <h6>حماية البيانات</h6>
                        <p>نحن نتخذ تدابير أمنية مناسبة لحماية معلوماتك الشخصية من الوصول غير المصرح به.</p>
                        
                        <h6>مشاركة البيانات</h6>
                        <p>نحن لا نبيع أو نؤجر أو نشارك معلوماتك الشخصية مع أطراف ثالثة دون موافقتك.</p>
                        
                        <h6>ملفات الارتباط (Cookies)</h6>
                        <p>نستخدم ملفات الارتباط لتحسين تجربتك على الموقع وتذكر تفضيلاتك.</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Terms of Service Modal -->
    <div class="modal fade" id="termsModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-file-contract me-2"></i>شروط الاستخدام
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="terms-content">
                        <h6>قبول الشروط</h6>
                        <p>باستخدام هذه المنصة، فإنك توافق على الالتزام بهذه الشروط والأحكام.</p>
                        
                        <h6>الحسابات والتسجيل</h6>
                        <p>يجب أن تكون المعلومات المقدمة عند التسجيل دقيقة ومحدثة. أنت مسؤول عن الحفاظ على سرية كلمة المرور.</p>
                        
                        <h6>استخدام المحتوى</h6>
                        <p>المحتوى التعليمي مخصص للاستخدام الشخصي فقط. ممنوع نسخ أو توزيع المحتوى دون إذن.</p>
                        
                        <h6>السلوك المقبول</h6>
                        <p>يجب استخدام المنصة بطريقة مسؤولة ولا تضر بالآخرين أو بالمنصة نفسها.</p>
                        
                        <h6>إنهاء الخدمة</h6>
                        <p>نحتفظ بالحق في إنهاء أو تعليق حسابك في حالة انتهاك هذه الشروط.</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Support Modal -->
    <div class="modal fade" id="supportModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-headset me-2"></i>الدعم الفني
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="support-info">
                        <div class="text-center mb-4">
                            <i class="fas fa-headset fa-3x text-primary mb-3"></i>
                            <h5>نحن هنا لمساعدتك</h5>
                        </div>
                        
                        <div class="contact-methods">
                            <div class="contact-item d-flex align-items-center mb-3">
                                <div class="contact-icon bg-primary text-white rounded-circle p-2 me-3">
                                    <i class="fas fa-envelope"></i>
                                </div>
                                <div>
                                    <strong>البريد الإلكتروني</strong><br>
                                    <a href="mailto:<?= ADMIN_EMAIL ?>"><?= ADMIN_EMAIL ?></a>
                                </div>
                            </div>
                            
                            <div class="contact-item d-flex align-items-center mb-3">
                                <div class="contact-icon bg-success text-white rounded-circle p-2 me-3">
                                    <i class="fab fa-whatsapp"></i>
                                </div>
                                <div>
                                    <strong>واتساب</strong><br>
                                    <a href="https://wa.me/966XXXXXXXXX">+966 XX XXX XXXX</a>
                                </div>
                            </div>
                            
                            <div class="contact-item d-flex align-items-center">
                                <div class="contact-icon bg-info text-white rounded-circle p-2 me-3">
                                    <i class="fas fa-clock"></i>
                                </div>
                                <div>
                                    <strong>ساعات العمل</strong><br>
                                    السبت - الخميس: 9:00 ص - 6:00 م
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="frontend/assets/js/common.js"></script>
    <script src="frontend/assets/js/app.js"></script>
    
    <script>
        // تهيئة AOS
        AOS.init({
            duration: 600,
            easing: 'ease-in-out',
            once: true,
            offset: 50
        });
        
        // إخفاء شاشة التحميل عند تحميل الصفحة
        window.addEventListener('load', function() {
            const loadingOverlay = document.getElementById('loadingOverlay');
            if (loadingOverlay) {
                loadingOverlay.style.display = 'none';
            }
        });
        
        // إظهار شاشة التحميل عند إرسال النماذج
        document.addEventListener('DOMContentLoaded', function() {
            const forms = document.querySelectorAll('form');
            forms.forEach(form => {
                form.addEventListener('submit', function() {
                    const loadingOverlay = document.getElementById('loadingOverlay');
                    if (loadingOverlay) {
                        loadingOverlay.style.display = 'flex';
                    }
                });
            });
        });
        
        // تحسين تجربة المستخدم
        document.querySelectorAll('.btn-auth').forEach(btn => {
            btn.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-2px)';
            });
            
            btn.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
            });
        });
        
        // إضافة تأثيرات على الحقول
        document.querySelectorAll('.form-control').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.style.transform = 'scale(1.02)';
            });
            
            input.addEventListener('blur', function() {
                this.parentElement.style.transform = 'scale(1)';
            });
        });
        
        // حماية من النقر المتكرر
        let formSubmitted = false;
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(e) {
                if (formSubmitted) {
                    e.preventDefault();
                    return false;
                }
                formSubmitted = true;
                
                // إعادة تمكين الإرسال بعد 3 ثوان
                setTimeout(() => {
                    formSubmitted = false;
                }, 3000);
            });
        });
        
        // تحسين الأداء - تأخير تحميل الخطوط
        if ('requestIdleCallback' in window) {
            requestIdleCallback(() => {
                const link = document.createElement('link');
                link.rel = 'stylesheet';
                link.href = 'https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700&display=swap';
                document.head.appendChild(link);
            });
        }
    </script>
    
    <!-- Analytics (إزالة التعليق عند الحاجة) -->
    <!-- 
    <script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'GA_MEASUREMENT_ID');
    </script>
    -->
</body>
</html>