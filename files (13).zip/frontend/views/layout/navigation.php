<?php
/**
 * شريط التنقل الرئيسي
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 09:00:19
 */

// التحقق من حالة تسجيل الدخول
$currentUser = isset($user) ? $user : ($sessionManager->isLoggedIn() ? $sessionManager->getCurrentUser() : null);
$isLoggedIn = $currentUser !== null;
$isAdmin = $isLoggedIn && ($currentUser['is_admin'] ?? false);

// الحصول على الصفحة الحالية
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
?>

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
    <div class="container">
        <!-- الشعار -->
        <a class="navbar-brand d-flex align-items-center" href="index.php">
            <img src="assets/images/logo.png" alt="<?= SITE_NAME ?>" height="40" class="me-2">
            <span class="fw-bold text-primary"><?= SITE_NAME ?></span>
        </a>

        <!-- زر القائمة للموبايل -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- القائمة الرئيسية -->
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <!-- الرئيسية -->
                <li class="nav-item">
                    <a class="nav-link <?= $currentPage === 'index' ? 'active' : '' ?>" href="index.php">
                        <i class="fas fa-home me-1"></i>الرئيسية
                    </a>
                </li>

                <!-- الدورات -->
                <li class="nav-item">
                    <a class="nav-link <?= in_array($currentPage, ['courses', 'course']) ? 'active' : '' ?>" href="courses.php">
                        <i class="fas fa-graduation-cap me-1"></i>الدورات
                    </a>
                </li>

                <?php if ($isLoggedIn): ?>
                    <!-- دوراتي -->
                    <li class="nav-item">
                        <a class="nav-link <?= $currentPage === 'profile' ? 'active' : '' ?>" href="profile.php">
                            <i class="fas fa-user-graduate me-1"></i>دوراتي
                        </a>
                    </li>
                <?php endif; ?>

                <!-- من نحن -->
                <li class="nav-item">
                    <a class="nav-link" href="#about">
                        <i class="fas fa-info-circle me-1"></i>من نحن
                    </a>
                </li>

                <!-- تواصل معنا -->
                <li class="nav-item">
                    <a class="nav-link" href="#contact">
                        <i class="fas fa-envelope me-1"></i>تواصل معنا
                    </a>
                </li>
            </ul>

            <!-- القائمة اليمنى -->
            <ul class="navbar-nav">
                <!-- مبدل المظاهر -->
                <li class="nav-item">
                    <button class="btn btn-link nav-link border-0" id="themeToggle" title="تغيير المظهر">
                        <i class="fas fa-moon" id="themeIcon"></i>
                    </button>
                </li>

                <!-- البحث -->
                <li class="nav-item dropdown me-2">
                    <button class="btn btn-outline-secondary" data-bs-toggle="dropdown">
                        <i class="fas fa-search"></i>
                    </button>
                    <div class="dropdown-menu dropdown-menu-end p-3" style="width: 300px;">
                        <form action="courses.php" method="get">
                            <div class="input-group">
                                <input type="text" class="form-control" name="search" 
                                       placeholder="ابحث عن الدورات..." 
                                       value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
                                <button class="btn btn-primary" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                </li>

                <?php if ($isLoggedIn): ?>
                    <!-- الإشعارات -->
                    <li class="nav-item dropdown me-2">
                        <a class="nav-link position-relative" href="#" data-bs-toggle="dropdown">
                            <i class="fas fa-bell"></i>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" 
                                  id="notificationBadge" style="display: none;">
                                0
                            </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" style="width: 350px;">
                            <h6 class="dropdown-header">
                                <i class="fas fa-bell me-1"></i>الإشعارات
                            </h6>
                            <div id="notificationsList">
                                <div class="dropdown-item text-center text-muted py-3">
                                    <i class="fas fa-inbox fa-2x mb-2 d-block"></i>
                                    لا توجد إشعارات جديدة
                                </div>
                            </div>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item text-center small" href="profile.php#notifications">
                                عرض جميع الإشعارات
                            </a>
                        </div>
                    </li>

                    <!-- القائمة الشخصية -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" data-bs-toggle="dropdown">
                            <img src="<?= htmlspecialchars($currentUser['avatar_url'] ?: 'assets/images/default-avatar.png') ?>" 
                                 alt="صورة المستخدم" class="rounded-circle me-2" width="32" height="32">
                            <span class="d-none d-md-inline">
                                <?= htmlspecialchars($currentUser['first_name'] . ' ' . $currentUser['last_name']) ?>
                            </span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <h6 class="dropdown-header">
                                    <i class="fas fa-user-circle me-1"></i>
                                    <?= htmlspecialchars($currentUser['first_name'] . ' ' . $currentUser['last_name']) ?>
                                </h6>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            
                            <li>
                                <a class="dropdown-item" href="profile.php">
                                    <i class="fas fa-user me-2"></i>الملف الشخصي
                                </a>
                            </li>
                            
                            <li>
                                <a class="dropdown-item" href="profile.php#courses">
                                    <i class="fas fa-graduation-cap me-2"></i>دوراتي
                                </a>
                            </li>
                            
                            <li>
                                <a class="dropdown-item" href="profile.php#certificates">
                                    <i class="fas fa-certificate me-2"></i>الشهادات
                                </a>
                            </li>
                            
                            <li>
                                <a class="dropdown-item" href="subscribe.php">
                                    <i class="fas fa-key me-2"></i>تفعيل كود
                                </a>
                            </li>

                            <?php if ($isAdmin): ?>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item text-primary" href="editdash.php">
                                        <i class="fas fa-cogs me-2"></i>لوحة التحكم
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="settings.php">
                                        <i class="fas fa-sliders-h me-2"></i>الإعدادات
                                    </a>
                                </li>
                            <?php endif; ?>

                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item text-danger" href="logout.php?token=<?= generateCSRFToken() ?>">
                                    <i class="fas fa-sign-out-alt me-2"></i>تسجيل الخروج
                                </a>
                            </li>
                        </ul>
                    </li>

                <?php else: ?>
                    <!-- تسجيل الدخول والتسجيل -->
                    <li class="nav-item me-2">
                        <a class="btn btn-outline-primary" href="login.php">
                            <i class="fas fa-sign-in-alt me-1"></i>تسجيل الدخول
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="btn btn-primary" href="register.php">
                            <i class="fas fa-user-plus me-1"></i>إنشاء حساب
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<!-- شريط التقدم للصفحة -->
<div class="page-progress" id="pageProgress"></div>

<style>
.navbar {
    transition: all 0.3s ease;
    backdrop-filter: blur(10px);
}

.navbar.scrolled {
    background: rgba(255, 255, 255, 0.95) !important;
    box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1) !important;
}

.nav-link {
    position: relative;
    transition: all 0.3s ease;
    border-radius: 8px;
    margin: 0 2px;
}

.nav-link:hover {
    background: rgba(102, 126, 234, 0.1);
    color: #667eea !important;
}

.nav-link.active {
    background: linear-gradient(45deg, #667eea, #764ba2);
    color: white !important;
}

.nav-link.active::after {
    content: '';
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translateX(-50%);
    width: 0;
    height: 0;
    border-left: 6px solid transparent;
    border-right: 6px solid transparent;
    border-top: 6px solid #667eea;
}

.navbar-brand:hover {
    transform: scale(1.05);
    transition: transform 0.3s ease;
}

.dropdown-menu {
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
    border: none;
    padding: 0.5rem 0;
}

.dropdown-item {
    padding: 0.7rem 1.5rem;
    transition: all 0.3s ease;
    border-radius: 0;
}

.dropdown-item:hover {
    background: linear-gradient(45deg, #667eea, #764ba2);
    color: white;
    transform: translateX(5px);
}

.dropdown-header {
    background: linear-gradient(45deg, #667eea, #764ba2);
    color: white;
    margin: 0;
    padding: 1rem 1.5rem;
    border-radius: 15px 15px 0 0;
}

.page-progress {
    position: fixed;
    top: 0;
    left: 0;
    width: 0%;
    height: 3px;
    background: linear-gradient(45deg, #667eea, #764ba2);
    z-index: 9999;
    transition: width 0.1s ease;
}

.notification-item {
    padding: 1rem;
    border-bottom: 1px solid #f0f0f0;
    transition: all 0.3s ease;
}

.notification-item:hover {
    background: #f8f9fa;
}

.notification-item:last-child {
    border-bottom: none;
}

.notification-new {
    background: rgba(102, 126, 234, 0.1);
    border-left: 4px solid #667eea;
}

.badge-notification {
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.1); }
    100% { transform: scale(1); }
}

@media (max-width: 768px) {
    .navbar-nav {
        text-align: center;
    }
    
    .nav-link {
        padding: 0.7rem 1rem;
        margin: 2px 0;
    }
    
    .dropdown-menu {
        position: static !important;
        transform: none !important;
        width: 100%;
        box-shadow: none;
        border: 1px solid #dee2e6;
        border-radius: 0;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // تأثير التمرير على شريط التنقل
    let lastScrollTop = 0;
    const navbar = document.querySelector('.navbar');
    
    window.addEventListener('scroll', function() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        // إضافة كلاس عند التمرير
        if (scrollTop > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
        
        // تحديث شريط التقدم
        const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
        const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const scrolled = (winScroll / height) * 100;
        document.getElementById('pageProgress').style.width = scrolled + '%';
        
        lastScrollTop = scrollTop;
    });
    
    // تهيئة مبدل المظاهر
    const themeToggle = document.getElementById('themeToggle');
    const themeIcon = document.getElementById('themeIcon');
    
    // قراءة المظهر المحفوظ
    const savedTheme = localStorage.getItem('theme') || 'light';
    applyTheme(savedTheme);
    
    themeToggle.addEventListener('click', function() {
        const currentTheme = document.body.getAttribute('data-theme') || 'light';
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        applyTheme(newTheme);
        localStorage.setItem('theme', newTheme);
    });
    
    function applyTheme(theme) {
        document.body.setAttribute('data-theme', theme);
        themeIcon.className = theme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
        
        // تحديث ألوان شريط التنقل
        if (theme === 'dark') {
            navbar.classList.add('navbar-dark', 'bg-dark');
            navbar.classList.remove('navbar-light', 'bg-white');
        } else {
            navbar.classList.add('navbar-light', 'bg-white');
            navbar.classList.remove('navbar-dark', 'bg-dark');
        }
    }
    
    // تحميل الإشعارات
    <?php if ($isLoggedIn): ?>
    loadNotifications();
    
    function loadNotifications() {
        fetch('api.php?action=get_notifications')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    updateNotifications(data.notifications);
                }
            })
            .catch(error => console.error('Error loading notifications:', error));
    }
    
    function updateNotifications(notifications) {
        const badge = document.getElementById('notificationBadge');
        const list = document.getElementById('notificationsList');
        
        if (notifications.length === 0) {
            badge.style.display = 'none';
            list.innerHTML = `
                <div class="dropdown-item text-center text-muted py-3">
                    <i class="fas fa-inbox fa-2x mb-2 d-block"></i>
                    لا توجد إشعارات جديدة
                </div>
            `;
            return;
        }
        
        // تحديث العداد
        const unreadCount = notifications.filter(n => !n.is_read).length;
        if (unreadCount > 0) {
            badge.textContent = unreadCount;
            badge.style.display = 'block';
            badge.classList.add('badge-notification');
        } else {
            badge.style.display = 'none';
        }
        
        // تحديث القائمة
        list.innerHTML = notifications.map(notification => `
            <div class="notification-item ${!notification.is_read ? 'notification-new' : ''}" 
                 data-id="${notification.id}">
                <div class="d-flex align-items-start">
                    <div class="notification-icon me-2 mt-1">
                        <i class="fas ${getNotificationIcon(notification.type)} text-primary"></i>
                    </div>
                    <div class="flex-grow-1">
                        <div class="notification-title fw-bold small">
                            ${notification.title}
                        </div>
                        <div class="notification-message text-muted small">
                            ${notification.message}
                        </div>
                        <div class="notification-time text-muted small">
                            ${timeAgo(notification.created_at)}
                        </div>
                    </div>
                    ${!notification.is_read ? '<div class="notification-dot bg-primary rounded-circle"></div>' : ''}
                </div>
            </div>
        `).join('');
        
        // إضافة مستمعي الأحداث
        document.querySelectorAll('.notification-item').forEach(item => {
            item.addEventListener('click', function() {
                const notificationId = this.dataset.id;
                markNotificationRead(notificationId);
            });
        });
    }
    
    function getNotificationIcon(type) {
        const icons = {
            'course': 'fa-graduation-cap',
            'lesson': 'fa-play-circle',
            'certificate': 'fa-certificate',
            'system': 'fa-cog',
            'subscription': 'fa-key'
        };
        return icons[type] || 'fa-bell';
    }
    
    function markNotificationRead(notificationId) {
        fetch('api.php?action=mark_notification_read', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ notification_id: notificationId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadNotifications(); // إعادة تحميل الإشعارات
            }
        });
    }
    
    function timeAgo(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diffInSeconds = Math.floor((now - date) / 1000);
        
        if (diffInSeconds < 60) return 'منذ لحظات';
        if (diffInSeconds < 3600) return `منذ ${Math.floor(diffInSeconds / 60)} دقيقة`;
        if (diffInSeconds < 86400) return `منذ ${Math.floor(diffInSeconds / 3600)} ساعة`;
        if (diffInSeconds < 2592000) return `منذ ${Math.floor(diffInSeconds / 86400)} يوم`;
        return date.toLocaleDateString('ar-SA');
    }
    
    // تحديث الإشعارات كل دقيقة
    setInterval(loadNotifications, 60000);
    <?php endif; ?>
    
    // تحسين تجربة البحث
    const searchInput = document.querySelector('input[name="search"]');
    if (searchInput) {
        let searchTimeout;
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                // يمكن إضافة بحث مباشر هنا
            }, 300);
        });
    }
});
</script>