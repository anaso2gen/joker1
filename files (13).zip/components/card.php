<?php
/**
 * مكون البطاقة القابل لإعادة الاستخدام
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

function renderCard($options = []) {
    $defaults = [
        'title' => '',
        'content' => '',
        'image' => '',
        'footer' => '',
        'class' => '',
        'style' => '',
        'animate' => true,
        'shadow' => true,
        'hover_effect' => true
    ];
    
    $config = array_merge($defaults, $options);
    
    $classes = ['card'];
    if ($config['class']) $classes[] = $config['class'];
    if ($config['shadow']) $classes[] = 'shadow-sm';
    if ($config['hover_effect']) $classes[] = 'card-hover';
    
    $animateAttr = $config['animate'] ? 'data-aos="fade-up"' : '';
    
    ob_start();
    ?>
    <div class="<?php echo implode(' ', $classes); ?>" 
         style="<?php echo $config['style']; ?>" 
         <?php echo $animateAttr; ?>>
        
        <?php if ($config['image']): ?>
        <div class="card-img-container">
            <img src="<?php echo htmlspecialchars($config['image']); ?>" 
                 class="card-img-top" 
                 alt="<?php echo htmlspecialchars($config['title']); ?>"
                 loading="lazy">
        </div>
        <?php endif; ?>
        
        <div class="card-body">
            <?php if ($config['title']): ?>
            <h5 class="card-title"><?php echo htmlspecialchars($config['title']); ?></h5>
            <?php endif; ?>
            
            <?php if ($config['content']): ?>
            <div class="card-text"><?php echo $config['content']; ?></div>
            <?php endif; ?>
        </div>
        
        <?php if ($config['footer']): ?>
        <div class="card-footer">
            <?php echo $config['footer']; ?>
        </div>
        <?php endif; ?>
    </div>
    
    <style>
    .card-hover {
        transition: all 0.3s ease;
    }
    
    .card-hover:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.15) !important;
    }
    
    .card-img-container {
        position: relative;
        overflow: hidden;
        border-radius: 0.375rem 0.375rem 0 0;
    }
    
    .card-img-container img {
        transition: transform 0.3s ease;
    }
    
    .card-hover:hover .card-img-container img {
        transform: scale(1.05);
    }
    </style>
    <?php
    return ob_get_clean();
}
?>