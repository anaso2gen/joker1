<?php
/**
 * مكون الزر القابل لإعادة الاستخدام
 */

if (!defined('LEARNING_PLATFORM')) {
    die('Direct access not allowed');
}

function renderButton($options = []) {
    $defaults = [
        'text' => 'زر',
        'type' => 'button',
        'variant' => 'primary',
        'size' => '',
        'icon' => '',
        'icon_position' => 'left',
        'class' => '',
        'id' => '',
        'onclick' => '',
        'disabled' => false,
        'loading' => false,
        'animate' => false
    ];
    
    $config = array_merge($defaults, $options);
    
    $classes = ['btn', 'btn-' . $config['variant']];
    if ($config['size']) $classes[] = 'btn-' . $config['size'];
    if ($config['class']) $classes[] = $config['class'];
    if ($config['animate']) $classes[] = 'btn-animated';
    
    $attributes = [];
    if ($config['id']) $attributes[] = 'id="' . $config['id'] . '"';
    if ($config['onclick']) $attributes[] = 'onclick="' . htmlspecialchars($config['onclick']) . '"';
    if ($config['disabled'] || $config['loading']) $attributes[] = 'disabled';
    
    $iconHtml = '';
    if ($config['icon']) {
        $iconHtml = '<i class="' . $config['icon'] . '"></i>';
    }
    
    ob_start();
    ?>
    <button type="<?php echo $config['type']; ?>" 
            class="<?php echo implode(' ', $classes); ?>" 
            <?php echo implode(' ', $attributes); ?>>
        
        <?php if ($config['loading']): ?>
            <span class="spinner-border spinner-border-sm me-2"></span>
            جاري التحميل...
        <?php else: ?>
            <?php if ($config['icon'] && $config['icon_position'] === 'left'): ?>
                <?php echo $iconHtml; ?><?php if ($config['text']): ?> <?php endif; ?>
            <?php endif; ?>
            
            <?php if ($config['text']): ?>
                <span><?php echo htmlspecialchars($config['text']); ?></span>
            <?php endif; ?>
            
            <?php if ($config['icon'] && $config['icon_position'] === 'right'): ?>
                <?php if ($config['text']): ?> <?php endif; ?><?php echo $iconHtml; ?>
            <?php endif; ?>
        <?php endif; ?>
    </button>
    
    <style>
    .btn-animated {
        position: relative;
        overflow: hidden;
        transition: all 0.3s ease;
    }
    
    .btn-animated::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
        transition: left 0.5s;
        z-index: 0;
    }
    
    .btn-animated:hover::before {
        left: 100%;
    }
    
    .btn-animated > * {
        position: relative;
        z-index: 1;
    }
    
    .btn-animated:hover {
        transform: translateY(-2px);
    }
    </style>
    <?php
    return ob_get_clean();
}
?>