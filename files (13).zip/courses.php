<?php
/**
 * صفحة عرض جميع الدورات التدريبية
 * منصة ترند التعليمية - Learning Management System
 * المطور: anaso2gen
 * التاريخ: 2025-05-29 08:52:12
 */

define('LEARNING_PLATFORM', true);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/session.php';

$user = $sessionManager->isLoggedIn() ? $sessionManager->getCurrentUser() : null;

// معاملات البحث والفلترة
$search = sanitizeInput($_GET['search'] ?? '');
$category = sanitizeInput($_GET['category'] ?? '');
$level = sanitizeInput($_GET['level'] ?? '');
$sortBy = sanitizeInput($_GET['sort'] ?? 'latest');
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 12;

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    
    // بناء استعلام البحث
    $whereConditions = ['c.is_active = 1'];
    $params = [];
    
    if ($search) {
        $whereConditions[] = '(c.name LIKE ? OR c.description LIKE ? OR c.short_description LIKE ?)';
        $searchTerm = "%$search%";
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }
    
    if ($category) {
        $whereConditions[] = 'c.category = ?';
        $params[] = $category;
    }
    
    if ($level) {
        $whereConditions[] = 'c.level = ?';
        $params[] = $level;
    }
    
    $whereClause = implode(' AND ', $whereConditions);
    
    // تحديد ترتيب النتائج
    $orderBy = match($sortBy) {
        'popular' => 'students_count DESC',
        'price_low' => 'c.price ASC',
        'price_high' => 'c.price DESC',
        'rating' => 'avg_rating DESC',
        'alphabetical' => 'c.name ASC',
        default => 'c.created_at DESC'
    };
    
    // حساب العدد الإجمالي
    $countStmt = $pdo->prepare("
        SELECT COUNT(*) as total 
        FROM courses c 
        WHERE $whereClause
    ");
    $countStmt->execute($params);
    $totalCourses = $countStmt->fetch()['total'];
    $totalPages = ceil($totalCourses / $perPage);
    
    // جلب الدورات
    $offset = ($page - 1) * $perPage;
    $stmt = $pdo->prepare("
        SELECT c.*, 
               (SELECT COUNT(*) FROM subscriptions s WHERE s.course_id = c.id AND s.is_active = 1) as students_count,
               (SELECT COUNT(*) FROM sections sec WHERE sec.course_id = c.id) as sections_count,
               (SELECT COUNT(*) FROM lessons l JOIN sections sec ON l.section_id = sec.id WHERE sec.course_id = c.id) as lessons_count,
               (SELECT AVG(rating) FROM course_reviews cr WHERE cr.course_id = c.id) as avg_rating,
               (SELECT COUNT(*) FROM course_reviews cr WHERE cr.course_id = c.id) as reviews_count
        FROM courses c 
        WHERE $whereClause 
        ORDER BY $orderBy 
        LIMIT ? OFFSET ?
    ");
    
    $params[] = $perPage;
    $params[] = $offset;
    $stmt->execute($params);
    $courses = $stmt->fetchAll();
    
    // جلب الفئات المتاحة
    $categoriesStmt = $pdo->query("
        SELECT DISTINCT category, COUNT(*) as count 
        FROM courses 
        WHERE is_active = 1 AND category IS NOT NULL 
        GROUP BY category 
        ORDER BY count DESC
    ");
    $categories = $categoriesStmt->fetchAll();
    
    // جلب المستويات المتاحة
    $levelsStmt = $pdo->query("
        SELECT DISTINCT level, COUNT(*) as count 
        FROM courses 
        WHERE is_active = 1 AND level IS NOT NULL 
        GROUP BY level 
        ORDER BY 
            CASE level 
                WHEN 'beginner' THEN 1 
                WHEN 'intermediate' THEN 2 
                WHEN 'advanced' THEN 3 
                ELSE 4 
            END
    ");
    $levels = $levelsStmt->fetchAll();
    
    // التحقق من اشتراكات المستخدم
    $userSubscriptions = [];
    if ($user) {
        $subStmt = $pdo->prepare("
            SELECT course_id FROM subscriptions 
            WHERE user_id = ? AND is_active = 1
        ");
        $subStmt->execute([$user['id']]);
        $userSubscriptions = $subStmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
} catch (PDOException $e) {
    logSecurityEvent('Failed to load courses', 'medium', ['error' => $e->getMessage()]);
    $courses = [];
    $categories = [];
    $levels = [];
    $totalCourses = 0;
    $totalPages = 0;
}

// دالة تحويل مستوى الدورة للعربية
function getLevelText($level) {
    return match($level) {
        'beginner' => 'مبتدئ',
        'intermediate' => 'متوسط',
        'advanced' => 'متقدم',
        default => 'غير محدد'
    };
}

// دالة تحويل مستوى الدورة للون
function getLevelColor($level) {
    return match($level) {
        'beginner' => 'success',
        'intermediate' => 'warning',
        'advanced' => 'danger',
        default => 'secondary'
    };
}

// تضمين ملف العرض
require_once __DIR__ . '/frontend/views/pages/courses.php';
?>